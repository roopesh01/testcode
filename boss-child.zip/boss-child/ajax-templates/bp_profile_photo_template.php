<?php
include '../../../../wp-config.php';
 global $wpdb, $bp,$current_user;
if(!is_user_logged_in())
{
   $redirectURL = site_url('login');
   $output = array('login' => 0, 'message' => "You are not IIS member.", "redirect" => $redirectURL);
   echo json_encode($output);
   exit();
}
$user_id = $current_user->ID;
$data = $_POST['image'];

 
list($type, $data) = explode(';', $data);

list(, $data)      = explode(',', $data);


$data = base64_decode($data);

// $imageName = time().'.png';
$upload_dir   = wp_upload_dir();
$image_basedir = $upload_dir['basedir'];
// check avatar folder is exists or not
if (!file_exists($image_basedir.'/avatars')) {
    mkdir($image_basedir.'/avatars', 0775, true);
}
// check user folder is exists or not 
if (!file_exists($image_basedir.'/avatars/'.$user_id)) {
    mkdir($image_basedir.'/avatars/'.$user_id, 0775, true);
}
$userimage = bp_get_activity_avatar(array('user_id' => $user_id,'type' => "full")); // full name
$userimage1 = bp_get_activity_avatar(array('user_id' => $user_id, 'type' => "thumb"));

$pos = strpos($userimage, '/avatars/'.$user_id);
if($pos === false)
{
    $bpthumb = time().'qwr-bpthumb.jpg';
    $bpfull = time().'qwr-bpfull.jpg';
}else
{

    $src = (string) reset(simplexml_import_dom(DOMDocument::loadHTML($userimage))->xpath("//img/@src"));
    $image_url = $src;
    $temp_string = "avatars/".$user_id;
    $explode_url = explode($temp_string, $image_url);
    $bpfull =  $explode_url[1];


    $src1 = (string) reset(simplexml_import_dom(DOMDocument::loadHTML($userimage1))->xpath("//img/@src"));
    $image_url1 = $src1;
    $temp_string1 = "avatars/".$user_id;
    $explode_url1 = explode($temp_string1, $image_url1);
    $bpthumb =  $explode_url1[1];
}


$status1 = file_put_contents($image_basedir.'/avatars/'.$user_id.'/'.$bpfull, $data);
$status = file_put_contents($image_basedir.'/avatars/'.$user_id.'/'.$bpthumb, $data);
if($status1 == true && $status == true)
{ 
    $redirectURL = site_url('my-account/user_profile');
    $output = array('status' => 1, 'message' => "Profile photo successfully uploaded.", "redirect" => $redirectURL);
    echo json_encode($output);
    $blockchain_setting =  get_option('update_profile_img_bc');
    if($blockchain_setting == "enable")
    {
        blockchain_updates();
    }
    exit();
}else
{
   $redirectURL = site_url('my-account/user_profile');
   $output = array('status' => 0, 'message' => "Image uploading Failded.", "redirect" => $redirectURL);
   echo json_encode($output);
   exit();
}
$redirectURL = site_url('my-account/user_profile');
$output = array('status' => 0, 'message' => "Server error.", "redirect" => $redirectURL);
echo json_encode($output);
exit();
 

?>