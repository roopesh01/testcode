<?php


function set_default_meta( $post_ID ) {
	global $post;
	if ( get_post_type() === 'donation_cause' ) :
		update_post_meta( $post_ID, 'donation_status', 'enable' );
	endif;
	return $post_ID;
}
add_action( 'wp_insert_post', 'set_default_meta' );


add_action( 'admin_footer-edit.php', 'rudr_status_into_inline_edit' );

function rudr_status_into_inline_edit() {
	// ultra-simple example
	?>
	<style>
		.overlay:before {content: "";background-position: center center;background-repeat: no-repeat;opacity: 1;background-color: rbga(0,0,0,0) !important;position: fixed;top: calc(50% - 84px);left: calc(50% - 84px);background-size: cover;background: transparent;height: 168px;width: 168px;z-index: 9999 !important;background-image: url(/wp-content/themes/boss-child/images/spin.gif);}
		#TB_window {
	width: 900px !important;
	margin-left: -412px !important;
}
#TB_ajaxContent {
	width: auto !important;
}
	</style>
	<script>
	(function($)
	{
	$(document).ready( function()
	{

		$(document).on('click','.disable_cause a, .enable_cause a', function(e)
		{
		   var post_id = $(this).attr("data-id");
		   var status = $(this).text();
		   var self = this;
		   var confirms = confirm("Are You Sure");
		   if(confirms==true)
		   {
			   //return false;
			   $("html").addClass("overlay");
				$.ajax
				({
					type: 'POST',
					/////////get website url:
					url: '/wp-content/themes/boss-child/ajax-templates/cause_enable_ajax_backend.php',
					data:
					{
						post_id: post_id,
						status: status
					},
					success: function(html)
					{
						//$("html").removeClass("overlay");
						$("html").removeClass("overlay");
						var textstatus = $(self).text();
						if(textstatus=='Disable Cause')
						{
							$(self).text("Enable Cause");
							alert("Donation cause disabled");
						}
						else
						{
							$(self).text("Disable Cause");
							alert("Donation cause enabled");
						}
					},
					error: function(MLHttpRequest, textStatus, errorThrown)
					{
					}
				});
			}
		});
	});
	})(jQuery);
	</script>
	<?php
}


?>
