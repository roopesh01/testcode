<?php
include '../../../../wp-config.php';

global $wpdb;

$curentuserid = get_current_user_id();
$catetable    = $wpdb->prefix . 'user_category';
$table        = $wpdb->prefix . 'user_sub_category';
$metatable    = 'wp68_usermeta';
$subcatid     = vl_sanitize_unslash( 'subcatid' );
$ratingtable  = $wpdb->prefix . 'ratings';
$pricetable   = $wpdb->prefix . 'expert_price';
$prefix       = $wpdb->prefix;
$single       = true;

/********************** Sort By Rating *****************************/
if ( isset( $_POST['sort_by_rating'] ) ) {
	$ratings = $wpdb->get_results( "SELECT * FROM $ratingtable ORDER BY `totalrating` DESC" );

	if ( $ratings ) :
		foreach ( $ratings as $result ) :
			$userid = $result->expertid;

			if ( $userid != $currentuserid ) :
				$firstname     = get_user_meta( $userid, 'first_name', $single );
				$lastname      = get_user_meta( $userid, 'last_name', $single );
				$expertPrice   = $wpdb->get_var( "SELECT `price` FROM $pricetable WHERE `user_id`='$userid'" );
				$AboutYourSelf = bp_get_profile_field_data( 'field=AboutYourSelf&user_id=' . $userid );
				$title         = bp_get_profile_field_data( 'field=Title&user_id=' . $userid );
				$city          = bp_get_profile_field_data( 'field=City&user_id=' . $userid );
				$state         = bp_get_profile_field_data( 'field=State&user_id=' . $userid );
				$salutation    = bp_get_profile_field_data( 'field=salutation&user_id=' . $userid );
				?>
				<tr> <!-- Table Row -->
				   <td> <!-- Table Column -->
					   <div class="expertbycategorytags"> <!-- Expert  Category Main Div -->
						   <div class="row customexpert">  <!-- Expert Category Sub Div -->
							   <div class="col-md-3 col-lg-2 ce-image">
								   <a href="<?php echo site_url(); ?>/user-basic-profile/?ExpertId=<?php echo $userid; ?>"><?php echo get_avatar( $userid, $size ); ?></a>
							   </div>
							   <div class="col-md-6 col-lg-7 ce-content">
								   <h4 class="ce-title"><a href="<?php echo site_url(); ?>/user-basic-profile/?ExpertId=<?php echo $userid; ?>">
																			<?php
																			if ( $salutation ) {
																				echo $salutation . '&nbsp;';
																			}echo $firstname . '&nbsp;' . $lastname;
?>
</a></h4>
									<p class="ce-info"><span><?php echo $city . $state; ?></span></p>
									<p class="ce-details"><?php echo $AboutYourSelf; ?></p>
								</div>
								<div class="col-md-3 col-lg-3 ce-action">
									<div class="ce-pricing">
										<span class="profile-detail profile-stat price">
											<input type="hidden" name="basic_amount"/>
											<?php
											   $expertprices = number_format( (float) $expertPrice, 2, '.', '' );
											?>
											<strong class="actual-price"><?php echo $expertprices; ?></strong>
														   <small>Credits per minute</small>
													   </span>
												   </div>
												   <a href="/request-a-call/?ExpertId=<?php echo $userid; ?>" class="call_link">Request A Call</a>
												   <div class="expRating">
														<?php
														$ratingtable = $wpdb->prefix . '';
														$ratingcount = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$wpdb->vl_ratings} WHERE `expertid`=%d", $userid ) );

														if ( $ratingcount ) {
															$counting    = count( $ratingcount );
															$totalrating = 0;
															$ratings     = 0;
															foreach ( $ratingcount as $ratingcounts ) :
																$totalrating = $ratingcounts->totalrating;
																$ratings    += $totalrating;
															endforeach;
															$averagerating = $ratings / $counting;
															$average       = number_format( $averagerating );
															//echo $average;
															switch ( $average ) {
																case '5':
																	echo '<img src="/wp-content/themes/boss-child/images/rating/five-star.png" title="Awesome - 5 stars"/>';
																	break;
																case '4':
																	echo '<img src="/wp-content/themes/boss-child/images/rating/four-star.png" title="Pretty good - 4 stars"/>';
																	break;
																case '3':
																	echo '<img src="/wp-content/themes/boss-child/images/rating/three-star.png" title="Average - 3 stars"/>';
																	break;
																case '2':
																	echo '<img src="/wp-content/themes/boss-child/images/rating/two-star.png" title="Bad - 2 stars"/>';
																	break;
																case '1':
																	echo '<img src="/wp-content/themes/boss-child/images/rating/one-star.png" title="Very Poor - 1 star"/>';
																	break;
																default:
																	echo '<img src="/wp-content/themes/boss-child/images/rating/no-star.png" title="No Rating"/>';
															}
														} else {
															echo '<small>No Rating For This Expert</small>';
														}
														?>
													</div>
												</div>
											</div> <!-- Expert Category Sub Div -->
										</div> <!-- Expert  Category Main Div -->
									</td> <!-- Table Column -->
								</tr> <!-- Table Row -->
								<?php
							endif;
		endforeach;
					endif;
}
/******************************************** Sort By Rating Start *************************************/

/******************************************** Sort By Pricing Start *************************************/
if ( isset( $_POST['sort_by_price'] ) ) {
	$sortbyprice = vl_sanitize_unslash( 'sort_by_price' );
	$subcatid    = vl_sanitize_unslash( 'subcategoryid' );

	if ( $sortbyprice == 'valuehigh' ) {
		if ( $subcatid == '0' ) {
			$expertprice = $wpdb->get_results( "SELECT * FROM $pricetable ORDER BY `price` DESC" );
			if ( $expertprice ) :
				foreach ( $expertprice as $results ) :
							$userid = $results->user_id;
							//echo $userid;
					if ( $userid != $curentuserid ) :
						$firstname     = get_user_meta( $userid, 'first_name', $single );
						$lastname      = get_user_meta( $userid, 'last_name', $single );
						$expertPrice   = $wpdb->get_var( "SELECT `price` FROM $pricetable WHERE `user_id`='$userid'" );
						$AboutYourSelf = bp_get_profile_field_data( 'field=AboutYourSelf&user_id=' . $userid );
						$title         = bp_get_profile_field_data( 'field=Title&user_id=' . $userid );
						$city          = bp_get_profile_field_data( 'field=City&user_id=' . $userid );
						$state         = bp_get_profile_field_data( 'field=State&user_id=' . $userid );
						$salutation    = bp_get_profile_field_data( 'field=salutation&user_id=' . $userid );
						?>
					   <tr> <!-- Table Row -->
						   <td> <!-- Table Column -->
							   <div class="expertbycategorytags"> <!-- Expert  Category Main Div -->
								   <div class="row customexpert">  <!-- Expert Category Sub Div -->
									   <div class="col-md-3 col-lg-2 ce-image">
										   <a href="<?php echo site_url(); ?>/user-basic-profile/?ExpertId=<?php echo $userid; ?>"><?php echo get_avatar( $userid, $size ); ?></a>
									   </div>
									   <div class="col-md-6 col-lg-7 ce-content">
										   <h4 class="ce-title"><a href="<?php echo site_url(); ?>/user-basic-profile/?ExpertId=<?php echo $userid; ?>">
																					<?php
																					if ( $salutation ) {
																						echo $salutation . '&nbsp;';
																					} echo $firstname . '&nbsp;' . $lastname;
?>
</a></h4>
										   <p class="ce-info"><span><?php echo $city . $state; ?></span></p>
										   <p class="ce-details"><?php echo $AboutYourSelf; ?></p>
									   </div>
									   <div class="col-md-3 col-lg-3 ce-action">
										   <div class="ce-pricing">
										   <span class="profile-detail profile-stat price">
										   <input type="hidden" name="basic_amount"/>
											<?php
											   $expertprices = number_format( (float) $expertPrice, 2, '.', '' );
											?>
										   <strong class="actual-price"><?php echo $expertprices; ?></strong>
													<small>Credits per minute</small>
													<small>per minute</small>
													</span>
													</div>
													<a href="/request-a-call/?ExpertId=<?php echo $userid; ?>" class="call_link">Request A Call</a>
													<div class="expRating">
												<?php
												$ratingcount = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM $wpdb->vl_ratings WHERE `expertid`=%d",  $userid ) );

												if ( $ratingcount ) {
													$counting    = count( $ratingcount );
													$totalrating = 0;
													$ratings     = 0;
													foreach ( $ratingcount as $ratingcounts ) :
														$totalrating = $ratingcounts->totalrating;
														$ratings    += $totalrating;
													endforeach;
													$averagerating = $ratings / $counting;
													$average       = number_format( $averagerating );
													//echo $average;
													switch ( $average ) {
														case '5':
															echo '<img src="/wp-content/themes/boss-child/images/rating/five-star.png" title="Awesome - 5 stars"/>';
															break;
														case '4':
															echo '<img src="/wp-content/themes/boss-child/images/rating/four-star.png" title="Pretty good - 4 stars"/>';
															break;
														case '3':
															echo '<img src="/wp-content/themes/boss-child/images/rating/three-star.png" title="Average - 3 stars"/>';
															break;
														case '2':
															echo '<img src="/wp-content/themes/boss-child/images/rating/two-star.png" title="Bad - 2 stars"/>';
															break;
														case '1':
															echo '<img src="/wp-content/themes/boss-child/images/rating/one-star.png" title="Very Poor - 1 star"/>';
															break;
														default:
															echo '<img src="/wp-content/themes/boss-child/images/rating/no-star.png" title="No Rating"/>';
													}
												} else {
													echo '<small>No Rating For This Expert</small>';
												}
												?>
										   </div>
												</div>
											</div> <!-- Expert Category Sub Div -->
										</div> <!-- Expert  Category Main Div -->
									</td> <!-- Table Column -->
								</tr> <!-- Table Row -->
								<?php
							 endif;
						endforeach;
						endif;
		} else {
			$categoryname = $wpdb->get_var( $wpdb->prepare( "SELECT `sub_category_name` FROM $table WHERE `id`= %d", $subcatid ) );
			$catname      = $wpdb->get_results( $wpdb->prepare( "SELECT DISTINCT mt.* FROM {$wpdb->prefix}wp68_usermeta mt INNER JOIN `$wpdb->vl_expert_price` ep ON mt.user_id = ep.user_id WHERE mt.meta_value LIKE %s ORDER BY ep.price DESC", '%' . $wpdb->esc_like( $categoryname ) . '%' ) );

			if ( $catname ) {

				foreach ( $catname as $result ) :
					$userid = $result->user_id;
					if ( $userid != $curentuserid ) :
						$firstname     = get_user_meta( $userid, 'first_name', $single );
						$lastname      = get_user_meta( $userid, 'last_name', $single );
						$expertPrice   = $wpdb->get_var( "SELECT `price` FROM $pricetable WHERE `user_id`='$userid'" );
						$AboutYourSelf = bp_get_profile_field_data( 'field=AboutYourSelf&user_id=' . $userid );
						$title         = bp_get_profile_field_data( 'field=Title&user_id=' . $userid );
						$city          = bp_get_profile_field_data( 'field=City&user_id=' . $userid );
						$state         = bp_get_profile_field_data( 'field=State&user_id=' . $userid );
						$salutation    = bp_get_profile_field_data( 'field=salutation&user_id=' . $userid );
					?>
				   <div class="row customexpert">
								<div class="col-md-3 col-lg-2 ce-image"><a href="<?php echo site_url(); ?>/user-basic-profile/?ExpertId=<?php echo $userid; ?>"><?php echo get_avatar( $userid, $size ); ?></a></div>
								<div class="col-md-6 col-lg-7 ce-content">
									<h4 class="ce-title"><a href="<?php echo site_url(); ?>/user-basic-profile/?ExpertId=<?php echo $userid; ?>">
																				<?php
																				if ( $salutation ) {
																					echo $salutation . '&nbsp;';
																				} echo $firstname . '&nbsp;' . $lastname;
?>
</a></h4>
									<p class="ce-info"><span><?php echo $city . $state; ?></span></p>
									<p class="ce-details"><?php echo $AboutYourSelf; ?></p>
								</div>
								<div class="col-md-3 col-lg-3 ce-action">
									<div class="ce-pricing">
										<span class="profile-detail profile-stat price">
										<input type="hidden" name="basic_amount"/>
										<?php
											$expertprices = number_format( (float) $expertPrice, 2, '.', '' );
										?>
										<strong class="actual-price"><?php echo $expertprices; ?></strong>
												<small>Credits per minute</small>
												<?php echo $userid; ?>
												</span>
											</div>
											 <a href="/request-a-call/?ExpertId=<?php echo $userid; ?>" class="call_link">Request A Call</a>
										<div>
											<?php
											$ratingtable = $wpdb->prefix . '';
											$ratingcount = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM $wpdb->vl_ratings WHERE `expertid`= %d", $userid ) );
											if ( $ratingcount ) {
												$counting    = count( $ratingcount );
												$totalrating = 0;
												$ratings     = 0;
												foreach ( $ratingcount as $ratingcounts ) :
													$totalrating = $ratingcounts->totalrating;
													$ratings    += $totalrating;
												endforeach;
												$averagerating = $ratings / $counting;
												$average       = number_format( $averagerating );
												switch ( $average ) {
													case '5':
														echo '<img src="/wp-content/themes/boss-child/images/rating/five-star.png" title="Awesome - 5 stars"/>';
														break;
													case '4':
														echo '<img src="/wp-content/themes/boss-child/images/rating/four-star.png" title="Pretty good - 4 stars"/>';
														break;
													case '3':
														echo '<img src="/wp-content/themes/boss-child/images/rating/three-star.png" title="Average - 3 stars"/>';
														break;
													case '2':
														echo '<img src="/wp-content/themes/boss-child/images/rating/two-star.png" title="Bad - 2 stars"/>';
														break;
													case '1':
														echo '<img src="/wp-content/themes/boss-child/images/rating/one-star.png" title="Very Poor - 1 star"/>';
														break;
													default:
														echo '<img src="/wp-content/themes/boss-child/images/rating/no-star.png" title="No Rating"/>';
												}
											}
											?>
										 </div>
										</div>
								</div>
							<?php
							endif;
					endforeach;
			}
		}
	} else {

		if ( $subcatid == '0' ) {
			$expertprice = $wpdb->get_results( "SELECT * FROM $pricetable ORDER BY `price` ASC" );
			if ( $expertprice ) :
				foreach ( $expertprice as $results ) :
					$userid = $results->user_id;
					//echo $userid;
					if ( $userid != $curentuserid ) :
						$firstname     = get_user_meta( $userid, 'first_name', $single );
						$lastname      = get_user_meta( $userid, 'last_name', $single );
						$expertPrice   = $wpdb->get_var( $wpdb->prepare( "SELECT `price` FROM $pricetable WHERE `user_id`= %d", $userid ) );
						$AboutYourSelf = bp_get_profile_field_data( 'field=AboutYourSelf&user_id=' . $userid );
						$title         = bp_get_profile_field_data( 'field=Title&user_id=' . $userid );
						$city          = bp_get_profile_field_data( 'field=City&user_id=' . $userid );
						$state         = bp_get_profile_field_data( 'field=State&user_id=' . $userid );
						$salutation    = bp_get_profile_field_data( 'field=salutation&user_id=' . $userid );
						?>
						<tr><!-- Table Row -->
						<td> <!-- Table Column -->
						   <div class="expertbycategorytags"> <!-- Expert  Category Main Div -->
							   <div class="row customexpert">  <!-- Expert Category Sub Div -->
								   <div class="col-md-3 col-lg-2 ce-image">
									   <a href="<?php echo site_url(); ?>/user-basic-profile/?ExpertId=<?php echo $userid; ?>"><?php echo get_avatar( $userid, $size ); ?></a>
								   </div>
								   <div class="col-md-6 col-lg-7 ce-content">
									   <h4 class="ce-title"><a href="<?php echo site_url(); ?>/user-basic-profile/?ExpertId=<?php echo $userid; ?>">
																				<?php
																				if ( $salutation ) {
																					echo $salutation . '&nbsp;';
																				} echo $firstname . '&nbsp;' . $lastname;
	?>
	</a></h4>
									   <p class="ce-info"><span><?php echo $city . $state; ?></span></p>
									   <p class="ce-details"><?php echo $AboutYourSelf; ?></p>
										   </div>
										   <div class="col-md-3 col-lg-3 ce-action">
									   <div class="ce-pricing">
										   <span class="profile-detail profile-stat price">
										   <input type="hidden" name="basic_amount"/>
											<?php
											   $expertprices = number_format( (float) $expertPrice, 2, '.', '' );
											?>
											<strong class="actual-price"><?php echo $expertprices; ?></strong>
											   <small>Credits per minute</small>
											   </span>
												   </div>
												   <a href="/request-a-call/?ExpertId=<?php echo $userid; ?>" class="call_link">Request A Call</a>
												   <div class="expRating">
												<?php
												$ratingtable = $wpdb->prefix . 'ratings';
												$ratingcount = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM $ratingtable WHERE `expertid`= %d", $userid ) );

												if ( $ratingcount ) {
													$counting    = count( $ratingcount );
													$totalrating = 0;
													$ratings     = 0;
													foreach ( $ratingcount as $ratingcounts ) :
														$totalrating = $ratingcounts->totalrating;
														$ratings    += $totalrating;
													endforeach;
													$averagerating = $ratings / $counting;
													$average       = number_format( $averagerating );
													//echo $average;
													switch ( $average ) {
														case '5':
															echo '<img src="/wp-content/themes/boss-child/images/rating/five-star.png" title="Awesome - 5 stars"/>';
															break;
														case '4':
															echo '<img src="/wp-content/themes/boss-child/images/rating/four-star.png" title="Pretty good - 4 stars"/>';
															break;
														case '3':
															echo '<img src="/wp-content/themes/boss-child/images/rating/three-star.png" title="Average - 3 stars"/>';
															break;
														case '2':
															echo '<img src="/wp-content/themes/boss-child/images/rating/two-star.png" title="Bad - 2 stars"/>';
															break;
														case '1':
															echo '<img src="/wp-content/themes/boss-child/images/rating/one-star.png" title="Very Poor - 1 star"/>';
															break;
														default:
															echo '<img src="/wp-content/themes/boss-child/images/rating/no-star.png" title="No Rating"/>';
													}
												} else {
													echo '<small>No Rating For This Expert</small>';
												}
													?>
												</div>
													</div>
												</div> <!-- Expert Category Sub Div -->
											</div> <!-- Expert  Category Main Div -->
										</td> <!-- Table Column -->
									</tr> <!-- Table Row -->
									<?php
								endif;
				endforeach;
					endif;
		} else {
			$categoryname = $wpdb->get_var( $wpdb->prepare( "SELECT `sub_category_name` FROM $table WHERE `id`= %d", $subcatid ) );

			$catname      = $wpdb->get_results( "SELECT DISTINCT `$metatable`.* FROM $metatable INNER JOIN `$pricetable` ON $metatable.user_id =$pricetable.user_id WHERE $metatable.meta_value LIKE '%$categoryname%' ORDER BY $pricetable.price ASC" );

			if ( $catname ) :
				foreach ( $catname as $results ) :
					$userid = $results->user_id;
					//echo $userid;
					if ( $userid != $curentuserid ) :
						$firstname     = get_user_meta( $userid, 'first_name', $single );
						$lastname      = get_user_meta( $userid, 'last_name', $single );
						$expertPrice   = $wpdb->get_var( "SELECT `price` FROM $pricetable WHERE `user_id`='$userid'" );
						$AboutYourSelf = bp_get_profile_field_data( 'field=AboutYourSelf&user_id=' . $userid );
						$title         = bp_get_profile_field_data( 'field=Title&user_id=' . $userid );
						$city          = bp_get_profile_field_data( 'field=City&user_id=' . $userid );
						$state         = bp_get_profile_field_data( 'field=State&user_id=' . $userid );
						$salutation    = bp_get_profile_field_data( 'field=salutation&user_id=' . $userid );
						?>
						<tr><!-- Table Row -->
						   <td> <!-- Table Column -->
							   <div class="expertbycategorytags"> <!-- Expert  Category Main Div -->
								   <div class="row customexpert">  <!-- Expert Category Sub Div -->
									   <div class="col-md-3 col-lg-2 ce-image">
										   <a href="<?php echo site_url(); ?>/user-basic-profile/?ExpertId=<?php echo $userid; ?>"><?php echo get_avatar( $userid, $size ); ?></a>
									   </div>
									   <div class="col-md-6 col-lg-7 ce-content">
										   <h4 class="ce-title"><a href="<?php echo site_url(); ?>/user-basic-profile/?ExpertId=<?php echo $userid; ?>">
																						<?php
																						if ( $salutation ) {
																							echo $salutation . '&nbsp;';
																						} echo $firstname . '&nbsp;' . $lastname;
?>
</a></h4>
										   <p class="ce-info"><span><?php echo $city . $state; ?></span></p>
										   <p class="ce-details"><?php echo $AboutYourSelf; ?></p>
										   </div>
										   <div class="col-md-3 col-lg-3 ce-action">
										   <div class="ce-pricing">
											   <span class="profile-detail profile-stat price">
											   <input type="hidden" name="basic_amount"/>
												<?php
												   $expertprices = number_format( (float) $expertPrice, 2, '.', '' );
												?>
												<strong class="actual-price"><?php echo $expertprices; ?></strong>
												   <small>Credits per minute</small>
												   </span>
												   </div>
												   <a href="/request-a-call/?ExpertId=<?php echo $userid; ?>" class="call_link">Request A Call</a>
												   <div class="expRating">
													<?php
													$ratingtable = $wpdb->prefix . 'ratings';
													$ratingcount = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM $ratingtable WHERE `expertid`= %d", $userid ) );

													if ( $ratingcount ) {
														$counting    = count( $ratingcount );
														$totalrating = 0;
														$ratings     = 0;
														foreach ( $ratingcount as $ratingcounts ) :
															$totalrating = $ratingcounts->totalrating;
															$ratings    += $totalrating;
															endforeach;
														$averagerating = $ratings / $counting;
														$average       = number_format( $averagerating );
														//echo $average;
														switch ( $average ) {
															case '5':
																echo '<img src="/wp-content/themes/boss-child/images/rating/five-star.png" title="Awesome - 5 stars"/>';
																break;
															case '4':
																echo '<img src="/wp-content/themes/boss-child/images/rating/four-star.png" title="Pretty good - 4 stars"/>';
																break;
															case '3':
																echo '<img src="/wp-content/themes/boss-child/images/rating/three-star.png" title="Average - 3 stars"/>';
																break;
															case '2':
																echo '<img src="/wp-content/themes/boss-child/images/rating/two-star.png" title="Bad - 2 stars"/>';
																break;
															case '1':
																echo '<img src="/wp-content/themes/boss-child/images/rating/one-star.png" title="Very Poor - 1 star"/>';
																break;
															default:
																echo '<img src="/wp-content/themes/boss-child/images/rating/no-star.png" title="No Rating"/>';
														}
													} else {
														echo '<small>No Rating For This Expert</small>';
													}
													?>
													</div>
												</div>
											</div> <!-- Expert Category Sub Div -->
										</div> <!-- Expert  Category Main Div -->
									</td> <!-- Table Column -->
								</tr> <!-- Table Row -->
								<?php
							endif;
							endforeach;
					endif;
		}
	}
}
/******************************************** Sort By Pricing End *************************************/

/******************************************** Sort By SubCategory *************************************/
if ( isset( $_POST['subcatid'] ) ) {

		$catid       = $wpdb->get_var( $wpdb->prepare( "SELECT `category_id` FROM $table WHERE `id`= %d", $subcatid ) );
		$catname     = $wpdb->get_var( $wpdb->prepare( "SELECT `category_name` FROM $catetable WHERE `id`= %d", $catid ) );
		$imgurl      = $wpdb->get_var( $wpdb->prepare( "SELECT `img_url` FROM $catetable WHERE `id`= %d", $catid ) );
		$subcategory = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM $table WHERE `category_id`= %d", $catid ) );
		$categorykey = $wpdb->get_var( $wpdb->prepare( "SELECT `category_key` FROM $catetable WHERE `id`= %d", $catid ) );
		//echo $categorykey;
		$categorykeys = $prefix . $categorykey;
		//die();
	if ( $imgurl ) {
		echo $imgurl;
	} else {
		$url = '/wp-content/themes/boss-child/images/category_images/default_cat.jpg';
		echo $url;
	}
		?>

	   <hr/>
			<div class="categorywithsub">
			<h2 class="CategoryHead"><?php echo $catname; ?></h2>
			<div class="subcategory">
					<div class="BrowseCategory categorytags">
						<ul class="categorylist tagcategorylist">
							<?php
							if ( $subcategory ) :
								foreach ( $subcategory as $result ) :
									echo '<li><a href="javascript:void(0);" data-id="' . $result->id . '" class="browse_cats">' . $result->sub_category_name . '</a></li>';
								endforeach;
							endif;
							?>

						</ul>
					</div>
			  </div>
			  </div>
			<div class="tagsection">
				<h2 class="Tagss">Tags</h2>
				<div class="alltags">
					<ul class="taglist">
						<?php
						$tags = $wpdb->get_results( "SELECT * FROM {$wpdb->vl_user_tags} WHERE `sub_category_id`='$subcatid'" );
						if ( $tags ) :
							foreach ( $tags as $result ) :
								echo '<li><a href="javascript:void(0);" data-id="' . $result->id . '" class="browse_tags">' . $result->tag_name . '</a></li>';
						endforeach;
						endif;
						?>

					</ul>
				</div>
			</div>
			<hr/>
		<?php
		/* Category Name Through Sub Category*/
		$subcategoryname = $wpdb->get_var( "SELECT `sub_category_name` FROM $table WHERE `id`=$subcatid" );
		$catname         = $wpdb->get_results( "SELECT * FROM $metatable WHERE `meta_value` LIKE '%$subcategoryname%' AND `meta_key`='$categorykeys'" );
		if ( $catname ) {
			echo '<input type="hidden" value="' . $subcatid . '" id="subcatid">';
			foreach ( $catname as $result ) :
				$userid = $result->user_id;
				if ( $userid != $curentuserid ) :
					$firstname     = get_user_meta( $userid, 'first_name', $single );
					$lastname      = get_user_meta( $userid, 'last_name', $single );
					$AboutYourSelf = bp_get_profile_field_data( 'field=AboutYourSelf&user_id=' . $userid );
					$expertPrice   = $wpdb->get_var( "SELECT `price` FROM $pricetable WHERE `user_id`='$userid'" );
					$title         = bp_get_profile_field_data( 'field=Title&user_id=' . $userid );
					$city          = bp_get_profile_field_data( 'field=City&user_id=' . $userid );
					$state         = bp_get_profile_field_data( 'field=State&user_id=' . $userid );
					$salutation    = bp_get_profile_field_data( 'field=salutation&user_id=' . $userid );
				?>
			   <tr>
				   <td>
				   <div class="row customexpert">
								<div class="col-md-3 col-lg-2 ce-image"><a href="<?php echo site_url(); ?>/user-basic-profile/?ExpertId=<?php echo $userid; ?>"><?php echo get_avatar( $userid, $size ); ?></a>
								</div>
								<div class="col-md-6 col-lg-7 ce-content">
									<h4 class="ce-title"><a href="<?php echo site_url(); ?>/user-basic-profile/?ExpertId=<?php echo $userid; ?>">
																				<?php
																				if ( $salutation ) {
																					echo $salutation . '&nbsp;';
																				} echo $firstname . '&nbsp;' . $lastname;
?>
</a></h4>
									<p class="ce-info"><span><?php echo $city . $state; ?></span></p>
									<p class="ce-details"><?php echo $AboutYourSelf; ?></p>
								</div>
								<div class="col-md-3 col-lg-3 ce-action">
									<div class="ce-pricing">
										<span class="profile-detail profile-stat price">
										<input type="hidden" name="basic_amount"/>
										<?php
											$expertprices = number_format( (float) $expertPrice, 2, '.', '' );
										?>
										<strong class="actual-price"><?php echo $expertprices; ?></strong>
												<small>Credits per minute</small>
												</span>
											</div>
										 <a href="/request-a-call/?ExpertId=<?php echo $userid; ?>" class="call_link">Request A Call</a>
										<div>
										<?php
										$ratingtable = $wpdb->prefix . 'ratings';
										$ratingcount = $wpdb->get_results( "SELECT * FROM $ratingtable WHERE `expertid`='$userid'" );
										/*echo '<pre>';
										print_r($ratingcount);
										echo '</pre>';*/
										if ( $ratingcount ) {
											$counting    = count( $ratingcount );
											$totalrating = 0;
											$ratings     = 0;
											foreach ( $ratingcount as $ratingcounts ) :
												$totalrating = $ratingcounts->totalrating;
												$ratings    += $totalrating;
											endforeach;
											$averagerating = $ratings / $counting;
											$average       = number_format( $averagerating );
											//echo $average;
											switch ( $average ) {
												case '5':
													echo '<img src="/wp-content/themes/boss-child/images/rating/five-star.png" title="Awesome - 5 stars"/>';
													break;
												case '4':
													echo '<img src="/wp-content/themes/boss-child/images/rating/four-star.png" title="Pretty good - 4 stars"/>';
													break;
												case '3':
													echo '<img src="/wp-content/themes/boss-child/images/rating/three-star.png" title="Average - 3 stars"/>';
													break;
												case '2':
													echo '<img src="/wp-content/themes/boss-child/images/rating/two-star.png" title="Bad - 2 stars"/>';
													break;
												case '1':
													echo '<img src="/wp-content/themes/boss-child/images/rating/one-star.png" title="Very Poor - 1 star"/>';
													break;
												default:
													echo '<img src="/wp-content/themes/boss-child/images/rating/no-star.png" title="No Rating"/>';
											}
										}
										?>
									 </div>
										</div>
								</div>
								</td>
								</tr>
						<?php
						endif;
			endforeach;
		} else {
			echo '<tr>
                    <td>
                    <h4 class="backtosearch">No Result Found</h4>
                    </td>
                    </tr>';

		}
}
/******************************************** Sort By SubCategory *************************************/

/******************************************** Sort By Alpha Descending *************************************/
if ( isset( $_POST['alpha_desc'] ) ) {

					$single    = true;
					$args      = array(
						'role'    => 'experts',
						'orderby' => 'user_nicename',
						'order'   => 'DESC',
					);
					$allexpert = get_users( $args );
	if ( $allexpert ) :
		foreach ( $allexpert as $result ) :
			$userid = $result->ID;
			//echo $userid;
			if ( $userid != $curentuserid ) :
				$firstname     = get_user_meta( $userid, 'first_name', $single );
				$lastname      = get_user_meta( $userid, 'last_name', $single );
				$expertPrice   = $wpdb->get_var( "SELECT `price` FROM $pricetable WHERE `user_id`='$userid'" );
				$AboutYourSelf = bp_get_profile_field_data( 'field=AboutYourSelf&user_id=' . $userid );
				$title         = bp_get_profile_field_data( 'field=Title&user_id=' . $userid );
				$city          = bp_get_profile_field_data( 'field=City&user_id=' . $userid );
				$state         = bp_get_profile_field_data( 'field=State&user_id=' . $userid );
				$salutation    = bp_get_profile_field_data( 'field=salutation&user_id=' . $userid );
				?>
				<tr> <!-- Table Row -->
				   <td> <!-- Table Column -->
					   <div class="expertbycategorytags"> <!-- Expert  Category Main Div -->
						   <div class="row customexpert">  <!-- Expert Category Sub Div -->
							   <div class="col-md-3 col-lg-2 ce-image">
								   <a href="<?php echo site_url(); ?>/user-basic-profile/?ExpertId=<?php echo $userid; ?>"><?php echo get_avatar( $userid, $size ); ?></a>
							   </div>
							   <div class="col-md-6 col-lg-7 ce-content">
								   <h4 class="ce-title"><a href="<?php echo site_url(); ?>/user-basic-profile/?ExpertId=<?php echo $userid; ?>">
																			<?php
																			if ( $salutation ) {
																				echo $salutation . '&nbsp;';
																			} echo $firstname . '&nbsp;' . $lastname;
?>
</a></h4>
									<p class="ce-info"><span><?php echo $city . $state; ?></span></p>
									<p class="ce-details"><?php echo $AboutYourSelf; ?></p>
								</div>
								<div class="col-md-3 col-lg-3 ce-action">
									<div class="ce-pricing">
										<span class="profile-detail profile-stat price">
										<input type="hidden" name="basic_amount"/>
										<?php
										   $expertprices = number_format( (float) $expertPrice, 2, '.', '' );
										?>
										<strong class="actual-price"><?php echo $expertprices; ?></strong>
													   <small>Credits per minute</small>
													   </span>
												   </div>
												   <a href="/request-a-call/?ExpertId=<?php echo $userid; ?>" class="call_link">Request A Call</a>
												   <div class="expRating">
														<?php
														$ratingtable = $wpdb->prefix . 'ratings';
														$ratingcount = $wpdb->get_results( "SELECT * FROM $ratingtable WHERE `expertid`='$userid'" );
														/*echo '<pre>';
														print_r($ratingcount);
														echo '</pre>';*/
														if ( $ratingcount ) {
															$counting    = count( $ratingcount );
															$totalrating = 0;
															$ratings     = 0;
															foreach ( $ratingcount as $ratingcounts ) :
																$totalrating = $ratingcounts->totalrating;
																$ratings    += $totalrating;
															endforeach;
															$averagerating = $ratings / $counting;
															$average       = number_format( $averagerating );
															//echo $average;
															switch ( $average ) {
																case '5':
																	echo '<img src="/wp-content/themes/boss-child/images/rating/five-star.png" title="Awesome - 5 stars"/>';
																	break;
																case '4':
																	echo '<img src="/wp-content/themes/boss-child/images/rating/four-star.png" title="Pretty good - 4 stars"/>';
																	break;
																case '3':
																	echo '<img src="/wp-content/themes/boss-child/images/rating/three-star.png" title="Average - 3 stars"/>';
																	break;
																case '2':
																	echo '<img src="/wp-content/themes/boss-child/images/rating/two-star.png" title="Bad - 2 stars"/>';
																	break;
																case '1':
																	echo '<img src="/wp-content/themes/boss-child/images/rating/one-star.png" title="Very Poor - 1 star"/>';
																	break;
																default:
																	echo '<img src="/wp-content/themes/boss-child/images/rating/no-star.png" title="No Rating"/>';
															}
														} else {
															echo '<small>No Rating For This Expert</small>';
														}
														?>
													</div>
												</div>
											</div> <!-- Expert Category Sub Div -->
										</div> <!-- Expert  Category Main Div -->
									</td> <!-- Table Column -->
								</tr> <!-- Table Row -->
								<?php
							endif;
		endforeach;
					endif;

}
/******************************************** Sort By Alpha Descending *************************************/

/******************************************** Sort By Alpha Ascending *************************************/
if ( isset( $_POST['alpha_asc'] ) ) {

					$single    = true;
					$args      = array(
						'role'    => 'experts',
						'orderby' => 'user_nicename',
						'order'   => 'ASC',
					);
					$allexpert = get_users( $args );
	if ( $allexpert ) :
		foreach ( $allexpert as $result ) :
			$userid = $result->ID;
			//echo $userid;
			if ( $userid != $curentuserid ) :
				$firstname     = get_user_meta( $userid, 'first_name', $single );
				$lastname      = get_user_meta( $userid, 'last_name', $single );
				$expertPrice   = $wpdb->get_var( "SELECT `price` FROM $pricetable WHERE `user_id`='$userid'" );
				$AboutYourSelf = bp_get_profile_field_data( 'field=AboutYourSelf&user_id=' . $userid );
				$title         = bp_get_profile_field_data( 'field=Title&user_id=' . $userid );
				$city          = bp_get_profile_field_data( 'field=City&user_id=' . $userid );
				$state         = bp_get_profile_field_data( 'field=State&user_id=' . $userid );
				$salutation    = bp_get_profile_field_data( 'field=salutation&user_id=' . $userid );
				?>
				<tr> <!-- Table Row -->
				   <td> <!-- Table Column -->
					   <div class="expertbycategorytags"> <!-- Expert  Category Main Div -->
						   <div class="row customexpert">  <!-- Expert Category Sub Div -->
							   <div class="col-md-3 col-lg-2 ce-image">
								   <a href="<?php echo site_url(); ?>/user-basic-profile/?ExpertId=<?php echo $userid; ?>"><?php echo get_avatar( $userid, $size ); ?></a>
							   </div>
							   <div class="col-md-6 col-lg-7 ce-content">
								   <h4 class="ce-title"><a href="<?php echo site_url(); ?>/user-basic-profile/?ExpertId=<?php echo $userid; ?>">
																			<?php
																			if ( $salutation ) {
																				echo $salutation . '&nbsp;';
																			} echo $firstname . '&nbsp;' . $lastname;
?>
</a></h4>
									<p class="ce-info"><span><?php echo $city . $state; ?></span></p>
									<p class="ce-details"><?php echo $AboutYourSelf; ?></p>
								</div>
								<div class="col-md-3 col-lg-3 ce-action">
									<div class="ce-pricing">
										<span class="profile-detail profile-stat price">
										<input type="hidden" name="basic_amount"/>
											<?php
											$expertprices = number_format( (float) $expertPrice, 2, '.', '' );
											?>
										<strong class="actual-price"><?php echo $expertprices; ?></strong>
													   <small>Credits per minute</small>
													   </span>
												   </div>
												   <a href="/request-a-call/?ExpertId=<?php echo $userid; ?>" class="call_link">Request A Call</a>
												   <div class="expRating">
														<?php
														$ratingtable = $wpdb->prefix . 'ratings';
														$ratingcount = $wpdb->get_results( "SELECT * FROM $ratingtable WHERE `expertid`='$userid'" );
														/*echo '<pre>';
														print_r($ratingcount);
														echo '</pre>';*/
														if ( $ratingcount ) {
															$counting    = count( $ratingcount );
															$totalrating = 0;
															$ratings     = 0;
															foreach ( $ratingcount as $ratingcounts ) :
																$totalrating = $ratingcounts->totalrating;
																$ratings    += $totalrating;
															endforeach;
															$averagerating = $ratings / $counting;
															$average       = number_format( $averagerating );
															//echo $average;
															switch ( $average ) {
																case '5':
																	echo '<img src="/wp-content/themes/boss-child/images/rating/five-star.png" title="Awesome - 5 stars"/>';
																	break;
																case '4':
																	echo '<img src="/wp-content/themes/boss-child/images/rating/four-star.png" title="Pretty good - 4 stars"/>';
																	break;
																case '3':
																	echo '<img src="/wp-content/themes/boss-child/images/rating/three-star.png" title="Average - 3 stars"/>';
																	break;
																case '2':
																	echo '<img src="/wp-content/themes/boss-child/images/rating/two-star.png" title="Bad - 2 stars"/>';
																	break;
																case '1':
																	echo '<img src="/wp-content/themes/boss-child/images/rating/one-star.png" title="Very Poor - 1 star"/>';
																	break;
																default:
																	echo '<img src="/wp-content/themes/boss-child/images/rating/no-star.png" title="No Rating"/>';
															}
														} else {
															echo '<small>No Rating For This Expert</small>';
														}
														?>
													</div>
												</div>
											</div> <!-- Expert Category Sub Div -->
										</div> <!-- Expert  Category Main Div -->
									</td> <!-- Table Column -->
								</tr> <!-- Table Row -->
								<?php
							endif;
		endforeach;
					endif;
}
/******************************************** Sort By Alpha Ascending *************************************/

/******************************************** Sort By Category*********************************************/
if ( isset( $_POST['categorykey'] ) ) {
						$categorykey = $_POST['categorykey'];
						$experts     = $wpdb->get_results( "SELECT * FROM $metatable WHERE `meta_key`='$categorykey' AND `meta_value` !=''" );
					   /* echo '<pre>';
						print_r($experts);
						echo '</pre>';
						die();*/
	if ( $experts ) :
		foreach ( $experts as $result ) :
			$userid = $result->user_id;
			if ( $userid != $curentuserid ) :
				$firstname     = get_user_meta( $userid, 'first_name', $single );
				$lastname      = get_user_meta( $userid, 'last_name', $single );
				$expertPrice   = $wpdb->get_var( "SELECT `price` FROM $pricetable WHERE `user_id`='$userid'" );
				$AboutYourSelf = bp_get_profile_field_data( 'field=AboutYourSelf&user_id=' . $userid );
				$title         = bp_get_profile_field_data( 'field=Title&user_id=' . $userid );
				$city          = bp_get_profile_field_data( 'field=City&user_id=' . $userid );
				$state         = bp_get_profile_field_data( 'field=State&user_id=' . $userid );
				$salutation    = bp_get_profile_field_data( 'field=salutation&user_id=' . $userid );
				?>
				<tr> <!-- Table Row -->
				<td> <!-- Table Column -->
				<div class="expertbycategorytags"> <!-- Expert  Category Main Div -->
					<div class="row customexpert">  <!-- Expert Category Sub Div -->
						<div class="col-md-3 col-lg-2 ce-image">
							<a href="<?php echo site_url(); ?>/user-basic-profile/?ExpertId=<?php echo $userid; ?>"><?php echo get_avatar( $userid, $size ); ?></a>
						</div>
						<div class="col-md-6 col-lg-7 ce-content">
							<h4 class="ce-title"><a href="<?php echo site_url(); ?>/user-basic-profile/?ExpertId=<?php echo $userid; ?>">
																		<?php
																		if ( $salutation ) {
																			echo $salutation . '&nbsp;';
																		} echo $firstname . '&nbsp;' . $lastname;
	?>
	</a></h4>
									<p class="ce-info"><span><?php echo $city . $state; ?></span></p>
									<p class="ce-details"><?php echo $AboutYourSelf; ?></p>
								</div>
								<div class="col-md-3 col-lg-3 ce-action">
									<div class="ce-pricing">
										<span class="profile-detail profile-stat price">
										<input type="hidden" name="basic_amount"/>
										<?php
										$expertprices = number_format( (float) $expertPrice, 2, '.', '' );
										?>
										<strong class="actual-price"><?php echo $expertprices; ?></strong>
													<small>Credits per minute</small>
													</span>
												</div>
												<a href="/request-a-call/?ExpertId=<?php echo $userid; ?>" class="call_link">Request A Call</a>
												<div class="expRating">
													<?php
													$ratingtable = $wpdb->prefix . 'ratings';
													$ratingcount = $wpdb->get_results( "SELECT * FROM $ratingtable WHERE `expertid`='$userid'" );
													/*echo '<pre>';
													print_r($ratingcount);
													echo '</pre>';*/
													if ( $ratingcount ) {
														$counting    = count( $ratingcount );
														$totalrating = 0;
														$ratings     = 0;
														foreach ( $ratingcount as $ratingcounts ) :
															$totalrating = $ratingcounts->totalrating;
															$ratings    += $totalrating;
														endforeach;
														$averagerating = $ratings / $counting;
														$average       = number_format( $averagerating );
														//echo $average;
														switch ( $average ) {
															case '5':
																echo '<img src="/wp-content/themes/boss-child/images/rating/five-star.png" title="Awesome - 5 stars"/>';
																break;
															case '4':
																echo '<img src="/wp-content/themes/boss-child/images/rating/four-star.png" title="Pretty good - 4 stars"/>';
																break;
															case '3':
																echo '<img src="/wp-content/themes/boss-child/images/rating/three-star.png" title="Average - 3 stars"/>';
																break;
															case '2':
																echo '<img src="/wp-content/themes/boss-child/images/rating/two-star.png" title="Bad - 2 stars"/>';
																break;
															case '1':
																echo '<img src="/wp-content/themes/boss-child/images/rating/one-star.png" title="Very Poor - 1 star"/>';
																break;
															default:
																echo '<img src="/wp-content/themes/boss-child/images/rating/no-star.png" title="No Rating"/>';
														}
													} else {
														echo '<small>No Rating For This Expert</small>';
													}
													?>
													</div>
													</div>
												</div> <!-- Expert Category Sub Div -->
											</div> <!-- Expert  Category Main Div -->
										</td> <!-- Table Column -->
									</tr> <!-- Table Row -->
									<?php
							endif;
endforeach;
				endif;
}
/******************************************** Sort By Category*************************************/



?>
