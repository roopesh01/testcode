(function ($) {
  "use strict";
  $(document).ready(function () {
    var self;
    function pageScript(ids) {
      self = this;
      self.ids = {};
      self.ids = $.extend(self.ids, ids);
      self.svg = $(self.ids.graphSvg);
      self.currentDataType = undefined;
      self.filters = {
        source: { name: "Source", value: "", active: true },
        target: { name: "Target", value: "", active: true }
      };

      /*
      color: { name: "Node Color", value: "", active: true },
        opacity: { name: "Node Opacity", value: "", active: true },
        strock: { name: "Node Strock", value: "", active: true },
        "node-size": { name: "Node size", value: "", active: true },
        "node-Text": { name: "Node Text", value: "", active: true },
        "link-width": { name: "Link width", value: "", active: true }
      */

      self.filterData = [];
      self.rawData = [];
      self.stateData = {
        ids: [],
        title: "",
        content: "",
        footer: ""
      };
      self.stepShort = {
        startIndex: 0,
        endIndex: 0
      };
      self.storyData = {
        title: "",
        steps: []
      };
      self.options = {
        enableDblcZoom: false,
        enableNodeText: true,
        enableLinkArrow: false,
        nodes: [],
        links: [],
        nodeRadius: 5
      };
      self.path = graphVariables.siteUrl ? graphVariables.siteUrl : "";
      self.init();
    }
    $.extend(pageScript.prototype, {
      init: function () {
        self.fetchData();
        self.registerListener();
      },
      fetchData: function () {
        $.ajax({
          url: self.path + "/wp-content/themes/boss-child/service/storyService.php",
          method: "post",
          dataType: "json",
          data: {
            method: 'query'
          },
          error: function (xhr, textStatus) {
            console.log(xhr, "error");
          },
          success: function (data, textStatus) {
            var storyList = "";
            if (data.success) {
              for (var i = 0; i < data.stories.length; i++) {
                storyList += "<li><a target='_blank' href='" + self.path + "/story/?id=" + data.stories[i].id + "' class='vl-story-title'>" + data.stories[i].title + "</a><span class='vl-story-del-icon' data-id='" + data.stories[i].id + "'></span><span class='vl-story-edit-icon' data-id='" + data.stories[i].id + "'></span></li>";
              }
              $(self.ids.storyList).html(storyList);
            } else {
              console.log(data, textStatus);
            }
          }
        });
      },
      uploadData: function () { },
      registerListener: function () {
        $(self.ids.storyList).on("click", ".vl-story-edit-icon", function (event) {
          var id = $(this).attr("data-id");
          var elem = this;
          $.ajax({
            url: self.path + "/wp-content/themes/boss-child/service/storyService.php",
            method: "post",
            dataType: "json",
            data: {
              method: 'get',
              id: id
            },
            error: function (xhr, textStatus) {
              console.log(xhr, "error");
            },
            success: function (data, textStatus) {
              if (data.success) {
                console.log(data);
                self.options = $.extend({}, data.graph);
                self.storyData = {
                  title: data.storyTitle,
                  steps: data.story || []
                };
                self.options['storyHolder']={
                  steps:data.story || []
                };
                self.buildStoryStep();
                $(self.ids.storyTitle).val(data.storyTitle);
                $(".vl-accordion").accordion("option", "active", 1);
                $('.vl-story-graph').buildNetwork(self.options);
              } else {
                console.log(data, textStatus);
              }
            }
          });
        });

        $(self.ids.saveStory).click(function (event) {
          self.storyData.title = $(self.ids.storyTitle).val();
          $.ajax({
            url: self.path + "/wp-content/themes/boss-child/service/storyService.php",
            method: "post",
            dataType: "json",
            data: {
              method: 'put',
              graph: self.options,
              story: self.storyData
            },
            error: function (xhr, textStatus) {
              console.log(xhr, "error");
            },
            success: function (data, textStatus) {
              if (data.success) {
                self.toast("Story saved successfully.", "success");
                var story = "<li><a target='_blank' href='" + self.path + "/story/?id=" + data.id + "' class='vl-story-title'>" + self.storyData.title + "</a><span class='vl-story-del-icon' data-id='" + data.id + "'></span><span class='vl-story-edit-icon' data-id='" + data.id + "'></span></li>";
                $(self.ids.storyList).append(story);
              } else {
                console.log(data, textStatus);
              }
            }
          });
        });

        $(self.ids.storyList).on("click", ".vl-story-del-icon", function (event) {
          var id = $(this).attr("data-id");
          var elem = this;
          $.ajax({
            url: self.path + "/wp-content/themes/boss-child/service/storyService.php",
            method: "post",
            dataType: "json",
            data: {
              method: 'delete',
              id: id
            },
            error: function (xhr, textStatus) {
              console.log(xhr, "error");
            },
            success: function (data, textStatus) {
              if (data.success) {
                $(elem).closest('li').remove();
                self.toast("Story deleted successfully.", "success");
              } else {
                console.log(data, textStatus);
              }
            }
          });
        });


        $(self.ids.storyHolder).on(
          "click",
          ".vl-remove-story-node",
          function () {
            var index = $(this).attr("data-value");
            self.storyData.steps.splice(index, 1);
            $(this)
              .closest(".vl-story-state")
              .remove();
            self.svg.trigger("story.stepRemoved", { data: index });
            self.buildStoryStep();
          }
        );

        $(self.ids.storyHolder)
          .sortable({
            update: function (event, ui) {
              self.stepShort.endIndex = ui.item.index();
              var temp = self.storyData.steps[self.stepShort.startIndex];
              self.storyData.steps.splice(self.stepShort.startIndex, 1);
              self.storyData.steps.splice(self.stepShort.endIndex, 0, temp);
              self.svg.trigger("story.shortSteps", { data: self.stepShort });
              self.buildStoryStep();
            },
            start: function (event, ui) {
              self.stepShort.startIndex = ui.item.index();
            }
          })
          .disableSelection();

        $(self.ids.buildGraph).click(self.buildGraphData);

        $(self.ids.dataField).on("change", ".vl-data-filters", function (event) {
          var value = $(this).val();
          var dataKey = $(this).attr("data-filter-key");
          self.filters[dataKey].value = value;
        });

        $(self.ids.stateHolder).on("click", ".vl-remove-state-node", function (
          event
        ) {
          var value = $(this).attr("data-value");
          var index = self.stateData.ids.indexOf(value);
          self.svg.trigger("story.stateElemRemove", { data: value });
          if (index > -1) {
            self.stateData.ids.splice(index, 1);
          }
          $(this)
            .closest(".vl-state-elem")
            .remove();
        });

        $(self.ids.next).on("click", function () {
          self.svg.trigger("story.next");
        });

        $(self.ids.previous).on("click", function () {
          self.svg.trigger("story.previous");
        });

        $(self.ids.showText).on("change", function () {
          var check = $(this).prop("checked");
          self.svg.trigger("story.enableNodeText", { checked: check });
        });

        $(self.ids.stickyMode).on("change", function () {
          var check = $(this).prop("checked");
          self.svg.trigger("story.enableStickyMode", { checked: check });
        });

        $(self.ids.showArrow).on("change", function () {
          var check = $(this).prop("checked");
          self.svg.trigger("story.enableLinkArrow", { checked: check });
        });

        $(self.ids.buildStep).on("click", function () {
          $.extend(self.stateData, {
            title: $(self.ids.stepTitle).val(),
            content: $(self.ids.stepContent).val(),
            footer: $(self.ids.stepFooter).val()
          });
          self.storyData.steps.push(self.stateData);
          self.clearInputs();
          self.svg.trigger("story.pushState", { data: self.stateData });
          self.stateData = {
            ids: [],
            title: "",
            content: "",
            footer: ""
          };
          self.buildStoryStep();
        });

        $(self.ids.play).on("click", function () {
          self.svg.trigger("story.playStory");
        });

        $(self.svg).on("story.stepChanged", function (event, { data: step }) {
          $(self.ids.stepTitle).val(step.title);
          $(self.ids.stepContent).val(step.content);
        });

        $(self.svg).on("story.graphStateAdded", function (
          event,
          { data: node }
        ) {
          self.stateData.ids.push(node.id);
          self.buildStateNodes();
          $(".vl-accordion").accordion("option", "active", 1);
          self.preventEvent(event);
        });

        $(self.ids.dataUpload).change(function () {
          self.reset();
          var regex = /^([a-zA-Z0-9\s_\\.\-:])+(.csv|.txt|.json)$/;
          var fileName = $(this)
            .val()
            .toLowerCase();
          if (regex.test(fileName)) {
            if (typeof FileReader != "undefined") {
              var reader = new FileReader();
              reader.onload = function (e) {
                self.currentDataType = fileName.substr(
                  fileName.lastIndexOf(".") + 1,
                  fileName.length
                );
                self.parseData(e.target.result);
              };
              reader.readAsText($(this)[0].files[0]);
            } else {
              self.toast("This browser does not support HTML5.", "error");
            }
          } else {
            self.toast(
              "Please upload a valid file , Only json,csv,tsv are allowed."
            );
          }
        });
      },
      buildStateNodes: function () {
        var stateString = "";
        self.stateData.ids.map(function (d) {
          stateString +=
            "<li class='vl-state-elem'><span class='vl-state-node'>" +
            d +
            "</span><span class='vl-remove-state-node' data-value='" +
            d +
            "'></span></li>";
        });
        $(self.ids.stateHolder).html(stateString);
      },
      buildStoryStep: function () {
        var storyString = "";
        for (var i = 0; i < self.storyData.steps.length; i++) {
          storyString +=
            "<li class='vl-story-state'><span class='vl-story-node'>" +
            self.storyData.steps[i].title +
            "</span></span><span class='vl-remove-story-node' data-value='" +
            i +
            "'></span></li>";
        }
        $(self.ids.storyHolder)
          .html("")
          .html(storyString);
      },
      buildGraph: function () {
        self.svg.buildNetwork(self.options);
      },
      parseJsonData: function () {
        self.buildGraph();
      },
      parseCsvData: function () {
        var source = self.filters.source.value;
        var target = self.filters.target.value;
        console.log(source, target);
        if (self.checkEmpty(source) && self.checkEmpty(target)) {
          self.toast("Select source and target value form fields.", "error");
          //return;
        }
        var tempData = self.rawData;
        var nodeHash = self.rawData.reduce((hash, node) => {
          hash[node[source]] = node;
          return hash;
        }, {});

        tempData.forEach(function (data) {
          var temp = {
            source: data[source],
            target: data[target]
          };
          if (nodeHash[data[source]] && nodeHash[data[target]]) {
            self.options.links.push(temp);
          }
        });
        for (var key in nodeHash) {
          var node = nodeHash[key];
          node["id"] = node[source];
          self.options.nodes.push(node);
        }
        self.buildGraph();
      },
      buildGraphData: function () {
        switch (self.currentDataType) {
          case "csv": {
            self.parseCsvData();
            break;
          }

          case "tsv": {
            self.parseCsvData();
            break;
          }

          case "json": {
            self.parseJsonData();
            break;
          }
        }
      },
      parseData: function (rawData) {
        switch (self.currentDataType) {
          case "csv": {
            rawData = d3.csvParse(rawData);
            self.filterData = Object.keys(rawData[0]);
            self.rawData = rawData;
            for (var filterKey in self.filters) {
              self.filters[filterKey].active = true;
            }
            break;
          }
          case "json": {
            rawData = JSON.parse(rawData);
            self.filterData = Object.keys(rawData.nodes[0]);
            self.options.links = rawData.links;
            self.options.nodes = rawData.nodes;
            self.filters.source.active = false;
            self.filters.target.active = false;
            break;
          }
        }
        self.buildFilter();
      },
      buildFilter: function () {
        var dataFieldList = "";
        for (var filterKey in self.filters) {
          var filter = self.filters[filterKey];
          if (filter.active) {
            var optionSelect =
              "<select class='vl-data-filters' data-filter-key='" +
              filterKey +
              "'>";
            self.filterData.map(function (elem, index) {
              optionSelect +=
                "<option value='" + elem + "'>" + elem + "</option>";
            });
            optionSelect += "<select>";

            dataFieldList +=
              "<li>" +
              "<span class='vl-data-field'>" +
              filter.name +
              "</span>" +
              optionSelect +
              "</li>";
          }
        }
        $(self.ids.dataField).html(dataFieldList);
      },
      reset: function () {
        self.filterData = [];
        self.rawData = [];
        self.options = {
          enableDblcZoom: false,
          enableNodeText: true,
          enableLinkArrow: false,
          nodes: [],
          links: [],
          nodeRadius: 5
        };
        self.stateData = {
          ids: [],
          title: "",
          content: "",
          footer: ""
        };
        self.storyData = {
          title: "",
          steps: []
        };
        self.clearInputs();
        $(self.ids.storyHolder).html("");
        $(self.ids.storyTitle).html("");
      },
      preventEvent: function (event) {
        event.stopPropagation();
        event.preventDefault();
      },
      checkEmpty: function (val) {
        return val.length === 0 || !val.trim();
      },
      clearInputs: function () {
        $(self.ids.stepTitle).val("");
        $(self.ids.stepContent).val("");
        $(self.ids.stepFooter).val("");
        $(self.ids.stateHolder).html("");
      },
      toast: function (message, type) {
        switch (type) {
          case "success": {
            $(self.ids.toaster).attr("class", "alert alert-success");
            break;
          }
          case "info": {
            $(self.ids.toaster).attr("class", "alert alert-info");
            break;
          }
          case "warning": {
            $(self.ids.toaster).attr("class", "alert alert-warning");
            break;
          }
          case "error": {
            $(self.ids.toaster).attr("class", "alert alert-danger");
            break;
          }
        }
        var messageHolder = $(self.ids.toaster);
        if (!messageHolder.data("is-showing")) {
          $(self.ids.toaster + " .vl-message-content")
            .data("is-showing", true)
            .html(message);
          messageHolder.css({ display: "block", opacity: 1 });
          setTimeout(function () {
            messageHolder.animate({ opacity: 0 }, function () {
              $(this).hide();
            });
          }, 2000);
        }
      }
    });

    new pageScript({
      storyList: "#vlStoryList",
      next: "#vlStoryNext",
      play: "#vlStoryPlay",
      toaster: "#vlMessage",
      graphSvg: "#vlStoryGraph",
      showArrow: "#vlShowArrow",
      showText: "#vlShowNodeText",
      /*buildStory: "#vlBuildStory",*/
      saveStory: "#vlSaveStory",
      stickyMode: "#vlStickyMode",
      previous: "#vlStoryPrevious",
      stateHolder: "#vlStateHolder",
      storyHolder: "#vlStoryHolder",
      buildStep: "#vlBuildStoryStep",
      stepTitle: "#vlStoryStepTitle",
      dataField: "#vlStoryDataFields",
      storyTitle: "#vlStoryTitle",
      buildGraph: "#vlBuildStoryGraph",
      dataUpload: "#vlStoryDataUpload",
      stepContent: "#vlStoryStepContent",
      stepFooter: "#vlStoryFooterContent"
    });
  });
})(jQuery);
