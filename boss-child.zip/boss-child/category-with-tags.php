<?php
/*
 * Template Name: Category With Tags
 *
 */
get_header();
?>
<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"/>
<div class="page-full-width">
	<div id="primary" class="site-content">
		<div id="content" role="main">
		
		<div class="row categorytagssection col-sm-12 col-xs-12 col-lg-12 col-md-12">
		
		<div class="BrowseCategory categorytags col-md-12">
			<h5 class="categoryheading"><a class="browse_by_category browse_by_categorytags" href="javascript:void(0);">Browse By Category</a></h5>
			<ul class="categorylist tagcategorylist" style="display: none;">
				<li class="browsecategory">Business</li>
					<div class="childtags" style="display: none;">
						<ul>
						   <li class="browsetags">Entrepreneurship</li>
				<li class="browsetags">Product Design</li>
				<li class="browsetags">Fundraising</li>
				<li class="browsetags">Social Media</li>
				<li class="browsetags">Product Development</li>
				<li class="browsetags">Company Culture</li>
				<li class="browsetags">Angel Investor</li>
				<li class="browsetags">Seed Capital</li>
						</ul>
					</div>
				<li class="browsecategory">Sales &amp; Marketing</li>
					<div class="childtags" style="display: none;">
							<ul>
							   <li class="browsetags">Entrepreneurship</li>
					<li class="browsetags">Product Design</li>
					<li class="browsetags">Fundraising</li>
					<li class="browsetags">Social Media</li>
					<li class="browsetags">Product Development</li>
					<li class="browsetags">Company Culture</li>
					<li class="browsetags">Angel Investor</li>
					<li class="browsetags">Seed Capital</li>
							</ul>
						</div>
				<li class="browsecategory">Funding</li>
					<div class="childtags" style="display: none;">
							<ul>
							   <li class="browsetags">Entrepreneurship</li>
					<li class="browsetags">Product Design</li>
					<li class="browsetags">Fundraising</li>
					<li class="browsetags">Social Media</li>
					<li class="browsetags">Product Development</li>
					<li class="browsetags">Company Culture</li>
					<li class="browsetags">Angel Investor</li>
					<li class="browsetags">Seed Capital</li>
							</ul>
						</div>
				<li class="browsecategory">Product &amp; Design</li>
					<div class="childtags" style="display: none;">
							<ul>
							   <li class="browsetags">Entrepreneurship</li>
					<li class="browsetags">Product Design</li>
					<li class="browsetags">Fundraising</li>
					<li class="browsetags">Social Media</li>
					<li class="browsetags">Product Development</li>
					<li class="browsetags">Company Culture</li>
					<li class="browsetags">Angel Investor</li>
					<li class="browsetags">Seed Capital</li>
							</ul>
						</div>
				<li class="browsecategory">Technology</li>
					<div class="childtags" style="display: none;">
							<ul>
							   <li class="browsetags">Entrepreneurship</li>
					<li class="browsetags">Product Design</li>
					<li class="browsetags">Fundraising</li>
					<li class="browsetags">Social Media</li>
					<li class="browsetags">Product Development</li>
					<li class="browsetags">Company Culture</li>
					<li class="browsetags">Angel Investor</li>
					<li class="browsetags">Seed Capital</li>
							</ul>
						</div>
			</ul>
		</div>

		</div>

		</div>
	</div>
</div>

<?php
include( 'addtofavoritejs.php' );
get_footer();
