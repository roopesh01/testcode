(function ($) {
    $(document).ready(function(e)
	{
		$("#poll_list_view_tmp").DataTable
		({
			"language": 
			{                                    
			  "search": " ",
			  "searchPlaceholder": "Search..."
			}
		});
        $( ".poll_list_main_div .alignright" ).insertBefore( $( "#poll_list_view_tmp_filter label" ) );
    $('#allfiler').on('change', function(){
        var value = $(this).val();
        var currentUrl = $('.current_page_url').val();
        if(value == "role") {
                $("#rolediv").show();
        } else {
            $("#rolediv").hide();
        }				
        if(value == "membership") {
                $("#memberdiv").show();
        } else {
            $("#memberdiv").hide();
        }
        if(value == "status") {
            $("#statusdiv").show();
        } else {
                $("#statusdiv").hide();
        }
        if(value == "tag") {
            $("#tagdiv").show();
        } else {
            $("#tagdiv").hide();
        }
        if(value == "vote_status") {
            $("#votediv").show();
        } else {
            $("#votediv").hide();
        }
        if(value == "all") {
            location.href = currentUrl;
        }
    });
});
})(jQuery);