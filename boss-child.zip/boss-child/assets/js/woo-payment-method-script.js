function detectCardType(number) {
    var re = {
        electron: /^(4026|417500|4405|4508|4844|4913|4917)\d+$/,
        maestro: /^(5018|5020|5038|5612|5893|6304|6759|6761|6762|6763|0604|6390)\d+$/,
        dankort: /^(5019)\d+$/,
        interpayment: /^(636)\d+$/,
        unionpay: /^(62|88)\d+$/,
        visa: /^4[0-9]{12}(?:[0-9]{3})?$/,
        mastercard: /^5[1-5][0-9]{14}$/,
        amex: /^3[47][0-9]{13}$/,
        diners: /^3(?:0[0-5]|[68][0-9])[0-9]{11}$/,
        discover: /^6(?:011|5[0-9]{2})[0-9]{12}$/,
        jcb: /^(?:2131|1800|35\d{3})\d{11}$/
    };
    if (re.electron.test(number)) {
        return 'Electron';
    } else if (re.maestro.test(number)) {
        return 'Maestro';
    } else if (re.dankort.test(number)) {
        return 'Dankort';
    } else if (re.interpayment.test(number)) {
        return 'Interpayment';
    } else if (re.unionpay.test(number)) {
        return 'Unionpay';
    } else if (re.visa.test(number)) {
        return 'Visa';
    } else if (re.mastercard.test(number)) {
        return 'Mastercard';
    } else if (re.amex.test(number)) {
        return 'American Express';
    } else if (re.diners.test(number)) {
        return 'Diners Club';
    } else if (re.discover.test(number)) {
        return 'Discover';
    } else if (re.jcb.test(number)) {
        return 'JCB';
    } else {
        return undefined;
    }
}

jQuery("#edit1").keyup(function($) {
    var thisNum = $(this).val();
    $(".stripe_card_type").val(detectCardType(thisNum));
});


jQuery(document).ready(function() {
    jQuery("#table_payment_method").DataTable({
        "language": {
            "search": " ",
            "searchPlaceholder": "Search..."
        }
    });
    jQuery('#edit1').keypress(validateNumber);
    jQuery('#user_card_cvv_number').keypress(validateNumber);
    jQuery('#billing_zip').keypress(validateNumber);
    jQuery('#billing_city').keypress(lettersOnly);
    jQuery('#billing_state').keypress(lettersOnly);

    jQuery(document).on('click', '.add_new_card', function(e) {
        jQuery('#savedcards').show();
    });

    jQuery(document).on('click', '.add_method', function(e) {
        e.preventDefault();
        var date = $("#user_card_expire").val();
        var addmthod = "addmethod";
        $('.add_field_box_error').removeAttr('style');
        $('.add_field_error').html('');
        var error_stauts = true;
        if ($("#edit1").val() === "") {
            jQuery('.card_error').html("<p class='errorMsg'><i class='fa fa-exclamation-triangle' aria-hidden='true'></i>&nbsp;Please enter Card Number</p>");
            jQuery("#savedcards .nameCardWrapper .cardnumberwrap").css("border", "1px solid #ff0000");
            error_stauts = false;
        } else {
            jQuery('.card_error').html("");
            jQuery("#savedcards .nameCardWrapper .cardnumberwrap").removeAttr("style");
        }
        if ($("#name_on_card").val() === "") {
            jQuery('.card_name_error').html("<p class='errorMsg'><i class='fa fa-exclamation-triangle' aria-hidden='true'></i>&nbsp;Please enter Your Name</p>");
            jQuery("#savedcards .nameCardWrapper .cardnamewrap").css("border", "1px solid #ff0000");
            error_stauts = false;
        } else {
            jQuery('.card_name_error').html("");
            jQuery("#savedcards .nameCardWrapper .cardnamewrap").removeAttr("style");
        }

        if ($("#short_name_card").val() === "") {
            jQuery('.short_name_error').html("<p class='errorMsg'><i class='fa fa-exclamation-triangle' aria-hidden='true'></i>&nbsp;Please enter Card Name</p>");
            jQuery("#savedcards .nameCardWrapper .cardshortnamewrap").css("border", "1px solid #ff0000");
            error_stauts = false;
        } else {
            jQuery('.short_name_error').html("");
            jQuery("#savedcards .nameCardWrapper .cardshortnamewrap").removeAttr("style");
        }

        if ($("select#user_card_expire_month option:selected").val() === "") {
            jQuery('.card_expiry_month_error').html("<p class='errorMsg'><i class='fa fa-exclamation-triangle' aria-hidden='true'></i>&nbsp;Please select month</p>");
            jQuery("#savedcards .nameCardWrapper .cardexpirymonthwrap").css("border", "1px solid #ff0000");
            error_stauts = false;
        } else {
            jQuery('.card_expiry_month_error').html("");
            jQuery("#savedcards .nameCardWrapper .cardexpirymonthwrap").removeAttr("style");
        }

        if ($("select#user_card_expire_year option:selected").val() === "") {
            jQuery('.card_expiry_year_error').html("<p class='errorMsg'><i class='fa fa-exclamation-triangle' aria-hidden='true'></i>&nbsp;Please select Year</p>");
            jQuery("#savedcards .nameCardWrapper .cardexpiryyearwrap").css("border", "1px solid #ff0000");
            error_stauts = false;
        } else {
            jQuery('.card_expiry_year_error').html("");
            jQuery("#savedcards .nameCardWrapper .cardexpiryyearwrap").removeAttr("style");
        }

        if ($("#user_card_cvv_number").val() === "") {
            jQuery('.card_cvv_error').html("<p class='errorMsg'><i class='fa fa-exclamation-triangle' aria-hidden='true'></i>&nbsp;Please enter CVV Number</p>");
            jQuery("#savedcards .nameCardWrapper .cardcvvwrap").css("border", "1px solid #ff0000");
            error_stauts = false;
        } else {
            jQuery('.card_cvv_error').html("");
            jQuery("#savedcards .nameCardWrapper .cardcvvwrap").removeAttr("style");
        }

        if (error_stauts == false) {
            return false;
        }
        // validate_date(date, addmthod);
        // if (jQuery.trim($("#edit1").val()) === "" || jQuery.trim($("#user_card_expire_month").val()) === "" || jQuery.trim($("#user_card_expire_year").val()) === "" || jQuery.trim($("#user_card_cvv_number").val()) === "" || jQuery.trim($("#name_on_card").val()) === "") {
        //     return false;
        // }
        jQuery("html").addClass("overlay");
        var data = new FormData(document.getElementById("savedcards"));
        jQuery.ajax({
            type: 'POST',
            url: ajaxurl,
            async: false,
            dataType: 'json',
            data: data,
            contentType: false,
            cache: false,
            processData: false,
            success: function(data) {
                if (data['stripe_error'] == 1) {
                    jQuery(".new_card_status").addClass("alert-success");
                    jQuery(".new_card_status").addClass("alert alert-danger");
                    jQuery(".new_card_status").html(data['messgae']);
                    jQuery(".new_card_status").show();
                }
                if (data['login_error'] == 1) {
                    parent.location = data['redirect'];
                }
                if (data['success'] == 1) {
                    jQuery(".new_card_status").removeClass("alert-danger");
                    jQuery(".new_card_status").addClass("alert alert-success");
                    jQuery(".new_card_status").html("Your card has saved successfully");
                    jQuery(".new_card_status").show();
                    parent.location = data['redirect'];
                }
                jQuery("html").removeClass("overlay");
            },
            error: function(MLHttpRequest, textStatus, errorThrown) {}
        });
    });
});

function validateNumber(event) {
    var key = window.event ? event.keyCode : event.which;
    if (event.keyCode === 8 || event.keyCode === 46) {
        return true;
    } else if (key < 48 || key > 57) {
        return false;
    } else {
        return true;
    }
};

function lettersOnly(evt) {
    evt = (evt) ? evt : event;
    var charCode = (evt.charCode) ? evt.charCode : ((evt.keyCode) ? evt.keyCode :
        ((evt.which) ? evt.which : 0));
    if (charCode > 31 && (charCode < 65 || charCode > 90) &&
        (charCode < 97 || charCode > 122)) {
        return false;
    }
    return true;
}

function delete_Card_Details(useid, token_id, wpnonce) {

    bootbox.confirm({
        message: "Are you sure to delete this card?",
        buttons: {
            confirm: {
                label: 'Yes',
                className: 'btn-success'
            },
            cancel: {
                label: 'No',
                className: 'btn-danger'
            }
        },
        callback: function(result) {
            if (result == true) {
                var wp_delete_nonce = $("input[name=wp_delete_nonce]").val();
                $("html").addClass("overlay");
                $.ajax({
                    type: 'POST',
                    url: ajaxurl,
                    async: false,
                    dataType: 'json',
                    data: {
                        action: 'vl_saved_credit_cards_ajax1',
                        userid: useid,
                        token_id: token_id,
                        wpnonce: wpnonce,
                        deleteCard: "deleteCard",
                        wp_delete_nonce: wp_delete_nonce,
                    },
                    success: function(data) {
                        if (data['login_error'] == 1) {
                            parent.location = data['redirect'];
                        }
                        if (data['stripe_error'] == 1) {
                            var DataMessage = data['message'];
                            alert(DataMessage);
                            parent.location = data['redirect'];
                        }
                        if (data['success'] == 1) {
                            var DataMessage = data['message'];
                            alert(DataMessage);
                            parent.location = data['redirect'];
                        }
                        $("html").removeClass("overlay");
                    },
                    error: function(MLHttpRequest, textStatus, errorThrown) {}
                });
            }
        }
    });
}

function edit_card(useid, token_id, wpnonce) {
    $("html").addClass("overlay");
    var row_id = "row_" + token_id;
    var holder_name = $("#" + row_id + " td.card_holder_name").text();
    var card_name = $("#" + row_id + " td.card_short_name").text();
    $("div#editDetailPayment #edit_card_token_id").val('');
    $("div#editDetailPayment #edit_card_token_id").val(token_id.trim());
    $("div#editDetailPayment .edit_card_name").val(holder_name.trim());
    $("div#editDetailPayment #edit_short_name").val(card_name.trim());
    $("div#editDetailPayment div.edit_form_div").removeClass("hide");
    $("html").removeClass("overlay");
}

jQuery(document).ready(function() {
    jQuery(document).on('click', '.edit_method', function(e) {
        e.preventDefault();
        var editmthod = "editmthod";
        $('.edit_field_box_error').removeAttr('style');
        $('.edit_field_error').html('');
        var error_status = true;
        if (jQuery.trim($(".edit_card_name").val()) === "") {
            jQuery('.edit_name_err').html("<p class='errorMsg'><i class='fa fa-exclamation-triangle' aria-hidden='true'></i>&nbsp;Please enter name</p>");
            jQuery(".edit_name_wrap").css("border", "1px solid #ff0000");
            var error_status = false;
        } else {
            jQuery('.edit_name_err').html("");
            jQuery(".edit_name_wrap").removeAttr("style");
        }

        if (jQuery.trim($("#edit_short_name").val()) === "") {
            jQuery('.edit_short_err').html("<p class='errorMsg'><i class='fa fa-exclamation-triangle' aria-hidden='true'></i>&nbsp;Please enter short name</p>");
            jQuery(".edit_short_wrap").css("border", "1px solid #ff0000");
            var error_status = false;
        } else {
            jQuery('.edit_short_err').html("");
            jQuery(".edit_short_wrap").removeAttr("style");
        }


        if ($("select#edit_user_card_expire_month option:selected").val() === "") {
            jQuery('.edit_month_err').html("<p class='errorMsg'><i class='fa fa-exclamation-triangle' aria-hidden='true'></i>&nbsp;Please select expiry month</p>");
            jQuery(".edit_month_wrap").css("border", "1px solid #ff0000");
            var error_status = false;
        } else {
            jQuery('.edit_month_err').html("");
            jQuery(".edit_month_wrap").removeAttr("style");
        }

        if ($("select#edit_user_card_expire_year option:selected").val() === "") {
            jQuery('.edit_year_err').html("<p class='errorMsg'><i class='fa fa-exclamation-triangle' aria-hidden='true'></i>&nbsp;Please select expiry year</p>");
            jQuery(".edit_year_wrap").css("border", "1px solid #ff0000");
            var error_status = false;
        } else {
            jQuery('.edit_year_err').html("");
            jQuery(".edit_year_wrap").removeAttr("style");
        }

        if (false == error_status) {
            return false;
        }

        jQuery("html").addClass("overlay");

        var card_expiry_month = $("select#edit_user_card_expire_month option:selected").val();
        var card_expiry_year = $("select#edit_user_card_expire_year option:selected").val();
        var edit_card_token_id = $('#edit_card_token_id').val();
        var card_short_name = $("#edit_short_name").val();
        var card_name = $(".edit_card_name").val();
        var update_wp_nonce = $("input[name=update_wp_nonce]").val();
        jQuery.ajax({
            type: 'POST',
            url: ajaxurl,
            async: false,
            dataType: 'json',
            data: {
                action: 'vl_saved_credit_cards_ajax1',
                update_card: "update_card",
                card_token_id: edit_card_token_id,
                card_expiry_month: card_expiry_month,
                card_expiry_year: card_expiry_year,
                card_short_name: card_short_name,
                card_name: card_name,
                update_wp_nonce: update_wp_nonce,
            },
            success: function(data) {
                if (data['login_error'] == 1) {
                    parent.location = data['redirect'];
                }
                if (data['success'] == 1) {
                    jQuery(".edit_card_status").removeClass("alert-danger");
                    jQuery(".edit_card_status").addClass("alert alert-success");
                    jQuery(".edit_card_status").html("Your card has updated successfully");
                    jQuery(".edit_card_status").show();
                    setTimeout(function() {
                        window.location.reload(1);
                    }, 2000);
                } else {
                    jQuery(".edit_card_status").removeClass("alert-success");
                    jQuery(".edit_card_status").addClass("alert alert-danger");
                    jQuery(".edit_card_status").html(data['message']);
                    jQuery(".edit_card_status").show();
                }
                jQuery("html").removeClass("overlay");
            },
            error: function(MLHttpRequest, textStatus, errorThrown) {}
        });
    });
});