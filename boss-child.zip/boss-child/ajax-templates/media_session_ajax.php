<?php
    include '../../../../wp-config.php';
    global $wpdb, $current_user;
    $userid = $current_user->ID;
    //echo $userid;    
    if(isset($_POST['mediaid']))
    {
        $mediaid = $_POST['mediaid'];
        $value = $_POST['mediatypes'];
        update_post_meta( $mediaid, 'mediatype', $value);         
    }
   
