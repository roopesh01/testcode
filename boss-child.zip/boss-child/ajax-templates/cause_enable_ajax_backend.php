<?php
include '../../../../wp-config.php';
global $wpdb;
if(isset($_POST['post_id'])|| isset($_POST['status']))
{
    $post_id = $_POST['post_id'];
    $status = $_POST['status'];
    if($status=='Disable Cause'):
        update_post_meta($post_id,'donation_status','disable');
    else:
        update_post_meta($post_id,'donation_status','enable'); 
    endif;
}
