<?php
include '../../../../../wp-config.php';
 global $wpdb,$current_user;
 $curentuserid     = $current_user->ID;
 $metatable        = 'wp68_usermeta';
 $ratingtable      = $wpdb->prefix . 'ratings';
 $pricetable       = $wpdb->prefix . 'expert_price';
 $prefix           = $wpdb->prefix;
 $single           = true;
 $post_table       = $wpdb->prefix . 'posts';
$post_meta_table   = $wpdb->prefix . 'postmeta';
$logo_type         = 'company_logo';
$prev_logo_type    = 'prev_company_logo';
$expert_team_table = $wpdb->prefix . 'expert_team_detail';
$donation_table    = $wpdb->prefix . 'user_donation_details';
$biling_table      = $wpdb->prefix . 'BillingInformation';
$conf_table        = $wpdb->prefix . 'setup_conference_call';
if ( isset( $_POST['search_by_team'] ) ) {
					$team_id              = $_POST['search_by_team'];
					$single               = true;
					$allexpert            = $wpdb->get_results( "SELECT * FROM $expert_team_table WHERE `current_user_id`=$curentuserid AND `id`=$team_id" );
					$invited_experts      = $allexpert[0]->invited_experts;
					$invited_expert_array = explode( ',', $invited_experts )
					?>
				 <!-- <table id="ExpertByCategory">
				<thead>
					<tr>
					<th>&nbsp; </th>
					</tr>
				</thead> -->
				<tbody class="tablebodyhtml"> <!-- Table Body Section -->
					<?php
					if ( $invited_expert_array ) :
						foreach ( $invited_expert_array as $userid ) :
							if ( $userid != $currentuserid && $userid !== 2 ) :
								$get_client = $wpdb->get_results( "SELECT * FROM $biling_table WHERE `userid`=$currentuserid AND `expertid`=$userid" );
								if ( $get_client ) {
									$firstname     = get_user_meta( $userid, 'first_name', $single );
									$lastname      = get_user_meta( $userid, 'last_name', $single );
									$AboutYourSelf = $wpdb->get_var( "SELECT value FROM wp68_bp_xprofile_data WHERE `user_id`='$userid' AND `field_id`='241'" );
									$city          = bp_get_profile_field_data( 'field=City&user_id=' . $userid );
									$state         = bp_get_profile_field_data( 'field=State&user_id=' . $userid );
									$Company       = bp_get_profile_field_data( 'field=Company&user_id=' . $userid );
									$Country       = bp_get_profile_field_data( 'field=Country&user_id=' . $userid );
									$JobTitle      = bp_get_profile_field_data( 'field=JobTitle&user_id=' . $userid );
								} elseif ( 'is_friend' == BP_Friends_Friendship::check_is_friend( $currentuserid, $userid ) ) {
									$firstname      = get_user_meta( $userid, $prefix . 'friend_first_hidden_name', $single );
									$lastname       = get_user_meta( $userid, $prefix . 'friend_last_hidden_name', $single );
									$JobTitle       = get_user_meta( $userid, $prefix . 'friend_job_title_hidden_name', $single );
									$AboutYourSelf  = $wpdb->get_var( "SELECT meta_value FROM wp68_usermeta WHERE `user_id` = '$userid' AND `meta_key` = 'wp68_14_friend_bio_hidden_name'" );
									$city           = get_user_meta( $userid, $prefix . 'friend_city_hidden_name', $single );
									$state          = get_user_meta( $userid, $prefix . 'friend_state_hidden_name', $single );
									$Country        = get_user_meta( $userid, $prefix . 'friend_country_hidden_name', $single );
									$Company        = get_user_meta( $userid, $prefix . 'friend_company_hidden_name', $single );
									$friend_profile = get_user_meta( $userid, $prefix . 'friend_profile_hidden', $single );
									if ( $friend_profile == 'yes' ) :
										$avatar = get_avatar( $userid, $size );
									else :
										$avatar = '<img src="/wp-content/themes/boss-child/images/avatar-member.jpg"/>';
									endif;

									$logo_friend      = get_user_meta( $userid, $prefix . 'friend_company_logo_hidden', $single );
									$prev_logo_friend = get_user_meta( $userid, $prefix . 'friend_prev_company_logo_hidden', $single );
								} else {
									$firstname      = get_user_meta( $userid, $prefix . 'member_first_hidden_name', $single );
									$lastname       = get_user_meta( $userid, $prefix . 'member_last_hidden_name', $single );
									$JobTitle       = get_user_meta( $userid, $prefix . 'member_job_title_hidden_name', $single );
									$AboutYourSelf  = $wpdb->get_var( "SELECT meta_value FROM wp68_usermeta WHERE `user_id` = '$userid' AND `meta_key` = 'wp68_14_member_bio_hidden_name'" );
									$city           = get_user_meta( $userid, $prefix . 'member_city_hidden_name', $single );
									$state          = get_user_meta( $userid, $prefix . 'member_state_hidden_name', $single );
									$Country        = get_user_meta( $userid, $prefix . 'member_country_hidden_name', $single );
									$Company        = get_user_meta( $userid, $prefix . 'member_company_hidden_name', $single );
									$member_profile = get_user_meta( $userid, $prefix . 'member_profile_hidden', $single );
									if ( $member_profile == 'yes' ) :
										$avatar = get_avatar( $userid, $size );
									else :
										$avatar = '<img src="/wp-content/themes/boss-child/images/avatar-member.jpg"/>';
									endif;
									$logo_member      = get_user_meta( $userid, $prefix . 'member_company_logo_hidden', $single );
									$prev_logo_member = get_user_meta( $userid, $prefix . 'member_prev_company_logo_hidden', $single );
								}

								$salutation                         = bp_get_profile_field_data( 'field=salutation&user_id=' . $userid );
								$expertPrice                        = $wpdb->get_var( "SELECT `price` FROM $pricetable WHERE `user_id`='$userid'" );
								$title                              = bp_get_profile_field_data( 'field=Title&user_id=' . $userid );
								?>
								<tr> <!-- Table Row -->
								   <td class="hide">
									   <p><?php echo $FinalFullName = ( empty( $firstname ) ) ? str_replace( ' ', '', $lastname ) : str_replace( ' ', '', $firstname ) . '&nbsp;' . str_replace( ' ', '', $lastname ); ?></p>
								   </td>

								   <td> <!-- Table Column -->
									   <div class="expertbycategorytags"> <!-- Expert  Category Main Div -->
										   <div class="row customexpert">  <!-- Expert Category Sub Div -->                
											   <div class="col-md-2 col-lg-2 ce-image">
												   <a href="<?php echo site_url(); ?>/user-basic-profile/?ExpertId=<?php echo $userid; ?>"><?php echo get_avatar( $userid, $size ); ?></a>
											   </div>
											   <div class="col-md-7 col-lg-7 ce-content">
												   <div class="clientBriefInfo">
												   <div class="clientNameWrap">
												   <h4 class="ce-title"><a href="<?php echo site_url(); ?>/user-basic-profile/?ExpertId=<?php echo $userid; ?>">
																							<?php
																							if ( $salutation ) {
																								echo $salutation . '&nbsp;';
																							}echo $firstname . '&nbsp;' . $lastname;
?>
</a></h4>
												   <p class="ce-info"><span>
													<?php
													if ( $city || $state || $Country ) {
														echo '<i class="fa fa-map-marker" aria-hidden="true"></i>';
													}if ( $city ) {
														echo $city;
													} if ( $city && $state ) {
														echo ',&nbsp';
													} if ( $state ) {
														echo $state;
													}if ( ( $state || $city ) && $Country ) {
														echo ',&nbsp';
													}if ( $Country ) {
														echo $Country;}
?>
</span></p>
												   <p class="client-desg">
													<?php
													if ( $JobTitle ) :
														echo $JobTitle;
endif;
?>
,</p>
												   <p class="client-desg">
													<?php
													if ( $Company ) :
														echo $Company;
endif;
?>
</p>
												   </div>
															<?php
															$current_logo      = $wpdb->get_results( "SELECT * FROM $post_table WHERE `post_author`=$userid AND `post_type`='$logo_type'" );
															$logo_img_url      = $current_logo[0]->guid;
															$logo_id           = $current_logo[0]->ID;
															$company_logo_name = get_post_meta( $logo_id, 'company_logo_name', true );
															$prev_company_logo = $wpdb->get_results( "SELECT * FROM $post_table WHERE `post_author`=$userid AND `post_type`='$prev_logo_type'" );
														?>
																												
														<p class="ce-details">
														<?php
														if ( $AboutYourSelf ) {
																$string = strip_tags( $AboutYourSelf );
															if ( strlen( $string ) > 150 ) {
																// truncate string
																$stringCut = substr( $string, 0, 150 );
																// make sure it ends in a word so assassinate doesn't become ass...
																$string = substr( $stringCut, 0, strrpos( $stringCut, ' ' ) ) . '.... <a class="read_moree" href="/user-basic-profile/?ExpertId=' . $userid . '">Read More</a>';
															}
																echo $string;
														}
															?>
														  </p>
														<div class="previousOrgLogo">
															<?php
															if ( $current_logo ) :
																$current_logo_show = '<div class="leftMainLogo">                                                           
                                                                <a class="custom_tooltip" title="' . $company_logo_name . '" href="javascript:void(0);"><img src="' . $logo_img_url . '"/></a>
															     </div>';
																endif;
															if ( $get_client ) {
																echo $current_logo_show;
															} elseif ( 'is_friend' == BP_Friends_Friendship::check_is_friend( $currentuserid, $userid ) ) {
																if ( $logo_friend == 'yes' ) {
																	echo $current_logo_show;
																}
															} else {
																if ( $logo_member == 'yes' ) {
																	echo $current_logo_show;
																}
															}
															if ( $prev_company_logo ) :
																$prev_logo_show = '<div class="rightAffiliateLogos">
                                                                <ul>
                                                                  <li class="prevEmpText"><span>Affiliations</span></li>';
																foreach ( $prev_company_logo as $logos ) :
																		$prev_img_url           = $logos->guid;
																		$logoidd                = $logos->ID;
																		$prev_company_logo_name = get_post_meta( $logoidd, 'company_logo_name', true );
																		$prev_logo_show        .= '<li><a class="custom_tooltip" title="' . $prev_company_logo_name . '" href="javascript:void(0);"><img src="' . $prev_img_url . '"></a></li>';
																	endforeach;
																   $prev_logo_show .= '</ul>';
																   $prev_logo_show .= '</div>';
															 endif;
															if ( $get_client ) {
																echo $prev_logo_show;
															} elseif ( 'is_friend' == BP_Friends_Friendship::check_is_friend( $currentuserid, $userid ) ) {
																if ( $prev_logo_friend == 'yes' ) {
																	echo $prev_logo_show;
																}
															} else {
																if ( $prev_logo_member == 'yes' ) {
																	echo $prev_logo_show;
																}
															}
															?>
														</div>
													</div>
												</div>
												<div class="col-md-3 col-lg-3 ce-action">
												   <div class="ce-pricing">
														 <span class="profile-detail profile-stat price">
														<input type="hidden" name="basic_amount"/>
														<?php
														   $expertprices = number_format( (float) $expertPrice, 2, '.', '' );
														?>
														<strong class="actual-price"><?php echo $expertprices; ?>&nbsp;CR/minute</strong>
														<?php
														   $todaydate   = date( 'm/d/Y' );
														   $get_charity = $wpdb->get_results( "SELECT * FROM `$donation_table` WHERE `start_time` <= '$todaydate' AND `end_time` >= '$todaydate' AND user_id=$userid ORDER BY `donation_percentage` DESC" );
														   /* Custom Code For Total Donation Amount */
																	   $the_post      = "SELECT * FROM $donation_table WHERE user_id='$userid' order by end_time desc";
																	   $donation      = $wpdb->get_results( $the_post, OBJECT );
																	   $total_charity = 0;
														if ( $donation ) :
															foreach ( $donation as $key => $donations ) :
																$donationoid         = $donations->id;
																$userstarttime       = $donations->start_time;
																$userid              = $donations->user_id;
																$firstname           = get_user_meta( $userid, 'first_name', true );
																$lastname            = get_user_meta( $userid, 'last_name', true );
																$donation_percentage = $donations->donation_percentage;
																$causeofdonation     = $donations->donation_cause;
																$userendtime         = $donations->end_time;
																$date1               = new DateTime( $userstarttime );
																$date2               = new DateTime( $userendtime );
																$diff                = $date2->diff( $date1 )->format( '%a' );
																$donation_status     = $donations->donation_status;
																$final_percentage    = $donation_percentage;
																$currentdate         = date( 'm/d/Y' );
																$currentstr          = strtotime( $currentdate );
																$startstr            = strtotime( $userstarttime );
																$endstr              = strtotime( $userendtime );
																$startdatetime       = date( 'Y-m-d H:i:s', $startstr );
																$enddatetime         = date( 'Y-m-d H:i:s', $endstr );
																$result              = $wpdb->get_results( $wpdb->prepare( "SELECT estimated_length, amount, coupone_code, conference_datetime, conference_type, 'conference_booking' FROM $conf_table WHERE DATE(conference_datetime) >= %s AND DATE(conference_datetime) <= %s AND expert_ids REGEXP %d AND booking_status = %s UNION SELECT usertime, amount, coupon, booking_timestamp, conference_type, 'booking' FROM $biling_table WHERE DATE(booking_timestamp) >= %s AND DATE(booking_timestamp) <= %s AND expertid = %d AND paymentstatus = %s AND booking_status = %d", $startdatetime, $enddatetime, $userid, 'booked', $startdatetime, $enddatetime, $userid, 'completed', 0 ) );

																if ( $donation_status == 1 ) {
																	$status = 'Ended';
																} else {
																	if ( $startstr <= $currentstr && $endstr >= $currentstr ) {
																		$status = 'Active';
																	} elseif ( $startstr >= $currentstr && $endstr >= $currentstr ) {
																		$status = 'Inactive';
																	} elseif ( $startstr <= $currentstr && $endstr <= $currentstr ) {
																		$status = 'Ended';
																	}
																}

																$count        = 1;
																$totalcharity = 0;
																if ( $result ) :
																	foreach ( $result as $results ) :
																		$booking_belongs = $results->conference_booking;
																		if ( $booking_belongs == 'conference_booking' ) :

																			$diff                = $results->estimated_length;
																			$conference_datetime = $results->conference_datetime;
																			$booking_time_str    = strtotime( $conference_datetime );
																			$normal_date         = date( 'Y/m/d', $booking_time_str );
																			$start_time          = date( 'h:i A', $booking_time_str );
																			$estimate_seconds    = $diff * 60;
																			$end_booking_str     = $booking_time_str + $estimate_seconds;
																			$end_time            = date( 'h:i A', $end_booking_str );
																			$type                = $results->conference_type;
																			if ( $type == 'Voice' ) {
																				$user_price = $price = $wpdb->get_var( $wpdb->prepare( "SELECT price FROM $pricetable WHERE user_id= %d", $userid ) );
																			} elseif ( $type == 'Video' ) {
																				$user_price = $price = $wpdb->get_var( $wpdb->prepare( "SELECT video_min_price FROM $pricetable WHERE user_id= %d", $userid ) );
																			} elseif ( $type == 'Chat' ) {
																				$user_price = $price = $wpdb->get_var( $wpdb->prepare( "SELECT chat_price FROM $pricetable WHERE user_id= %d", $userid ) );
																			} elseif ( $type == 'SMS' ) {
																				$user_price = $price = $wpdb->get_var( $wpdb->prepare( "SELECT sms_price FROM $pricetable WHERE user_id= %d", $userid ) );
																			}
																			$full_price   = ( $diff * $user_price );
																			$coupon_value = $results->coupone_code;
																			$mypost       = get_page_by_title( $coupon_value, OBJECT, 'request_coupon' );
																			$post_id      = $mypost->ID;
																			$coupon_type  = get_post_meta( $post_id, '_coupon_type', true );
																			if ( $coupon_type == 'percentage' ) {
																				$percentage        = get_post_meta( $post_id, '_coupon_percentage', true );
																				$amount_percentage = ( $full_price * $percentage ) / 100;
																				$final_amount      = ( $amount - $amount_percentage );
																				$final_amount      = sprintf( '%0.2f', $final_amount );
																			} else {
																				$percentage = get_post_meta( $post_id, '_coupon_amount', true );
																			}
																			if ( $coupon_value == 'NULL' || $coupon_value == '' ) {
																				$payment        = $full_price;
																				$charity_amount = ( $payment * $final_percentage ) / 100;
																			} else {
																				$payment        = $final_amount;
																				$charity_amount = ( $payment * $final_percentage ) / 100;
																			}
																	else :
																		$usertime         = $results->estimated_length;
																		$timeexpload      = explode( '  ', $usertime );
																		$userextradate    = $timeexpload[0];
																		$userextractetime = $timeexpload[1];
																		$userextractetime = explode( '-', $userextractetime );
																		$userexstart      = $userextradate . ' ' . $userextractetime[0];
																		$userexend        = $userextradate . ' ' . $userextractetime[1];
																		$userexstartstr   = strtotime( $userexstart );
																		$normal_date      = date( 'Y/m/d', $userexstartstr );
																		$start_time       = date( 'h:i A', $userexstartstr );
																		$userexendstr     = strtotime( $userexend );
																		$end_time         = date( 'h:i A', $userexendstr );
																		$diff             = abs( $userexstartstr - $userexendstr ) / 60;
																		$payment          = $results->amount;
																		$charity_amount   = ( $payment * $final_percentage ) / 100;
																	endif;

																	$count++;
																	$total_charity += $charity_amount;
																endforeach;
															 endif;
														 endforeach;
																		endif;
																		$total_charityy = number_format( (float) $total_charity, 2, '.', '' );
														if ( $total_charityy != '0.00' ) :
															$total_charity = '<div class="ep-charContribution"><span>Charity Contribution: </span>CR ' . $total_charityy . '</div>';
																			else :
																				$total_charity = '';
																		endif;
																			/* Custom Code For Total Donation Amount */
																			if ( ! empty( $get_charity ) ) {
																				$donation_id = $get_charity[0]->donation_id;
																				$titles      = get_the_title( $donation_id );
																				$post_url    = get_post_permalink( $donation_id );
																				$image_url   = get_the_post_thumbnail_url( $donation_id, $size = 'post-thumbnail' );
																				echo $total_charity;
																				echo '<div class="doneImgPge"><div class="cltCurrLogo"><a class="custom_tooltip" title="' . $titles . '" href="' . $post_url . '"><img width="77" height="80" src="' . $image_url . '" class="attachment-thumbnail size-thumbnail wp-post-image" alt=""/></a></div><div class="chClDetail"><span class="chtNameDonate">' . $firstname . '&nbsp; donates to</span><span class="chtPercentage">UTICA ' . $get_charity[0]->donation_percentage . '%</span></div></div>';
																			}
														?>
														</span>
													</div>
													<a href="/request-a-call/?ExpertId=<?php echo $userid; ?>" class="call_link">Request A Call</a>
													<div class="expRating">                                                    
														<?php
														$average  = $wpdb->get_var( "SELECT Avg(totalrating) FROM $ratingtable WHERE expertid = $userid" );
														$average2 = number_format( (float) $average, 2, '.', '' );
														if ( $average2 > 4.5 ) {
															echo '<img src="/wp-content/themes/boss-child/images/rating/five-star.png" title="Awesome - 5 stars"/>';
															/*echo '<br/>';
															echo $average2.' out of 5 stars';*/
														} elseif ( $average2 > 3.5 ) {
															echo '<img src="/wp-content/themes/boss-child/images/rating/four-star.png" title="Pretty good - 4 stars"/>';
															/*echo '<br/>';
															echo $average2.' out of 5 stars';*/
														} elseif ( $average2 > 2.5 ) {
															echo '<img src="/wp-content/themes/boss-child/images/rating/three-star.png" title="Average - 3 stars"/>';
															/*echo '<br/>';
															echo $average2.' out of 5 stars';*/
														} elseif ( $average2 > 1.5 ) {
															echo '<img src="/wp-content/themes/boss-child/images/rating/two-star.png" title="Bad - 2 stars"/>';
															/*echo '<br/>';
															echo $average2.' out of 5 stars';*/
														} elseif ( $average2 > 0.5 ) {
															echo '<img src="/wp-content/themes/boss-child/images/rating/one-star.png" title="Very Poor - 1 star"/>';
															/*echo '<br/>';
															echo $average2.' out of 5 stars';*/
														} else {
															echo '<small>No Rating For This Expert</small>';
														}
														?>
													</div>
												</div>                    
											</div> <!-- Expert Category Sub Div -->
										</div> <!-- Expert  Category Main Div -->
									</td> <!-- Table Column -->

									<!-- Rating td -->
									<td class="hide">
										<p><?php echo $average2; ?></p>
									</td>
									<!-- Price td -->
									<td class="hide">
										<p><?php echo $expertprices; ?></p>
									</td>
									<!-- Reputataion td -->
									<td class="hide">
										<p><?php echo get_user_meta( $userid, 'ap_reputation', true ); ?></p>
										 
									</td>
									<!-- Charity td -->
									<td class="hide">
										<?php
										$todaydate               = date( 'm/d/Y' );
										$get_charity             = $wpdb->get_var( "SELECT `donation_percentage` FROM `$donation_table` WHERE `start_time` <= '$todaydate' AND `end_time` >= '$todaydate' AND user_id=$userid ORDER BY `donation_percentage` DESC" );
										echo   $userTotalCharity = ( $get_charity ) ? $get_charity : 0;
										?>

									</td>
									<!-- City td -->
									<td class="hide">
										<?php
										if ( $city ) {
											echo $city;
										}
										?>
									</td>
									<!-- State td -->
									<td class="hide">
										<?php
										if ( $state ) {
											echo $state;
										}
											?>
									</td>
									 <td class="hide">
											<?php
											if ( $Country ) {
												echo  getCountryISOCODE( $Country ) . ' ' . $Country;
											}
										?>
									</td>
									<td class="hide">
									<?php
									if ( $JobTitle ) :
										echo $JobTitle;
endif;
?>
									</td>
									  <td class="hide">
									<?php
									$catArary  = array();
									$tabledata = $wpdb->prefix . 'cat_';
									$category  = $wpdb->get_results( "SELECT * FROM $metatable WHERE `user_id` = '$userid' AND `meta_key` LIKE '%$tabledata%'" );
									if ( $category ) :
										foreach ( $category as $categories ) :
												$cat_key = $categories->meta_key;
												$newkey  = str_replace( $tabledata, '', $cat_key );
												echo $newkey . '<br/>';
												//$wpdb->get_var("SELECT ")
										endforeach;
									endif;
									?>
									</td>
									<td class="hide">
										<?php
										if ( $Company ) :
											echo $Company;
endif;
?>
 
									</td>
								</tr> <!-- Table Row -->
							<?php
						endif;
						endforeach;
					endif;
					?>
									
				</tbody> <!-- Table Body Section -->           
			<?php
}
?>
