<?php
include '../../../../wp-config.php';
global $wpdb;
$main = array();
if(!isset($_REQUEST['userName']))
{
	$main['userImg'] = "";
	$main['attendiesid'] = "";
	$main['userType'] = "";

	echo json_encode($main);
	exit();
}
$userName = $_REQUEST['userName'];
$currentUser = $_REQUEST['currentUser'];
// get user id by username
$main = array();
$userInfo = get_user_by('login', $userName);
$current_userInfo = get_user_by('login', $currentUser);
$current_userID = $current_userInfo->ID;
$attendiesid = $userInfo->ID;
if(get_current_user_id() == $attendiesid)
{
	$userType = "current";
}else
{
	$userType = "other";
}

$image_url =  bp_get_activity_avatar(array('user_id' => $attendiesid));
$src = (string) reset(simplexml_import_dom(DOMDocument::loadHTML($image_url))->xpath("//img/@src"));
$image_url = $src;

$current_user_timezone = unserialize(get_user_meta($current_userID, "user_timezone_detail", TRUE));
$mytimezone_id = $current_user_timezone['timeZoneId'];
$user_chat_time = new DateTime("now", new DateTimeZone($mytimezone_id));
$chat_time = $user_chat_time->format('h:i A');
$main['userImg'] = $image_url;
$main['attendiesid'] = $attendiesid;
$main['userType'] = $userType;
$main['timeZone'] = $mytimezone_id;
$main['chat_time'] = $chat_time;
 
echo json_encode($main);
exit();
?>