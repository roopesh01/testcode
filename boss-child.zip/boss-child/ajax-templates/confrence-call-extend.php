<?php
include '../../../../wp-config.php';
global $wpdb;
$user_id = get_current_user_id(); 
	if ($user_id == 0) 
	{
		$redirect = site_url()."/registration-page/login/";
		echo json_encode(array('login_error'=>1,'redirect'=>$redirect));	
		exit; 
	}
	global $wpdb;
	$new_amount = $_POST['amount'];
	$credit_url = $_POST['crediturl'];
	$bookingid = $_POST["bookingid"];
	$timeextend = $_POST["timeextend"];
	$timeinmin = $timeextend/60;
	$blog_id = get_current_blog_id();
	$my_meta_key = "wp68_".$blog_id."_user_points";
	$current_user_credits = get_user_meta($user_id, $my_meta_key, true);
	if($current_user_credits <= $new_amount)
	{
		$message = "You Credits Balance is not enough to make this booking. please buy the credits from <a href='".$credit_url."' target='_blank'>Here</a> and try again.";
		echo json_encode(array('stripe_error'=>1,'messgae'=>$message));	
		exit;
	}
	else
	{
		$biling_table = $wpdb->prefix.'BillingInformation';
		$conf_table = $wpdb->prefix.'setup_conference_call';
		$extendtable =$wpdb->prefix.'extended_call_billing';
		
		$get_bookings = $wpdb->get_results("(SELECT team_id, amount , conference_datetime, conference_type, id, booking_status, estimated_length, booking_id, time_zone, expert_ids, 'conference_booking', gmt_endtime FROM $conf_table WHERE booking_id =$bookingid) UNION (SELECT expertid, amount, usertime, conference_type, id, booking_status, '15', booking_id, 'Asia/Calcutta', expertid, 'booking', gmt_endtime FROM $biling_table WHERE booking_id = $bookingid) ORDER BY team_id desc");
		$updated_user_points = $current_user_credits - $new_amount;
		$update = update_user_meta($user_id, $my_meta_key, $updated_user_points);
		$chargeId = "ch_".uniqid();
		foreach($get_bookings as $get_booking)
		{
			$userid = get_current_user_id();
			$team_id = $get_booking->team_id;
			$estimate_time = $get_booking->conference_datetime;
			$a_time  = strtotime($estimate_time);
			$pre_gmt_end_date = $get_booking->gmt_endtime;
			$pre_gmt_end_str = strtotime($pre_gmt_end_date);
			$prv_amount = $get_booking->amount;
			$new_total = $prv_amount + $new_amount;
			$previous_call_length = $get_booking->estimated_length;
			$new_call_length = $previous_call_length + $timeinmin;
			$time_length_second = $timeextend; 
			$end_booking_timestamp = $pre_gmt_end_str + $time_length_second;
			$gmt_end_time = date('Y-m-d H:i:s', $end_booking_timestamp);
			$booking_belong = $get_booking->conference_booking;
			if($booking_belong == "conference_booking")
			{
				$updatestatus = $wpdb->query( $wpdb->prepare("UPDATE $conf_table SET amount= %d, gmt_endtime= %s, estimated_length= %d WHERE booking_id= %d", $new_total, $gmt_end_time, $new_call_length, $bookingid) );
				
			}
			else
			{
				$timeexpload = explode("  ", $estimate_time);
				$date_ext = $timeexpload[0];
				$time_ext = $timeexpload[1];
				$time_ext = explode("-", $time_ext);
				$ex_end_time  = $date_ext." ". $time_ext[1];
				$end_booking_str = strtotime($ex_end_time);
				$new_end_str = $end_booking_str + $timeextend;
				$end_time = date('h:i A', $new_end_str);
				$newusertime = $date_ext."  ".$time_ext[0]."-".$end_time;
				$end_booking_timestamp = $pre_gmt_end_str + $timeextend;
				$gmt_end_time = date('Y-m-d H:i:s', $end_booking_timestamp);
				$updatestatus = $wpdb->query( $wpdb->prepare("UPDATE $biling_table SET amount=%s, usertime=%s, gmt_endtime= %s WHERE booking_id = %s", $new_total, $newusertime, $gmt_end_time, $bookingid) );
			}
			$recordinster = $wpdb->insert( $extendtable,
				array(	'userid' => $userid,
						'team_id' =>$team_id,
						'booking_id' =>$bookingid,                      
						'bookingdatetime'=> $estimate_time,
						'timeextend'=>  $timeinmin,            
						'previousamount'=>$prv_amount,
						'newamount' =>$new_amount,
						'transactionid' =>$chargeId,
						'paymentstatus' => 'completed',
						'payment_gateway' =>'Credits Point System',),
					array('%d','%d','%d','%s','%d','%f','%f','%s','%s','%s')
					); 
		}
		if($recordinster == 1)
		{
			echo json_encode(array('success'=>1,'extlimit'=>$pre_gmt_end_date,'message'=>'Payment successfull call will be extended'));
			exit;
		}
	}