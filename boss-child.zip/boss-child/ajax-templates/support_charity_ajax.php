<?php

include '../../../../wp-config.php';
global $wpdb;
$table = $wpdb->prefix.'expert_team_detail';
$conference_table = $wpdb->prefix.'setup_conference_call';
$response_table = $wpdb->prefix.'conference_call_response';
$currentuserid = get_current_user_id();
if(isset($_POST['charity_id']))
{
    echo ' <div class="back_gallery"><a href="'.get_site_url().'">Home</a> >> <a href="/charity-cause/">Charity Cause</a> >> Content View</div>';
    $charity_id = $_POST['charity_id'];    
    $content_post = get_post($charity_id);
    $content = $content_post->post_content;
    $content = apply_filters('the_content', $content);
    $content = str_replace(']]>', ']]&gt;', $content);
    $title = get_the_title($charity_id);
    $img_url = get_the_post_thumbnail_url($charity_id);    
    echo '<div class="charity_detail"><h1 class="charity_title">'.$title.'</h1><img class="post_img" src="'.$img_url.'"/><div class="charity_content"><p>'.$content.'</p></div></div>';
}


?>