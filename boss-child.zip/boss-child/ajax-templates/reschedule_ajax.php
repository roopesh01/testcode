<?php
include '../../../../wp-config.php';
global $wpdb;
$table = $wpdb->prefix.'venuemeetingdetail';
$currentuserid = get_current_user_id();

if(isset($_POST['venuedate']) || isset($_POST['venuetime']) || isset($_POST['timeformat']))
{
    
    include $_SERVER['DOCUMENT_ROOT'] . '/wp-content/themes/boss-child/email-template/reschedule_meeting.php';    
}