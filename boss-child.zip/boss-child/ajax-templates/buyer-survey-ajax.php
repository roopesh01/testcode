<?php
    include '../../../../wp-config.php';
    global $wpdb, $current_user;
    $userid = $current_user->ID;
    echo $userid;
    
    if(isset($_POST['CourtSurvey']) || isset($_POST['Prosecution']) || isset($_POST['LawEnforcement']) || isset($_POST['LawOperation']))
    {
        $CourtSurvey = $_POST['CourtSurvey'];
        $Prosecution =  $_POST['Prosecution'];
        $LawEnforcement =  $_POST['LawEnforcement'];
        $LawOperation =  $_POST['LawOperation'];
        $keyvalue = 'submitsurvey';
       
        $CourtSurveykey = 'CourtSurvey';
        $Prosecutionkey = 'Prosecution';
        $LawEnforcementkey = 'LawEnforcement';
        $LawOperationkey = 'LawOperation';
        $submitsurveykey = 'submitsurveykey';
        $keyvalue = 'submitsurvey';
        
        $metas = array
        ( 
            $CourtSurveykey   =>        $CourtSurvey,
            $Prosecutionkey    =>       $Prosecution, 
            $LawEnforcementkey         => $LawEnforcement,
            $LawOperationkey      => $LawOperation,
            $submitsurveykey     => $keyvalue
        );
        foreach($metas as $key => $value) 
        {
            update_user_meta( $userid, $key, $value );
        }
    }
?>