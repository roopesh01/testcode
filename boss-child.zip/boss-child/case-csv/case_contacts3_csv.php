<?php
	include '../../../../wp-config.php';
	global $wpdb;
	$filename   = 'case_contacts_level3.csv';
	$header_row = array(
		0  => 'id',
		1  => 'contact_id',
		2  => 'category',
		3  => 'gender',
		4  => 'account_id',
		5  => 'job_title',
		6  => 'primary_city',
		7  => 'primary_state_prov1',
		8  => 'primary_country',
		9  => 'home_city',
		10 => 'home_state_province',
		11 => 'home_country',
	);
	$data_rows  = array();
	$table      = $wpdb->prefix . 'case_contacts_level3';
	$result     = $wpdb->get_results( "SELECT * FROM $table" );
	foreach ( $result as $results ) {
		$row         = array();
		$row[0]      = $results->id;
		$row[1]      = $results->contact_id;
		$row[2]      = $results->category;
		$row[3]      = $results->gender;
		$row[4]      = $results->account_id;
		$row[5]      = $results->job_title;
		$row[6]      = $results->primary_city;
		$row[7]      = $results->primary_state_prov1;
		$row[8]      = $results->primary_country;
		$row[9]      = $results->home_city;
		$row[10]     = $results->home_state_province;
		$row[11]     = $results->home_country;
		$data_rows[] = $row;
	}
	$fh = @fopen( 'php://output', 'w' );
	fprintf( $fh, chr( 0xEF ) . chr( 0xBB ) . chr( 0xBF ) );
	header( 'Cache-Control: must-revalidate, post-check=0, pre-check=0' );
	header( 'Content-Description: File Transfer' );
	header( 'Content-type: text/csv' );
	header( "Content-Disposition: attachment; filename={$filename}" );
	header( 'Expires: 0' );
	header( 'Pragma: public' );
	fputcsv( $fh, $header_row );
	foreach ( $data_rows as $data_row ) {
		fputcsv( $fh, $data_row );
	}
	fclose( $fh );
	die();



