<?php
include '../../../../wp-config.php';
global $current_user;
$user_id = $current_user->ID;
$currentdirectory = get_stylesheet_directory_uri();
$blockchain_setting =  get_option('update_user_profile_bc');

if(isset($_FILES["logo_file"]["type"]) && isset( $_POST['cpt_nonce_field'] ) && wp_verify_nonce( $_POST['cpt_nonce_field'], 'cpt_nonce_action' ) )
{
    $validextensions = array("jpeg", "jpg", "png", "JPG","JPEG","PNG");
    $temp1 = $_FILES["logo_file"]["name"];
    $temporary = explode(".", $_FILES["logo_file"]["name"]);    
    $file_title = $temporary[0];
    $file_name = sanitize_title($file_title);
    $getext =  $temporary[1];
    if($getext=='jpg' OR $getext=='JPG' OR $getext=='JPEG'):
        $getext ='jpeg';
    endif; 
    $newfile = $temporary[0].'.'.$getext;     
    $file_type = $_FILES["logo_file"]["type"];
    $file_extension = end($temporary);
    $company_logo_name = $_POST['company_name'];
    if ((($_FILES["logo_file"]["type"] == "image/png") || ($_FILES["logo_file"]["type"] == "image/jpg") || ($_FILES["logo_file"]["type"] == "image/jpeg") || ($_FILES["logo_file"]["type"] == "image/JPG") || ($_FILES["logo_file"]["type"] == "image/JPEG") || ($_FILES["logo_file"]["type"] == "image/PNG") )&& ($_FILES["logo_file"]["size"] < 1097152)//Approx. 1mb files can be uploaded.
    && in_array($file_extension, $validextensions)) 
    {
        if ($_FILES["logo_file"]["error"] > 0)
        {
            $errorMessage =  $_FILES["logo_file"]["error"];
             echo json_encode(array("status" => 0 , 'message' => $errorMessage));
                exit();   
        }
        else
        {
            /*chagne file name */                
                $fileData = pathinfo(basename($_FILES["logo_file"]["name"]));
                $fileName =  $file_title. '.' . $getext;
            /*chagne file name */
            $directory = $_SERVER['DOCUMENT_ROOT'] . '/wp-content/themes/boss-child/iis/company_logo/users/'.$user_id.'/current_company/';            
            if (wp_mkdir_p($directory)) 
            {
                //echo 'It worked <br/>';
            }
            if (file_exists($directory.$fileName))
            {
                echo json_encode(array("status" => 0 , 'message' => "File already exists."));
                exit();      
            }
            else
            {             
                $sourcePath = $_FILES['logo_file']['tmp_name']; // Storing source path of the file in a variable
                //echo $sourcePath;                
                $targetPath =  $directory.$fileName;// Target path where file is to be stored
                //echo $targetPath;
                $uploadedfile =  move_uploaded_file($sourcePath,$targetPath); // Moving Uploaded file
                $imgurl = $currentdirectory.'/iis/company_logo/users/'.$user_id.'/current_company/'.$fileName;
                //echo $imgurl;
                if($uploadedfile):                   
                    $my_cptpost_args = array
                    (                    
                        'post_title'    => $file_title,                    
                        'post_name'    => $file_name,                    
                        'post_status'   => 'inherit',                    
                        'post_type' => $_POST['post_type'], 
                        'post_mime_type' => $_FILES["logo_file"]["type"],                  
                        'post_author' => $user_id,
                        'guid'  =>  $imgurl                
                    );
                    // insert the post into the database                    
                    $cpt_id = wp_insert_post( $my_cptpost_args, $wp_error);
                    $path = 'iis/company_logo/users/'.$user_id.'/current_company/'.$fileName;
                    update_post_meta($cpt_id, 'logo_path', $path);
                    update_post_meta($cpt_id, 'company_logo_name', $company_logo_name);

                    
                         $outPutArray = array('logo_id' => $cpt_id,
                        'guid' => $cpt_id,
                        'imageURL' => $imgurl,
                        'logoTitle' => $company_logo_name
                        )    ;
                    
                    echo json_encode(array("status" => 1 , 'message' => "Image Uploaded Successfully...!!", 'response' => $outPutArray));
                    if($blockchain_setting == "enable")
                    {
                        blockchain_updates();
                    }
                            exit();            
                endif;                
            }
        }
    }
    else
    {
        echo json_encode(array("status" => 0 , 'message' => "<span id='invalid'>***Invalid file Size or Type***<span>"));
                            exit();  
    }
}
?>