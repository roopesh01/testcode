(function($)
{

    $(document).ready(function(e)
    {

            $(".amounts").keyup(function (e)
            {
                var VAL = $(this).val();
                //alert(VAL);
                //var intRegex = /[0-9 -()+]+$/;
                var intRegex = /^([0-9]+[\.]?[0-9]?[0-9]?|[0-9]+)$/g;
                if(!intRegex.test(VAL))
                {
                    bootbox.alert("Please enter a valid no");
                    $(this).val("");
                }
            });
            $(document).on('click','#donation_submit', function(e)
            {
                    var amounts = $('.amounts').val();
                    var first_names = $('.first_names').val();
                    var second_names = $('.second_names').val();
                    var emails = $('.emails').val();
                    var booking_id = $('.booking_id').val();
                    var numericReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
                    if ($(this).hasClass('has_donation'))
                    {
                        e.preventDefault();
                        if(amounts=='' || first_names=='' || second_names=='' || emails=='')
                        {
                            bootbox.alert("Please Fill All Fields");
                        }
                        else
                        {

                            if(!numericReg.test(emails))
                            {
                                bootbox.alert("Please Enter An Email Address");
                            }
                            else
                            {
                                $.ajax
                                ({
                                    type: 'POST',
                                    url: ajaxurl,
                                    async:    false,
                                    data:
                                    {
                                        action: 'vl_mobile_donation',
                                        first_names: first_names,
                                        second_names: second_names,
                                        emails: emails,
                                        amounts: amounts,
                                        booking_id: booking_id
                                    },
                                    success: function(html)
                                    {
                                        //alert(html);
                                        $("#donation_submit").removeClass('has_donation');
                                        $('#donation_submit').click();
                                    },
        							error: function(MLHttpRequest, textStatus, errorThrown)
                                    {
                                    }
        						});
                             }
                        }
    				}
                    else
                    {
                        $('#xclick').submit();
                        $(this).addClass('has_donation');
    				}
    		});
        });
})(jQuery);