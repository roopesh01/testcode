<?php
header( 'Content-type: text/xml' );

?> 
<Response>
	<?php
	if ( $_REQUEST['DialCallStatus'] == 'no-answer' || $_REQUEST['DialCallStatus'] == 'busy' || $_REQUEST['DialCallStatus'] == 'failed' ) {
	?>
 <!-- Forward Call to +12067261019 incase of No show of Expert -->
 
	<Dial callerId="+12062020307"><Number>+12067261019</Number></Dial>
	<?php } ?>
   <Hangup/>
</Response>
