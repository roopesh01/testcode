<?php

/* Start- Change buddypress 'Cancel friendship' button text and url  */
function mb_bp_friend_button( $button ) {
	if ( is_array( $button ) && isset( $button['id'] ) ) {

		if ( $button['id'] == 'is_friend' ) {
			$oldUrl                = $button['link_href'];
			$explode_oldUrl        = explode( 'remove-friend/', $oldUrl );
			$new_explode_url       = explode( '/?_wpno', $explode_oldUrl[1] );
			$button['link_text']   = '<i class="fa fa-users" aria-hidden="true"></i> Meet the Members';
			$button['link_href']   = site_url() . '/user-basic-profile/?ExpertId=' . $new_explode_url[0];
			$button['link_class'] .= ' meet-the-members';
		}
	}
	return $button;
}
add_filter( 'bp_get_add_friend_button', 'mb_bp_friend_button' );
/* End- Change buddypress 'Cancel friendship' button text and url  */

/* Start - Set buddypress profile menu position  */
function my_change_profile_tab_order() {
	global $bp;

	/**
 * @todo Error: E_USER_NOTICE  bp_nav was called <strong>incorrectly</strong>. The bp_nav and bp_options_nav globals should not be used directly and are deprecated. Please use the BuddyPress nav functions instead. Please see <a href="https://codex.wordpress.org/Debugging_in_WordPress">Debugging in WordPress</a> for more information. (This message was added in version 2.6.0.)
 */

	$bp->bp_nav['activity']['position']      = 10;
	$bp->bp_nav['profile']['position']       = 20;
	$bp->bp_nav['messages']['position']      = 30;
	$bp->bp_nav['friends']['position']       = 40;
	$bp->bp_nav['groups']['position']        = 50;
	$bp->bp_nav['blog']['position']          = 60;
	$bp->bp_nav['media']['position']         = 45;
	$bp->bp_nav['member-events']['position'] = 70;
	$bp->bp_nav['notifications']['position'] = 75;
	$bp->bp_nav['questions']['position']     = 80;
	$bp->bp_nav['answers']['position']       = 85;
	$bp->bp_nav['invite-anyone']['position'] = 90;
	$bp->bp_nav['settings']['position']      = 95;
	$bp->bp_nav['reputation']['position']    = 100;
}

// @todo uncomment hook after fixing callback.
//add_action( 'bp_setup_nav', 'my_change_profile_tab_order', 999 );

/* End - Set buddypress profile menu position  */

/* Start - Update buddypress profile field from woocommerce account setting page  */
add_action( 'woocommerce_save_account_details', 'save_buddypress_data_from_woocommerce' );
function save_buddypress_data_from_woocommerce( $user_id ) {
	global $wpdb, $bp,$current_user;
	$blod_id = get_current_blog_id();
	if ( isset( $_POST['account_first_name'] ) && isset( $_POST['account_last_name'] ) ) {
		$fullName = trim( $_POST['account_first_name'] ) . ' ' . trim( $_POST['account_last_name'] );
		xprofile_set_field_data( 1, $user_id, trim( $fullName ) );
		update_user_meta( $user_id, 'nickname', trim( $fullName ) );
	}
	if ( isset( $_POST['mobile_auth_number'] ) ) {
		xprofile_set_field_data( 625, $user_id, trim( $_POST['mobile_auth_number'] ) );
	}
	if ( isset( $_POST['account_salutation'] ) ) {
		xprofile_set_field_data( 902, $user_id, trim( $_POST['account_salutation'] ) );
	}
	if ( isset( $_POST['show_public_realname'] ) ) {
		$public_realname_key = 'wp68_' . $blod_id . '_show_public_realname';
		update_user_meta( $user_id, $public_realname_key, trim( $_POST['show_public_realname'] ) );
		if ( isset( $_POST['public_hidden_name'] ) && $_POST['show_public_realname'] == 'no' ) {
			$public_name = preg_replace( '/\s\s+/', ' ', trim( $_POST['public_hidden_name'] ) );
			update_user_meta( $user_id, 'wp68_' . $blod_id . '_public_hidden_name', $public_name );
		}
	}
	if ( isset( $_POST['show_member_realname'] ) ) {
		$member_realname_key = 'wp68_' . $blod_id . '_show_member_realname';
		update_user_meta( $user_id, $member_realname_key, trim( $_POST['show_member_realname'] ) );
		if ( isset( $_POST['member_hidden_name'] ) && $_POST['show_member_realname'] == 'no' ) {
			$member_name = preg_replace( '/\s\s+/', ' ', trim( $_POST['member_hidden_name'] ) );
			update_user_meta( $user_id, 'wp68_' . $blod_id . '_member_hidden_name', $member_name );
		}
	}

}
/* End - Update buddypress profile field from woocommerce account setting page  */

/* This function will call get_user_meta hook and return real or modified name */
function get_user_privacy_setting_names_init() {
	add_filter( 'get_user_metadata', 'get_user_privacy_setting_names', 10, 4 );
}
/* Start - Return real or privacy settings first name or last name */
function get_user_privacy_setting_names( $null, $object_id, $meta_key, $single ) {
	global $bp, $wpdb;

	if ( $meta_key != 'first_name' && $meta_key != 'last_name' ) {
		return null;
	}

	// passed meta key is first name or last name

	$caseName               = '';
	$blog_id                = get_current_blog_id();
	$public_realname_key    = 'wp68_' . $blog_id . '_show_public_realname';
	$public_hidden_name_key = 'wp68_' . $blog_id . '_public_hidden_name';
	$member_realname_key    = 'wp68_' . $blog_id . '_show_member_realname';
	$member_hidden_name_key = 'wp68_' . $blog_id . '_member_hidden_name';
	// loggedin user id and pass user id is same then return real name
	if ( get_current_user_id() == $object_id ) {
		return null;
	} elseif ( ! is_user_logged_in() ) { // means show public name according to setting
		// get public setting yes or no
		$public_realname_status = get_user_meta( $object_id, $public_realname_key, true );
		if ( $public_realname_status != 'no' ) {
			return null;
		} else {

			 // get public hidden name
			$public_hidden_name         = get_user_meta( $object_id, $public_hidden_name_key, true );
			$explode_public_hidden_name = explode( ' ', $public_hidden_name );
			if ( $meta_key == 'first_name' && count( $explode_public_hidden_name ) > 0 ) {
				return array( $explode_public_hidden_name[0] );
			} elseif ( $meta_key == 'last_name' && count( $explode_public_hidden_name ) > 1 ) {
				return array( end( $explode_public_hidden_name ) );
			} elseif ( $meta_key == 'last_name' && count( $explode_public_hidden_name ) == 1 ) {
				return '';
			} else {
				return array( $public_hidden_name );
			}
		}
	} elseif ( is_super_admin() || current_user_can( 'administrator' ) ) {
		return null;
	} elseif ( bp_is_friend( $object_id ) == 'is_friend' ) {
		// check logged user id and object/pass user id is friends or not. Now is friend then return real name
		return null;
	}

	$biling_table = $wpdb->prefix . 'BillingInformation';
	$conf_table   = $wpdb->prefix . 'setup_conference_call';
	// check logged user id and object id has booked call (Clients (Booked))
	$logged_user_id = get_current_user_id();
	// check on one to one call booking
	$total_billing_result = $wpdb->get_var( "SELECT COUNT(*) FROM $biling_table WHERE `userid` = $logged_user_id AND `expertid` = $object_id " );
	 // check on conference call booking
	$total_conf_result = $wpdb->get_var( "SELECT COUNT(*) FROM $conf_table WHERE `current_user_id` = $logged_user_id AND `expert_ids` REGEXP '([[:blank:][:punct:]]|^)$object_id([[:blank:][:punct:]]|$)' " );
	if ( $total_billing_result > 0 ) {
		// means call boooked then show real real
		return null;
	} elseif ( $total_conf_result > 0 ) {  // check on conference call booking
		// means call boooked then show real real
		return null;
	} else {
		 // get member setting yes or no. logged user is iis member but not friend to object user.
		$member_realname_status = get_user_meta( $object_id, $member_realname_key, true );

		if ( $member_realname_status != 'no' ) {

			return null;
		} else {

			 // get public hidden name
			$member_hidden_name         = get_user_meta( $object_id, $member_hidden_name_key, true );
			$explode_member_hidden_name = explode( ' ', $member_hidden_name );

			if ( $meta_key == 'first_name' && count( $explode_member_hidden_name ) > 0 ) {
				return array( $explode_member_hidden_name[0] );
			} elseif ( $meta_key == 'last_name' && count( $explode_member_hidden_name ) > 1 ) {
				return array( end( $explode_member_hidden_name ) );
			} elseif ( $meta_key == 'last_name' && count( $explode_member_hidden_name ) == 1 ) {

				return '';
			} else {
				return array( $member_hidden_name );
			}
		}
	}
	return null;
}

add_action( 'init', 'get_user_privacy_setting_names_init' );
/* End - Return real or privacy settings first name or last name */

function nominne_user_login_redirect() {
	$user = wp_get_current_user();
	if ( in_array( 'nominee', (array) $user->roles ) ) {
		if( ! is_page( 'join-options' ) ) {
			$url = site_url( 'join-options' );
			wp_redirect( $url );
			exit();
		}
	}
}

require( 'class-iis-ajax-method.php' );

