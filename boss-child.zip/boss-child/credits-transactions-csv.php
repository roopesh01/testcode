<?php
include '../../../wp-config.php';
if ( ! is_user_logged_in() ) {
	$url = site_url( '/registration-page/login/' );
	wp_redirect( $url );
	exit;
}
?>
<?php
// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Template Name: Credits Transactions CSV
 *
 */


global $wpdb;
$trcf_purchased_shop          = 0; // total received credits from purchased shop
$trcf_expert_call             = 0; // total received credits from expert call
$trcf_expert_call_future      = 0; // total received credits in future date
$trcf_expert_single_call      = 0; // total received credits from  expert one to one call
$trcf_director                = 0; // total recived credits from director
$trcf_admin                   = 0; // total recived credits from admin
$trcf_registration            = 0; // total recived credits from registration
$trcf_revoke                  = 0; // total received credits from revoked method(refund)
$tect_company                 = 0; // total expense(Transfer) credits to company
$tect_donation                = 0; // total expense credits to donation
$tect_expert_call             = 0; //total expense credits to expert calls
$tect_shop                    = 0; // total expense credits to purchase shop product
$tect_revoke                  = 0; // total expense credits to revoked method(refund)
$tect_converted_currency      = 0; // total express credits to converted into currency
$total_credits_in             = 0;
$total_credits_out            = 0;
$net_credits_balance          = 0;
$credit_allotment_logs_Table  = $wpdb->prefix . 'credit_allotment_logs';
$setup_call_Table             = $wpdb->prefix . 'setup_conference_call';
$billing_Table                = $wpdb->prefix . 'BillingInformation';
$posts_Table                  = $wpdb->prefix . 'posts';
$user_call_status_table       = $wpdb->prefix . 'user_call_status';
$team_table                   = $wpdb->prefix . 'expert_team_detail';
$user_donation_Table          = $wpdb->prefix . 'user_donation_details';
$admin_transection_logs_Table = $wpdb->prefix . 'admin_transection_logs';
$responsetable                = $wpdb->prefix . 'conference_call_response';
$chat_conference_table        = $wpdb->prefix . 'chat_conference_data';
$sms_incomingSMS_table        = $wpdb->prefix . 'incomingSMS';
$credit_revoke_logs_Table     = $wpdb->prefix . 'credit_revoke_logs';
$conversion_log_Table         = $wpdb->prefix . 'credit_currency_conversion_log';
$current_date                 = date( 'Y-m-d h:i A' );
$logged_user_id               = get_current_user_id();

$filename = 'credits_transactiobs_csv.csv';
$fp       = fopen( 'php://output', 'w' );
// set header
$header = array( 'Money In', 'Money Out', 'Purpose', 'Net Credits Balance' );
header( 'Content-type: application/csv' );
header( 'Content-Disposition: attachment; filename=' . $filename );
fputcsv( $fp, $header );
$output_data_array = array();
//Credits received by shop
// The query arguments
							$args_array                = array(
								'post_type'   => 'shop_order',
								'post_status' => array( 'wc-completed', 'wc-processing' ),
								'numberposts' => -1,
								'meta_key'    => '_customer_user',
								'meta_value'  => get_current_user_id(),
							);
							  $current_customer_orders = get_posts( $args_array );

							foreach ( $current_customer_orders as $customer_order ) :

											$order                   = wc_get_order( $customer_order );
											$item_count              = $order->get_item_count();
											$order_items             = $order->get_items();
											$buy_credit_type_product = 0;
											$single_order_credits    = 0;
								foreach ( $order_items as $order_item_id => $order_item ) {
									$item_name  = $order_item['name'];
									$product_id = $order_item['product_id'];
									$term_list  = wp_get_post_terms( $product_id, 'product_cat', array( 'fields' => 'ids' ) );
									// check product is exists 61 category
									if ( isset( $term_list[0] ) && $term_list[0] == '61' ) {
										$buy_credit_type_product = 1;
										// get product credits
										$products_credit_points = get_post_meta( $product_id, '_no_of_points', true );
										$single_order_credits   = $single_order_credits + $products_credit_points;
										$trcf_purchased_shop    = $trcf_purchased_shop + $products_credit_points;


									}
								}
											$order_id       = $order->get_order_number();
											$transection_id = get_post_meta( $order_id, '_transaction_id' );

											$method_name = get_post_meta( $order_id, '_payment_method', true );
											// buy_credit_type_product is zero mean this order is not buy credits
								if ( $buy_credit_type_product == 0 ) {
									continue;
								}

												$order_date = date( 'm/d/Y', strtotime( $order->order_date ) );
			endforeach;

							array_push( $output_data_array, array( 'CR ' . number_format( $trcf_purchased_shop, 2 ), 'CR ' . 0.00, 'Credits received by shop', '' ) );

							// Credits received (Allocated) start
							$all_alloted_credits = $wpdb->get_results( "SELECT * FROM $credit_allotment_logs_Table WHERE `alloted_userids` REGEXP '([[:blank:][:punct:]]|^)$logged_user_id([[:blank:][:punct:]]|$)' " );
							foreach ( $all_alloted_credits  as $key => $alloted_credits ) {
								if ( $alloted_credits->allocation_status == 'admin_allocated' ) {
									$trcf_admin = $trcf_admin + $alloted_credits->credits_alloted;
								} // end if
								if ( $alloted_credits->allocation_status == 'registration_allocated' ) {
									$trcf_registration = $trcf_registration + $alloted_credits->credits_alloted;
								}
								if ( $alloted_credits->allocation_status == 'director_allocated' ) {
									$trcf_director = $trcf_director + $alloted_credits->credits_alloted;
								}
							} //end foreach
							array_push( $output_data_array, array( 'CR ' . number_format( $trcf_admin, 2 ), 'CR ' . 0.00, 'Credits received by admin', '' ) );
							array_push( $output_data_array, array( 'CR ' . number_format( $trcf_registration, 2 ), 'CR ' . 0.00, 'Credits received by registration', '' ) );
							array_push( $output_data_array, array( 'CR ' . number_format( $trcf_director, 2 ), 'CR ' . 0.00, 'Credits received by company', '' ) );
							//Credits received (Allocated) end
							// Credits received by experts call start
							$sql_query = "(SELECT expert_rate, current_user_id, call_topic, team_id, conference_datetime, conference_type, conference_id, booking_status, estimated_length, booking_id, expert_ids, gmt_starttime, gmt_endtime, 'conference_booking', amount, coupone_code, refund_status FROM $setup_call_Table WHERE `expert_ids` REGEXP '([[:blank:][:punct:]]|^)$logged_user_id([[:blank:][:punct:]]|$)' AND booking_status = 'booked' AND gmt_endtime <= '$current_date' AND conference_type in ('Video' , 'Voice' , 'Chat' , 'SMS')) UNION (SELECT expert_rate, userid, message, expertid, usertime, conference_type, conference_id, booking_status, '15', booking_id, expertid, gmt_starttime, gmt_endtime, 'booking', amount, coupon, refund_status FROM $billing_Table WHERE `expertid` REGEXP '([[:blank:][:punct:]]|^)$logged_user_id([[:blank:][:punct:]]|$)' AND booking_status = 0 AND gmt_endtime <= '$current_date' AND conference_type in ('Video' , 'Voice' , 'Chat' , 'SMS')) ORDER BY gmt_starttime desc";

							$setup_call_results = $wpdb->get_results( $sql_query );
							foreach ( $setup_call_results  as $key => $call_result ) {
								$booking_status       = $call_result->booking_status;
								$conference_booking   = $call_result->conference_booking;
								$conference_id        = $call_result->conference_id;
								$booking_id           = $call_result->booking_id;
								$conference_type      = $call_result->conference_type;
								$userInfo             = get_user_by( 'id', $logged_user_id );
								$start_gmt_time       = $call_result->gmt_starttime;
								$gmtstr               = strtotime( $start_gmt_time );
								$start_gmt_time       = date( 'Y-m-d H:i:s', $gmtstr );
								$expert_rate          = 0;
								$discount_amount      = 0;
								$donation_amount      = 0;
								$single_call_amount   = 0;
								$total_pending_amount = 0;
								$from_name            = $userInfo->user_login;
								$refund_status        = $call_result->refund_status;
								$coupon_eligible      = 'NA';
								$call_string          = "SELECT sum(duration) as total_duration from $user_call_status_table WHERE conference_id = '" . $conference_id . "' AND from_name = '$from_name'";

								 $call_detail = $wpdb->get_results( $call_string );
								// booked means one to one call
								// calculate total call duration in minuts

								$call_duration = $call_detail[0]->total_duration / 60;

								if ( $conference_booking == 'booking' ) {


									$expert_rate         = $call_result->expert_rate;
									$conference_datetime = $call_result->conference_datetime;
									$timeexpload         = explode( '  ', $conference_datetime );
									$date                = $timeexpload[0];
									$time_check          = $timeexpload[1];
									$ex_time             = explode( '-', $time_check );
									$starttime           = $ex_time[0];
									$endtime             = $ex_time[1];
									$userstarttime       = $date . ' ' . $starttime;
									$userendtime         = $date . ' ' . $endtime;
									$date1               = strtotime( $userstarttime );
									$date2               = strtotime( $userendtime );
									$diff                = $date2 - $date1;
									$diff                = $diff / 60;
									$estimated_length    = $diff;
									$conferenceDateTime  = $userstarttime;
									// change date formate for donation
									$conference_start_date = date( 'm/d/Y', strtotime( $call_result->gmt_starttime ) );
									// get sms details
									// discount coupon only for one to one call.
									if ( $call_result->coupone_code != '' ) {
										$coupone_code = $call_result->coupone_code;
										$mypost       = get_page_by_title( $coupone_code, OBJECT, 'request_coupon' );
										if ( ! empty( $mypost ) ) {
											$post_id           = $mypost->ID;
											$post_title        = $mypost->post_title;
											$coupon_percentage = get_post_meta( $post_id, '_coupon_percentage', true ); //
											// change coupon status
											$coupon_eligible = ( $coupon_percentage == '' ) ? 'NA' : 'apply';
										}
									}
								} elseif ( $conference_booking == 'conference_booking' ) {
									// Discount coupon is not eligible for conference call
									$expert_rate_array  = unserialize( $call_result->expert_rate );
									$expert_rate        = $expert_rate_array[ $logged_user_id ];
									$estimated_length   = $call_result->estimated_length;
									$conferenceDateTime = $call_result->conference_datetime;
									// change date formate for donation
									$conference_start_date = date( 'm/d/Y', strtotime( $call_result->gmt_starttime ) );

								}

								if ( $conference_type == 'SMS' ) {
									$twillo_sql_query = "SELECT * FROM `wp68_bp_xprofile_data` WHERE `user_id`= '" . $logged_user_id . "' AND `field_id` = '279' ";
									$twillo_results   = $wpdb->get_results( $twillo_sql_query );
									foreach ( $twillo_results as $Numberdetails ) {
										$UserphoneNumber = $Numberdetails->value;

									}
									$sms_join_time = 0;
									for ( $i = 0; $i < ( $estimated_length / 5 ); $i++ ) {
										if ( $i == 0 ) {
											$sms_starttime = $start_gmt_time;
										}
										$conference_start = $sms_starttime;
										$increse_gmt      = $gmtstr + ( 5 * 60 );
										$sms_starttime    = date( 'Y-m-d H:i:s', $increse_gmt );
										$gmtstr           = strtotime( $sms_starttime );

										$get_total_sms_time = $wpdb->get_var( "SELECT COUNT(*) FROM $sms_incomingSMS_table WHERE `conference_id` = '$conference_id' AND `FromNumber` = '$UserphoneNumber' AND datetime >= '$conference_start' AND datetime <= '$sms_starttime' " );
										if ( $get_total_sms_time ) {
											$sms_join_time = $sms_join_time + 5;
										}
									}
									$call_duration = $sms_join_time;
								} elseif ( $conference_type == 'Chat' ) {
									$twillo_sql_query = "SELECT * FROM `wp68_bp_xprofile_data` WHERE `user_id`= '" . $logged_user_id . "' AND `field_id` = '279' ";
									$twillo_results   = $wpdb->get_results( $twillo_sql_query );
									foreach ( $twillo_results as $Numberdetails ) {
										$UserphoneNumber = $Numberdetails->value;

									}
									$chat_join_time = 0;
									for ( $i = 0; $i < ( $estimated_length / 5 ); $i++ ) {
										if ( $i == 0 ) {
											$chat_starttime = $start_gmt_time;
										}
										$mystarttime         = $chat_starttime;
										$increse_gmt         = $gmtstr + ( 5 * 60 );
										$chat_starttime      = date( 'Y-m-d H:i:s', $increse_gmt );
										$gmtstr              = strtotime( $chat_starttime );
										$get_total_chat_time = $wpdb->get_var( "SELECT COUNT(*) FROM $chat_conference_table WHERE `conference_id` = '$conference_id' AND `FromName` = '$from_name' AND datetime >= '$mystarttime' AND datetime <= '$chat_starttime' " );
										if ( $get_total_chat_time ) {
											$chat_join_time = $chat_join_time + 5;
										}
									}
									$call_duration = $chat_join_time;
								}
								 $donate_sql_string = "SELECT * FROM $user_donation_Table WHERE `user_id`= '$logged_user_id'  AND start_time <= '" . $conference_start_date . "' AND end_time >= '" . $conference_start_date . "' ";
								$donate_result      = $wpdb->get_row( $donate_sql_string );

								// check domnation result
								if ( $donate_result ) {
									$donate_rate = $donate_result->donation_percentage;
								} else {
									$donate_rate = 0;
								}

								$call_duration = number_format( $call_duration, 2 );

								// if coupon is apply then get discount amount
								if ( $coupon_eligible == 'apply' ) {
									$discount_amount = ( ( $expert_rate * $call_duration ) * $coupon_percentage ) / 100;
								} else {
									$discount_amount = 0;
								}

									$donation_amount = ( ( ( $expert_rate * $call_duration ) - $discount_amount ) * $donate_rate ) / 100;
								if ( $call_duration == '0' || $call_duration == '' ) {
									$single_call_amount = 0;
									$discount_amount    = 0;
									$donation_amount    = 0;
								} else {
									$single_call_amount = ( ( $expert_rate * $call_duration ) - $discount_amount ) - $donation_amount;
								}

									// check payment status
									// if payment status is pending not show in main account
								if ( $refund_status == '0' ) {
									$total_pending_amount = $total_pending_amount + $single_call_amount;
									$refund_message       = 'Pending';
								} else {
									// payment completed

									$trcf_expert_call = $trcf_expert_call + $single_call_amount;
									$refund_message   = 'Completed';
								}
							}
							array_push( $output_data_array, array( 'CR ' . number_format( $trcf_expert_call, 2 ), 'CR ' . 0.00, 'Credits received by experts call', '' ) );
							//Credits received by experts call end
							// Credits received by experts call for future date (Where status is pending) start
							$sql_query = "(SELECT expert_rate, current_user_id, call_topic, team_id, conference_datetime, conference_type, conference_id, booking_status, estimated_length, booking_id, expert_ids, gmt_starttime, gmt_endtime, 'conference_booking', amount, coupone_code, refund_status FROM $setup_call_Table WHERE `expert_ids` REGEXP '([[:blank:][:punct:]]|^)$logged_user_id([[:blank:][:punct:]]|$)' AND booking_status = 'booked' AND gmt_endtime > '$current_date' AND conference_type in ('Video' , 'Voice' , 'Chat' , 'SMS')) UNION (SELECT expert_rate, userid, message, expertid, usertime, conference_type, conference_id, booking_status, '15', booking_id, expertid, gmt_starttime, gmt_endtime, 'booking', amount, coupon, refund_status FROM $billing_Table WHERE `expertid` REGEXP '([[:blank:][:punct:]]|^)$logged_user_id([[:blank:][:punct:]]|$)' AND booking_status = 0 AND gmt_endtime > '$current_date' AND conference_type in ('Video' , 'Voice' , 'Chat' , 'SMS')) ORDER BY gmt_starttime desc";

							$setup_call_results = $wpdb->get_results( $sql_query );
							foreach ( $setup_call_results  as $key => $call_result ) {
								$booking_status     = $call_result->booking_status;
								$conference_booking = $call_result->conference_booking;
								$conference_id      = $call_result->conference_id;
								$booking_id         = $call_result->booking_id;
								$conference_type    = $call_result->conference_type;
								$userInfo           = get_user_by( 'id', $logged_user_id );
								$start_gmt_time     = $call_result->gmt_starttime;
								$gmtstr             = strtotime( $start_gmt_time );
								$start_gmt_time     = date( 'Y-m-d H:i:s', $gmtstr );
								$expert_rate        = 0;
								$discount_amount    = 0;
								$donation_amount    = 0;
								$single_call_amount = 0;
								$from_name          = $userInfo->user_login;
								$refund_status      = $call_result->refund_status;
								$coupon_eligible    = 'NA';
								if ( $conference_booking == 'booking' ) {

									// discount coupon only for one to one call.
									if ( $call_result->coupone_code != '' ) {
										$coupone_code      = $call_result->coupone_code;
										$mypost            = get_page_by_title( $coupone_code, OBJECT, 'request_coupon' );
										$post_id           = $mypost->ID;
										$post_title        = $mypost->post_title;
										$coupon_percentage = get_post_meta( $post_id, '_coupon_percentage', true ); //
										// change coupon status
										$coupon_eligible = ( $coupon_percentage == '' ) ? 'NA' : 'apply';
									}
									$expert_rate         = $call_result->expert_rate;
									$conference_datetime = $call_result->conference_datetime;
									$timeexpload         = explode( '  ', $conference_datetime );
									$date                = $timeexpload[0];
									$time_check          = $timeexpload[1];
									$ex_time             = explode( '-', $time_check );
									$starttime           = $ex_time[0];
									$endtime             = $ex_time[1];
									$userstarttime       = $date . ' ' . $starttime;
									$userendtime         = $date . ' ' . $endtime;
									$date1               = strtotime( $userstarttime );
									$date2               = strtotime( $userendtime );
									$diff                = $date2 - $date1;
									$diff                = $diff / 60;
									$estimated_length    = $diff;
									$conferenceDateTime  = $userstarttime;

									$conference_start_date = date( 'm/d/Y', strtotime( $call_result->gmt_starttime ) );
									// get sms details
									$call_duration = ( $call_result->amount / $expert_rate );

								} elseif ( $conference_booking == 'conference_booking' ) {
									// Discount coupon is not eligible for conference call
									$expert_rate_array  = unserialize( $call_result->expert_rate );
									$expert_rate        = $expert_rate_array[ $logged_user_id ];
									$estimated_length   = $call_result->estimated_length;
									$conferenceDateTime = $call_result->conference_datetime;
									// change date formate for donation
									$conference_start_date = date( 'm/d/Y', strtotime( $call_result->gmt_starttime ) );
									$call_duration         = $estimated_length;
								}

								$donate_sql_string = "SELECT * FROM $user_donation_Table WHERE `user_id`= '$logged_user_id'  AND start_time <= '" . $conference_start_date . "' AND end_time >= '" . $conference_start_date . "' ";
								$donate_result     = $wpdb->get_row( $donate_sql_string );
								// check domnation result
								if ( $donate_result ) {
									$donate_rate = $donate_result->donation_percentage;
								} else {
									$donate_rate = 0;
								}

								$call_duration = number_format( (float) $call_duration, 2, '.', '' );

									// if coupon is apply then get discount amount
								if ( $coupon_eligible == 'apply' ) {
									$discount_amount = ( ( $expert_rate * $call_duration ) * $coupon_percentage ) / 100;
								} else {
									$discount_amount = 0;
								}

									$donation_amount             = ( ( ( $expert_rate * $call_duration ) - $discount_amount ) * $donate_rate ) / 100;
									$single_call_amount          = ( ( $expert_rate * $call_duration ) - $discount_amount ) - $donation_amount;
										$trcf_expert_call_future = $trcf_expert_call_future + $single_call_amount;
									$refund_message              = ( $refund_status == '0' ) ? 'Pending' : 'Completed';
							}
							array_push( $output_data_array, array( 'CR ' . number_format( $trcf_expert_call_future, 2 ), 'CR ' . 0.00, 'Credits received by experts future call. Note - This amount is not including in total amount.', '' ) );
							//Credits received by experts call for future date (Where status is pending) end
							//credits received by revoke method start
							$revoke_sql_query = "SELECT * FROM $credit_revoke_logs_Table WHERE `userid_to`= '$logged_user_id' ";
							$revoke_result    = $wpdb->get_results( $revoke_sql_query );
							foreach ( $revoke_result  as $key => $revoke ) {
								$trcf_revoke = $trcf_revoke + $revoke->credits_revoked;
							}
							array_push( $output_data_array, array( 'CR ' . number_format( $trcf_revoke, 2 ), 'CR ' . 0.00, 'Credits received by Users (Revoke method)', '' ) );
							//credits received by revoke method end
							// Money Out
							// Credits expenese/out/transer to company start
							$all_expense_credits = $wpdb->get_results( "SELECT * FROM $credit_allotment_logs_Table WHERE `userid` REGEXP '([[:blank:][:punct:]]|^)$logged_user_id([[:blank:][:punct:]]|$)' " );
							foreach ( $all_expense_credits  as $key => $expense_credits ) {
								if ( $expense_credits->allocation_status == 'director_allocated' ) {
									$tect_company = $tect_company + $expense_credits->credits_alloted;
								}
							}

							array_push( $output_data_array, array( 'CR ' . 0.00, 'CR ' . number_format( $tect_company, 2 ), 'Credits Transfer to Company', '' ) );
							// Credits expenese/out/transer to company end

							//credits expense from director/admin revoke method start
							$revoke_sql_query = "SELECT * FROM $credit_revoke_logs_Table WHERE `revoked_userids`= '$logged_user_id' ";
							$revoke_result    = $wpdb->get_results( $revoke_sql_query );
							foreach ( $revoke_result  as $key => $revoke ) {
								$tect_revoke = $tect_revoke + $revoke->credits_revoked;
							}
							array_push( $output_data_array, array( 'CR ' . 0.00, 'CR ' . number_format( $tect_revoke, 2 ), 'Credits revoked by group owner', '' ) );
							//credits expense from director/admin revoke method end

							//credits expense by credit to currency conversion method start
							$cc_results = $wpdb->get_results( "SELECT * FROM $conversion_log_Table WHERE `user_id`= '$logged_user_id' ORDER BY `id` DESC " );

							foreach ( $cc_results  as $cc_result ) {
								$tect_converted_currency = $tect_converted_currency + $cc_result->credits;
							}
							array_push( $output_data_array, array( 'CR ' . 0.00, 'CR ' . number_format( $tect_converted_currency, 2 ), 'Credits to currency conversion', '' ) );
							//credits expense by credit to currency conversion method end

							//Credits expense to experts call start
							$sql_query = "(SELECT expert_rate, current_user_id, call_topic, team_id, conference_datetime, conference_type, conference_id, booking_status, estimated_length, booking_id, expert_ids, gmt_starttime, 'conference_booking', amount, coupone_code, payment_gateway, transactionid FROM $setup_call_Table WHERE `current_user_id` = '$logged_user_id' AND booking_status = 'booked' AND conference_type in ('Video' , 'Voice' , 'Chat' , 'SMS')) UNION (SELECT expert_rate, userid, message, expertid, usertime, conference_type, conference_id, booking_status, '15', booking_id, expertid, gmt_starttime, 'booking', amount, coupon, payment_gateway, transactionid FROM $billing_Table WHERE `userid` = '$logged_user_id' AND booking_status = 0 AND conference_type in ('Video' , 'Voice' , 'Chat' , 'SMS')) ORDER BY gmt_starttime desc";

							$expense_expert_bookings = $wpdb->get_results( $sql_query );
							foreach ( $expense_expert_bookings as $key => $expert_booking ) {

										$transactionid   = $expert_booking->transactionid;
										$payment_gateway = $expert_booking->payment_gateway;
										//$paymentstatus = $expert_booking->paymentstatus;
										$booking_id     = $expert_booking->booking_id;
										$booking_belong = $expert_booking->conference_booking;

										$total_paid_amount   = 0;
										$call_type           = $expert_booking->conference_type;
										$expert_amount       = $expert_booking->amount;
										$final_expert_amount = number_format( (float) $expert_amount, 2, '.', '' );
										$call_topic          = $expert_booking->call_topic;

										$booking_status = 'booked';
										//$status = $expert_booking->completed;
										$refund_query_string = "SELECT `amount` FROM $admin_transection_logs_Table WHERE `user_id`= '$logged_user_id' AND `transaction_type` = 'Outgoing' AND `orderid` = '$booking_id' ";

										$get_refund_amount = $wpdb->get_var( $refund_query_string );
								if ( $booking_belong == 'conference_booking' ) {
									$team_id          = $expert_booking->team_id;
									$team_name        = $wpdb->get_var( $wpdb->prepare( "SELECT team_name FROM $team_table WHERE id= %d", $team_id ) );
									$confernce_time   = $expert_booking->conference_datetime;
									$conf_str         = strtotime( $confernce_time );
									$start_time       = date( 'h:i A', $conf_str );
									$estimate_seconds = $estimate_length * 60;
									$end_booking_str  = $conf_str + $estimate_seconds;
									$end_time         = date( 'h:i A', $end_booking_str );
									$nowtime          = date( 'm/d/Y', $conf_str );

									$call_time = $start_time . '-' . $end_time;

								} else {
									$team_id = $expert_booking->team_id;
									//$user_id = $expert_booking->userid;
									$expert_first_name = get_user_meta( $team_id, 'first_name', true );
									$expert_lastname   = get_user_meta( $team_id, 'last_name', true );
									//$user_firstname =  get_user_meta($user_id, 'first_name', true);
									//$user_lastname = get_user_meta($user_id, 'last_name', true);
									$team_name = $expert_first_name . ' ' . $expert_lastname;
									//$user_full_name = $user_firstname." ".$user_lastname;
									$usertime     = $expert_booking->conference_datetime;
									$divide_time  = explode( '  ', $usertime );
									$mybefstr     = $divide_time[0];
									$afterstrtime = strtotime( $mybefstr );
									$nowtime      = date( 'm/d/Y', $afterstrtime );
									$call_time    = $divide_time[1];

								}
								if ( $get_refund_amount == '' ) {
									$get_refund_amount = 0;
								}
										$net_paid_amount   = ( $expert_amount - $get_refund_amount );
										$final_paid_amount = $net_paid_amount;
										$tect_expert_call  = $tect_expert_call + $final_paid_amount;
							}
							array_push( $output_data_array, array( 'CR ' . 0.00, 'CR ' . number_format( $tect_expert_call, 2 ), 'Credits expenses for experts call', '' ) );
							//Credits expense to experts call end
							//Credits Expense (donation ) by host during exppert calls start
							$sql_query = "(SELECT expert_rate, current_user_id, call_topic, team_id, conference_datetime, conference_type, conference_id, booking_status, estimated_length, booking_id, expert_ids, gmt_starttime, gmt_endtime, 'conference_booking', amount, coupone_code, refund_status FROM $setup_call_Table WHERE `expert_ids` REGEXP '([[:blank:][:punct:]]|^)$logged_user_id([[:blank:][:punct:]]|$)' AND booking_status = 'booked' AND gmt_endtime <= '$current_date' AND conference_type in ('Video' , 'Voice', 'SMS', 'Chat')) UNION (SELECT expert_rate, userid, message, expertid, usertime, conference_type, conference_id, booking_status, '15', booking_id, expertid, gmt_starttime, gmt_endtime, 'booking', amount, coupon, refund_status FROM $billing_Table WHERE `expertid` REGEXP '([[:blank:][:punct:]]|^)$logged_user_id([[:blank:][:punct:]]|$)' AND booking_status = 0 AND gmt_endtime <= '$current_date' AND conference_type in ('Video' , 'Voice', 'SMS' , 'Chat')) ORDER BY gmt_starttime desc";

							$setup_call_results = $wpdb->get_results( $sql_query );
							foreach ( $setup_call_results  as $key => $call_result ) {
								$booking_status       = $call_result->booking_status;
								$booking_id           = $call_result->booking_id;
								$conference_booking   = $call_result->conference_booking;
								$conference_id        = $call_result->conference_id;
								$conference_type      = $call_result->conference_type;
								$start_gmt_time       = $call_result->gmt_starttime;
								$userInfo             = get_user_by( 'id', $logged_user_id );
								$expert_rate          = 0;
								$discount_amount      = 0;
								$donation_amount      = 0;
								$single_call_amount   = 0;
								$total_pending_amount = 0;
								$from_name            = $userInfo->user_login;
								$refund_status        = $call_result->refund_status;
								$coupon_eligible      = 'NA';
								$call_string          = "SELECT sum(duration) as total_duration from $user_call_status_table WHERE conference_id = '" . $conference_id . "' AND from_name = '$from_name'";

								$call_detail = $wpdb->get_results( $call_string );
								// calculate total call duration in minuts
								$call_duration = $call_detail[0]->total_duration / 60;
								// booked means one to one call
								if ( $conference_booking == 'booking' ) {

									// discount coupon only for one to one call.
									if ( $call_result->coupone_code != '' ) {
										$coupone_code = $call_result->coupone_code;
										$mypost       = get_page_by_title( $coupone_code, OBJECT, 'request_coupon' );
										if ( ! empty( $mypost ) ) {
											$post_id           = $mypost->ID;
											$post_title        = $mypost->post_title;
											$coupon_percentage = get_post_meta( $post_id, '_coupon_percentage', true ); //
											// change coupon status
											$coupon_eligible = ( $coupon_percentage == '' ) ? 'NA' : 'apply';
										}
									}
									$expert_rate         = $call_result->expert_rate;
									$conference_datetime = $call_result->conference_datetime;
									$timeexpload         = explode( '  ', $conference_datetime );
									$date                = $timeexpload[0];
									$time_check          = $timeexpload[1];
									$ex_time             = explode( '-', $time_check );
									$starttime           = $ex_time[0];
									$endtime             = $ex_time[1];
									$userstarttime       = $date . ' ' . $starttime;
									$userendtime         = $date . ' ' . $endtime;
									$date1               = strtotime( $userstarttime );
									$date2               = strtotime( $userendtime );
									$diff                = $date2 - $date1;
									$diff                = $diff / 60;
									$estimated_length    = $diff;
									$conferenceDateTime  = $userstarttime;
									// change date formate for donation
									$conference_start_date = date( 'm/d/Y', strtotime( $call_result->gmt_starttime ) );

								} elseif ( $conference_booking == 'conference_booking' ) {
									// Discount coupon is not eligible for conference call
									$expert_rate_array  = unserialize( $call_result->expert_rate );
									$expert_rate        = $expert_rate_array[ $logged_user_id ];
									$estimated_length   = $call_result->estimated_length;
									$conferenceDateTime = $call_result->conference_datetime;
									// change date formate for donation
									$conference_start_date = date( 'm/d/Y', strtotime( $call_result->gmt_starttime ) );

								}

								if ( $conference_type == 'SMS' ) {
									$twillo_sql_query = "SELECT * FROM `wp68_bp_xprofile_data` WHERE `user_id`= '" . $logged_user_id . "' AND `field_id` = '279' ";
									$twillo_results   = $wpdb->get_results( $twillo_sql_query );
									foreach ( $twillo_results as $Numberdetails ) {
										$UserphoneNumber = $Numberdetails->value;

									}
									$sms_join_time = 0;
									for ( $i = 0; $i < ( $estimated_length / 5 ); $i++ ) {
										if ( $i == 0 ) {
											$sms_starttime = $start_gmt_time;
										}
										$conference_start = $sms_starttime;
										$increse_gmt      = $gmtstr + ( 5 * 60 );
										$sms_starttime    = date( 'Y-m-d H:i:s', $increse_gmt );
										$gmtstr           = strtotime( $sms_starttime );

										$get_total_sms_time = $wpdb->get_var( "SELECT COUNT(*) FROM $sms_incomingSMS_table WHERE `conference_id` = '$conference_id' AND `FromNumber` = '$UserphoneNumber' AND datetime >= '$conference_start' AND datetime <= '$sms_starttime' " );
										if ( $get_total_sms_time ) {
											$sms_join_time = $sms_join_time + 5;
										}
									}
									$call_duration = $sms_join_time;
								} elseif ( $conference_type == 'Chat' ) {
									$twillo_sql_query = "SELECT * FROM `wp68_bp_xprofile_data` WHERE `user_id`= '" . $logged_user_id . "' AND `field_id` = '279' ";
									$twillo_results   = $wpdb->get_results( $twillo_sql_query );
									foreach ( $twillo_results as $Numberdetails ) {
										$UserphoneNumber = $Numberdetails->value;
									}
									$chat_join_time = 0;
									for ( $i = 0; $i < ( $estimated_length / 5 ); $i++ ) {
										if ( $i == 0 ) {
											$chat_starttime = $start_gmt_time;
										}
										$mystarttime         = $chat_starttime;
										$increse_gmt         = $gmtstr + ( 5 * 60 );
										$chat_starttime      = date( 'Y-m-d H:i:s', $increse_gmt );
										$gmtstr              = strtotime( $chat_starttime );
										$get_total_chat_time = $wpdb->get_var( "SELECT COUNT(*) FROM $chat_conference_table WHERE `conference_id` = '$conference_id' AND `FromName` = '$from_name' AND datetime >= '$mystarttime' AND datetime <= '$chat_starttime' " );
										if ( $get_total_chat_time ) {
											$chat_join_time = $chat_join_time + 5;
										}
									}
									$call_duration = $chat_join_time;
								}
								 $donate_sql_string = "SELECT * FROM $user_donation_Table WHERE `user_id`= '$logged_user_id'  AND start_time <= '" . $conference_start_date . "' AND end_time >= '" . $conference_start_date . "' ";
								$donate_result      = $wpdb->get_row( $donate_sql_string );

								if ( $donate_result ) {
									$donate_rate = $donate_result->donation_percentage;
								} else {
									$donate_rate = 0;
								}


								$call_duration = number_format( $call_duration, 2 );
								// if coupon is apply then get discount amount
								if ( $coupon_eligible == 'apply' ) {
									$discount_amount = ( ( $expert_rate * $call_duration ) * $coupon_percentage ) / 100;
								} else {
									$discount_amount = 0;
								}

									$donation_amount = ( ( ( $expert_rate * $call_duration ) - $discount_amount ) * $donate_rate ) / 100;

								if ( $call_duration == '0' || $call_duration == '' ) {
									$single_call_amount = 0;
									$discount_amount    = 0;
									$donation_amount    = 0;
								} else {
									$single_call_amount = ( ( $expert_rate * $call_duration ) - $discount_amount ) - $donation_amount;
								}
									// check payment status
									// if payment status is pending not show in main account
								if ( $refund_status == '0' ) {
									$total_pending_amount = $total_pending_amount + $donation_amount;
									$refund_message       = 'Pending';
								} else {
									// payment completed

									$tect_donation  = $tect_donation + $donation_amount;
									$refund_message = 'Completed';
								}
							}
							array_push( $output_data_array, array( 'CR ' . 0.00, 'CR ' . number_format( $tect_donation, 2 ), 'Credit Expense (Donations)', '' ) );
							//Credits Expense (donation ) by host during exppert calls end

							//Credits Expense for shop order details start
							$user_id = get_current_user_id();
							// The query arguments
							$args            = array(
								'post_type'   => 'shop_order',
								'post_status' => array( 'wc-completed', 'wc-processing' ),
								'numberposts' => -1,
								'meta_key'    => '_customer_user',
								'meta_value'  => $user_id,
							);
							$customer_orders = get_posts( $args );

							foreach ( $customer_orders as $customer_order ) :
								// foreach ( $customer_orders->orders as $customer_order ) :

								$order                   = wc_get_order( $customer_order );
								$item_count              = $order->get_item_count();
								$order_items             = $order->get_items();
								$buy_credit_type_product = 0;

								foreach ( $order_items as $order_item_id => $order_item ) {
									$item_name  = $order_item['name'];
									$product_id = $order_item['product_id'];
									$term_list  = wp_get_post_terms( $product_id, 'product_cat', array( 'fields' => 'ids' ) );
									// check product is exists 61 category
									if ( isset( $term_list[0] ) && $term_list[0] == '61' ) {
										$buy_credit_type_product = 1;
									}
								}
								$order_id       = $order->get_order_number();
								$transection_id = get_post_meta( $order_id, '_transaction_id' );

								$method_name = get_post_meta( $order_id, '_payment_method', true );
								// buy_credit_type_product is zero mean this order is not buy credits
								if ( $buy_credit_type_product == 1 ) {
									continue;
								}
								$order_payment_method_name = ( $method_name == 'credits_gateway' ) ? 'Credits' : $method_name;
								if ( $order_payment_method_name != 'Credits' ) {
									continue;
								}
								$tect_shop = $tect_shop + $order->get_total();
			endforeach;
							array_push( $output_data_array, array( 'CR ' . 0.00, 'CR ' . number_format( $tect_shop, 2 ), 'Credits Expense by Shop', '' ) );
							//Credits Expense for shop order details end

							// calculate total money IN
							$total_credits_in = $trcf_purchased_shop + $trcf_expert_call + $trcf_director + $trcf_admin + $trcf_registration + $trcf_revoke;

							// calculate total money OUT
							$total_credits_out = $tect_company + $tect_donation + $tect_expert_call + $tect_shop + $tect_revoke + $tect_converted_currency;
							// calculate net balance
							$net_credits_balance = $total_credits_in - $total_credits_out;
							array_push( $output_data_array, array( '', '', '', '' ) ); // add extra row
							array_push( $output_data_array, array( '', '', '', '' ) ); // add extra row
							array_push( $output_data_array, array( 'TOTAL MONEY IN', 'TOTAL MONEY OUT', 'Net Balance', '' ) ); // add extra row
							array_push( $output_data_array, array( 'CR ' . number_format( $total_credits_in, 2 ), 'CR ' . number_format( $total_credits_out, 2 ), '', 'CR ' . number_format( $net_credits_balance, 2 ) ) );

							foreach ( $output_data_array as $key => $value ) {
								fputcsv( $fp, $value );
							}

							exit;


