<?php
include '../../../../wp-config.php';
global $wpdb;
$biling_table = $wpdb->prefix.'BillingInformation';
$conf_table = $wpdb->prefix.'setup_conference_call';
$call_table = $wpdb->prefix.'user_call_status';
$pricetable = $wpdb->prefix.'expert_price';
$booking_id = $_REQUEST['booking_id'];
$timezone = $_GET['timezone'];
$main = array();
	$current_login_id = get_current_user_id(); 
	$current_user_city = bp_get_profile_field_data('field=City&user_id='.$current_login_id);
	$current_user_country = bp_get_profile_field_data('field=Country&user_id='.$current_login_id);
    $current_user_timezone = unserialize(get_user_meta($current_login_id, "user_timezone_detail", TRUE));
	$mytimezone_id = $current_user_timezone['timeZoneId'];

$statusquery = $wpdb->get_results("(SELECT team_id, call_topic , conference_datetime, conference_type, conference_id, booking_status, estimated_length, booking_id, time_zone, expert_ids, 'conference_booking' FROM $conf_table WHERE booking_id =$booking_id) UNION (SELECT expertid, message, usertime, 'voice', conference_id, booking_status, '15', booking_id, 'Asia/Calcutta', expertid, 'booking' FROM $biling_table WHERE booking_id = $booking_id) ORDER BY team_id desc");

foreach($statusquery as $ex_value)
{
	$confernce_time  = $ex_value->conference_datetime;
	$estimate_length = 	$ex_value->estimated_length;
	$timezone_id_initial = $ex_value->time_zone;
	$id_experts = $ex_value->expert_ids;
	$conference_id = $ex_value->conference_id;
	$expertarray = explode(",",$id_experts);
	//$timezone_id_initial = explode(" ",$timezone_id_initial);
	$booking_belong = $ex_value->conference_booking;
	$countexpert = $ex_value->team_id;
	
	$expertcity = bp_get_profile_field_data('field=City&user_id='.$countexpert);
				
	$expertcountry = bp_get_profile_field_data('field=Country&user_id='.$countexpert);
   
	if($booking_belong == "conference_booking")
	{
		$saved_timezone_id = $timezone_id_initial;
	}
	else
	{
		$expert_user_timezone = unserialize(get_user_meta($countexpert, "user_timezone_detail", TRUE));
    	$saved_timezone_id = $expert_user_timezone['timeZoneId'];
	}

	$timezone_id = $mytimezone_id;	
	$date = new DateTime("now", new DateTimeZone($timezone_id) );
	
	$current_date = $date->format('Y-m-d h:i A');

	$current_time = strtotime($current_date);
	if($booking_belong == "conference_booking")
	{
		$con_confernce_time = new DateTime($confernce_time, new DateTimeZone($saved_timezone_id));
		$con_confernce_time->format('Y-m-d h:i A');
		$con_confernce_time->setTimezone(new DateTimeZone($timezone_id));
		$booking_time_str = strtotime($con_confernce_time->format('Y-m-d h:i A'));	
		$start_time = date('h:i A', $booking_time_str);
		$estimate_seconds = $estimate_length*60;
		$end_booking_str = $booking_time_str + $estimate_seconds;
		$end_time = date('h:i A', $end_booking_str);
		$price=0;
		foreach($expertarray as $expertid):
		   $credit_price = $wpdb->get_var("SELECT `price` FROM $pricetable WHERE user_id=$expertid");
		   $price += $credit_price;
		endforeach;
	
	}
	else
	{	
		$price= $wpdb->get_var( $wpdb->prepare("SELECT price FROM $pricetable WHERE user_id= %d", $countexpert) );
		$user_expert_time = $ex_value->conference_datetime;
		$timeexpload = explode("  ", $user_expert_time);
		$date_ext = $timeexpload[0];
		$time_ext = $timeexpload[1];
		$time_ext = explode("-", $time_ext);
		$ex_start_time =  $date_ext." ". $time_ext[0];
		$ex_end_time  = $date_ext." ". $time_ext[1];								
		$con_ex_start_time = new DateTime($ex_start_time, new DateTimeZone($saved_timezone_id));
		$con_ex_start_time->format('F j, Y h:i A');
		$con_ex_start_time->setTimezone(new DateTimeZone($timezone_id));						
		$new_ex_start_time = $con_ex_start_time->format('F j, Y h:i A');
		$con_ex_end_time = new DateTime($ex_end_time, new DateTimeZone($saved_timezone_id));
		$con_ex_end_time->format('F j, Y h:i A');
		$con_ex_end_time->setTimezone(new DateTimeZone($timezone_id));
										
		$new_ex_end_time = $con_ex_end_time->format('F j, Y h:i A');		
		$booking_time_str = strtotime($new_ex_start_time);
		$start_time = date('h:i A', $booking_time_str);		
		$end_booking_str = strtotime($new_ex_end_time);
		$end_time = date('h:i A', $end_booking_str);	
		$ex_start_str = strtotime($new_ex_start_time);
		$ex_end_str = strtotime($new_ex_end_time);
		$diff = abs($ex_start_str - $ex_end_str);
	}
	$popup_str = $end_booking_str - 120 ;
	
	$popuptime = date('h:i A', $popup_str);
	if($current_time == $popup_str)
	{
		$status = "payement";
		$main['status'] = $status;
	}
	else if($current_time == $end_booking_str)
	{
		$status = "callend";
		$main['status'] = $status;
	}
	else
	{
		$main['status'] = '0';
	}
	$attendies = array();
	$attendies_img = array();
	$attend_user = $wpdb->get_results("SELECT from_name FROM $call_table WHERE conference_id = '$conference_id' AND duration = '0'");
	foreach($attend_user as $userattends)
	{
		$attendusername = $userattends->from_name;
		$userdetails = get_user_by('login',$attendusername);
		$attendiesid = $userdetails->ID;
		$attendies[$attendiesid] = $attendusername;
		$image_url =  bp_get_activity_avatar(array('user_id' => $attendiesid));
		$src = (string) reset(simplexml_import_dom(DOMDocument::loadHTML($image_url))->xpath("//img/@src"));
		$image_url = $src;
		$attendies_img[$attendiesid] = $image_url;
	}
	$main['userattend'] = $attendies;
	$main['profileimage'] = $attendies_img;
}

$main['current'] = $current_time;
$main['pop'] = $popup_str;
$main['end_booking_str'] = $end_booking_str;
echo json_encode($main);
?>