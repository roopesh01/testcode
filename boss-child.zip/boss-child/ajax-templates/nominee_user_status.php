<?php 
include '../../../../wp-config.php';
global $wpdb,$current_user;
$table = $wpdb->prefix."nominee_details";
$list_table = $wpdb->prefix."nominee_list";
$list_vote_table = $wpdb->prefix."nominee_list_vote";
$user_id = $current_user->ID;
$role = $_POST['user_role'];
$email = trim($_POST['email']);
if(email_exists($email))
{
	// this user is iis user
	echo "Already IIS user. So you can't change user status.";
	exit();
}
$row_id = trim($_POST['row_id']);
$admin_note = $_POST['review_admin'];
$user_status = $_POST['user_status'];
$action = $_POST['action'];
$recordid = $_POST['record_id'];
$review = $_POST['review'];
if($action == "user_stauts")
{
	if($user_status == "accept")
	{
		$user_detail = $wpdb->get_results("SELECT * FROM $table WHERE emailid='$email' AND id='$row_id'");
		
		$first_name = $user_detail[0]->firstname;
		$middlename = $user_detail[0]->middlename;
		$lastname = $user_detail[0]->lastname;
		$company = $user_detail[0]->company;
		$job_title = $user_detail[0]->jobtitle;
		$bio = $user_detail[0]->description;
		$file_name = $user_detail[0]->profile_url;
		$work_experience = $user_detail[0]->work_experience;
		$nominator_id = $user_detail[0]->member_id;
		$update = $wpdb->query("UPDATE $table SET user_status='$user_status', admin_review_note='$admin_note' WHERE emailid='$email' AND id='$row_id' ");
		
		// $status_update = $wpdb->query("UPDATE $table SET ad_approved_userstatus='$role' WHERE emailid='$email' AND role_selected='$role'");
		
		$data = array( 
		'firstname' => $first_name, 
		'middlename' => $middlename,
		'lastname' => $lastname,
		'emailid' => $email,
		'company' => $company,
		'jobtitle' => $job_title,
		'description' => $bio,
		'work_experience' => $work_experience,
		'profile_url' => $file_name,
		'user_status' => $user_status,
		'nominee_decision' => '',
		'nominator_id' => $nominator_id
	);
	
		$format = array( 
			'%s',
			'%s', 
			'%s',
			'%s',
			'%s',
			'%s',
			'%s',
			'%s',
			'%s',
			'%s',
			'%s',
			'%s'
		); 
		$insert_sql = $wpdb->insert($list_table, $data, $format);
	
		if($update >= 1 && $insert_sql == 1)
		{
			echo "Comment Saved Successfully.";
			exit();
		}
		else   
		{
			echo 'Record Not Updated.';
			exit();
		}	
	}
	else
	{
		if($user_status == "declined")
		{
			
			$update = $wpdb->query("UPDATE $table SET user_status='$user_status', admin_review_note='$admin_note' WHERE emailid='$email' AND id='$row_id'");
			$delete = $wpdb->query("DELETE FROM $list_table WHERE emailid='$email' ");
			if($update >= 1)
			{
				echo "Status Changed Successfully.";
				exit();
			}
			else   
			{
				echo 'Changes Not Saved.';
				exit();
			}
			
			
		}
		else
		{
			$update = $wpdb->query("UPDATE $table SET user_status='$user_status', admin_review_note='$admin_note' WHERE emailid='$email' AND id='$row_id'");
			$delete = $wpdb->query("DELETE FROM $list_table WHERE emailid='$email'");
			if($update >= 1)
			{
				echo "Comment Saved Successfully.";
				exit();
			}
			else   
			{
				echo 'Record Not Updated.';
				exit();
			}
			
		}		
	}
	
}
else if($action == "second_user")
{
	$list_table = $wpdb->prefix."nominee_list_vote";
	$update = $wpdb->query("UPDATE $list_table SET review_status='$review' WHERE id='$recordid'");
	if($update == 1)
	{
		echo "Changes Saved Successfully.";
		exit();
	}
	else   
	{
		echo 'Changes Not Updated.';
		exit();
	}
	
}
// else
// {
	
// 	$update = $wpdb->query("UPDATE $table SET review_status='$review' WHERE id='$recordid'");
// 	if($update == 1)
// 	{
// 		echo "Changes Saved Successfully.";
// 	}
// 	else   
// 	{
// 		echo 'Changes Not Updated.';
// 	}
	
// }