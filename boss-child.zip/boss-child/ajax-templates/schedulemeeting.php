<?php
include '../../../../wp-config.php';
global $wpdb;
$venuetable = $wpdb->prefix.'venuedetail';
$currentuserid = get_current_user_id();

if(isset($_POST['venuedate']) || isset($_POST['venuetime']) || isset($_POST['meetinglocation']) || isset($_POST['address']) || isset($_POST['user_email']) || isset($_POST['cell_phones']))
{
    $venuedate = $_POST['venuedate'];    
    $venuetime = $_POST['venuetime'];
    $meetinglocation = $_POST['meetinglocation'];
    $address = $_POST['address'];
    $venuezip = $_POST['venuezip'];
    $virtualdetail = $_POST['virtualdetail'];
    $meetingdetail = $_POST['meetingdetail'];
    $radioValue = $_POST['radioValue'];
    
    //print_r($_POST);
   
    if($radioValue=='livevenue')
    {
        $wpdb->insert(
        $venuetable,
        array(
        'currentuserid'=>$currentuserid,
        'venuedate'=>$venuedate,
        'venuetime'=>$venuetime,
        'venuename'=>$meetinglocation,
        'address' =>$address,
        'venuezip'=>$venuezip,
        'howtofind'=>$meetingdetail
        ),
        array(
            '%d','%s','%s','%s','%s','%s','%s'
        )
        );
        
    }
    else
    {
        $wpdb->insert(
        $venuetable,
        array(
        'currentuserid'=>$currentuserid,
        'venuedate'=>$venuedate,
        'venuetime'=>$venuetime,        
        'virtualmeetinginfo' =>$virtualdetail,
        'howtofind'=>$meetingdetail
        ),
        array(
            '%d','%s','%s','%s','%s','%s','%s'
        )
        );
        
    }
}







?>