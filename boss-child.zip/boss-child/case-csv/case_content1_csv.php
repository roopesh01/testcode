<?php
	include '../../../../wp-config.php';
	global $wpdb;
	$filename   = 'case_content_level1.csv';
	$header_row = array(
		0 => 'id',
		1 => 'content_id',
		2 => 'parent_id',
		3 => 'user_category',
		4 => 'user_tags',
		5 => 'user_tag_notes',
		6 => 'type',
		7 => 'link',
	);
	$data_rows  = array();
	$table      = $wpdb->prefix . 'case_content_level1';
	$result     = $wpdb->get_results( "SELECT * FROM $table" );
	foreach ( $result as $results ) {
		$row         = array();
		$row[0]      = $results->id;
		$row[1]      = $results->content_id;
		$row[2]      = $results->parent_id;
		$row[3]      = $results->user_category;
		$row[4]      = $results->user_tags;
		$row[5]      = $results->user_tag_notes;
		$row[6]      = $results->type;
		$row[7]      = $results->link;
		$data_rows[] = $row;
	}
	$fh = @fopen( 'php://output', 'w' );
	fprintf( $fh, chr( 0xEF ) . chr( 0xBB ) . chr( 0xBF ) );
	header( 'Cache-Control: must-revalidate, post-check=0, pre-check=0' );
	header( 'Content-Description: File Transfer' );
	header( 'Content-type: text/csv' );
	header( "Content-Disposition: attachment; filename={$filename}" );
	header( 'Expires: 0' );
	header( 'Pragma: public' );
	fputcsv( $fh, $header_row );
	foreach ( $data_rows as $data_row ) {
		fputcsv( $fh, $data_row );
	}
	fclose( $fh );
	die();



