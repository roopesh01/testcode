<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        
        <link href="http://iisv2.crmmasterdev.wpengine.com/wp-content/themes/boss-child/css/jquery-ui.css" rel='stylesheet'/>
        <script src="http://iisv2.crmmasterdev.wpengine.com/wp-content/themes/boss-child/js/d3.v4.js"></script>
        <script  src="https://code.jquery.com/jquery-3.2.1.min.js"            integrity="sha256-hwg4gsxgFZhOsEEamdOYGBf13FyQuiTwlAQgxVSNgt4="
        crossorigin="anonymous"></script>
        <script src="http://iisv2.crmmasterdev.wpengine.com/wp-content/themes/boss-child/js/jquery-ui-1.11.2.js"></script>
        <style>
            .hierarchy-level{
                display: inline-block;
                width: 200px;
                margin: 0px 20px;
            }
            .node circle {
                fill: #fff;
                stroke-width: 1px;
            }

            .node text {
                font: 12px sans-serif;
            }

            .link {
                fill: none;
                stroke: #ccc;
                stroke-width: 1px;
            }

            #toolTip{
                display:none;
                position: absolute;
                display: block;        
            }
            #toolTip ul{
                list-style-type: none;
                padding: 5px 10px;
                background: #d0e8f9;
                border-radius: 4px;
            }

            svg{
                width:100%;
            }
        </style>
    </head>
    <body>


        <div id="plotingArea">
            <label><input type="radio" name="mode" value="cluster" checked> Dendrogram</label>
            <label><input type="radio" name="mode" value="tree"> Tree</label>
            <!--        <label><input type="radio" name="mode" value="hierarchy"> Hierarchy</label>-->
            <label>Search Node <input type="text" value="" ></label>            
            <div  class='iis-slider hierarchy-level' data-min='1' data-max='10' data-value='5'>
                <div  class="ui-slider-handle"></div>
            </div>
            <label><input type="button" name="reset" value="referesh" id="reset"></label>
        </div>
        <div id="toolTip"></div>
        <script>
            var i = 0, duration = 750, parent = "#plotingArea";
            var margin = {top: 20, right: 90, bottom: 30, left: 90}, width = 960 - margin.left - margin.right, height = 800 - margin.top - margin.bottom;
            var svg = d3.select(parent).append("svg").attr("width", width + margin.right + margin.left)
                    .attr("height", height + margin.top + margin.bottom).append("g")
                    .attr("transform", "translate(" + margin.left + "," + margin.top + ")");
            var modes = {};


            d3.json("http://iisv2.crmmasterdev.wpengine.com/wp-content/themes/boss-child/d3-graph/flare.json", function (error, flare) {
                if (error)
                    throw error;
                currentDataSet = flare;
                modes.tree = function (initialData) {
                    currentDataSet = initialData;
                    var ctrlKey = false, hirarchiLevel = 5, root, nodeUpdate, linkUpdate, currentNode;
                    var treemap = d3.tree().size([height, width - 160]), cluster = d3.cluster().size([height, width - 160]), behavior = {};
                    behavior.collapse = collapse;
                    behavior.showDetails = showDetails;
                    behavior.diagonal = diagonal;
                    behavior.nodeClicked = nodeClicked;
                    behavior.changeGraphMode = changeGraphMode;
                    behavior.searchNode = searchNode;
                    behavior.buildGraph = buildGraph;
                    behavior.init = init;
                    function buildGraph(data, source) {
                        if (!source) {
                            root = d3.hierarchy(data, function (d) {
                                return d.children;
                            });
                            root.x0 = height / 2;
                            root.y0 = 0;
                            source = root;
                        }
                        var treeData = treemap(root);
                        var nodes = treeData.descendants(), links = treeData.descendants().slice(1);
                        nodes.forEach(function (d) {
                            d.y = d.depth * 180
                        });

                        nodes = nodes.filter(function (d) {
                            if (d.depth >= hirarchiLevel) {
                                return false;
                            } else {
                                return true;
                            }
                        });

                        links = links.filter(function (d) {
                            if (d.depth >= hirarchiLevel) {
                                return false;
                            } else {
                                return true;
                            }
                        });
                        var node = svg.selectAll('g.node').data(nodes, function (d) {
                            return d.id || (d.id = ++i);
                        });

                        var nodeEnter = node.enter().append('g').attr('class', 'node').on('click', behavior.nodeClicked)
                                .attr("transform", function (d) {
                                    return "translate(" + source.y0 + "," + source.x0 + ")";
                                });

                        nodeEnter.append('circle').attr('class', 'node').attr('r', 1e-6).style("fill", function (d) {
                            return d._children ? "lightsteelblue" : "#fff";
                        }).attr("stroke", "steelblue").on("mouseout", function () {
                            $("#toolTip").hide();
                        }).on("mousemove", behavior.showDetails);

                        nodeEnter.append('text').attr("dy", ".35em").attr("x", function (d) {
                            return d.children || d._children ? -13 : 13;
                        }).attr("text-anchor", function (d) {
                            return d.children || d._children ? "end" : "start";
                        }).text(function (d) {
                            return d.data.name;
                        });

                        nodeUpdate = nodeEnter.merge(node);

                        nodeUpdate.transition().duration(duration).attr("transform", function (d) {
                            return "translate(" + d.y + "," + d.x + ")";
                        });

                        nodeUpdate.select('circle.node').attr('r', 4.5).style("fill", function (d) {
                            return d._children ? "lightsteelblue" : "#fff";
                        }).attr('cursor', 'pointer');

                        var nodeExit = node.exit().transition().duration(duration).attr("transform", function (d) {
                            return "translate(" + source.y + "," + source.x + ")";
                        }).remove();

                        nodeExit.select('circle').attr('r', 1e-6);

                        nodeExit.select('text').style('fill-opacity', 1e-6);

                        var link = svg.selectAll('path.link').data(links, function (d) {
                            return d.id;
                        });

                        var linkEnter = link.enter().insert('path', "g").attr("class", "link").attr('d', function (d) {
                            var o = {x: source.x0, y: source.y0}
                            return diagonal(o, o)
                        });

                        linkUpdate = linkEnter.merge(link);

                        linkUpdate.transition().duration(duration).attr('d', function (d) {
                            return diagonal(d, d.parent)
                        });

                        var linkExit = link.exit().transition().duration(duration).attr('d', function (d) {
                            var o = {x: source.x, y: source.y}
                            return diagonal(o, o)
                        }).remove();

                        nodes.forEach(function (d) {
                            d.x0 = d.x;
                            d.y0 = d.y;
                        });
                    }


                    function init() {
                        registerListener();
                        root = d3.hierarchy(currentDataSet, function (d) {
                            return d.children;
                        });
                        root.x0 = height / 2;
                        root.y0 = 0;
                        currentNode = root;
                        behavior.buildGraph(null, root);
                    }

                    function registerListener() {
                        d3.select("#reset").on('click', function () {
                            root = d3.hierarchy(flare, function (d) {
                                return d.children;
                            });
                            root.x0 = height / 2;
                            root.y0 = 0;
                            behavior.buildGraph(null, root);
                        });
                        d3.select("body").on('keydown', function () {
                            ctrlKey = d3.event.ctrlKey;
                        });
                        d3.select("body").on('keyup', function () {
                            ctrlKey = false;
                        });
                        d3.select(parent).selectAll("input[type='radio']").on("change", behavior.changeGraphMode);
                        d3.selectAll("input[type='text']").on("keyup", behavior.searchNode);
                        $(parent + " .iis-slider").each(function () {
                            var min = parseInt($(this).attr("data-min") | 0);
                            var max = parseInt($(this).attr("data-max") | 0);
                            var value = parseInt($(this).attr("data-value") | 0);
                            var handler = $(this).find(".ui-slider-handle");
                            $(this).slider({
                                min: min,
                                max: max,
                                value: value,
                                create: function () {
                                    handler.text($(this).slider("value"));
                                },
                                slide: function (event, ui) {
                                    handler.text(ui.value);
                                }
                            });
                        });
                        $(parent + " .hierarchy-level").on("slide", function (event, ui) {
                            hirarchiLevel = parseInt(ui.value) + 1;
                            behavior.buildGraph(null, root);
                        });
                    }

                    function showDetails(d) {
                        let htm = "<ul>";
                        if (d.children) {
                            d.children.filter(function (elem) {
                                htm += "<li>" + elem.data.name + "</li>";
                            });
                        } else {
                            htm += "<li>" + d.data.name + "</li>";
                        }
                        htm += "<ul>";
                        $("#toolTip").html(htm).css({display: "block", top: d.x + 30, left: d.y});
                    }

                    function nodeClicked(d) {
                        if (ctrlKey) {
                            currentDataSet = d.data;
                            currentNode = d;
                            behavior.buildGraph(currentDataSet, false);
                        } else {
                            if (d.children) {
                                d._children = d.children;
                                d.children = null;
                            } else {
                                d.children = d._children;
                                d._children = null;
                            }
                            behavior.buildGraph(null, d);
                        }
                    }

                    function diagonal(s, d) {
                        var path = `M ${s.y} ${s.x}
                    C ${(s.y + d.y) / 2} ${s.x},
                      ${(s.y + d.y) / 2} ${d.x},
                      ${d.y} ${d.x}`
                        return path
                    }

                    function collapse(d) {
                        if (d.children) {
                            d._children = d.children
                            d._children.forEach(collapse)
                            d.children = null
                        }
                    }

                    function changeGraphMode() {
                        switch (this.value) {
                            case "tree":
                            {
                                treemap(root);
                                break;
                            }
                            case "cluster":
                            {
                                cluster(root);
                                break;
                            }
                        }

                        var t = d3.transition().duration(750);
                        nodeUpdate.transition(t).attr("transform", function (d) {
                            return "translate(" + d.y + "," + d.x + ")";
                        });

                        linkUpdate.transition(t).attr("d", function (d) {
                            var o = {x: currentNode.x, y: currentNode.y}
                            return diagonal(d, d.parent);
                        });
                    }

                    function searchNode() {
                        var value = this.value.toLowerCase();
                        if (value.trim() == "") {
                            nodeUpdate.select("circle").attr("stroke", "steelblue");
                            nodeUpdate.select("text").attr("fill", "#444");
                            return;
                        }
                        nodeUpdate.filter(function (d) {
                            if (d.data.name.toLowerCase().lastIndexOf(value) >= 0) {
                                d3.select(this).select("circle").attr("stroke", "red");
                                d3.select(this).select("text").attr("fill", "red");
                            } else {
                                d3.select(this).select("circle").attr("stroke", "steelblue");
                                d3.select(this).select("text").attr("fill", "#444");
                            }
                        });
                    }
                    behavior.init();
                }
                modes.packed = function (initialData) {
                    currentDataSet = initialData;
                    var ctrlKey = false, hirarchiLevel = 5, root, nodeUpdate, currentNode, i;
                    var packLayout = d3.pack().size([height, width - 160]), cluster = d3.cluster().size([height, width - 160]), behavior = {};
                    behavior.showDetails = showDetails;
                    behavior.nodeClicked = nodeClicked;
                    behavior.searchNode = searchNode;
                    behavior.buildGraph = buildGraph;
                    behavior.init = init;
                    svg.append('g').attr('class', 'packed');
                    function buildGraph(data, source) {
                        if (!source) {
                            root = d3.hierarchy(data, function (d) {
                                return d.children;
                            });
                            root.sum(function (d) {
                                return d.size;
                            });
                            root.x0 = height / 2;
                            root.y0 = 0;
                            source = root;
                        }
                        packLayout(root);
                        var nodes = root.descendants();
                        nodes = nodes.filter(function (d) {
                            if (d.depth >= hirarchiLevel) {
                                return false;
                            } else {
                                return true;
                            }
                        });
                        var node = svg.select(".packed").selectAll('g.node').data(nodes, function (d) {
                            return d.id || (d.id = ++i);
                        });

                        var nodeEnter = node.enter().append('g').attr('class', 'node').on('click', behavior.nodeClicked)
                                .attr("transform", function (d) {
                                    return 'translate(' + [d.x, d.y] + ')';
                                });

                        nodeEnter.append('circle').attr('r', function (d) {
                            return d.r;
                        }).on("mousemove", behavior.showDetails)


                        nodeEnter.append('text').attr('dy', 4)
                                .text(function (d) {
                                    return d.children === undefined ? d.data.name : '';
                                });

                        nodeUpdate = nodeEnter.merge(node);

                        nodeUpdate.transition().duration(duration).attr("transform", function (d) {
                            return 'translate(' + [d.x, d.y] + ')';
                        });

                        nodeUpdate.select('circle.node').attr('r', function (d) {
                            return d.r;
                        }).attr('cursor', 'pointer');

                        var nodeExit = node.exit().transition().duration(duration).remove();

                        nodeExit.select('circle').attr('r', function (d) {
                            return d.r;
                        });

                    }


                    function init() {
                        registerListener();
                        root = d3.hierarchy(currentDataSet, function (d) {
                            return d.children;
                        });
                        root.sum(function (d) {
                            return d.size;
                        });
                        currentNode = root;
                        behavior.buildGraph(null, root);
                    }

                    function registerListener() {
                        d3.select("#reset").on('click', function () {
                            root = d3.hierarchy(flare, function (d) {
                                return d.children;
                            });
                            root.x0 = height / 2;
                            root.y0 = 0;
                            behavior.buildGraph(null, root);
                        });
                        d3.select("body").on('keydown', function () {
                            ctrlKey = d3.event.ctrlKey;
                        });
                        d3.select("body").on('keyup', function () {
                            ctrlKey = false;
                        });
                        d3.select(parent).selectAll("input[type='radio']").on("change", behavior.changeGraphMode);
                        d3.selectAll("input[type='text']").on("keyup", behavior.searchNode);
                        $(parent + " .iis-slider").each(function () {
                            var min = parseInt($(this).attr("data-min") | 0);
                            var max = parseInt($(this).attr("data-max") | 0);
                            var value = parseInt($(this).attr("data-value") | 0);
                            var handler = $(this).find(".ui-slider-handle");
                            $(this).slider({
                                min: min,
                                max: max,
                                value: value,
                                create: function () {
                                    handler.text($(this).slider("value"));
                                },
                                slide: function (event, ui) {
                                    handler.text(ui.value);
                                }
                            });
                        });
                        $(parent + " .hierarchy-level").on("slide", function (event, ui) {
                            hirarchiLevel = parseInt(ui.value) + 1;
                            behavior.buildGraph(null, root);
                        });
                    }

                    function showDetails(d) {
                        let htm = "<ul>";
                        if (d.children) {
                            d.children.filter(function (elem) {
                                htm += "<li>" + elem.data.name + "</li>";
                            });
                        } else {
                            htm += "<li>" + d.data.name + "</li>";
                        }
                        htm += "<ul>";
                        $("#toolTip").html(htm).css({display: "block", top: d.x + 30, left: d.y});
                    }

                    function nodeClicked(d) {
                        if (ctrlKey) {
                            currentDataSet = d.data;
                            currentNode = d;
                            console.log(currentDataSet);
                            behavior.buildGraph(currentDataSet, false);
                        } else {
                            if (d.children) {
                                d._children = d.children;
                                d.children = null;
                            } else {
                                d.children = d._children;
                                d._children = null;
                            }
                            console.log()
                            //behavior.buildGraph(null, d);
                        }
                    }

                    function searchNode() {
                        var value = this.value.toLowerCase();
                        if (value.trim() == "") {
                            nodeUpdate.select("circle").attr("stroke", "steelblue");
                            nodeUpdate.select("text").attr("fill", "#444");
                            return;
                        }
                        nodeUpdate.filter(function (d) {
                            if (d.data.name.toLowerCase().lastIndexOf(value) >= 0) {
                                d3.select(this).select("circle").attr("stroke", "red");
                                d3.select(this).select("text").attr("fill", "red");
                            } else {
                                d3.select(this).select("circle").attr("stroke", "steelblue");
                                d3.select(this).select("text").attr("fill", "#444");
                            }
                        });
                    }
                    behavior.init();
                }
//                modes.packed(currentDataSet);
                modes.tree(currentDataSet);
            });
        </script>
    </body>