/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


function getRandomColor() {
    var letters = '0123456789ABC';
    var color = '#';
    for (var i = 0; i < 6; i++) {
        color += letters[Math.floor(Math.random() * 13)];
    }
    return color;
}

var circleCoord = function (node, index, num_nodes, circle) {
    var circumference = circle.node().getTotalLength();
    var pointAtLength = function (l) {
        return circle.node().getPointAtLength(l)
    };
    var sectionLength = (circumference) / num_nodes;
    var position = sectionLength * index + sectionLength / 2;
    return pointAtLength(circumference - position)
}

function buildTooltip(d) {
    var html = "";
    if (d.name) {
        html += "<span class='tipKey'>Name : </span> " + d.name + "<br/>";
    }
    if (d && d.teamName) {
        html += "<span class='tipKey'>Team Name : </span>" + d.teamName + "<br/>";
    }
    if (d && d.org) {
        html += "<span class='tipKey'>Organization : </span>" + d.org + "<br/>";
    }
    if (d && d.teamDesc) {
        html += "<span class='tipKey'>Description : </span>" + d.teamDesc + "<br/>";
    }
    if (d && d.userConnected) {
        html += "<span class='tipKey'>No. of members : </span>" + d.userConnected + "<br/>";
    }

    if (d && d.job_title) {
        html += "<span class='tipKey'>Designation : </span>" + d.job_title + "<br/>";
    }
    if (d && d.city) {
        html += "<span class='tipKey'>City : </span>" + d.city + "<br/>";
    }
    if (d && d.country) {
        html += "<span class='tipKey'>Country : </span>" + d.country + "<br/>";
    }
    if (d && d.state) {
        html += "<span class='tipKey'>State : </span>" + d.state + "<br/>";
    }
    if (d && d.userPrice) {
        html += "<span class='tipKey'>Payrate : </span>" + d.userPrice + "<br/>";
    }
    if (d && d.wealth) {
        html += "<span class='tipKey'>Wealth : </span>" + d.wealth + "<br/>";
    }
    if (d && d.registered) {
        html += "<span class='tipKey'>Registered : </span>" + d.registered + "<br/>";
    }
    if (d && d.teams) {
        html += "<span class='tipKey'>Teams : </span>" + d.teams + "<br/>";
    }
    if (d && d.category) {
        html += "<span class='tipKey'>Market : </span>" + d.category + "<br/>";
    }
    return html;
}


function toolTipPosition(elem, tooltip, node) {
    tooltip.transition().duration(200).style("opacity", 0.9);
    let pos = $(elem).offset(), width = $(elem).width(), height = $(elem).height();
    let left = pos.left + (width - (width / 7)) - 200;
    let top = pos.top + (height - (height / 7)) - 70;
    tooltip.html(buildTooltip(node)).style("left", left + "px").style("top", top + "px");
}

function matchChopValues(value, availableOptions) {
    var found = false;
    for (var i = 0; i < availableOptions.length; i++) {
        if (value.indexOf(availableOptions[i].toLowerCase()) >= 0) {
            found = true;
            break;
        }
    }
    return found;
}

$.fn.outerHTML = function (elem) {
    return $(elem).append(this.eq(0).clone()).html();
};

$(document).on("click", ".printGraph", function () {
    var divContents = "";
    if ($(this).hasClass("printGraph")) {
        divContents = $($(this).attr("data-wrap")).outerHTML('<svg/>');
    } else {
        divContents = $($(this).attr("data-wrap")).outerHTML('<div/>');
    }

    var printWindow = window.open('', '', 'height=' + window.screen.availHeight + ',width=' + window.screen.availWidth + '');
    printWindow.document.write('<!DOCTYPE html><html><head><title>DIV Contents</title>');
    printWindow.document.write(`<style>
svg.teamMemberSvg .nodes circle {
    stroke: #fff;
    stroke-width: 1.5px;
}
        
svg.teamMemberSvg .links line,svg .link {
    stroke: #999;
    stroke-opacity: 0.6;
}
        svg .link {
    fill: none;
            stroke: #ccc;
    stroke-width: 1px;
}
        
svg.teamMemberSvg .nodes text {
    pointer-events: none;
    font: 10px sans-serif;
    fill: #444;
    display: none;
    letter-spacing: 0px;
    stroke-width: 0px;
}
  
svg.teamMemberSvg rect {
      fill: #d1e8f3;
    width: 100%;
    height: 100%;
}
        
svg.teamMemberSvg {
    width: 100%;
    height: 100%;
    position: relative;
    border: 1px solid #ccc;
    float: left;    
}
        
html,body{
        height:calc(100% - 50px);
        min-height:600px;
        margin:0px;
        padding:0px;
}
</style>`);
    printWindow.document.write('</head><body >');
    printWindow.document.write(divContents);
    printWindow.document.write('</body></html>');
    printWindow.document.close();
    printWindow.print();
    printWindow.close();
});


function printGoogleMaps(mapId, map) {
    const width = window.screen.availWidth;
    const height = window.screen.availHeight;
    const $body = $('body');
    const $mapContainer = $(mapId).css({width: width, height: height});
    const $mapContainerParent = $mapContainer.parent();
    google.maps.event.trigger(map, 'resize');
    const $printContainer = $('<div style="position:relative;">');
    $printContainer.append($mapContainer).prependTo($body);
    const $content = $body.children().not($printContainer).not('script').detach();
    const $patchedStyle = $('<style media="print">').text(`img { max-width: none !important; }a[href]:after { content: ""; }`).appendTo('head');
    google.maps.event.addListenerOnce(map, "idle", function () {
        window.print();
        $body.prepend($content);
        $mapContainerParent.prepend($mapContainer);
        $printContainer.remove();
        $patchedStyle.remove();
        $(mapId).css({width: '', height: ''});
        google.maps.event.trigger(map, 'resize');
    });
}