<?php
/*
 * Template Name: Transactions
 *

 */
get_header(); ?>

<style>
.transaction table{
	width: 100%;
}
.transaction table  thead th{
	font-weight: bold;
	padding: 8px;
}
.transaction tbody tr:nth-child(2){
	display: none;
}
.transaction  table tbody:nth-child(odd){
	background: #eeeeee;
}

.transaction table td{
	padding: 8px;
}
.transaction div.t-infoline{
	display: block;
	width: 100%;
}
.transaction div.t-infoline label{
	display: inline-block;
	width: 20%;
	font-weight: bold;
}
.expandall {
	color: blue;
	text-decoration: underline;
}

</style>

<script type="text/javascript">
$(document).ready(function () 
{
	$(document).on('click', '.expandall', function(e)
	{
		//alert("hello");
		var condition = $(this).parent('td').parent('tr').next('.transaction-info');        
		$(".transaction-info").hide();
		$(condition).show();
		/*if(condition.is(":visible"))
		{
			$(condition).hide();
		} 
		else
		{
			$(condition).show();
		}*/
		
	});
   /* $('tbody').click(function () 
	{
		
		$(this).find('tr:nth-child(2)').slideToggle();        
	});*/
});
</script>
<div class="page-full-width">
	<div id="primary" class="site-content">
		<div id="content" role="main">

			<div class="transaction">
		<h3>Billing And Transaction Information</h3>
		
		<?php
		global $wpdb;
		$userid    = get_current_user_id();
		$table     = $wpdb->prefix . 'BillingInformation';
		$getresult = $wpdb->get_results( "SELECT * FROM $table WHERE expertid='$userid'" );
		//echo '<pre>';
		//print_r($getresult);
		?>
				
		
		<div>
			  
		   <table style="border: 1px solid black; border-collapse: collapse;" class="transactiontable" border="1">
				<thead>             
							<tr>
								<th>Name</th>
								<th>City</th>
								<th>Payment Status</th>
								<th>Amount</th>
								<th>User Time</th>
								<th>Message For Expert</th>
							</tr>
				</thead>
					<?php if ( $getresult ) { ?>
					<?php foreach ( $getresult as $transactionresult ) { ?> 
					<tbody>
								<tr>
							<td><?php echo $transactionresult->firstname; ?>&nbsp;<a href="javascript:void(0)" class="expandall">Expand All</a></td>
							<td><?php echo $transactionresult->city; ?></td>                            
							<td><?php echo $transactionresult->paymentstatus; ?></td>
							<td><?php echo $transactionresult->amount . '$'; ?></td> 
							<td><?php echo $transactionresult->usertime; ?></td>
							<td><?php echo $transactionresult->message; ?></td>
								</tr>
								<tr class="transaction-info">
									<td colspan="6">
<div>
	<div class='t-infoline'><label>First Name</label> <?php echo $transactionresult->firstname; ?></div>
	<div class='t-infoline'><label>Last Name</label> <?php echo $transactionresult->lastname; ?></div>
	<div class='t-infoline'><label>Address Line 1</label> <?php echo $transactionresult->addressline1; ?></div>
	<div class='t-infoline'><label>Address Line 2</label> <?php echo $transactionresult->addressline2; ?></div>
	<div class='t-infoline'><label>Phone</label> <?php echo $transactionresult->phone; ?></div>
	<div class='t-infoline'><label>Email</label> <?php echo $transactionresult->email; ?></div>
	<div class='t-infoline'><label>Zip Code</label> <?php echo $transactionresult->zipcode; ?></div>
	<div class='t-infoline'><label>City</label> <?php echo $transactionresult->city; ?></div>
	<div class='t-infoline'><label>State</label> <?php echo $transactionresult->state; ?></div>
	<div class='t-infoline'><label>Country</label> <?php echo $transactionresult->country; ?></div>
	<div class='t-infoline'><label>Payment Status</label> <?php echo $transactionresult->paymentstatus; ?></div>
	<div class='t-infoline'><label>Amount</label> <?php echo $transactionresult->amount . '$'; ?></div> 
	<div class='t-infoline'><label>Transaction Id</label> <?php echo $transactionresult->transactionid; ?></div>
	<div class='t-infoline'><label>User Time</label> <?php echo $transactionresult->usertime; ?></div>
	<div class='t-infoline'><label>Message For Expert</label> <?php echo $transactionresult->message; ?></div>
</div>
									</td>
								</tr>
				</tbody>
				<?php
} #End foreach Block   #End if Block
} else {
	echo '<tr><td colspan="6">';
	echo 'No Transaction Found';
	echo '</td></tr>';
}
					?>
			</table>

			
		</div>
	</div>
	</div><!-- #content -->
	</div><!-- #primary -->

</div><!-- .page-full-width -->
<?php get_footer(); ?>
