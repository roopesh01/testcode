    (function($)
    {
        $(document).ready(function() 
        { 
                 /* Pagination JQuery*/
                   $("#expert_team_pagination").DataTable
                   ({
                        order: [],
                        columnDefs: [ { orderable: false, targets: [0] } ],
                        "language": {
                            "search": " ",
                            "searchPlaceholder": "Search Expert..."
                        }
                    });                    
                    $("#invitelist").DataTable
                    ({
                       
                        order: [],
                        columnDefs: [ { orderable: false, targets: [0] } ],
                        "language": {
                            "search": " ",
                            "searchPlaceholder": "Search..."
                        }
                    });
                    
                    $("#upcoming_event").DataTable
                    ({
                        
                        "language": {
                        "search": " ",
                        "searchPlaceholder": "Search..."
                    }
                    });
                 /* Paginatoin JQuery*/
                /*Date Picker*/
                    $('#meetingdate').datepicker
                    ({
                        minDate : 0,                        
                        dateFormat: 'yy-mm-dd'
                    });
                /*Date Picker*/
                /* Google Map JQuery */
                $("#geocomplete").geocomplete({
                    map: "#map_canvas"
                });
                    var options = 
                    {
                        map: "#map_canvas"
                    };
                    $("#geocomplete").geocomplete(options)
                    .bind("geocode:result", function(event, result)
                    {
                        $.log("Result: " + result.formatted_address);
                    })
                    .bind("geocode:error", function(event, status)
                    {
                        $.log("ERROR: " + status);
                    })
                    .bind("geocode:multiple", function(event, results)
                    {
                        $.log("Multiple: " + results.length + " results found");
                    });
                    /* Google Map JQuery */
                       $("#selectunselect").change(function()
                        {     //"select all" change
                            $(".confirmuser").prop('checked', $(this).prop("checked")); //change all ".checkbox" checked status
                        });
              
                    /* Add User From Next Page*/
                    
                    $(document).on('click','#create_team_disable', function(e)
                    {
                        $(".create_team_status").html('<label>You Must First Add Users To Create Team</label>');                        
                    });
                    $(document).on('click','#addteam', function(e)
                    {
                            var new_team_name = $("#new_team_name").val();
                            var new_team_desc = $("#new_team_desc").val();
                            if(new_team_name=='' && new_team_desc=='')
                            {
                               // alert("Enter Team Name");
                               $("#error_team_name").html('<p class="errorMsg"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i>&nbsp;Enter Team Name</p>');
                               $("#error_team_desc").html('<p class="errorMsg"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i>&nbsp;Enter Team Description</p>');   
                            }
                            else if(new_team_name=='')
                            {
                                $("#error_team_name").html('<p class="errorMsg"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i>&nbsp;Enter Team Name</p>');
                            }
                            else if(new_team_desc=='')
                            {
                                $("#error_team_desc").html('<p class="errorMsg"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i>&nbsp;Enter Team Description</p>');
                            }
                            else
                            {
                                $("html").addClass("overlay");
                                $.ajax
                                ({
                                    type: 'POST',
                                    /////////get website url:
                                    url: '/wp-content/themes/boss-child/ajax-templates/invited-experts.php',
                                    data: 
                                    {
                                        new_team_name: new_team_name,
                                        new_team_desc:new_team_desc                                  
                                    },
                                    success: function(html)
                                    { 
                                        $("html").removeClass("overlay");                                        
                                        window.location.href = "/team-members/";
                                                                                                                              
                                    },
                                    error: function(MLHttpRequest, textStatus, errorThrown)
                                    {
                                    }
                                });                        
                            }                        
                    });
                    /* Form Validation */
                     $('#new_team_name').blur(function(e) 
                     {
                        var tval = $(this).val();
                        var tlength = tval.length;
                        if(tlength=='0')
                        {
                            $("#error_team_name").html('<p class="errorMsg"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i>&nbsp;Enter Team Name</p>');
                        }
                        else
                        {
                           $("#error_team_name").html(''); 
                        }                       
                     });                     
                     $('#new_team_desc').blur(function(e) 
                     {
                        var tval = $(this).val();
                        var tlength = tval.length;
                        if(tlength=='0')
                        {
                            $("#error_team_desc").html('<p class="errorMsg"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i>&nbsp;Enter Team Description</p>');
                        }
                        else
                        {
                           $("#error_team_desc").html(''); 
                        }                       
                     }); 
                     $('#meeting_title').blur(function(e) 
                     {
                        var tval = $(this).val();
                        var tlength = tval.length;
                        if(tlength=='0')
                        {
                            $("#error_title").html('<p class="errorMsg"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i>&nbsp;Enter Meeting Title</p>');
                        }
                        else
                        {
                           $("#error_title").html(''); 
                        }                       
                     }); 
                     $('#meeting_desc').blur(function(e) 
                     {
                        var tval = $(this).val();
                        var tlength = tval.length;
                        if(tlength=='0')
                        {
                            $("#error_desc").html('<p class="errorMsg"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i>&nbsp;Enter Meeting Description</p>');
                        }
                        else
                        {
                           $("#error_desc").html(''); 
                        }                       
                     });
                     $('#meetinglocation').blur(function(e) 
                     {
                        var tval = $(this).val();
                        var tlength = tval.length;
                        if(tlength=='0')
                        {
                            $("#error_venue_name").html('<p class="errorMsg"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i>&nbsp;Enter Meeting Location</p>');
                        }
                        else
                        {
                           $("#error_venue_name").html(''); 
                        }                       
                     });
                     $('#geocomplete').blur(function(e) 
                     {
                        var tval = $(this).val();
                        var tlength = tval.length;
                        if(tlength=='0')
                        {
                            $("#error_venue_address").html('<p class="errorMsg"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i>&nbsp;Enter Meeting Address</p>');
                        }
                        else
                        {
                           $("#error_venue_address").html(''); 
                        }                       
                     });
                     $('#virtualdetail').blur(function(e) 
                     {
                        var tval = $(this).val();
                        var tlength = tval.length;
                        if(tlength=='0')
                        {
                            $("#error_virtual_detail").html('<p class="errorMsg"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i>&nbsp;Enter Virtual Detail</p>');
                        }
                        else
                        {
                           $("#error_virtual_detail").html(''); 
                        }                       
                     });
                     $('#meetingdate').blur(function(e) 
                     {
                        var tval = $(this).val();
                        var tlength = tval.length;
                        if(tlength=='0')
                        {
                            $("#error_meeting_date").html('<p class="errorMsg"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i>&nbsp;Enter Meeting Date</p>');
                        }
                        else
                        {
                           $("#error_meeting_date").html(''); 
                        }                       
                     });                           
                    /* Form Validation */
                    
                    $(document).on('click', "#Addusertolist", function(e)
                    {
                        
                        var venuedate = $("#meetingdate").val();
                        var venuetime = $("#venuetime").val() + ':' + $("#minutes").val();
                        var timeformat = $("#venuetimeformat").val();
                        var meetinglocation = $("#meetinglocation").val();
                        var address = $("#geocomplete").val();
                        var virtualdetail = $("#virtualdetail").val();
                        var meetingdetail = $("#meetingdetail").val();
                        var radioValue = $("input[name='venuetype']:checked").val();
                        var meeting_title = $("#meeting_title").val();
                        var meeting_desc = $("#meeting_desc").val();                        
                        var timezones = $("#webinarTimesForm_timeZone").val();                        
                        
                        if(radioValue=="livevenue")
                        {
                            
                            if(meeting_title=='' && meeting_desc=='' && venuedate=='' && meetinglocation=='' && address=='')
                            {
                                 $("#error_title").html('<p class="errorMsg"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i>&nbsp;Enter Meeting Title</p>');
                                 $("#error_desc").html('<p class="errorMsg"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i>&nbsp;Enter Meeting Description</p>');
                                 $("#error_meeting_date").html('<p class="errorMsg"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i>&nbsp;Enter Meeting Date</p>');
                                 $("#error_venue_name").html('<p class="errorMsg"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i>&nbsp;Enter Meeting Location</p>');
                                 $("#error_venue_address").html('<p class="errorMsg"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i>&nbsp;Enter Meeting Address</p>');  
                            }
                            else if(meeting_desc=='' && venuedate=='' && meetinglocation=='' && address=='')
                            {
                                 $("#error_desc").html('<p class="errorMsg"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i>&nbsp;Enter Meeting Description</p>');
                                 $("#error_meeting_date").html('<p class="errorMsg"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i>&nbsp;Enter Meeting Date</p>');
                                 $("#error_venue_name").html('<p class="errorMsg"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i>&nbsp;Enter Meeting Location</p>');
                                 $("#error_venue_address").html('<p class="errorMsg"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i>&nbsp;Enter Meeting Address</p>');                                   
                            }
                            else if(venuedate=='' && meetinglocation=='' && address=='')
                            {
                                 
                                 $("#error_meeting_date").html('<p class="errorMsg"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i>&nbsp;Enter Meeting Date</p>');
                                 $("#error_venue_name").html('<p class="errorMsg"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i>&nbsp;Enter Meeting Location</p>');
                                 $("#error_venue_address").html('<p class="errorMsg"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i>&nbsp;Enter Meeting Address</p>');    
                            }
                            else if(meetinglocation=='' && address=='')
                            {
                                 $("#error_venue_name").html('<p class="errorMsg"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i>&nbsp;Enter Meeting Location</p>');
                                 $("#error_venue_address").html('<p class="errorMsg"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i>&nbsp;Enter Meeting Address</p>');   
                            }
                            else if(meeting_title=='') 
                            {                            
                                $("#error_title").html('<p class="errorMsg"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i>&nbsp;Enter Meeting Title</p>');
                            }                            
                            else if (meeting_desc=='') 
                            {                            
                                //alert("enter meeting description");
                                $("#error_desc").html('<p class="errorMsg"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i>&nbsp;Enter Meeting Description</p>');                            
                            } 
                            else if (venuedate=='') 
                            {
                                  //alert("enter meeting date");
                                  $("#error_meeting_date").html('<p class="errorMsg"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i>&nbsp;Enter Meeting Date</p>');                             
                            }
                            else if (meetinglocation=='') 
                            {
                                  //alert("enter meeting location"); 
                                  $("#error_venue_name").html('<p class="errorMsg"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i>&nbsp;Enter Meeting Location</p>');                             
                            }
                            else if (address=='') 
                            {
                              //alert("enter address"); 
                              $("#error_venue_address").html('<p class="errorMsg"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i>&nbsp;Enter Meeting Address</p>');                            
                            }                            
                            else
                            {
                                $("html").addClass("overlay");
                                $.ajax
                                ({
                                    type: 'POST',
                                    /////////get website url:
                                    url: '/wp-content/themes/boss-child/ajax-templates/invited-users.php',
                                    data: 
                                    {
                                        venuedate: venuedate,
                                        venuetime:venuetime,
                                        meetinglocation: meetinglocation,
                                        address: address,
                                        virtualdetail: virtualdetail,
                                        meetingdetail: meetingdetail,
                                        timeformat: timeformat,
                                        radioValue:radioValue,
                                        meeting_title: meeting_title,
                                        meeting_desc: meeting_desc,
                                        timezones: timezones
                                    },
                                    success: function(html)
                                    { 
                                        $("html").removeClass("overlay");
                                        alert("Data Successfully submitted");                                            
                                        window.location.href = "/members-list/";                                                                             
                                    },
                                    error: function(MLHttpRequest, textStatus, errorThrown)
                                    {
                                    }
                                });
                            }                            
                        }
                        else if(radioValue=="virtualvenue")
                        {
                            if(meeting_title=='' && meeting_desc=='' && venuedate=='' && virtualdetail=='')
                            {
                                 $("#error_title").html('<p class="errorMsg"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i>&nbsp;Enter Meeting Title</p>');
                                 $("#error_desc").html('<p class="errorMsg"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i>&nbsp;Enter Meeting Description</p>');
                                 $("#error_meeting_date").html('<p class="errorMsg"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i>&nbsp;Enter Meeting Date</p>');
                                 $("#error_virtual_detail").html('<p class="errorMsg"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i>&nbsp;Enter Virtual Detail</p>');
                            }
                            else if(meeting_desc=='' && venuedate=='' && virtualdetail=='')
                            {
                                 $("#error_desc").html('<p class="errorMsg"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i>&nbsp;Enter Meeting Description</p>');
                                 $("#error_meeting_date").html('<p class="errorMsg"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i>&nbsp;Enter Meeting Date</p>');
                                 $("#error_virtual_detail").html('<p class="errorMsg"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i>&nbsp;Enter Virtual Detail</p>');                                
                            }
                            else if(venuedate=='' && virtualdetail=='')
                            {
                                $("#error_meeting_date").html('<p class="errorMsg"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i>&nbsp;Enter Meeting Date</p>');
                                $("#error_virtual_detail").html('<p class="errorMsg"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i>&nbsp;Enter Virtual Detail</p>'); 
                            }                               
                            else if(meeting_title=='') 
                            {                            
                                alert("enter meeting title");                                
                            } 
                            else if (meeting_desc=='') 
                            {                            
                                alert("enter meeting description");                            
                            } 
                            else if (venuedate=='') 
                            {
                                alert("enter meeting date");                            
                            }
                            else if (virtualdetail=='') 
                            {
                                alert("enter meeting location");                            
                            }
                            else
                            {
                                $("html").addClass("overlay");
                                $.ajax
                                ({
                                    type: 'POST',
                                    /////////get website url:
                                    url: '/wp-content/themes/boss-child/ajax-templates/invited-users.php',
                                    data: 
                                    {
                                        venuedate: venuedate,
                                        venuetime:venuetime,
                                        meetinglocation: meetinglocation,                                        
                                        virtualdetail: virtualdetail,
                                        meetingdetail: meetingdetail,
                                        timeformat: timeformat,
                                        radioValue:radioValue,
                                        meeting_title: meeting_title,
                                        meeting_desc: meeting_desc,
                                        timezones: timezones
                                    },
                                    success: function(html)
                                    { 
                                        $("html").removeClass("overlay");                                        
                                        alert("Data Successfully submitted");    
                                        window.location.href = "/members-list/";
                                    },
                                    error: function(MLHttpRequest, textStatus, errorThrown)
                                    {
                                    }
                                });
                            }
                        }
                    });
       
                   
                /* Add User From Next Page*/
                /* Delete User From Page*/
                    $(document).on('click', "#removeusertolist", function(e)
                    {
                            var val = [];
                            var count = 0;                            
                            $('.confirmuser:checked').each(function(i)
                            {
                                //val[i] = $(this).val();
                                val.push($(this).val());
                                count++;
                            });                            
                            var deletevalue  = val.join();
                            var tableid = $('.tableid').val(); 
                            //alert(tableid);
                            if(count==0)
                            {
                                alert("you Have To Select At Least One User To Delete From List");
                            }                                          
                            else 
                            {
                                    var confirmdelete = confirm("Are you sure you want to delete?"); 
                                    if(confirmdelete==true)
                                    {
                                        
                                            $("html").addClass("overlay");
                                            $.ajax
                                            ({
                                                type: 'POST',
                                                /////////get website url:
                                                url: '/wp-content/themes/boss-child/ajax-templates/invited-users.php',
                                                data: 
                                                {
                                                    deletevalue: deletevalue,
                                                    tableid: tableid                          
                                                },
                                                success: function(html)
                                                { 
                                                    $("html").removeClass("overlay");
                                                    alert(html);
                                                    window.location.href = "/schedule-new-meeting/";
                                                },
                                                error: function(MLHttpRequest, textStatus, errorThrown)
                                                {
                                                }
                                            });
                                    }        
                            }
                    });
                    
                    $(document).on('click', "#removeexperts", function(e)
                    {
                            var allvalue = [];
                            var count = 0;                            
                            $('.confirmuser:checked').each(function(i)
                            {
                                //val[i] = $(this).val();
                                allvalue.push($(this).val());
                                count++;
                            });                            
                            var deletevalue  = allvalue.join();
                            //alert(deletevalue);
                            var tableid = $('.tableid').val();                           
                            if(count==0)
                            {
                                alert("you Have To Select At Least One User To Delete From List");
                            }                                          
                            else 
                            {
                                    var confirmdelete = confirm("Are you sure you want to delete?"); 
                                    if(confirmdelete==true)
                                    {
                                        
                                            $("html").addClass("overlay");
                                            $.ajax
                                            ({
                                                type: 'POST',
                                                /////////get website url:
                                                url: '/wp-content/themes/boss-child/ajax-templates/invited-experts.php',
                                                data: 
                                                {
                                                    deletevalue: deletevalue,
                                                    tableid: tableid                          
                                                },
                                                success: function(html)
                                                { 
                                                    $("html").removeClass("overlay");
                                                    alert(html);
                                                    window.location.href = "/create-new-team/";
                                                },
                                                error: function(MLHttpRequest, textStatus, errorThrown)
                                                {
                                                }
                                            });
                                    }    
                            }
                    });
                /* Delete User From Page */
                
                /* Schedule Mail User  */
                    $(document).on('click', "#meetingscheduled", function(e)
                    {
                        var venuedate = $("#meetingdate").val();
                        var venuetime = $("#venuetime").val() + ':' + $("#minutes").val();
                        var timeformat = $("#venuetimeformat").val();
                        var meetinglocation = $("#meetinglocation").val();
                        var address = $("#geocomplete").val();
                        var virtualdetail = $("#virtualdetail").val();
                        var meetingdetail = $("#meetingdetail").val();
                        var radioValue = $("input[name='venuetype']:checked").val();
                        var meeting_title = $("#meeting_title").val();
                        var meeting_desc = $("#meeting_desc").val();                        
                        var timezones = $("#webinarTimesForm_timeZone").val();                        
                        
                        if(radioValue=="livevenue")
                        {
                            
                            if(meeting_title=='' && meeting_desc=='' && venuedate=='' && meetinglocation=='' && address=='')
                            {
                                 $("#error_title").html('<p class="errorMsg"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i>&nbsp;Enter Meeting Title</p>');
                                 $("#error_desc").html('<p class="errorMsg"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i>&nbsp;Enter Meeting Description</p>');
                                 $("#error_meeting_date").html('<p class="errorMsg"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i>&nbsp;Enter Meeting Date</p>');
                                 $("#error_venue_name").html('<p class="errorMsg"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i>&nbsp;Enter Meeting Location</p>');
                                 $("#error_venue_address").html('<p class="errorMsg"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i>&nbsp;Enter Meeting Address</p>');  
                            }
                            else if(meeting_desc=='' && venuedate=='' && meetinglocation=='' && address=='')
                            {
                                 $("#error_desc").html('<p class="errorMsg"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i>&nbsp;Enter Meeting Description</p>');
                                 $("#error_meeting_date").html('<p class="errorMsg"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i>&nbsp;Enter Meeting Date</p>');
                                 $("#error_venue_name").html('<p class="errorMsg"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i>&nbsp;Enter Meeting Location</p>');
                                 $("#error_venue_address").html('<p class="errorMsg"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i>&nbsp;Enter Meeting Address</p>');                                   
                            }
                            else if(venuedate=='' && meetinglocation=='' && address=='')
                            {
                                 
                                 $("#error_meeting_date").html('<p class="errorMsg"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i>&nbsp;Enter Meeting Date</p>');
                                 $("#error_venue_name").html('<p class="errorMsg"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i>&nbsp;Enter Meeting Location</p>');
                                 $("#error_venue_address").html('<p class="errorMsg"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i>&nbsp;Enter Meeting Address</p>');    
                            }
                            else if(meetinglocation=='' && address=='')
                            {
                                 $("#error_venue_name").html('<p class="errorMsg"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i>&nbsp;Enter Meeting Location</p>');
                                 $("#error_venue_address").html('<p class="errorMsg"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i>&nbsp;Enter Meeting Address</p>');   
                            }
                            else if(meeting_title=='') 
                            {                            
                                $("#error_title").html('<p class="errorMsg"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i>&nbsp;Enter Meeting Title</p>');
                            }                            
                            else if (meeting_desc=='') 
                            {                            
                                //alert("enter meeting description");
                                $("#error_desc").html('<p class="errorMsg"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i>&nbsp;Enter Meeting Description</p>');                            
                            } 
                            else if (venuedate=='') 
                            {
                                  //alert("enter meeting date");
                                  $("#error_meeting_date").html('<p class="errorMsg"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i>&nbsp;Enter Meeting Date</p>');                             
                            }
                            else if (meetinglocation=='') 
                            {
                                  //alert("enter meeting location"); 
                                  $("#error_venue_name").html('<p class="errorMsg"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i>&nbsp;Enter Meeting Location</p>');                             
                            }
                            else if (address=='') 
                            {
                              //alert("enter address"); 
                              $("#error_venue_address").html('<p class="errorMsg"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i>&nbsp;Enter Meeting Address</p>');                            
                            }                            
                            else
                            {
                                var usercount = $("#usercount").val();
                                $("html").addClass("overlay");
                                $.ajax
                                ({
                                    type: 'POST',
                                    /////////get website url:
                                    url: '/wp-content/themes/boss-child/ajax-templates/invited-users.php',
                                    data: 
                                    {
                                        meetingnotify: usercount                           
                                    },
                                    success: function(html)
                                    { 
                                        $("html").removeClass("overlay");
                                        //alert(html);
                                        window.location.href = "/schedule-new-meeting/";
                                    },
                                    error: function(MLHttpRequest, textStatus, errorThrown)
                                    {
                                    }
                                });
                            }                            
                        }
                        else if(radioValue=="virtualvenue")
                        {
                            if(meeting_title=='' && meeting_desc=='' && venuedate=='' && virtualdetail=='')
                            {
                                 $("#error_title").html('<p class="errorMsg"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i>&nbsp;Enter Meeting Title</p>');
                                 $("#error_desc").html('<p class="errorMsg"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i>&nbsp;Enter Meeting Description</p>');
                                 $("#error_meeting_date").html('<p class="errorMsg"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i>&nbsp;Enter Meeting Date</p>');
                                 $("#error_virtual_detail").html('<p class="errorMsg"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i>&nbsp;Enter Virtual Detail</p>');
                            }
                            else if(meeting_desc=='' && venuedate=='' && virtualdetail=='')
                            {
                                 $("#error_desc").html('<p class="errorMsg"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i>&nbsp;Enter Meeting Description</p>');
                                 $("#error_meeting_date").html('<p class="errorMsg"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i>&nbsp;Enter Meeting Date</p>');
                                 $("#error_virtual_detail").html('<p class="errorMsg"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i>&nbsp;Enter Virtual Detail</p>');                                
                            }
                            else if(venuedate=='' && virtualdetail=='')
                            {
                                $("#error_meeting_date").html('<p class="errorMsg"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i>&nbsp;Enter Meeting Date</p>');
                                $("#error_virtual_detail").html('<p class="errorMsg"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i>&nbsp;Enter Virtual Detail</p>'); 
                            }                               
                            else if(meeting_title=='') 
                            {                            
                                alert("enter meeting title");                                
                            } 
                            else if (meeting_desc=='') 
                            {                            
                                alert("enter meeting description");                            
                            } 
                            else if (venuedate=='') 
                            {
                                alert("enter meeting date");                            
                            }
                            else if (virtualdetail=='') 
                            {
                                alert("enter meeting location");                            
                            }
                            else
                            {
                                $("html").addClass("overlay");
                                var usercount = $("#usercount").val();
                                $("html").addClass("overlay");
                                $.ajax
                                ({
                                    type: 'POST',
                                    /////////get website url:
                                    url: '/wp-content/themes/boss-child/ajax-templates/invited-users.php',
                                    data: 
                                    {
                                        meetingnotify: usercount                           
                                    },
                                    success: function(html)
                                    { 
                                        $("html").removeClass("overlay");                                        
                                        window.location.href = "/schedule-new-meeting/";
                                    },
                                    error: function(MLHttpRequest, textStatus, errorThrown)
                                    {
                                    }
                                });
                            }
                        }
                    });                    
                    $(document).on('click', "#create_new_team", function(e)
                    {
                            var new_team_name = $("#new_team_name").val();
                            var new_team_desc = $("#new_team_desc").val();
                            if(new_team_name=='' && new_team_desc=='')
                            {
                               // alert("Enter Team Name");
                               $("#error_team_name").html('Enter Team Name');
                               $("#error_team_desc").html('Enter Team Description');   
                            }
                            else if(new_team_name=='')
                            {
                                $("#error_team_name").html('Enter Team Name');
                            }
                            else if(new_team_desc=='')
                            {
                                $("#error_team_desc").html('Enter Team Description');
                            }
                            else
                            {
                                var confirmuser = confirm("Do you want to create new team ?");
                                if(confirmuser==true)
                                {
                                    $("html").addClass("overlay");
                                    var tableids = $(".tableid").val();
                                    $("html").addClass("overlay");
                                    $.ajax
                                    ({
                                        type: 'POST',                                
                                        url: '/wp-content/themes/boss-child/ajax-templates/invited-experts.php',
                                        data: 
                                        {
                                            tableids: tableids,
                                            new_team_name: new_team_name,
                                            new_team_desc: new_team_desc                          
                                        },
                                        success: function(html)
                                        { 
                                            $("html").removeClass("overlay");                                    
                                            window.location.href = "/my-expert-teams/#my_team_list";
                                        },
                                        error: function(MLHttpRequest, textStatus, errorThrown)
                                        {
                                        }
                                    });
                                }
                            }
                    });
                /* Schedule Mail User */
                /* Send Reminder  */
                    $(document).on('click', "#sendreminder", function(e)
                    {
                        var confirmuser = confirm("Are U Really Send Reminder Emails To Users");
                        if(confirmuser==true)
                        {
                            var countuser = $("#usercount").val();
                            $("html").addClass("overlay");
                            $.ajax
                            ({
                                type: 'POST',
                                /////////get website url:
                                url: '/wp-content/themes/boss-child/ajax-templates/invited-users.php',
                                data: 
                                {
                                    meetingreminder: countuser                           
                                },
                                success: function(html)
                                {
                                    $("html").removeClass("overlay");                                    
                                    window.location.href = "/schedule-new-meeting/";
                                },
                                error: function(MLHttpRequest, textStatus, errorThrown)
                                {
                                }
                            });
                        }
                    });
                   
                /* Send Reminder */
                /* Select Deselect All */
                    $("#selectunselect,#selectunselectfoot").change(function()
                    {  //"select all" change
                        $(".confirmuser").prop('checked', $(this).prop("checked")); //change all ".checkbox" checked status
                    });
                    //".checkbox" change
                     $('.confirmuser').change(function()
                    {
                        //uncheck "select all", if one of the listed checkbox item is unchecked
                        if(false == $(this).prop("checked"))
                        { //if this item is unchecked
                            $("#selectunselect,#selectunselectfoot").prop('checked', false); //change "select all" checked status to false
                        }
                        //check "select all" if all checkbox items are checked
                        if ($('.confirmuser:checked').length == $('.confirmuser').length)
                        {
                            $("#selectunselect,#selectunselectfoot").prop('checked', true);
                        }
                    });
                        $('#selectedinvited').change(function() 
                        {
                            if ($(this).prop('checked')) 
                            {
                                alert("You have elected to show your checkout history."); //checked
                            }
                            else 
                            {
                                alert("You have elected to turn off checkout history."); //not checked
                            }
                        });
                $("#livevenue").click(function() 
                {
                    if ($("#livevenue").is(":checked")) 
                    {
                        $('.livenuesection').show();
                        $('.virtualsection').hide();
                    }
                });
                $("#virtualvenue").click(function() 
                {
                    if ($("#virtualvenue").is(":checked")) 
                    {
                        $('.virtualsection').show();
                        $('.livenuesection').hide();
                    }
                });
            });         
        })(jQuery);