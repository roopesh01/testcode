<?php
    include '../../../../wp-config.php';
    global $wpdb, $current_user;
    $userid = $current_user->ID;
   echo $userid;
    
    if(isset($_POST['Risk_Management']) || isset($_POST['Cyber_Insurance']) || isset($_POST['Cyber_Coverages']))
    {
        $Risk_Management = $_POST['Risk_Management'];
        $Cyber_Insurance =  $_POST['Cyber_Insurance'];
        $Cyber_Coverages =  $_POST['Cyber_Coverages'];
        $Private_Investigators =  $_POST['Private_Investigators'];
        $Forensic_Experts = $_POST['Forensic_Experts'];
        $IT_Security_Roles = $_POST['IT_Security_Roles'];
        $IT_Security_Products = $_POST['IT_Security_Products'];
        $IT_Security_Certifications = $_POST['IT_Security_Certifications'];
        $IT_Security_Frameworks = $_POST['IT_Security_Frameworks'];
        $Legal = $_POST['Legal'];
        $Prosecution = $_POST['Prosecution'];
        $Law_Enforcement = $_POST['Law_Enforcement'];
        $Trial_Lawyers = $_POST['Trial_Lawyers'];
        $Experience_Type = $_POST['Experience_Type'];
        $Ex_Skills= $_POST['Ex_Skills'];
        $Ex_Media = $_POST['Ex_Media'];
        $Victim_Services = $_POST['Victim_Services'];
        $keyvalue = 'submitsurvey';    
        $submitsurveykey = 'submitsurveykey';        
        
        $metas = array
        ( 
            'Risk_Management'           => $Risk_Management,
            'Cyber_Insurance'           => $Cyber_Insurance, 
            'Cyber_Coverages'           => $Cyber_Coverages,
            'Private_Investigators'     => $Private_Investigators,
            'Forensic_Experts'          =>  $Forensic_Experts, 
            'IT_Security_Roles'         => $IT_Security_Roles,
            'IT_Security_Products'       => $IT_Security_Products,
            'IT_Security_Certifications' => $IT_Security_Certifications, 
            'IT_Security_Frameworks'    => $IT_Security_Frameworks,
            'Legal'                     => $Legal,
            'Prosecution'               =>   $Prosecution, 
            'Law_Enforcement'           =>  $Law_Enforcement,
            'Trial_Lawyers'             =>  $Trial_Lawyers,
            'Experience_Type'           =>  $Experience_Type, 
            'Ex_Skills'                 =>  $Ex_Skills,
            'Ex_Media'                  =>  $Ex_Media,
            'Victim_Services'           =>  $Victim_Services,
            'submitsurveykey'           =>  $keyvalue
        );
        foreach($metas as $option_name => $value) 
        {
            //update_user_meta( $userid, $key, $value );
            update_user_option($userid, $option_name, $value);           
        }
    }
?>