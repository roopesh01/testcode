jQuery(document).ready(function($) {

    var current_user_id = jQuery('input[name=current_user_id]').val();
    var my_table;
    jQuery("#nominatationForm").insertAfter("#mobile-check");

    my_table = jQuery("#member_nominationn").DataTable({
        "language": { "search": " ", "searchPlaceholder": "Search..." }
    });
    jQuery("#nominate_new_member").DataTable({
        "language": { "search": " ", "searchPlaceholder": "Search..." }
    });

    jQuery(".nominee_submit").click(function() {
        var first = jQuery(".nominee_first").val();
        var last = jQuery(".nominee_last").val();
        var email = jQuery.trim(jQuery(".nominee_email").val());
        var jobtitle = jQuery(".nominee_title").val();
        var company = jQuery(".nominee_company").val();
        var vote = jQuery('input[name=nominee_vote]:checked').val();
        var experience_array = [];
        jQuery('input.extra_experience').each(function() {
            var value = jQuery(this).val();
            if (value != '') {
                experience_array.push(value);
            }
        });
        if (jQuery("input:radio[name='nominee_vote']").is(":checked")) {
            jQuery('.action_vote').html("");
        } else {

            jQuery('.action_vote').html("<p class='errorMsg'><i class='fa fa-exclamation-triangle' aria-hidden='true'></i>&nbsp;Please enter Your vote</p>");

        }
        if (jobtitle == "") {
            jQuery('.action_jobtitle').html("<p class='errorMsg'><i class='fa fa-exclamation-triangle' aria-hidden='true'></i>&nbsp;Please enter Job Title</p>");
            jQuery(".nominee_title").css("border", "1px solid #ff0000");
        } else {
            jQuery('.action_jobtitle').html("");
        }
        if (company == "") {
            jQuery('.action_company').html("<p class='errorMsg'><i class='fa fa-exclamation-triangle' aria-hidden='true'></i>&nbsp;Please enter Company Name</p>");
            jQuery(".nominee_company").css("border", "1px solid #ff0000");
        } else {
            jQuery('.action_company').html("");
        }
        if (first == "") {
            jQuery('.action_first').html("<p class='errorMsg'><i class='fa fa-exclamation-triangle' aria-hidden='true'></i>&nbsp;Please enter First Name</p>");
            jQuery(".nominee_first").css("border", "1px solid #ff0000");
        } else {
            jQuery('.action_first').html("");
        }

        if (last == "") {
            jQuery('.action_last').html("<p class='errorMsg'><i class='fa fa-exclamation-triangle' aria-hidden='true'></i>&nbsp;Please enter Last Name</p>");
            jQuery(".nominee_last").css("border", "1px solid #ff0000");
        } else {
            jQuery('.action_last').html("");
        }

        if (email == "") {
            jQuery('.action_email').html("<p class='errorMsg'><i class='fa fa-exclamation-triangle' aria-hidden='true'></i>&nbsp;Please enter Email ID</p>");
            jQuery(".nominee_email").css("border", "1px solid #ff0000");
        } else {
            jQuery('.action_email').html("");
        }

        if (IsEmail(email) == false) {
            jQuery('.action_email').html("<p class='errorMsg'><i class='fa fa-exclamation-triangle' aria-hidden='true'></i>&nbsp;Please enter valid Email ID</p>");
            jQuery(".nominee_email").css("border", "1px solid #ff0000");
            return false;
        } else {
            jQuery('.action_email').html("");
        }
        if (jQuery.trim(first) === "" || jQuery.trim(last) === "" || jQuery.trim(email) === "" || jQuery.trim(jobtitle) === "" || jQuery.trim(company) === "") {
            return false;
        } else {
            var data = new FormData(document.getElementById("nominee_form"));
            jQuery("html").addClass("overlay");
            data.append('action', 'vl_add_nominee');
            jQuery.ajax({
                type: "POST",
                url: ajaxurl,
                data: data,
                dataType: 'json',
                contentType: false,
                cache: false,
                enctype: 'multipart/form-data',
                processData: false,
                success: function(data) {
                    jQuery("html").removeClass("overlay");
                    if (data['status'] == 1) {
                        jQuery("#action_status").removeClass();
                        jQuery("#action_status").addClass("alert alert-success");
                        jQuery("#action_status").html(data['message']);
                        jQuery("#action_status").show();
                        setTimeout(function() {
                            jQuery("form#nominee_form").trigger("reset");
                            jQuery("form#nominee_form input[name='current_user_id']").val(current_user_id);
                            jQuery("form#nominee_form div#action_status").html('');
                            jQuery("form#nominee_form div.crop-box-status").html('');
                            jQuery("div.crop-image-box").hide();
                            jQuery("div#upload_demo_preview_box").addClass('hide');

                            jQuery("form#nominee_form div#action_status").removeClass();
                            jQuery("input.nominee_photo_url").val('');
                            // Data data table
                            var fullname = data['fullname'];
                            var entry_date = data['entry_date'];
                            var nominee_company = data['nominee_company'];
                            var nominee_title = data['nominee_title'];
                            my_table.row.add([fullname, entry_date, nominee_company, nominee_title]);
                            my_table.draw();
                            $("img#show_upload").attr("src", '');
                            $("img#show_upload").addClass("hide");
                            // reset crop box data
                            jQuery("#nominatationForm button.close").click();
                        }, 3000);

                    } else {
                        jQuery("#action_status").removeClass();
                        jQuery("#action_status").addClass("alert alert-danger");
                        jQuery("#action_status").html(data['message']);
                        jQuery("#action_status").show();
                    }

                },
                error: function(error) {
                    jQuery("html").removeClass("overlay");
                    jQuery("#action_status").html(error);

                }
            });
        }

    });

    $("div.crop-image-box").hide();
    $uploadCrop = $('#upload-demo').croppie({

        enableExif: true,

        viewport: {

            width: 150,

            height: 150,

            type: 'square'

        },

        boundary: {

            width: 220,

            height: 220

        }

    });

    $('#upload').on('change', function() {

        var reader = new FileReader();
        $("div.crop-box-status").html('');

        $("div.crop-box-status").html("Please wait... <i class='fa fa-spinner fa-spin'></i>");
        reader.onload = function(e) {

            $uploadCrop.croppie('bind', {

                url: e.target.result

            }).then(function() {
                $("div.crop-box-status").html('');

            });

        }

        reader.readAsDataURL(this.files[0]);
        $("div.crop-image-box").show();
        $("div#upload_demo_preview_box").removeClass('hide');
        $("div.cropContainer").removeClass('hide');

    });


    $('.upload-result').on('click', function(ev) {
        $("div.crop-box-status").html('');
        $("div.crop-box-status").html("Please wait... <i class='fa fa-spinner fa-spin'></i>");
        $uploadCrop.croppie('result', {

            type: 'canvas',

            size: 'viewport'

        }).then(function(resp) {
            var wp_nonce = $("input[name=wp_nominee_nonce]").val();
            $.ajax({

                url: ajaxurl,
                type: "POST",
                dataType: 'json',
                data: {
                    action: 'vl_add_nominee',
                    image: resp,
                    wp_nominee_nonce: wp_nonce
                },


                success: function(data) {
                    $("div.crop-box-status").html('');
                    if (data['image_status'] == 1) {
                        $("form#nominee_form input.nominee_photo_url").val(data['info']);
                        $("div.crop-box-status").html("<p class='alert-success alert'>" + data['message'] + "</p>");
                        html = '<img src="' + resp + '" />';
                        $("img#show_upload").attr("src", resp);
                        $("img#show_upload").removeClass("hide");
                        $("div.browseImageWrap label.btn").removeClass("uploadCameraIcon");
                        $("div.browseImageWrap label.btn").addClass("uploadLabel");
                        setTimeout(function() {
                            $("div.crop-box-status").html('');

                        }, 2000);
                    } else {
                        $("form#nominee_form input.nominee_photo_url").val(data['info']);
                        $("div.crop-box-status").html("<p class='alert-danger alert'>" + data['message'] + "</p>");
                    }


                }

            });

        });

    });

    $("a.close_crop_box").click(function() {
        $("div.crop-box-status").html('');
        $("div.cropContainer").addClass("hide");

    });

    $(".delete-image").click(function() {

        var image_src = $('img#show_upload').attr('src');
        if (image_src != '') {
            if (confirm("Are you sure?")) {
                $("div.crop-image-box .upload-result").css("opacity", "0");
                $("div.crop-image-box .delete-image").css("opacity", "0");
                $("img#show_upload").attr("src", '');
                $("img#show_upload").addClass("hide");
                $("div.browseImageWrap label.btn").removeClass("uploadLabel");
                $("div.browseImageWrap label.btn").addClass("uploadCameraIcon");
                $("div.crop-box-status").html("<p class='alert-success alert'>Profile Image Successfully Deleted.</p>");
                setTimeout(function() {
                    $("div.crop-box-status").html('');
                    $("div.crop-image-box .upload-result").removeAttr("style");
                    $("div.crop-image-box .delete-image").removeAttr("style");
                    $("a.close_crop_box").trigger("click");
                }, 2000);
            }
        } else {
            alert("First upload a image then you can delete.");
        }
    });

});

function IsEmail(email) {
    var regex = /^([a-zA-Z0-9_\.\-\+])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
    if (!regex.test(email)) {
        return false;
    } else {
        return true;
    }
}

function addRow() {
    var numItems = $('div.extra_experience').length;
    var html = '<div class="extra_experience nom_field_container initialdiv initialdiv_' + numItems + '" ><input type="text" name="extra_experience[]" class="extra_experience" value="" placeholder="Experience" /><input type="button" id="' + numItems + '" style="width:50px;" value="-" onclick="removeRow(' + numItems + ')"></div>';

    $("div.extra_experience_row").append(html);
}

function removeRow(input) {
    var id = input;
    $("div.extra_experience_row .initialdiv_" + id).empty();
}