/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

function buildClusterGraph(container, visibleElem) {
    var multiSitePath=graphVariables.siteUrl?graphVariables.siteUrl:'';
    d3.json(multiSitePath+"/wp-content/themes/boss-child/service/getClusterData.php", function (error, users) {
        if (error)
            throw error;

        var svg = d3.select(container + " svg"), width = +$(visibleElem).width(), height = 500;
        width = (width * 69) / 100;
        var simulation = d3.forceSimulation()
                .force("link", d3.forceLink().id(function (d) {
                    return d.id;
                }))
                .force("charge", d3.forceManyBody().strength(-16))
                .force("center", d3.forceCenter(width / 2, height / 2))
                .force('x', d3.forceX(width / 2))
                .force('y', d3.forceY(height / 2));
        var filters = {
            byMarket: "",
            byCities: "",
            byState: "",
            byCountry: "",
            byJob: "",
            byCompany: "",
            byName: "",
            byTeam: "",
            byPrice: 0,
            byWealth: 0,
            byFraind: ""
        };
        var nodeObject = {};
        let nodeData = [], linkData = [], teamNameArray = [], teamArray = [], teamColorArray = [], nodeClicked, fishEyeEnable, isDragging;
        var linkIdCount = 1, nodeIdCount = 1;
        var brushMode = false, brushing = false;
        let usersNest = d3.nest().key(function (d) {
            return d.userId ? d.userId : d.teamId;
        }).entries(users.data);
        usersNest.map(function (user, index) {
            if (user.values[0]) {
                let node = user.values[0];
                if (node.userId) {
                    node.connection = [];
                    for (let i = 0; i < user.values.length; i++) {
                        let link = {};
                        link.source = node.userId;
                        link.target = user.values[i].teamId;
                        link.idx = linkIdCount;
                        linkIdCount++;
                        linkData.push(link);
                        node.connection.push(user.values[i].teamId);
                    }
                    node.id = node.userId;
                } else {
                    teamNameArray.push(node.teamName);
                    teamArray.push(node);
                    teamColorArray.push(getRandomColor());
                    node.id = node.teamId;
                }
                node.idx = nodeIdCount;
                nodeObject[node.id] = node;
                nodeData.push(node);
                nodeIdCount++;
            }
        });

        $(container + " .filterNodeSlider").attr("data-max", nodeData.length);
        $(container + " .filterLinkSlider").attr("data-max", linkData.length);
        var color = d3.scaleOrdinal().domain(teamNameArray).range(teamColorArray);
        var filterList = "";
        for (var i = 0; i < teamArray.length; i++) {
            filterList += '<li style="background:' + teamColorArray[i] + '">' +
                    '<input type="checkbox" class="cat-filter" data-value="' + teamArray[i].teamId + '"/><div>' +
                    '<span>' + teamArray[i].teamName + '</span>' +
                    '<span>(' + teamArray[i].userConnected + ')</span></div>' +
                    '<span data-team="' + teamArray[i].teamName + '"  class="iis-colorpicker" >' +
                    '<span class="color-holder" style="background:' + teamColorArray[i] + '"></span></span>' +
                    '</li>';
        }

        d3.select(container + " .teamList").html(filterList);

        var fisheye = d3.fisheye.circular().radius(120);
        svg.selectAll('.g-main').remove();
        var tooltip = d3.select(container).append("div").attr("class", "tooltip").style("opacity", "0");
        var gMain = svg.append('g').classed('g-main', true);
        var rect = gMain.append('rect').attr('width', width).attr('height', height).style('fill', '#d1e8f3').on("click", function () {
            if (event.target === this) {
                nodeClicked = false;
                nodeElem.each(function (d) {
                    d.selected = false;
                    d.previouslySelected = false;
                });
                nodeElem.classed("selected", false);
                searchNode();
                simulation.restart();
                $(container + " .selectedMembers").html("");
            }
        }).on("mousemove", function () {
            if (nodeClicked || !fishEyeEnable) {
                return;
            }
            simulation.stop();
            fisheye.focus(d3.mouse(this));
            nodeElem.each(function (d) {
                d.fisheye = fisheye(d);
            }).attr("cx", function (d) {
                return d.fisheye.x;
            }).attr("cy", function (d) {
                return d.fisheye.y;
            }).attr("r", function (d) {
                return d.userId ? d.fisheye.z * 4.5 : d.fisheye.z * 9;
            });
            linkElem.attr("x1", function (d) {
                return d.source.fisheye.x;
            }).attr("y1", function (d) {
                return d.source.fisheye.y;
            }).attr("x2", function (d) {
                return d.target.fisheye.x;
            }).attr("y2", function (d) {
                return d.target.fisheye.y;
            });
            textElem.attr("x", function (d) {
                return d.fisheye.x;
            }).attr("y", function (d) {
                return d.fisheye.y;
            });
        });
        var gDraw = gMain.append('g');
        var zoomer = d3.zoom().scaleExtent([.5, 10]).on("zoom", zoomed);
        gMain.call(zoomer).on("dblclick.zoom", null);
        var gBrushHolder = gDraw.append('g');
        gBrushHolder.call(zoomer);
        var gBrush = null, shiftKey;
        d3.select("body").on('keydown', keydown);
        d3.select("body").on('keyup', keyup);
        function keydown() {
            shiftKey = d3.event.shiftKey;
            if (shiftKey) {
                // if we already have a brush, don't do anything
                if (gBrush)
                    return;
                brushMode = true;
                if (!gBrush) {
                    gBrush = gBrushHolder.append('g');
                    //gBrush.call(brush);
                }
            }
        }

        function keyup() {
            shiftKey = false;
            brushMode = false;
            if (!gBrush)
                return;
            if (!brushing) {
// only remove the brush if we're not actively brushing
// otherwise it'll be removed when the brushing ends
                gBrush.remove();
                gBrush = null;
            }
        }
        ;
        /*    var brush = d3.brush().on("start", brushstarted).on("brush", brushed).on("end", brushended);
         function brushstarted() {
         brushing = true;
         nodeElem.each(function (d) {
         d.previouslySelected = shiftKey && d.selected;
         });
         }
         
         function brushed() {
         if (!d3.event.sourceEvent)
         return;
         if (!d3.event.selection)
         return;
         var extent = d3.event.selection;
         nodeElem.classed("selected", function (d) {
         if ((d3.select(this).style("opacity") == 0.1) && d.name == "") {
         return false;
         } else {
         return d.selected = d.previouslySelected ^
         (extent[0][0] <= d.x && d.x < extent[1][0]
         && extent[0][1] <= d.y && d.y < extent[1][1]);
         }
         });
         }
         
         function brushended() {
         if (!d3.event.sourceEvent)
         return;
         if (!d3.event.selection)
         return;
         if (!gBrush)
         return;
         gBrush.call(brush.move, null);
         if (!brushMode) {
         // the shift key has been release before we ended our brushing
         gBrush.remove();
         gBrush = null;
         }
         
         $("#selectedMembers").html("");
         var memberHtml = "";
         nodeData.forEach(function (d) {
         if (d.selected && d.name.trim().length > 0) {
         memberHtml += "<li data-id='" + d.userId + "'>" + d.name + "<span class='remove-selecetd'>x</span></li>";
         }
         });
         $("#selectedMembers").html(memberHtml);
         brushing = false;
         }*/

        function zoomed() {
            gDraw.attr('transform', d3.event.transform);
        }

        var linkElem = gDraw.append("g").attr("class", "links").selectAll("line").data(linkData)
                .enter().append("line").attr("stroke-width", function (d) {
            return 1;
        });
        var node_drag = d3.drag().on("start", dragstarted).on("drag", dragged).on("end", dragended);

        var nodeContainer = gDraw.append("g").attr("class", "nodes").selectAll(".node").data(nodeData).enter().append("g").attr("class", "node").call(node_drag);

        var nodeElem = nodeContainer.append("circle").attr("r", function (d) {
            return d.userId ? 4.5 : 9;
        }).attr("fill", function (d) {
            return color(d.teamId);
        }).attr("id", function (d) {
            return d.id;
        }).on('mouseover', nodeMouseOver).on('mouseout', nodeMouseOut).on("click", connectedNodes).on("dblclick", doubleClickedNode);
        var textElem = nodeContainer.append("text").attr("dx", 10).attr("dy", ".35em").text(function (d) {
            return d.userId ? d.name : d.teamName;
        });
        simulation.nodes(nodeData).on("tick", ticked);
        simulation.force("link").links(linkData);
        function searchNode() {
            var searchUser = $(container + " .activeTeamSlider").is(":checked");
            var searchedTeam = [];
            $(container + " .teamList li input").each(function () {
                if ($(this).prop("checked")) {
                    searchedTeam.push($(this).attr("data-value"));
                }
            });

//                    filters.byName = $("#search_by_expert").val() ? $("#search_by_expert").val().trim().toLowerCase() : "";
//                    filters.byCompany = $("#search_by_company").val() ? $("#search_by_company").val().trim().toLowerCase() : "";
//                    filters.byJob = $("#search_by_jobtitle").val() ? $("#search_by_jobtitle").val().trim().toLowerCase() : "";
//                    filters.byCountry = $("#search_by_country").val() ? $("#search_by_country").val().trim().toLowerCase() : "";
//                    filters.byState = $("#search_by_state").val() ? $("#search_by_state").val().trim().toLowerCase() : "";
//                    filters.byCities = $("#search_by_cities").val() ? $("#search_by_cities").val().trim().toLowerCase() : "";
//                    filters.byMarket = $("#search_by_market").val() ? $("#search_by_market").val().trim().toLowerCase() : "";
            var companyArr = [], jobArr = [], countryArr = [], stateArr = [], citiesArr = [], marketArr = [], nameArr = [];
//                    if (filters.byCompany.length > 0) {
//                        companyArr.push(filters.byCompany);
//                    }
//                    if (filters.byJob.length > 0) {
//                        jobArr.push(filters.byJob);
//                    }
//                    if (filters.byCountry.length > 0) {
//                        countryArr.push(filters.byCountry);
//                    }
//                    if (filters.byState.length > 0) {
//                        stateArr.push(filters.byState);
//                    }
//                    if (filters.byCities.length > 0) {
//                        citiesArr.push(filters.byCities);
//                    }
//                    if (filters.byMarket.length > 0) {
//                        marketArr.push(filters.byMarket);
//                    }
//                    if (filters.byName.length > 0) {
//                        nameArr.push(filters.byName);
//                    }

            /*   $("#keywordList span").each(function () {
             var chopValue = $(this).text() ? $(this).text().trim() : "";
             if (chopValue.length > 0) {
             if ($(this).hasClass("search_by_cities")) {
             citiesArr.push(chopValue);
             }
             if ($(this).hasClass("search_by_state")) {
             stateArr.push(chopValue);
             }
             if ($(this).hasClass("search_by_expert")) {
             nameArr.push(chopValue);
             }
             if ($(this).hasClass("search_by_market")) {
             marketArr.push(chopValue);
             }
             if ($(this).hasClass("search_by_country")) {
             countryArr.push(chopValue);
             }
             if ($(this).hasClass("search_by_jobtitle")) {
             jobArr.push(chopValue);
             }
             if ($(this).hasClass("search_by_company")) {
             companyArr.push(chopValue);
             }
             }
             });*/
            var teamCreation = [];
            if (searchUser && teamCreatedObj && teamCreatedObj.min) {
                users.cat.forEach(function (d) {
                    if (d.teamId && d.dateCreated) {
                        var min = teamCreatedObj.min.getTime();
                        var max = teamCreatedObj.max.getTime();
                        var tuser = new Date(d.dateCreated).getTime();
                        if (tuser >= min && tuser <= max) {
                            teamCreation.push(d.teamId);
                        }
                    }
                });
            }
            //console.log(teamCreation);
            var filterNodes = nodeElem.filter(function (d) {
                var currentUserPrice = parseFloat(d.userPrice) || 0;
                var currentUserWealth = d.wealth ? parseFloat(d.wealth) : 0;

                //      citiesArr  stateArr  nameArr  marketArr countryArr  jobArr   companyArr
                var searchByTeamCondition = (filters.byTeam.length === 0 ? true : false) ? true : d.teams ? d.teams.toLowerCase().indexOf(filters.byTeam) >= 0 : false;
                var searchByMarketCondition = (marketArr.length === 0 ? true : false) ? true : d.category ? matchChopValues(d.category.toLowerCase(), marketArr) : false;
                var searchByCitiesCondition = (citiesArr.length === 0 ? true : false) ? true : d.city ? matchChopValues(d.city.toLowerCase(), citiesArr) : false;
                var searchByStateCondition = (stateArr.length === 0 ? true : false) ? true : d.state ? matchChopValues(d.state.toLowerCase(), stateArr) : false;
                var searchByCountryCondition = (countryArr.length === 0 ? true : false) ? true : d.country ? matchChopValues(d.country.toLowerCase(), countryArr) : false;
                var searchByJobCondition = (jobArr.length === 0 ? true : false) ? true : d.job_title ? matchChopValues(d.job_title.toLowerCase(), jobArr) : false;
                var searchByCompanyCondition = (companyArr.length === 0 ? true : false) ? true : d.org ? matchChopValues(d.org.toLowerCase(), companyArr) : false;
                var searchByNameCondition = (nameArr.length === 0 ? true : false) ? true : d.name ? matchChopValues(d.name.toLowerCase(), nameArr) : false;
                //var searchByCreationCondition = false(teamCreation.length === 0 ? true : false) ? true : d.teamId ? matchChopValues(d.teamId.toLowerCase(), teamCreation) : false;
                var searchByCreationCondition = teamCreation.length > 0 ? false : true;
                var searchByTeamNameCondition = searchedTeam.length > 0 ? false : true;
                if (d.connection) {
                    for (var i = 0; i < d.connection.length; i++) {
                        if (!searchByCreationCondition) {
                            searchByCreationCondition = matchChopValues(d.connection[i].toLowerCase(), teamCreation);
                            if (searchByCreationCondition) {
                                searchByCreationCondition = matchChopValues(d.teamId.toLowerCase(), teamCreation);
                            }
                        }
                        if (searchedTeam.indexOf(d.connection[i]) >= 0) {
                            searchByTeamNameCondition = true;
                        }
                    }
                } else {
                    if (!searchByCreationCondition) {
                        searchByCreationCondition = matchChopValues(d.teamId.toLowerCase(), teamCreation);
                    }
                    if (searchedTeam.indexOf(d.teamId) >= 0) {
                        searchByTeamNameCondition = true;
                    }
                }

                if (searchByTeamNameCondition && searchByCreationCondition && searchByTeamCondition && searchByCitiesCondition && searchByMarketCondition &&
                        searchByStateCondition && searchByCountryCondition && searchByJobCondition && searchByCompanyCondition && searchByNameCondition) {
                    d.filtered = true;
                    return true;
                } else {
                    d.filtered = false;
                    return false;
                }
            });
            linkElem.style("opacity", 0.1);
            nodeElem.style("opacity", function (d) {
                return d.filtered ? 1 : 0.1;
            });
            textElem.style("opacity", function (d) {
                return d.filtered ? 1 : 0.1;
            });
            linkElem.style("opacity", function (o) {
                var flag = false;
                filterNodes.each(function (elem1) {
                    if (elem1.index == o.source.index) {
                        filterNodes.each(function (elem2) {
                            if (elem2.index == o.target.index) {
                                flag = true;
                                return false;
                            }
                        });
                    }
                });
                if (flag) {
                    return    1;
                } else {
                    return      0.1;
                }
            });
        }

        function doubleClickedNode() {
            let d = d3.select(this).node().__data__;
            if (d3.select(this).style("opacity") == 0.1) {
                return;
            }
            nodeClicked = true;
            simulation.stop();
            var dim = height - 80;
            var dim2 = width - 80;
            var circle = svg.append("path").attr("d", "M " + ((dim2 - dim) + 80) / 2 + ", " + (dim / 2 + 40) + " a " + dim / 2 + "," + dim / 2 + " 0 1,0 " + dim + ",0 a " + dim / 2 + "," + dim / 2 + " 0 1,0 " + dim * -1 + ",0")
                    .style("fill", "#fff").style("fill-opacity", 0);
            let tNode = [];
            let filterNode = nodeElem.filter(function (o) {
                if (neighboring(d, o) | neighboring(o, d)) {
                    if (d.index != o.index) {
                        tNode.push(o);
                    } else {
                        o.x = width / 2;
                        o.y = height / 2;
                    }
                    return this;
                } else {
                    d3.select(this).style("opacity", 0);
                }
                return null;
            });
            let filterText = textElem.filter(function (o) {
                if (neighboring(d, o) | neighboring(o, d)) {
                    return this;
                } else {
                    d3.select(this).style("opacity", 0);
                    return null;
                }
            });
            let filterLink = linkElem.filter(function (o) {
                if (d.index == o.source.index | d.index == o.target.index) {
                    return this;
                } else {
                    d3.select(this).style("opacity", 0);
                    return null;
                }
            });
            let filterLength = tNode.length;
            tNode.forEach(function (n, i) {
                var coord = circleCoord(n, i, filterLength, circle);
                n.x = coord.x;
                n.y = coord.y;
            });
            filterLink.transition().duration(450).attr("x1", function (d) {
                return d.source.x;
            }).attr("y1", function (d) {
                return d.source.y;
            }).attr("x2", function (d) {
                return d.target.x;
            }).attr("y2", function (d) {
                return d.target.y;
            });
            filterNode.transition().duration(450).attr("cx", function (d) {
                return d.x;
            }).attr("cy", function (d) {
                return d.y;
            });
            filterText.transition().duration(450).attr("x", function (d) {
                return d.x;
            }).attr("y", function (d) {
                return d.y;
            });
            //force.resume();
            circle.remove();
        }

        function connectedNodes() {
            let d = d3.select(this).node().__data__;
            if (d3.select(this).style("opacity") == 0.1) {
                return;
            }
            if (shiftKey) {
                if (d3.select(this).style("opacity") == 1) {
                    d.selected = !d.previouslySelected;
                    d.previouslySelected = d.selected;
                    if (d.selected) {
                        d3.select(this).classed("selected", true);
                        if (d.name.trim().length > 0) {
                            $(container + " .selectedMembers").append("<li data-id='" + d.userId + "'>" + d.name + "<span class='remove-selecetd'>x</span></li>");
                        }
                    } else {
                        d3.select(this).classed("selected", false);
                        $(container + " .selectedMembers li[data-id='" + d.userId + "']").remove();
                    }
                }
                return;
            }
            nodeElem.style("opacity", function (o) {
                return neighboring(d, o) | neighboring(o, d) ? 1 : 0.1;
            });
            textElem.style("opacity", function (o) {
                return neighboring(d, o) | neighboring(o, d) ? 1 : 0.1;
            });
            linkElem.style("opacity", function (o) {
                return d.index == o.source.index | d.index == o.target.index ? 1 : 0.1;
            });
            nodeClicked = true;
        }

        function nodeMouseOut() {
            tooltip.transition().duration(200).style("opacity", 0);
            if (nodeClicked) {
                return;
            }
            searchNode();
        }

        function nodeMouseOver() {
            let d = d3.select(this).node().__data__;
            if (d3.select(this).style("opacity") == 0.1) {
                return;
            }

            toolTipPosition(this, tooltip, d);
            if (nodeClicked || fishEyeEnable || isDragging || shiftKey) {
                return;
            }
            nodeElem.style("opacity", function (o) {
                return neighboring(d, o) | neighboring(o, d) ? 1 : 0.1;
            });
            textElem.style("opacity", function (o) {
                return neighboring(d, o) | neighboring(o, d) ? 1 : 0.1;
            });
            linkElem.style("opacity", function (o) {
                return d.index == o.source.index | d.index == o.target.index ? 1 : 0.1;
            });
        }

        function showAll() {
            nodeElem.style("opacity", 1);
            textElem.style("opacity", 1);
            linkElem.style("opacity", 1);
        }

        function ticked() {
            linkElem.attr("x1", function (d) {
                return d.source.x;
            }).attr("y1", function (d) {
                return d.source.y;
            }).attr("x2", function (d) {
                return d.target.x;
            }).attr("y2", function (d) {
                return d.target.y;
            });
            nodeElem.attr("cx", function (d) {
                return d.x;
            }).attr("cy", function (d) {
                return d.y;
            });
            textElem.attr("x", function (d) {
                return d.x;
            }).attr("y", function (d) {
                return d.y;
            });
        }

        var linkedByIndex = {};
        for (i = 0; i < nodeData.length; i++) {
            linkedByIndex[i + "," + i] = 1;
        }
        linkData.forEach(function (d) {
            linkedByIndex[d.source.index + "," + d.target.index] = 1;
        });
        function neighboring(a, b) {
            return linkedByIndex[a.index + "," + b.index];
        }

        d3.select(container + ' .clearStickyDrag').on("click", function () {
            nodeElem.each(function (d) { // Allow for clicking back on previous baseNodes
                d.fixed = false;
                d.fx = null;
                d.fy = null;
            });
            simulation.alphaTarget(0.1).restart();
        });
        d3.select(container + ' .fishEye').on("change", function () {
            if (d3.select(this).property("checked")) {
                fishEyeEnable = true;
            } else {
                fishEyeEnable = false;
            }
        });
        d3.select(container + ' .textVisibility').on("change", function () {
            if (d3.select(this).property("checked")) {
                textElem.style("display", "block");
            } else {
                textElem.style("display", "none");
            }
        });
        function dragstarted(d) {
            isDragging = true;
            if (!d3.event.active) {
                simulation.alphaTarget(0.3).restart();
            }

            if (!d.selected && !shiftKey) {
                // if this node isn't selected, then we have to unselect every other node
                nodeElem.classed("selected", function (p) {
                    return p.selected = p.previouslySelected = false;
                });
            }

            d3.select(this).classed("selected", function (p) {
                d.previouslySelected = d.selected;
                return d.selected = true;
            });
            nodeElem.filter(function (d) {
                return d.selected;
            })
                    .each(function (d) { //d.fixed |= 2; 
                        d.fx = d.x;
                        d.fy = d.y;
                    })

//                d.fx = d.x;
//                d.fy = d.y;
        }

        function dragged(d) {
            isDragging = true;
            nodeElem.filter(function (d) {
                return d.selected;
            }).each(function (d) {
                d.fx += d3.event.dx;
                d.fy += d3.event.dy;
            })
        }

        function dragended(d) {
            isDragging = false;
            if (!d3.event.active) {
                simulation.alphaTarget(0);
            }
            if (d3.select(container + ' .stickyDrag').property("checked")) {
                d.fixed = true;
            } else {
                d.fx = null;
                d.fy = null;
                nodeElem.filter(function (d) {
                    return d.selected;
                })
                        .each(function (d) { //d.fixed &= ~6; 
                            d.fx = null;
                            d.fy = null;
                        })
            }
        }

        var linkSVal = 0, nodeSVal = 0;
        $(container + " .filterContainer .iis-slider").each(function () {
            var min = parseInt($(this).attr("data-min") | 0);
            var max = parseInt($(this).attr("data-max") | 0);
            var value = parseInt($(this).attr("data-value") | 0);
            var handler = $(this).find(".ui-slider-handle");
            $(this).slider({
                min: min,
                max: max,
                value: value,
                create: function () {
                    handler.text($(this).slider("value"));
                },
                slide: function (event, ui) {
                    handler.text(ui.value);
                }
            });
        });

        $(container + " .linkDistanceSlider").on("slide", function (event, ui) {
            var currentValue = parseInt(ui.value);
            var charge = currentValue < 0 ? 40 : currentValue;
            simulation.stop();
            simulation.force("link").distance(charge)
            simulation.alpha(.25).restart();
        });

        $(container + " .nodeDistanceSlider").on("slide", function (event, ui) {
            var currentValue = parseInt(ui.value);
            simulation.stop();
            simulation.force('charge', d3.forceManyBody().strength(currentValue))
            simulation.force('center', d3.forceCenter(width / 2, height / 2));
            simulation.alpha(.25).restart();
        });

        $(container + " .filterNodeSlider").on("slide", function (event, ui) {
            nodeSVal = parseInt(ui.value);
            var filterNode = {};
            nodeElem.style("opacity", function (node) {
                var nodeSValCon = nodeSVal > 0 ? (node.idx <= nodeSVal) : true;
                if (nodeSValCon) {
                    filterNode[node.id] = node.id;
                    return 1;
                } else {
                    return 0;
                }
            });
            textElem.style("opacity", function (text) {
                var nodeSValCon = nodeSVal > 0 ? (text.idx <= nodeSVal) : true;
                if (nodeSValCon) {
                    return 1;
                } else {
                    return 0;
                }
            });
            linkElem.style("opacity", function (link) {
                var linkSValCon = linkSVal > 0 ? (link.idx <= linkSVal) : true;
                if ((link.source.id in filterNode) && (link.target.id in filterNode) && linkSValCon) {
                    return 1;
                } else {
                    return 0;
                }
            });
        });

        $(container + "  .filterLinkSlider").on("slide", function (event, ui) {
            linkSVal = parseInt(ui.value);
            var filterNode = {};
            nodeElem.style("opacity", function (node) {
                var nodeSValCon = nodeSVal > 0 ? (node.idx <= nodeSVal) : true;
                if (nodeSValCon) {
                    filterNode[node.id] = node.id;
                    return 1;
                } else {
                    return 0;
                }
            });
            linkElem.style("opacity", function (link) {
                var linkSValCon = linkSVal > 0 ? (link.idx <= linkSVal) : true;
                if ((link.source.id in filterNode) && (link.target.id in filterNode) && linkSValCon) {
                    return 1;
                } else {
                    return 0;
                }
            });
        });


//Filter through date creation start
        var maxTeamDate = d3.max(users.cat, function (d) {
            if (d.dateCreated) {
                return new Date(d.dateCreated).getTime();
            } else {
                return new Date().getTime();
            }
        });

        var minTeamDate = d3.min(users.cat, function (d) {
            if (d.dateCreated) {
                return new Date(d.dateCreated).getTime();
            } else {
                return new Date().getTime();
            }
        });

        $(container + " .activeTeamSlider").on("change", function () {
            $(container + " .teamSlider").dateRangeSlider("resize");
            if ($(this).prop("checked")) {
                $(container + " .teamSlider").dateRangeSlider("enable");
                searchNode();
            } else {
                $(container + " .teamSlider").dateRangeSlider("disable");
                searchNode();
            }
        });

        $(container + " .teamSlider").dateRangeSlider({
            range: {min: {days: 7}}, //use minimum range
            bounds: {
                min: new Date(minTeamDate - (24 * 60 * 60 * 1000 * 3)),
                max: new Date(maxTeamDate + (24 * 60 * 60 * 1000 * 3))
            },
            enabled: false,
            defaultValues: {
                min: new Date(minTeamDate),
                max: new Date(minTeamDate + (24 * 60 * 60 * 1000 * 225))
            }
        });
        var teamCreatedObj = null;
        $(container + " .teamSlider").bind("valuesChanging", function (e, Obj) {
            teamCreatedObj = Obj.values;
            searchNode();
        });
        //Filter through date creation end


        d3.selectAll(container + " .teamList li input").on("click", function () {
            searchNode();
        });
        d3.selectAll(container + " .selectAllTeam").on("click", function () {
            $(container + " .teamList li input").prop('checked', true);
            searchNode();
        });

        d3.selectAll(container + " .clearAllTeams").on("click", function () {
            $(container + " .teamList li input").prop('checked', false);
            searchNode();
        });
        d3.selectAll(container + " .invertTeam").on("click", function () {
            $(container + " .teamList li input").each(function () {
                if ($(this).prop('checked')) {
                    $(this).prop('checked', false);
                } else {
                    $(this).prop('checked', true);
                }
            });
            searchNode();
        });

        $(container + ' .filterContainer .iis-colorpicker').on("click", function (e) {
            var container = $(this).find(".iris-picker");
            if (!container.is(e.target) && container.has(e.target).length === 0) {
                $(this).iris('toggle');
            }
        }).iris({
            hide: true,
            palettes: true,
            change: function (event, ui) {
                $(this).find(".color-holder").css({"background": ui.color.toString()});
                var teamId = $(this).parent().find("input.cat-filter").attr("data-value");
                nodeElem.filter(function (d) {
                    if (d.teamId == teamId) {
                        return true;
                    } else {
                        return false;
                    }
                }).attr("fill", ui.color.toString());
            }
        });

        $(container + " .selectedMembers").on("click", ".remove-selecetd", function () {
            var id = $(this).parent().attr("data-id");
            if (id && id.length > 0) {
                var d = nodeObject[id];
                d.selected = false;
                d.previouslySelected = d.selected;
                $("#" + id).removeClass("selected");
                $(this).parent().remove();
            }
        });
        $(container + " .filterContainer").accordion({
            collapsible: true,
            heightStyle: "content"
        });
    });
}

