<?php
include '../../../../wp-config.php';
global $wpdb, $current_user;
$table = $wpdb->prefix . 'expert_team_detail';
$credit_table = $wpdb->prefix . 'expert_price';
$currentuser = $current_user->ID;
$teamid = $_POST['teamid'];
$userlist = $_POST['users'];
$calltype = $_POST['calltype'];
if (empty($userlist)) {
    $teamdetail = $wpdb->get_results("SELECT * FROM $table WHERE `current_user_id`='$currentuser' AND `id`='$teamid'");
    $invited_experts = $teamdetail[0]->invited_experts;
    $team_name = $teamdetail[0]->team_name;
    $expertarray = explode(",", $invited_experts);
    if ($expertarray):
        $allprice = 0;
        foreach ($expertarray as $expertid):
            $min_value = get_user_meta($expertid, 'minimumValue', true);
            $field_value = get_user_meta($expertid, 'fieldValue', true);
            if (empty($min_value) && empty($field_value)) {
                if ($calltype == "Video") {
                    $credit_price = $wpdb->get_var("SELECT `video_min_price` FROM $credit_table WHERE `user_id`=$expertid");
                } else if ($calltype == "Chat") {
                    $credit_price = $wpdb->get_var("SELECT `chat_price` FROM $credit_table WHERE `user_id`=$expertid");
                } else if ($calltype == "SMS") {
                    $credit_price = $wpdb->get_var("SELECT `sms_price` FROM $credit_table WHERE `user_id`=$expertid");
                } else {
                    $credit_price = $wpdb->get_var("SELECT `price` FROM $credit_table WHERE `user_id`=$expertid");
                }
                $fifteenminute = ($credit_price * 15);
                $thirtyminute = ($credit_price * 30);
                $onehour = ($credit_price * 60);
                $oneanhalfhour = ($credit_price * 90);
                $twohour = ($credit_price * 120);
                $twoanhalfhour = ($credit_price * 150);
                $threehour = ($credit_price * 180);
                $threehalfhour = ($credit_price * 210);
                $fourhours = ($credit_price * 240);
            } else {
                if ($calltype == "Video") {
                    $credit_price = $wpdb->get_var("SELECT `video_min_price` FROM $credit_table WHERE `user_id`=$expertid");
                } else if ($calltype == "Chat") {
                    $credit_price = $wpdb->get_var("SELECT `chat_price` FROM $credit_table WHERE `user_id`=$expertid");
                } else if ($calltype == "SMS") {
                    $credit_price = $wpdb->get_var("SELECT `sms_price` FROM $credit_table WHERE `user_id`=$expertid");
                } else {
                    $credit_price = $wpdb->get_var("SELECT `price` FROM $credit_table WHERE `user_id`=$expertid");
                }
                $fifteenminute = ($credit_price * 15);
                if ($min_value == "mintime" && $field_value > 15) {
                    $fifteenminute = $credit_price * $field_value;
                } else if ($min_value == "minamout" && $field_value > $fifteenminute) {
                    $fifteenminute = $field_value;
                }
                $thirtyminute = ($credit_price * 30);
                if ($min_value == "mintime" && $field_value > 30) {
                    $thirtyminute = $credit_price * $field_value;
                } else if ($min_value == "minamout" && $field_value > $thirtyminute) {
                    $thirtyminute = $field_value;
                }

                $onehour = ($credit_price * 60);
                if ($min_value == "mintime" && $field_value > 60) {
                    $onehour = $credit_price * $field_value;
                } else if ($min_value == "minamout" && $field_value > $onehour) {
                    $onehour = $field_value;
                }
                $oneanhalfhour = ($credit_price * 90);
                if ($min_value == "mintime" && $field_value > 90) {
                    $oneanhalfhour = $credit_price * $field_value;
                } else if ($min_value == "minamout" && $field_value > $oneanhalfhour) {
                    $oneanhalfhour = $field_value;
                }
                $twohour = ($credit_price * 120);
                if ($min_value == "mintime" && $field_value > 120) {
                    $twohour = $credit_price * $field_value;
                } else if ($min_value == "minamout" && $field_value > $twohour) {
                    $twohour = $field_value;
                }

                $twoanhalfhour = ($credit_price * 150);
                if ($min_value == "mintime" && $field_value > 150) {
                    $twoanhalfhour = $credit_price * $field_value;
                } else if ($min_value == "minamout" && $field_value > $twoanhalfhour) {
                    $twoanhalfhour = $field_value;
                }
                $threehour = ($credit_price * 180);
                if ($min_value == "mintime" && $field_value > 180) {
                    $threehour = $credit_price * $field_value;
                } else if ($min_value == "minamout" && $field_value > $threehour) {
                    $threehour = $field_value;
                }
                $threehalfhour = ($credit_price * 210);
                if ($min_value == "mintime" && $field_value > 210) {
                    $threehalfhour = $credit_price * $field_value;
                } else if ($min_value == "minamout" && $field_value > $threehalfhour) {
                    $threehalfhour = $field_value;
                }
                $fourhours = ($credit_price * 240);
                if ($min_value == "mintime" && $field_value > 240) {
                    $fourhours = $credit_price * $field_value;
                } else if ($min_value == "minamout" && $field_value > $fourhours) {
                    $fourhours = $field_value;
                }
            }
            $finalfifteen += $fifteenminute;
            $finalthirtyminute += $thirtyminute;
            $finalonehour += $onehour;
            $finaloneanhalfhour += $oneanhalfhour;
            $finaltwohour += $twohour;
            $finaltwoanhalfhour += $twoanhalfhour;
            $finalthreehour += $threehour;
            $finalthreehalfhour += $threehalfhour;
            $finalfourhours += $fourhours;
        endforeach;
    endif;
} else {
    $expertarray = explode(",", $userlist);
    $allprice = 0;
    foreach ($expertarray as $expertid):
        $min_value = get_user_meta($expertid, 'minimumValue', true);
        $field_value = get_user_meta($expertid, 'fieldValue', true);
        if (empty($min_value) && empty($field_value)) {
            if ($calltype == "Video") {
                $credit_price = $wpdb->get_var("SELECT `video_min_price` FROM $credit_table WHERE `user_id`=$expertid");
            } else if ($calltype == "Chat") {
                $credit_price = $wpdb->get_var("SELECT `chat_price` FROM $credit_table WHERE `user_id`=$expertid");
            } else if ($calltype == "SMS") {
                $credit_price = $wpdb->get_var("SELECT `sms_price` FROM $credit_table WHERE `user_id`=$expertid");
            } else {
                $credit_price = $wpdb->get_var("SELECT `price` FROM $credit_table WHERE `user_id`=$expertid");
            }
            $fifteenminute = ($credit_price * 15);
            $thirtyminute = ($credit_price * 30);
            $onehour = ($credit_price * 60);
            $oneanhalfhour = ($credit_price * 90);
            $twohour = ($credit_price * 120);
            $twoanhalfhour = ($credit_price * 150);
            $threehour = ($credit_price * 180);
            $threehalfhour = ($credit_price * 210);
            $fourhours = ($credit_price * 240);
            
        } else {
            if ($calltype == "Video") {
                $credit_price = $wpdb->get_var("SELECT `video_min_price` FROM $credit_table WHERE `user_id`=$expertid");
            } else if ($calltype == "Chat") {
                $credit_price = $wpdb->get_var("SELECT `chat_price` FROM $credit_table WHERE `user_id`=$expertid");
            } else if ($calltype == "SMS") {
                $credit_price = $wpdb->get_var("SELECT `sms_price` FROM $credit_table WHERE `user_id`=$expertid");
            } else {
                $credit_price = $wpdb->get_var("SELECT `price` FROM $credit_table WHERE `user_id`=$expertid");
            }
            $fifteenminute = ($credit_price * 15);
            if ($min_value == "mintime" && $field_value > 15) {
                $fifteenminute = $credit_price * $field_value;
            } else if ($min_value == "minamout" && $field_value > $fifteenminute) {
                $fifteenminute = $field_value;
            }
            $thirtyminute = ($credit_price * 30);
            if ($min_value == "mintime" && $field_value > 30) {
                $thirtyminute = $credit_price * $field_value;
            } else if ($min_value == "minamout" && $field_value > $thirtyminute) {
                $thirtyminute = $field_value;
            }

            $onehour = ($credit_price * 60);
            if ($min_value == "mintime" && $field_value > 60) {
                $onehour = $credit_price * $field_value;
            } else if ($min_value == "minamout" && $field_value > $onehour) {
                $onehour = $field_value;
            }
            $oneanhalfhour = ($credit_price * 90);
            if ($min_value == "mintime" && $field_value > 90) {
                $oneanhalfhour = $credit_price * $field_value;
            } else if ($min_value == "minamout" && $field_value > $oneanhalfhour) {
                $oneanhalfhour = $field_value;
            }
            $twohour = ($credit_price * 120);
            if ($min_value == "mintime" && $field_value > 120) {
                $twohour = $credit_price * $field_value;
            } else if ($min_value == "minamout" && $field_value > $twohour) {
                $twohour = $field_value;
            }

            $twoanhalfhour = ($credit_price * 150);
            if ($min_value == "mintime" && $field_value > 150) {
                $twoanhalfhour = $credit_price * $field_value;
            } else if ($min_value == "minamout" && $field_value > $twoanhalfhour) {
                $twoanhalfhour = $field_value;
            }
            $threehour = ($credit_price * 180);
            if ($min_value == "mintime" && $field_value > 180) {
                $threehour = $credit_price * $field_value;
            } else if ($min_value == "minamout" && $field_value > $threehour) {
                $threehour = $field_value;
            }
            $threehalfhour = ($credit_price * 210);
            if ($min_value == "mintime" && $field_value > 210) {
                $threehalfhour = $credit_price * $field_value;
            } else if ($min_value == "minamout" && $field_value > $threehalfhour) {
                $threehalfhour = $field_value;
            }
            $fourhours = ($credit_price * 240);
            if ($min_value == "mintime" && $field_value > 240) {
                $fourhours = $credit_price * $field_value;
            } else if ($min_value == "minamout" && $field_value > $fourhours) {
                $fourhours = $field_value;
            }
        }
        $finalfifteen += $fifteenminute;
        $finalthirtyminute += $thirtyminute;
        $finalonehour += $onehour;
        $finaloneanhalfhour += $oneanhalfhour;
        $finaltwohour += $twohour;
        $finaltwoanhalfhour += $twoanhalfhour;
        $finalthreehour += $threehour;
        $finalthreehalfhour += $threehalfhour;
        $finalfourhours += $fourhours;
    endforeach;
}
?>
<label>Set Estimate Length</label>
<select data-expert-id="<?php echo $userid; ?>" id="estimate_length" >
    <option value="">Select estimate length</option>
    <option data-time-attr="15" value="<?php echo $finalfifteen; ?>">15 Mins  (<?php printf("%04d", $finalfifteen); ?> Credits)</option>
    <option data-time-attr="30" value="<?php echo $finalthirtyminute; ?>">30 Mins  (<?php printf("%04d", $finalthirtyminute); ?> Credits)</option>
    <option data-time-attr="60" value="<?php echo $finalonehour; ?>">01 Hour  (<?php printf("%04d", $finalonehour); ?> Credits)</option>
    <option data-time-attr="90" value="<?php echo $finaloneanhalfhour; ?>">1.5 Hour  (<?php printf("%04d", $finaloneanhalfhour); ?> Credits)</option>

    <option data-time-attr="120" value="<?php echo $finaltwohour; ?>">02 Hour  (<?php printf("%04d", $finaltwohour); ?> Credits)</option>

    <option data-time-attr="150" value="<?php echo $finaltwoanhalfhour; ?>">2.5 Hour  (<?php printf("%04d", $finaltwoanhalfhour); ?> Credits)</option>

    <option data-time-attr="180" value="<?php echo $finalthreehour; ?>">03 Hour  (<?php printf("%04d", $finalthreehour); ?> Credits)</option>

    <option data-time-attr="210" value="<?php echo $finalthreehalfhour; ?>">3.5 Hour  (<?php printf("%04d", $finalthreehalfhour); ?> Credits)</option>

    <option data-time-attr="240" value="<?php echo $finalfourhours; ?>">04 Hour  (<?php printf("%04d", $finalfourhours); ?> Credits)</option>
</select>
