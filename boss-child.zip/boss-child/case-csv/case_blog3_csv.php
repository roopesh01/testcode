<?php
	include '../../../../wp-config.php';
	global $wpdb;
	$filename   = 'case_blog_level3.csv';
	$header_row = array(
		0 => 'id',
		1 => 'case_blog_id',
		2 => 'case_post',
		3 => 'author',
		4 => 'tags',
		5 => 'share',
		6 => 'case_expert',
		7 => 'post_views',
	);
	$data_rows  = array();
	$table      = $wpdb->prefix . 'case_blog_level3';
	$result     = $wpdb->get_results( "SELECT * FROM $table" );
	foreach ( $result as $results ) {
		$row         = array();
		$row[0]      = $results->post_title;
		$row[1]      = $results->case_blog_id;
		$row[2]      = $results->case_post;
		$row[3]      = $results->author;
		$row[4]      = $results->tags;
		$row[5]      = $results->share;
		$row[6]      = $results->case_expert;
		$row[7]      = $results->post_views;
		$data_rows[] = $row;
	}
	$fh = @fopen( 'php://output', 'w' );
	fprintf( $fh, chr( 0xEF ) . chr( 0xBB ) . chr( 0xBF ) );
	header( 'Cache-Control: must-revalidate, post-check=0, pre-check=0' );
	header( 'Content-Description: File Transfer' );
	header( 'Content-type: text/csv' );
	header( "Content-Disposition: attachment; filename={$filename}" );
	header( 'Expires: 0' );
	header( 'Pragma: public' );
	fputcsv( $fh, $header_row );
	foreach ( $data_rows as $data_row ) {
		fputcsv( $fh, $data_row );
	}
	fclose( $fh );
	die();



