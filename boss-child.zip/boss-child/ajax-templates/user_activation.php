<?php
include '../../../../wp-config.php';
global $wpdb,$current_user;
$table       = $wpdb->prefix . 'nominee_list';
$vote_table  = $wpdb->prefix . 'nominee_list_vote';
$id          = vl_sanitize_unslash( 'id' );
$email       = vl_sanitize_unslash( 'emailid' );
$action      = vl_sanitize_unslash( 'action' );
$coupon_code = vl_sanitize_unslash( 'code' );
$send        = vl_sanitize_unslash( 'send' );

if ( email_exists( $email ) ) {
	// this user is iis user
	echo "Already IIS user. So you can't change user status.";
	exit();
}
$user_detail   = $wpdb->get_results(
	$wpdb->prepare(
		"SELECT * FROM $table WHERE id= %d",
		$id
	)
);
$link_page_yes = get_site_url() . '/nominee-confirmation-page/?id=' . $id . '&email=' . $email . '&des=yes';

$link_page_no = get_site_url() . '/nominee-confirmation-page/?id=' . $id . '&email=' . $email . '&des=no';

foreach ( $user_detail as $user_details ) {

	$firstname  = $user_details->firstname;
	$middlename = $user_details->middlename;
	$lastname   = $user_details->lastname;
	$userrole   = $user_details->role_selected;
}

if ( ! empty( $middlename ) ) {
	$full_name = $firstname . ' ' . $middlename . ' ' . $lastname;
} else {
	$full_name = $firstname . ' ' . $lastname;
}

function user_activation_notification() {
	return 'User Activation Notification';
}
add_filter( 'wp_mail_from_name', 'user_activation_notification' );

if ( ! empty( $action ) ) {
	if ( ! empty( $send ) ) {
		$updatevote = $wpdb->query( $wpdb->prepare( "UPDATE $vote_table SET admin_override= 'yes', nominee_decision = 'Pending', send_coupon= %s, coupon_code= %s WHERE list_id = %d AND email_id= %s", $send, $coupon_code, $id, $email ) );
	} else {
		$updatevote = $wpdb->query( $wpdb->prepare( "UPDATE $vote_table SET admin_override= 'yes', nominee_decision = 'Pending' WHERE list_id = %d AND email_id= %s", $id, $email ) );
	}

	$updatelist = $wpdb->query( $wpdb->prepare( "UPDATE $table SET admin_override= 'yes', nominee_decision = 'Pending' WHERE id = %d AND emailid= %s", $id, $email ) );

	include VL_THEME_DIR . '/email-template/user_activation_email.php';

} else {
	if ( ! empty( $send ) ) {
		$updatevote = $wpdb->query( $wpdb->prepare( "UPDATE $vote_table SET send_coupon= %s, coupon_code= %s WHERE list_id = %d AND email_id= %s", $send, $coupon_code, $id, $email ) );
	}
	include VL_THEME_DIR . '/email-template/user_activation_email.php';
}
