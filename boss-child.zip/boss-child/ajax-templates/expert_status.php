<?php
include '../../../../wp-config.php';
global $wpdb,$current_user;
$table = $wpdb->prefix."expert_dashboard_status";
$id = $_POST['expertid'];
$expername = $_POST['expername'];
$status = $_POST['status'];
$user_check = $wpdb->get_results( $wpdb->prepare("SELECT * FROM $table WHERE userid= %d", $id) );
if(empty($user_check))
{
	$insert_variable = $wpdb->insert( $table,
                        array
                        (
                            'userid' => $id,
                            'username' =>$expername,
                            'userstatus' =>$status,                      
                        ),
                        array('%d','%s','%d')
                    );
					
	if($insert_variable == 1)
	{
		echo "status insert sucessful";
		echo $expername;
	}
}
else
{
	$updatestatus = $wpdb->query( $wpdb->prepare("UPDATE $table SET userstatus= %d WHERE userid = %d", $status, $id) );
	
	if($updatestatus == 1)
	{
		echo "status update sucessful";
		echo $status;
	}
}