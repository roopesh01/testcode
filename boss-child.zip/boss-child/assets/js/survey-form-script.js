    (function($)
    {
        $(document).ready(function()
        {
            var wp_nonce = $( '.wp_nonce' ).val();
            var home_url = $('.home_url').val();
            /* Seller Survey */
            $(document).on('click','#submit_category', function(e)
            {
                
               var select_category = $('#select_category').val();
               var confirms = confirm( 'Are you Sure' );              
               if( confirms==true )
               {
                   $("html").addClass("overlay");
                   $.ajax
                    ({
                        type: 'POST',
                        url: ajaxurl,
                        data: 
                        { 
                            select_category: select_category,
                            security: wp_nonce,
                            action : 'vl_primary_category'
                        },
                        success: function(html)
                        {
                            $("html").removeClass("overlay");
                            alert('success');
                            location.assign(home_url+'/my-account/user_survey/'); 
                        },
                        error: function(MLHttpRequest, textStatus, errorThrown)
                        {
                        }
                    });
                }                               
            });
            $(document).on('click','.show_hide', function(e)
            {
                $(this).parent('.surveysubheading').parent('.surveysection').find('.surveylabel').toggle();
                if($(this).hasClass('hide_show'))
                {
                    $(this).removeClass('hide_show');
                    $(this).text('+');
                }
                else
                {
                    $(this).addClass('hide_show');
                    $(this).text('-');                    
                }
            });
            $(document).on('click','.panel-title a', function(e)
            {                
				$(this).toggleClass('panOpen');
				$(this).parent('.panel-title').parent('.panel-heading').parent('.panel-default').toggleClass('panelOpen');                
            });                    
            $(document).on('click','#submitexpertsurveyy',function(e)
            {
                /* new functionality for unchecked */                
                var uncheckedarray = [];
                var checkedarray = [];
                var approvearray = [];
                
                 $( '.approve_sub_cat' ).each(function()
                 {
                     if ( ! $(this).is( ':checked' ) )
                     {
                        var unchecked_subcatid = $(this).attr("id");
                        uncheckedarray.push(unchecked_subcatid);
                     }
                     if ( $(this).is( ':checked' ) )
                     {
                        var checked_subcatid = $(this).attr("id");
                        checkedarray.push(checked_subcatid);
                     }
                 });
                 $('.approve_yes').each(function()
                 {
                     if ( ! $(this).is( ':checked' ) )
                     {
                        var approve_subcatid = $(this).attr("id");
                        approvearray.push(approve_subcatid);
                     }
                     
                 });
                var approvearr = approvearray.join(',' );                
                var checkedarr = checkedarray.join(',' ); 
                var uncheckedarr = uncheckedarray.join (',', );                              
                $("html").addClass("overlay"); 
                $.ajax
                ({
                    type: 'POST',                        
                    url: ajaxurl,
                    data: 
                    {
                        checkedarr: checkedarr,
                        approvearr: approvearr,
                        security: wp_nonce,
                        action: 'vl_survey_form_ajax'
                    },
                    success: function(html)
                    {
                        
                        $("html").removeClass("overlay");
                        alert('success');
                        location.assign(home_url+'/my-account/user_survey/');
                    },
                    error: function(MLHttpRequest, textStatus, errorThrown)
                    {
                    }
                });
            });            
          });
    })(jQuery);