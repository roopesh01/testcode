/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
var userLinkToOpen = location.origin;
function initGMap() {
  var Gmap = new google.maps.Map(document.getElementById("map"), {
    zoom: 2,
    minZoom: 2,
    center: { lat: 40.795343, lng: -6.365172 },
    mapTypeId: "terrain",
    gestureHandling: "greedy"
  });
  google.maps.event.addListener(Gmap, "move", function() {
    checkBounds();
  });

  var circles = [];
  var connectionArr = [];
  var multiSitePath = graphVariables.siteUrl ? graphVariables.siteUrl : "";
  $.ajax({
    url: multiSitePath + "/wp-content/themes/boss-child/service/getMapData.php",
    dataType: "json"
  }).done(function(data, status) {
    var arcs = [],
      lookupTable = {},
      users = [];
    var teamObj = {};
    var groupArray = [];
    var groupNameArray = [];
    var countryName = {};
    var colorArray = {};
    var groupCityName = [];
    var linearScale = d3
      .scaleLinear()
      .domain([
        0,
        d3.max(data, function(d) {
          return parseFloat(d.wealth) || 0;
        })
      ])
      .clamp(true)
      .range([4, 30]);
    data.forEach(function(node) {
      var tCountryName = toTitleCase(
        node.country ? node.country.trim() : node.country
      );
      if (countryName[tCountryName]) {
        var countryCount = countryName[tCountryName].count + 1;
        countryName[tCountryName].count = countryCount;
        var count = parseInt(countryName[tCountryName].stateCount) + 1;
        countryName[tCountryName].stateCount = count;
        var cityName = toTitleCase(node.city ? node.city.trim() : node.city);
        if (node.city) {
          if (countryName[tCountryName].cityArr[cityName]) {
            var ctyCount =
              parseInt(countryName[tCountryName].cityArr[cityName].count) + 1;
            countryName[tCountryName].cityArr[cityName].count = ctyCount;
          } else {
            countryName[tCountryName].cityArr[cityName] = {
              name: cityName,
              count: 1
            };
          }
        }
      } else {
        if (tCountryName) {
          countryName[tCountryName] = {
            name: tCountryName,
            stateCount: 1,
            cityArr: {},
            count: 1
          };
          var cityName = toTitleCase(node.city ? node.city.trim() : node.city);
          if (node.city) {
            if (countryName[tCountryName].cityArr[cityName]) {
              var ctyCount =
                parseInt(countryName[tCountryName].cityArr[cityName].count) + 1;
              countryName[tCountryName].cityArr[cityName].count = ctyCount;
            } else {
              countryName[tCountryName].cityArr[cityName] = {
                name: cityName,
                count: 1
              };
            }
          }
        }
      }
      var isCityFound = false;
      node.city = node.city == null ? "Default" : node.city;
      for (var city of groupCityName) {
        if (city == node.city) {
          isCityFound = true;
          break;
        }
      }
      if (!isCityFound) {
        groupCityName.push(node.city);
      }
      node.teamName = node.teamName == null ? "Default" : node.teamName;
      //For counting the filter user end
      var tTeamId = node.teamName.trim();
      if (!teamObj[tTeamId]) {
        teamObj[tTeamId] = tTeamId;
        groupArray.push(tTeamId);
        groupNameArray[tTeamId] = Object.assign({
          count: 1,
          name: node.teamName
        });
        // insert the city name
        colorArray[tTeamId] = getRandomColor();
      } else {
        var count = parseInt(groupNameArray[tTeamId].count + 1);
        groupNameArray[tTeamId] = Object.assign({
          count: count,
          name: node.teamName
        });
      }

      var id = null;
      id = node.userId;
      var bounceTimer;

      if (node.latitude && node.longitude) {
        var html =
          "Name :" +
          node.name +
          "<br>" +
          "Organization : " +
          node.org +
          "<br>" +
          "Designation : " +
          node.job_title +
          "<br>" +
          "City : " +
          node.city +
          "<br>" +
          "Country : " +
          node.country +
          "<br>" +
          "State : " +
          node.state +
          "<br>" +
          "wealth : " +
          node.wealth +
          "<br>" +
          "payrate : " +
          node.userPrice +
          "<br>" +
          //"DOC : " + node.registered + "<br>" +
          "UserId : " +
          node.userId +
          "";
        var user = new google.maps.Marker({
          position: {
            lat: parseFloat(node.latitude),
            lng: parseFloat(node.longitude)
          },
          initPosition: {
            lat: parseFloat(node.latitude),
            lng: parseFloat(node.longitude)
          },
          icon: {
            path: google.maps.SymbolPath.CIRCLE,
            scale: linearScale(node.wealth),
            fillColor: colorArray[node.teamName],
            fillOpacity: 0.9,
            strokeColor: "#fff",
            strokeOpacity: 1,
            strokeWeight: 2
          },
          draggable: false,
          map: Gmap,
          data: node
        });
        var infowindow = new google.maps.InfoWindow({
          content: html
        });
        users.push(user);
        google.maps.event.addListener(user, "mouseover", function() {
          infowindow.open(Gmap, user);
        });
        google.maps.event.addListener(user, "mouseout", function() {
          infowindow.close();
        });
        google.maps.event.addListener(user, "click", function() {
          //var twin = window.open(userLinkToOpen + user.data.userId);
        });
      }
      lookupTable[id] = Object.assign({}, node);
    });

    /*

         //important do not delete.

         var circleCount = d3.nest().key(function (d) {
         return Math.ceil(d.wealth);
         }).rollup(function (v) {
         return v.length;
         }).sortKeys(function (cElem, nElem) {
         return cElem - nElem;
         }).entries(data);
         */

    //Filter through pay rate start.
    var priceForSearch = 0;
    $(document).on("input", "#mapSlider", function() {
      priceForSearch = $(this).val();
      searchNode();
    });
    //Filter through pay rate end.

    //  Filter data using wealth Start
    var wealthForSearch = 0;
    var wcircleCount =
      Math.ceil(linearScale.invert(30)) >= 5
        ? 5
        : Math.ceil(linearScale.invert(30)) == 0
          ? 1
          : Math.ceil(linearScale.invert(30)) + 1;
    for (var i = 1; i <= wcircleCount; i++) {
      jQuery("#wealthFilterMap").append(
        "<div>" +
          '<span class="wealth-circle" data-value="' +
          i +
          '" style="padding:' +
          i * 3 +
          "px" +
          '"></span>' +
          '<span class="wealth-value">' +
          Math.ceil(linearScale.invert(i * 6)) +
          "</span>" +
          "</div>"
      );
    }

    jQuery("#wealthFilterMap .wealth-circle").on("click", function() {
      jQuery("#wealthFilterMap .wealth-circle").removeClass("active");
      jQuery(this).addClass("active");
      wealthForSearch = parseInt($(this).attr("data-value"));
      searchNode();
    });

    jQuery("#clearMapWealthFilter").on("click", function() {
      wealthForSearch = 0;
      jQuery("#wealthFilterMap .wealth-circle").removeClass("active");
      searchNode();
    });
    google.maps.event.addListener(map, "idle", function() {
      console.log("mak");
    });
    jQuery("#mapWrapper .printMap").on("click", function() {
      printGoogleMaps("#map", Gmap);
    });
    //Filter data using wealth End

    // Filter through country,city start
    var countryOption = "";
    var selectedCountries = [];
    var selectedCities = [];
    for (var country in countryName) {
      countryOption +=
        "<option>" +
        country +
        " - (" +
        countryName[country].count +
        ")</option>";
    }
    jQuery("#cityList").SumoSelect();
    jQuery("#countryList")
      .html(countryOption)
      .on("change", function() {
        selectedCountries = $(this).val();
        if (selectedCountries) {
          selectedCountries = selectedCountries.map(function(value, index) {
            return value.substring(0, value.lastIndexOf("-") - 1);
          });
        } else {
          selectedCountries = [];
        }
        var cityOption = "",
          cityObject = {};
        for (var i = 0; i < selectedCountries.length; i++) {
          var cityArr = countryName[selectedCountries[i]].cityArr;
          for (var city in cityArr) {
            if (!cityObject[city]) {
              cityObject[city] = cityArr[city];
            }
          }
        }
        for (var city in cityObject) {
          cityOption +=
            "<option>" + city + " - (" + cityObject[city].count + ")</option>";
        }

        jQuery("#cityList")
          .html(cityOption)
          .on("change", function() {
            selectedCities = $(this).val();
            selectedCities = selectedCities.map(function(value, index) {
              return value.substring(0, value.lastIndexOf("-") - 1);
            });
            searchNode();
          })
          .SumoSelect()
          .sumo.reload();
        selectedCities = [];
        searchNode();
      })
      .SumoSelect();

    // Filter through country,city  end.

    //Filter through category start.
    var filterList = "";
    for (var i = 0; i < groupArray.length; i++) {
      filterList +=
        '<li style="background:' +
        colorArray[groupArray[i]] +
        '">' +
        '<input type="checkbox" class="cat-filter" data-name="' +
        groupArray[i] +
        '"/>' +
        "<div><span>" +
        groupNameArray[groupArray[i]].name +
        "</span>" +
        "<span>(" +
        groupNameArray[groupArray[i]].count +
        ")</span></div>" +
        "</li>";
    }

    d3.select("#mapContainer .category-filter ul").html(filterList);
    d3
      .selectAll("#mapContainer .category-filter ul input")
      .on("change", function() {
        searchNode();
      });

    d3.selectAll("#mapContainer .action-filter input").on("click", function() {
      switch (d3.select(this).attr("value")) {
        case "All": {
          d3
            .selectAll("#mapContainer .category-filter ul input")
            .property("checked", true);
          break;
        }
        case "Clear": {
          d3
            .selectAll("#mapContainer .category-filter ul input")
            .property("checked", false);
          break;
        }
        case "Invert": {
          d3
            .selectAll("#mapContainer .category-filter ul input")
            .select(function() {
              if (d3.select(this).property("checked")) {
                d3.select(this).property("checked", false);
              } else {
                d3.select(this).property("checked", true);
              }
            });
          break;
        }
      }
      searchNode();
    });
    //Filter through category end.

    //Filter through user creation date start.
    jQuery("#activeMapUserSlider").on("change", function() {
      $("#mapUserSlider").dateRangeSlider("resize");
      if (jQuery(this).prop("checked")) {
        $("#mapUserSlider").dateRangeSlider("enable");
        searchNode();
      } else {
        $("#mapUserSlider").dateRangeSlider("disable");
      }
    });
    var userCreateObj = {};
    var maxUserDate = d3.max(data, function(d) {
      if (d.registered) {
        return new Date(d.registered).getTime();
      } else {
        return new Date().getTime();
      }
    });

    var minUserDate = d3.min(data, function(d) {
      if (d.registered) {
        return new Date(d.registered).getTime();
      } else {
        return new Date().getTime();
      }
    });

    $("#mapUserSlider").dateRangeSlider({
      range: { min: new Date(2012, 0, 1) }, //use minimum range
      bounds: {
        min: new Date(minUserDate),
        max: new Date(maxUserDate + 24 * 60 * 60 * 1000 * 30)
      },
      enabled: false,
      defaultValues: {
        min: new Date(minUserDate),
        max: new Date(minUserDate + 24 * 60 * 60 * 1000 * 15)
      }
    });

    $("#mapUserSlider").bind("valuesChanging", function(e, data) {
      userCreateObj = data.values;
      searchNode();
    });
    //Filter through user creation date end.

    //show friend connectivity start.
    jQuery("#activeMapFriendSlider").on("change", function() {
      $("#mapFriendSlider").dateRangeSlider("resize");
      if (jQuery(this).prop("checked")) {
        $("#mapFriendSlider").dateRangeSlider("enable");
        callbackFriendFilter();
      } else {
        $("#mapFriendSlider").dateRangeSlider("disable");
        searchNode();
      }
    });

    var maxFriendDate = d3.max(data, function(d) {
      if (d.registered) {
        return new Date(d.registered).getTime();
      } else {
        return new Date().getTime();
      }
    });

    var minFriendDate = d3.min(data, function(d) {
      if (d.registered) {
        return new Date(d.registered).getTime();
      } else {
        return new Date().getTime();
      }
    });

    $("#mapFriendSlider").dateRangeSlider({
      range: { min: new Date(2012, 0, 1) }, //use minimum range
      bounds: {
        min: new Date(minFriendDate),
        max: new Date(maxFriendDate + 24 * 60 * 60 * 1000 * 30)
      },
      enabled: false,
      defaultValues: {
        min: new Date(minFriendDate),
        max: new Date(minFriendDate + 24 * 60 * 60 * 1000 * 15)
      }
    });

    var friendCreateObj = {};
    $("#mapFriendSlider").bind("valuesChanging", function(e, data) {
      friendCreateObj = data.values;
      callbackFriendFilter();
    });

    function callbackFriendFilter() {
      if (friendCreateObj) {
        var searchFriend = $("#activeMapFriendSlider").is(":checked");
        var friendFilter = {};
        var friendFilterId = [];
        if (friendCreateObj.min && searchFriend) {
          users.forEach(function(d) {
            if (d.data) {
              var min = friendCreateObj.min.getTime();
              var max = friendCreateObj.max.getTime();
              var tfriendArray = [];
              if (d.data.friendGroup) {
                tfriendArray = d.data.friendGroup.split(",");
              }
              var tuser = new Date(d.data.registered).getTime();
              if (tuser >= min && tuser <= max && d.visible) {
                friendFilterId.push(d.data.userId);
                for (var i = 0; i < tfriendArray.length; i++) {
                  friendFilter[d.data.userId] = users.filter(function(td) {
                    if (td.data.userId == tfriendArray[i]) {
                      return true;
                    } else {
                      return false;
                    }
                  });
                }
              }
            }
          });
          connectionArr.forEach(function(d) {
            if (
              friendFilterId.indexOf("" + d.destination) >= 0 &&
              friendFilterId.indexOf("" + d.source) >= 0
            ) {
              d.setOptions({ strokeOpacity: 1 });
            } else {
              d.setOptions({ strokeOpacity: 0 });
            }
          });
        }
      }
    }

    //show friend connectivity end.
    function searchNode() {
      var filteredUserId = [];
      var wealthMax = Math.ceil(linearScale.invert(wealthForSearch * 6));
      var wealthMin = Math.ceil(linearScale.invert((wealthForSearch - 1) * 6));
      var searchUser = $("#activeMapUserSlider").is(":checked");

      var selectedText = [];
      d3
        .selectAll("#mapContainer .category-filter ul input")
        .select(function() {
          if (d3.select(this).property("checked")) {
            selectedText.push(d3.select(this).attr("data-name"));
          }
        });

      users.forEach(function(d) {
        var currentUserPrice = parseFloat(d.data.userPrice) || 0;
        var currentUserWealth = d.data.wealth ? parseFloat(d.data.wealth) : 0;
        var currentUserCountry = toTitleCase(
          d.data.country ? d.data.country.trim() : ""
        );
        var currentUserCity = toTitleCase(
          d.data.city ? d.data.city.trim() : ""
        );
        var currentUserCategory = d.data.teamId ? d.data.teamId : 0;
        var currentUserCreation = d.data.registered
          ? new Date(d.data.registered).getTime()
          : null;
        var priceCondition = (priceForSearch == 0 ? true : false)
          ? true
          : currentUserPrice <= priceForSearch;
        var wealthCondition = (wealthForSearch == 0 ? true : false)
          ? true
          : wealthMax >= currentUserWealth && wealthMin <= currentUserWealth;
        var countryCondition = (selectedCountries.length == 0 ? true : false)
          ? true
          : selectedCountries.indexOf(currentUserCountry) >= 0;
        var cityCondition = (selectedCities.length == 0 ? true : false)
          ? true
          : selectedCities.indexOf(currentUserCity) >= 0;
        var categoryCondition = (selectedText.length == 0 ? true : false)
          ? true
          : selectedText.indexOf(d.data.teamName) >= 0;
        var creationCondition = false;
        if (searchUser && userCreateObj && userCreateObj.min) {
          if (currentUserCreation) {
            var UCmin = userCreateObj.min.getTime();
            var UCmax = userCreateObj.max.getTime();
            creationCondition =
              currentUserCreation >= UCmin && currentUserCreation <= UCmax;
          } else {
            creationCondition = false;
          }
        } else {
          creationCondition = true;
        }

        if (
          priceCondition &&
          wealthCondition &&
          countryCondition &&
          cityCondition &&
          categoryCondition &&
          creationCondition
        ) {
          filteredUserId.push(d.data.userId);
          d.setVisible(true);
        } else {
          d.setVisible(false);
        }
      });
      connectionArr.forEach(function(d) {
        if (
          filteredUserId.indexOf("" + d.destination) >= 0 &&
          filteredUserId.indexOf("" + d.source) >= 0
        ) {
          d.setOptions({ strokeOpacity: 1 });
        } else {
          d.setOptions({ strokeOpacity: 0 });
        }
      });
    }

    function showAll() {
      users.forEach(function(d) {
        d.setVisible(true);
      });
      connectionArr.forEach(function(d) {
        d.setVisible(true);
        d.setOptions({ strokeOpacity: 1 });
      });
    }

    data.forEach(function(node) {
      if (node.friendGroup) {
        var friendArr = node.friendGroup.split(",");
        for (var i = 0; i < friendArr.length; i++) {
          if (
            lookupTable[friendArr[i]] &&
            lookupTable[friendArr[i]].latitude &&
            lookupTable[friendArr[i]].longitude
          ) {
            var arc = [];
            arc.push({
              lat: parseFloat(node.latitude),
              lng: parseFloat(node.longitude),
              userId: node.userId
            });
            arc.push({
              lat: parseFloat(lookupTable[friendArr[i]].latitude),
              lng: parseFloat(lookupTable[friendArr[i]].longitude),
              userId: lookupTable[friendArr[i]].userId
            });
            arcs.push(arc);
            var connection = new google.maps.Polyline({
              path: arc,
              geodesic: true,
              strokeColor: colorArray[node.teamId],
              strokeOpacity: 1.0,
              strokeWeight: 2,
              source: node.userId,
              destination: lookupTable[friendArr[i]].userId
            });
            connection.setMap(Gmap);
            connectionArr.push(connection);
          }
        }
      }
    });
  });

  $("#showConnectivity").on("change", function() {
    if ($(this).prop("checked")) {
      connectionArr.forEach(function(connection) {
        connection.setVisible(false);
      });
    } else {
      connectionArr.forEach(function(connection) {
        connection.setVisible(true);
      });
    }
  });
  function toTitleCase(str) {
    if (str) {
      return str.replace(/\w\S*/g, function(txt) {
        return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();
      });
    } else {
      return str;
    }
  }
  function getRandomColor() {
    var letters = "012345678";
    var color = "#";
    for (var i = 0; i < 6; i++) {
      color += letters[Math.floor(Math.random() * 9)];
    }
    return color;
  }
  google.maps.event.trigger(Gmap, "resize");
  d3.select("#mapContainer").style("display", "block");
  d3.select("#network").style("display", "none");
  d3.select("#cluster").style("display", "none");
}
