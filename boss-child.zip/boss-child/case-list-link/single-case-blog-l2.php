<?php

/*
Template Name: single case blog l2
*/
get_header();/*
the_title();
echo '<br/>';
 $test = get_page_template();
 echo $test;*/
?>
	<script src="https://code.jquery.com/ui/1.12.0/jquery-ui.js" type="text/javascript"></script>
	<link rel="stylesheet" href="<?php echo get_stylesheet_directory_uri(); ?>/css/create_meeting.css" />    
	<!-- Flexslider  CSS JS -->
	<!-- Data Table Script CSs-->
	<script src="<?php echo get_stylesheet_directory_uri(); ?>/expert-pagination/jquery.dataTables.min.js" type="text/javascript"></script>
	<script src="<?php echo get_stylesheet_directory_uri(); ?>/case-data/js/ion.imageSlider.js" type="text/javascript"></script>
	<link rel="stylesheet" href="<?php echo get_stylesheet_directory_uri(); ?>/expert-pagination/jquery.dataTables.css" />
	<link rel="stylesheet" href="<?php bloginfo( 'stylesheet_directory' ); ?>/css/jquery-ui.css"/>
	<link rel="stylesheet" href="<?php bloginfo( 'stylesheet_directory' ); ?>/case-data/css/ion.imageSlider.css"/>
	<link rel="stylesheet" href="<?php bloginfo( 'stylesheet_directory' ); ?>/case-data/css/ion.imageSlider.minimal.css"/>
	<!-- Data Table Script CSs-->    
	<!-- Custom Script -->   
	<script src="<?php echo get_stylesheet_directory_uri(); ?>/js/case_evidence_l3_js.js"></script>
	<?php
	global $wpdb, $current_user;
	$table      = $wpdb->prefix . 'case_events_timeline';
	$result     = $wpdb->get_results( "SELECT * FROM $table" );
	$user_id    = $current_user->ID;
		?>
		<div class="page-full-width"> <!-- Full Width-->
		<div id="primary" class="site-content"><!-- Site  Content-->
			<div id="content" role="main" class="contentmeeting pageSpacing"><!-- Main  Content-->
				<div><h2 class="ccTytl">Case Events Timeline</h2></div>
			
		<!----------------------------------Design View  Section --------------------->
		<div id="content_view">        
			<div class="ion-image-slider" id="evidenceSlider">
				<a href="https://dummyimage.com/900x600/000/fff&text=Evidence1"><img src="https://dummyimage.com/150x100/000/fff&text=Evidence1" alt=""></a>
				<a href="https://dummyimage.com/900x600/000/fff&text=Evidence2"><img src="https://dummyimage.com/150x100/000/fff&text=Evidence2" alt=""></a>
				<a href="https://dummyimage.com/900x600/000/fff&text=Evidence3"><img src="https://dummyimage.com/150x100/000/fff&text=Evidence3" alt=""></a>
				<a href="https://dummyimage.com/900x600/000/fff&text=Evidence4"><img src="https://dummyimage.com/150x100/000/fff&text=Evidence4" alt=""></a>
				<a href="https://dummyimage.com/900x600/000/fff&text=Evidence5"><img src="https://dummyimage.com/150x100/000/fff&text=Evidence5" alt=""></a>
			</div>
		<div class="content_view_section">
		<?php
		$result = $wpdb->get_results( "SELECT * FROM $table ORDER BY `id` ASC LIMIT 1" );
		echo '<table border="0">
<tr>
  <td width="12%">EventID</td>
  <td>' . $result[0]->event_id . '</td>
 </tr>
<tr>
  <td>Category</td>
  <td>' . $result[0]->category . '</td>
 </tr>
<tr>
  <td>Tags</td>
  <td>' . $result[0]->tags . '</td>
 </tr>
<tr>
  <td>Author</td>
  <td>' . $result[0]->author . '</td>
 </tr>
<tr>
  <td>Author Username</td>
  <td>' . $result[0]->author_username . '</td>
 </tr>
<tr>
  <td>Event Title</td>
  <td>' . $result[0]->title . '</td>
 </tr>
<tr>
  <td>Start Date</td>
  <td>' . $result[0]->start_date . '</td>
 </tr>
<tr>
  <td>Duration</td>
  <td>' . $result[0]->duration . '</td>
 </tr>
<tr>
  <td>End Date</td>
  <td>' . $result[0]->end_date . '</td>
 </tr>
<tr>
  <td>Color</td>
  <td>' . $result[0]->color . '</td>
 </tr>
<tr>
  <td>Person</td>
  <td>' . $result[0]->person . '</td>
 </tr>
<tr>
  <td>Summary</td>
  <td>' . $result[0]->summary . '</td>
 </tr>
</table>';
?>
   
				 </div>
		</div>
		</div>
			<!----------------------------------Design View  Section --------------------->
			
	</div><!-- Main  Content-->
	</div>     
	</div>            
  <!-- jQuery -->
  <!-- FlexSlider -->
  <!-- Syntax Highlighter -->
<script type="text/javascript">
	$( document ).ready(function() {
		$("#evidenceSlider").ionImageSlider({
			startFrom: 0,
			slideShow: false
		});
		$('.tabSearch').insertAfter('.list_view_section_length');
	});
</script>
<?php
get_footer();?>
