<?php
// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Template Name: Case Expense L2 PDF
 *
 */
require_once $_SERVER['DOCUMENT_ROOT'] . '/wp-content/themes/boss-child/dompdf/autoload.inc.php';
// reference the Dompdf namespace
use Dompdf\Dompdf;

// instantiate and use the dompdf class\
$condition_modifiers = get_post_meta( '350', 'product_condition_modifiers', true );
	global $wpdb, $current_user;
	$table   = $wpdb->prefix . 'case_blog';
	$result  = $wpdb->get_results( "SELECT * FROM $table" );
$dompdf      = new Dompdf();
$pdf_content = '
	<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
	<html xmlns="http://www.w3.org/1999/xhtml">
		<title>Order PDF</title>
		<head>
			<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		</head>
		<style type="text/css">	
		.woocommerce-MyAccount-content 
		{
    		
    		background-color: #ffffff;
    		box-sizing: border-box;
    		padding: 25px 30px;
    		width:100%;
		}	

		.woocommerce-MyAccount-content .table_subheading h4 
		{
    		background-color: #eee;
   			color: #333;
    		font-size: 14px;
    		letter-spacing: 0.1em;
    		margin-bottom: 0;
    		padding: 10px;
    		text-transform: uppercase;
		}

		table.my_account_orders 
		{
    		font-size: 0.85em;
		}
		table.shop_table 
		{
    		border: 1px solid #e1e1e1;
    		border-radius: 5px;
   			margin: 0 0px 24px 0;
    		text-align: left;
    		width: 100%;
		}

		table.shop_table td, table.shop_table th 
		{
    		padding: 4px 8px;
    		vertical-align: middle;
    		border: 4px soild #000000;
    		font-weight: 700;
    		text-transform: uppercase;
    		color: #666666;
		}	
		table.shop_table td {
    		padding: 6px 12px;
    		vertical-align: middle;
    		text-transform:capitalize;
    		color: #737373;
    		border-top: 1px solid #e1e1e1;
    		text-align:center;
		}

		table.shop_table tr {
    		border: 2px solid #e1e1e1;
		}

		.woocommerce-MyAccount-content h3 
		{
		    background-color: #eee;
		    color: #333;
		    font-size: 14px;
		    letter-spacing: 0.1em;
		    line-height: 1em;
		    margin-bottom: 0;
		    padding: 10px;
		    text-transform: uppercase;
		}

		.wcpaymentinfo .totalprice 
		{
		    -moz-border-bottom-colors: none;
		    -moz-border-left-colors: none;
		    -moz-border-right-colors: none;
		    -moz-border-top-colors: none;
		    background-color: #f3f3f3;
		    border-color: -moz-use-text-color #e5e5e5 #e5e5e5;
		    border-image: none;
		    border-style: none solid solid;
		    border-width: 0 1px 1px;
		    padding: 6px 12px;
		}
		.total_donation_lable 
		{
		    float: left;
		    width: 45.8%;
		}
		.total_donation_amout 
		{
		    float: right;
		    width: 54%;
		}

		.wcpaymentinfo .totalprice h2 
		{
		    color: #333;
		    font-family: inherit;
		    font-size: 12px;
		    font-weight: normal;
		    margin: 0;
		}

		table.table_donation
		{
    		margin-bottom: 0 !important;
		}
		</style>			
		<body>
			<div id="pdf_header" >
				</div>
				
				<div class="woocommerce-MyAccount-content">
					<div class="table_subheading">
						<h4>Case Expense Level 2</h4>
					</div>
					<table class="woocommerce-MyAccount-orders shop_table shop_table_responsive my_account_orders account-orders-table borderOK">
						<thead>
							<tr class="borderOK">
								<th class="order-number"><span class="nobr">Content ID</span></th>
								<th class="order-item"><span class="nobr">Category</span></th>
								<th class="order-total"><span class="nobr">Tags</span></th>
								<th class="order-date"><span class="nobr">Author</span></th>
								<th class="order-status"><span class="nobr">Author User Name</span></th>
								<th class="order-method"><span class="nobr">Content Title</span></th>								
							</tr>
						</thead>
						<tbody>';
foreach ( $result as $results ) :
	$pdf_content .= '
							<tr class="order borderOK">
								<td class="order-number borderOK" data-title="Order">
					               ' . $results->id . '
								</td>
								<td class="item-name borderOK" data-title="Item_Name">
									' . $results->category . '
								</td>
								<td class="order-total borderOK" data-title="Total">
									' . $results->tags . '
								</td>
								<td class="order-date borderOK" data-title="Date">
								    ' . $results->author . '
								</td>
								<td class="order-status borderOK" data-title="Status">
								' . $results->author_username . '
								</td>
       	                        <td class="order-status borderOK" data-title="Status">
								' . $results->post_title . '
								</td>								
							</tr>';
						endforeach;
						 $pdf_content .= '
						</tbody>
					</table>
				</div>
			</div>
 </body>
	</html>';

$dompdf->loadHtml( $pdf_content );
// (Optional) Setup the paper size and orientation
$dompdf->setPaper( 'A3', 'letter' );

// Render the HTML as PDF
$dompdf->render();
// Output the generated PDF to Browser
//$dompdf->stream();

// Output the generated PDF (1 = download and 0 = preview)
$dompdf->stream( 'codexxxx', array( 'Attachment' => 0 ) );

