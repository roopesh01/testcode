<?php
include '../../../../wp-config.php';
global $wpdb, $current_user;
if (!is_user_logged_in()) {
    $url = site_url('registration-page/login');
    wp_redirect($url);
    exit;
}
$usercategory = $wpdb->prefix . 'user_category';
$usersubcategory = $wpdb->prefix . 'user_sub_category';
$tagtable = $wpdb->prefix . 'user_tags';
$metatable = 'wp68_usermeta';
$prefix = $wpdb->prefix;
$currentuserid = $current_user->ID;
$ratingtable = $wpdb->prefix . 'ratings';
$post_table = $wpdb->prefix . 'posts';
$post_meta_table = $wpdb->prefix . 'postmeta';
$pricetable = $wpdb->prefix . 'expert_price';
$donation_table = $wpdb->prefix . 'user_donation_details';
$biling_table = $wpdb->prefix . 'BillingInformation';
$conf_table = $wpdb->prefix . 'setup_conference_call';
$logo_type = 'company_logo';
$prev_logo_type = 'prev_company_logo';
$table = $wpdb->prefix . "expert_team_detail";
$teamidadd = $_POST['teamidadd'];
if (isset($_POST['addvalue'])) {
    $addvalue = $_POST['addvalue'];
    $update = $wpdb->query("UPDATE $table SET `invited_experts` = CONCAT(invited_experts,',$addvalue') WHERE `current_user_id`='$currentuserid' AND `id`=$teamidadd");
    echo "UPDATE $table SET `invited_experts` = CONCAT(invited_experts,',$addvalue') WHERE `current_user_id`='$currentuserid' AND `id`=$teamidadd";
    die();
}
?>
<style>
    .action-filter input[type="button"] {
        margin-bottom: 5px !important;
        width: 30%;
        min-width: 0;
    }

    .action-filter .btn-primary {
        background-color: #337ab7;
        border-color: #2e6da4;
        color: #fff;
    }

    .action-filter .btn-danger, .price-filter .btn-danger {
        background-color: #d9534f;
        border-color: #d43f3a;
        color: #fff;
    }

    .action-filter .btn-info {
        background-color: #5bc0de;
        border-color: #46b8da;
        color: #fff;
    }

</style>
<div id="content" role="main">
    <!-- Content Section -->
    <!-- testing section -->
    <div id="user_content_header" data-team_id="<?php echo $teamidadd; ?>">       
        <div class="ap-list-head clearfix mutliple-search-box">
            <header class="entry-header">            
                <ul class="nav nav-tabs">                    
                    <li role="presentation">
                        <a data-target="#graphViewEdit" class="tab-logo mail_graph_logo ">Graph View</a>
                    </li>
                    <li role="presentation" class="active">
                        <a data-target="#listViewEdit" class="tab-logo active mail_table_logo">List View</a>
                    </li>
                </ul>
            </header>
            <div id="keywordList" class="keywordListSection"></div>
            <div class="newBrowseSearch" id="tags">
                <div class="categoriesDropdown">
                    <div class="dropdown">
                        <button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">Expert<span class="caret"></span></button>
                        <ul class="dropdown-menu">
                            <li>
                                <a href="javascript:;">
                                    <div class="cateNewInput catIpExperts"><input type="text" id="search_by_expert" name="search_by_expert" placeholder="Expert"/></div>
                                </a>
                            </li>
                        </ul>
                    </div>
                    <div class="dropdown">
                        <button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">Organization<span class="caret"></span></button>
                        <ul class="dropdown-menu">
                            <li>
                                <a href="javascript:;">
                                    <div class="cateNewInput catIpCompany"><input type="text" id="search_by_company" name="search_by_company" placeholder="Company"/></div>
                                </a>
                            </li>
                            <li>
                                <a href="javascript:;">
                                    <div class="cateNewInput catIpJob"><input type="text" id="search_by_jobtitle" name="search_by_jobtitle" placeholder="Job"/></div>
                                </a>
                            </li>
                        </ul>
                    </div>
                    <div class="dropdown">
                        <button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">Place<span class="caret"></span></button>
                        <ul class="dropdown-menu">
                            <li>
                                <a href="javascript:;">
                                    <div class="cateNewInput catIpCountry"><input type="text" id="search_by_country" name="search_by_country" placeholder="Country"/></div>
                                </a>
                            </li>
                            <li>
                                <a href="javascript:;">
                                    <div class="cateNewInput catIpState"><input type="text" id="search_by_state" name="search_by_state" placeholder="State"/></div>
                                </a>
                            </li>
                            <li>
                                <a href="javascript:;">
                                    <div class="cateNewInput catIpCity"><input type="text" id="search_by_cities" name="search_by_cities" placeholder="City"/></div>
                                </a>
                            </li>
                        </ul>
                    </div>
                    <div class="dropdown">
                        <button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">Market<span class="caret"></span></button>
                        <ul class="dropdown-menu">
                            <li>
                                <a href="javascript:;">
                                    <div class="cateNewInput catIpMarket"><input type="text" id="search_by_market" name="search_by_market" placeholder="Market"/></div>
                                </a>
                            </li>
                        </ul>
                    </div>
                    <div class="myNewTeam">
                        <a href="javascript:void(0);" class="my_team_list">
                           <!-- <img src="/wp-content/themes/boss-child/images/icon-myTeam.png"> -->My Teams <span class="caret"></span>
                        </a>
                        </a>
                        <div class="team_list" style="display: none;">                    
                            <?php
                            $team_table = $wpdb->prefix . 'expert_team_detail';
                            $myteams = $wpdb->get_results("SELECT * FROM $team_table WHERE `current_user_id`=$currentuserid");
                            if ($myteams):
                                echo '<ul class="team_list_ul">';
                                foreach ($myteams as $team):
                                    $team_name = $team->team_name;
                                    $team_id = $team->id;
                                    echo '<li><a href="javascript:void(0);" data-id="' . $team_id . '" class="search_by_team">' . $team_name . '</a></li>';
                                endforeach;
                                echo '</ul>';
                            endif;
                            ?>                    
                        </div>
                    </div>
                    <div class="myNewFriend">
                        <a href="javascript:void(0);" class="my_friend_list" data-id="<?php echo $currentuserid; ?>">
                           <!-- <img src="/wp-content/themes/boss-child/images/icon-myFriend.png">-->My Friends
                        </a>
                        </a>
                    </div>
                    <div class="sortBrwFilterNew">
                        <div class="int_filter_div sortBox">
                            <a id="int-sort-anchor" class="int_filter_option sortings custom_tooltip" title="sort by" href="javascript:void(0);" data-filter-attr="sort">Sort By<span class="tooltiptext">Sort By</span></a>
                            <div class="sort_options options_box sorting_options" style="display: none;">
                                <div class="sub_box_class" data-key-attr="sort" id="sort_box_id">
                                    <ul>
                                        <li><a href="javascript:void(0);" data-value="valuehigh" id="valuehigh"  class="valuehigh sort_by_price highest_sort">Sort By Highest Price</a></li>
                                        <li><a href="javascript:void(0);" data-value="valuelow" id="valuelow" class="valuelow sort_by_price lowest_sort">Sort By Lowest  Price</a></li>
                                        <li><a href="javascript:void(0);" data-value="totalrating" id="totalrating" class="totalrating">Sort By Rating</a></li>
                                        <li><a href="javascript:void(0);" data-value="ap_reputation" id="ap_reputation" class="ap_reputation">Sort By Most Popular</a></li>
                                        <li><a href="javascript:void(0);" data-value="alpha_desc" id="alpha_desc" class="alpha_desc">Sort By Z to A</a></li>
                                        <li><a href="javascript:void(0);" data-value="alpha_asc" id="alpha_asc" class="alpha_asc">Sort By A to Z</a></li>
                                        <li><a href="javascript:void(0);" data-value="high_charity" id="high_charity"  class="sort_by_charities">Sort By Highest % Charity</a></li>
                                        <li><a href="javascript:void(0);" data-value="low_charity" id="low_charity" class="sort_by_charities">Sort By Lowest % Charity</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <a href="javascript:void(0);" class="closeBox clear_all" data-value="clearvalue"><i class="apicon-x"></i><span class="tooltiptext">Clear All Filter</span></a>
                    </div>
                </div>
            </div>                
        </div>

        <div class="ap-list-head clearfix custom_filter">
            <!-- make new Filter -->
            <div class="filterAndButtons">
                <div class="sortBrwFilter">
                    <div class="int_filter_div sortBox">
                        <a id="int-sort-anchor" class="int_filter_option sortings custom_tooltip" title="sort by" href="javascript:void(0);" data-filter-attr="sort">Sort By</a>
                        <a href="javasript:void(0);" class="custom_tooltip" title="testttt">testt</a>
                        <div class="sort_options options_box sorting_options" style="display: none;">
                            <div class="sub_box_class" data-key-attr="sort" id="sort_box_id">
                                <ul>
                                    <li><a href="javascript:void(0);" data-value="valuehigh" id="valuehigh"  class="valuehigh sort_by_price highest_sort">Sort By Highest Price</a></li>
                                    <li><a href="javascript:void(0);" data-value="valuelow" id="valuelow" class="valuelow sort_by_price lowest_sort">Sort By Lowest  Price</a></li>
                                    <li><a href="javascript:void(0);" data-value="totalrating" id="totalrating" class="totalrating">Sort By Rating</a></li>
                                    <li><a href="javascript:void(0);" data-value="ap_reputation" id="ap_reputation" class="ap_reputation">Sort By Most Popular</a></li>
                                    <li><a href="javascript:void(0);" data-value="alpha_desc" id="alpha_desc" class="alpha_desc">Sort By Z to A</a></li>
                                    <li><a href="javascript:void(0);" data-value="alpha_asc" id="alpha_asc" class="alpha_asc">Sort By A to Z</a></li>
                                    <li><a href="javascript:void(0);" data-value="high_charity" id="high_charity"  class="sort_by_charities">Sort By Highest % Charity</a></li>
                                    <li><a href="javascript:void(0);" data-value="low_charity" id="low_charity" class="sort_by_charities">Sort By Lowest % Charity</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <a href="javascript:void(0);" class="closeBox clear_all" data-value="clearvalue"><i class="apicon-x"></i><span class="tooltiptext">Clear All Filter</span></a>                              
                </div>
                <div class="myFrTm">
                    <a href="javascript:void(0);" class="my_friend_list" data-id="<?php echo $currentuserid; ?>"><img src="/wp-content/themes/boss-child/images/icon-myFriend.png"> My Friends</a>&nbsp;
                    <a href="javascript:void(0);" class="my_team_list"><img src="/wp-content/themes/boss-child/images/icon-myTeam.png"> My Teams</a>   
                    <div class="team_list" style="display: none;">                    
                        <?php
                        $team_table = $wpdb->prefix . 'expert_team_detail';
                        $myteams = $wpdb->get_results("SELECT * FROM $team_table WHERE `current_user_id`=$currentuserid");
                        if ($myteams):
                            echo '<ul class="team_list_ul">';
                            foreach ($myteams as $team):
                                $team_name = $team->team_name;
                                $team_id = $team->id;
                                echo '<li><a href="javascript:void(0);" data-id="' . $team_id . '" class="search_by_team">' . $team_name . '</a></li>';
                            endforeach;
                            echo '</ul>';
                        endif;
                        ?>                    
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div id="listViewEdit" class="tab-pane  active">
        <div class="tablehtml">
            <?php
            $single = true;
            $blog_id = get_current_blog_id();
            /* $roles = array('administrator', 'experts');
              $users = array();
              foreach($roles as $role)
              { */
            $args = array
                (
                'blog_id' => $blog_id
            );
            $allexpert = get_users($args);
            ?>                       
            <table id="ExpertByCategory">
                <!-- Expert Table Data -->
                <thead style="display: none"> 
                    <tr>
                        <th>Expert Name</th>
                        <th>&nbsp; </th>
                        <th>Rating</th>
                        <th>Price</th>
                        <th>Repulation</th>
                        <th>Charity</th>
                        <th>City</th>
                        <th>State</th>
                        <th>Country</th>
                        <th>Job Title</th>
                        <th>Category/Subcateogyr</th>
                        <th>Company</th>
                    </tr>
                </thead>
                <tbody class="tablebodyhtml">
                    <!-- Table Body Section -->
                    <?php
                    if ($allexpert):
                        $existuserchecks = $wpdb->get_results("SELECT * FROM `$table` WHERE `current_user_id`= $currentuserid AND `id`= $teamidadd");
                        $invitedusers = $existuserchecks[0]->invited_experts;
                        $invitedusers = array_map('trim', explode(',', $invitedusers));
                        foreach ($allexpert as $result):
                            $userid = $result->ID;
                            if ($userid != $currentuserid && $userid !== 2):
                                $firstname = get_user_meta($userid, 'first_name', $single);
                                $lastname = get_user_meta($userid, 'last_name', $single);
                                $expertPrice = $wpdb->get_var("SELECT `price` FROM $pricetable WHERE `user_id`='$userid'");
                                $AboutYourSelf = bp_get_profile_field_data('field=AboutYourSelf&user_id=' . $userid);
                                $title = bp_get_profile_field_data('field=Title&user_id=' . $userid);
                                $city = bp_get_profile_field_data('field=City&user_id=' . $userid);
                                $state = bp_get_profile_field_data('field=State&user_id=' . $userid);
                                $Country = bp_get_profile_field_data('field=Country&user_id=' . $userid);
                                $salutation = bp_get_profile_field_data('field=salutation&user_id=' . $userid);
                                $Company = bp_get_profile_field_data('field=Company&user_id=' . $userid);
                                $JobTitle = bp_get_profile_field_data('field=JobTitle&user_id=' . $userid);
                                ?>
                                <tr>
                                    <!-- Table Row -->
                                    <td class="hide">
                                        <p><?php echo $FinalFullName = (empty($firstname)) ? str_replace(' ', '', $lastname) : str_replace(' ', '', $firstname) . '&nbsp;' . str_replace(' ', '', $lastname); ?></p>
                                    </td>
                                    <td>
                                        <!-- Table Column -->
                                        <div class="expertbycategorytags">
                                            <!-- Expert  Category Main Div -->
                                            <div class="row customexpert">
                                                <!-- Expert Category Sub Div -->                
                                                <div class="col-md-2 col-lg-2 ce-image">
                                                    <span class="confirmexpert">
                                                        <?php
                                                        if (array_search("" . $userid, $invitedusers) === false) {
                                                            echo '<input type="checkbox" id="' . $userid . '" name="checkuncheck[]" class="confirmuser" />';
                                                        } else {
                                                            echo '<input type="checkbox" id="' . $userid . '" name="checkuncheck[]" class="user_already_exist" checked="checked" disabled="true" title="Select/Unselect All"/><span class="aInvite"></span>';
                                                        }
                                                        ?>                                                                
                                                    </span>
                                                    <a href="<?php echo site_url(); ?>/user-basic-profile/?ExpertId=<?php echo $userid; ?>"><?php echo get_avatar($userid, $size); ?></a>
                                                </div>
                                                <div class="col-md-7 col-lg-7 ce-content">
                                                    <div class="clientBriefInfo">
                                                        <div class="clientNameWrap">
                                                            <h4 class="ce-title"><a href="<?php echo site_url(); ?>/user-basic-profile/?ExpertId=<?php echo $userid; ?>"><?php
                                                                    if ($salutation) {
                                                                        echo $salutation . '&nbsp;';
                                                                    }echo $firstname . '&nbsp;' . $lastname;
                                                                    ?></a></h4>
                                                            <p class="ce-info"><span><?php
                                                                    if ($city || $state || $Country) {
                                                                        echo '<i class="fa fa-map-marker" aria-hidden="true"></i>';
                                                                    }if ($city) {
                                                                        echo $city;
                                                                    } if ($city && $state) {
                                                                        echo ',&nbsp';
                                                                    } if ($state) {
                                                                        echo $state;
                                                                    }if (($state || $city) && $Country) {
                                                                        echo ',&nbsp';
                                                                    }if ($Country) {
                                                                        echo $Country;
                                                                    }
                                                                    ?></span></p>
                                                            <p class="client-desg"><?php
                                                                if ($JobTitle):echo $JobTitle;
                                                                endif;
                                                                ?>,</p>
                                                            <p class="client-desg"><?php
                                                                if ($Company):echo $Company;
                                                                endif;
                                                                ?></p>
                                                        </div>
                                                        <?php
                                                        $current_logo = $wpdb->get_results("SELECT * FROM $post_table WHERE `post_author`=$userid AND `post_type`='$logo_type'");
                                                        $logo_img_url = $current_logo[0]->guid;
                                                        $logo_id = $current_logo[0]->ID;
                                                        $company_logo_name = get_post_meta($logo_id, 'company_logo_name', true);
                                                        $prev_company_logo = $wpdb->get_results("SELECT * FROM $post_table WHERE `post_author`=$userid AND `post_type`='$prev_logo_type'");
                                                        ?>                                                      
                                                        <p class="ce-details"><?php
                                                            if ($AboutYourSelf) {
                                                                $string = strip_tags($AboutYourSelf);
                                                                if (strlen($string) > 240) {

                                                                    $stringCut = substr($string, 0, 240);
                                                                    $string = substr($stringCut, 0, strrpos($stringCut, ' ')) . '.... <a class="read_moree" href="/user-basic-profile/?ExpertId=' . $userid . '">Read More</a>';
                                                                }
                                                                echo $string;
                                                            }
                                                            ?></p>
                                                        <div class="previousOrgLogo">
                                                            <?php
                                                            if ($current_logo):
                                                                echo '<div class="leftMainLogo">                                                           
                                             <a class="custom_tooltip" title="' . $company_logo_name . '" href="javascript:void(0);"><img src="' . $logo_img_url . '"/></a>
                                             </div>';
                                                            endif;
                                                            if ($prev_company_logo):
                                                                echo '<div class="rightAffiliateLogos">
                                             <ul>
                                               <li class="prevEmpText"><span>Affiliations</span></li>';
                                                                foreach ($prev_company_logo as $logos):
                                                                    $prev_img_url = $logos->guid;
                                                                    $logoidd = $logos->ID;
                                                                    $prev_company_logo_name = get_post_meta($logoidd, 'company_logo_name', true);
                                                                    echo '<li><a class="custom_tooltip" title="' . $prev_company_logo_name . '" href="javascript:void(0);"><img src="' . $prev_img_url . '"></a></li>';
                                                                endforeach;
                                                                echo '</ul>';
                                                                echo '</div>';
                                                            endif;
                                                            ?>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-3 col-lg-3 ce-action paddingTop">
                                                    <div class="ce-pricing">
                                                        <span class="profile-detail profile-stat price">
                                                            <input type="hidden" name="basic_amount"/>
                                                            <?php
                                                            $expertprices = number_format((float) $expertPrice, 2, '.', '');
                                                            ?>
                                                            <?php
                                                            $todaydate = date("m/d/Y");
                                                            $get_charity = $wpdb->get_results("SELECT * FROM `$donation_table` WHERE `start_time` <= '$todaydate' AND `end_time` >= '$todaydate' AND user_id=$userid ORDER BY `donation_percentage` DESC");
                                                            /* if($get_charity)
                                                              {
                                                              print_r($get_charity);
                                                              } */
                                                            /*                                                             * ************************************** Custom Code For Total Donation Amount **************************************** */

                                                            $the_post = "SELECT * FROM $donation_table WHERE user_id='$userid' order by end_time desc";
                                                            $donation = $wpdb->get_results($the_post, OBJECT);
                                                            $total_charity = 0;
                                                            if ($donation):
                                                                foreach ($donation as $key => $donations):
                                                                    $donationoid = $donations->id;
                                                                    $userstarttime = $donations->start_time;
                                                                    $userid = $donations->user_id;
                                                                    $firstname = get_user_meta($userid, 'first_name', true);
                                                                    $lastname = get_user_meta($userid, 'last_name', true);
                                                                    $donation_percentage = $donations->donation_percentage;
                                                                    $causeofdonation = $donations->donation_cause;
                                                                    $userendtime = $donations->end_time;
                                                                    $date1 = new DateTime($userstarttime);
                                                                    $date2 = new DateTime($userendtime);
                                                                    $diff = $date2->diff($date1)->format("%a");
                                                                    $donation_status = $donations->donation_status;
                                                                    $final_percentage = $donation_percentage;
                                                                    $currentdate = date("m/d/Y");
                                                                    $currentstr = strtotime($currentdate);
                                                                    $startstr = strtotime($userstarttime);
                                                                    $endstr = strtotime($userendtime);
                                                                    $startdatetime = date("Y-m-d H:i:s", $startstr);
                                                                    $enddatetime = date("Y-m-d H:i:s", $endstr);
                                                                    $result = $wpdb->get_results($wpdb->prepare("SELECT estimated_length, amount, coupone_code, conference_datetime, conference_type, 'conference_booking' FROM $conf_table WHERE DATE(conference_datetime) >= %s AND DATE(conference_datetime) <= %s AND expert_ids REGEXP %d AND booking_status = %s UNION SELECT usertime, amount, coupon, booking_timestamp, conference_type, 'booking' FROM $biling_table WHERE DATE(booking_timestamp) >= %s AND DATE(booking_timestamp) <= %s AND expertid = %d AND paymentstatus = %s AND booking_status = %d", $startdatetime, $enddatetime, $userid, 'booked', $startdatetime, $enddatetime, $userid, 'completed', 0));

                                                                    if ($donation_status == 1) {
                                                                        $status = "Ended";
                                                                    } else {
                                                                        if ($startstr <= $currentstr && $endstr >= $currentstr) {
                                                                            $status = "Active";
                                                                        } elseif ($startstr >= $currentstr && $endstr >= $currentstr) {
                                                                            $status = "Inactive";
                                                                        } elseif ($startstr <= $currentstr && $endstr <= $currentstr) {
                                                                            $status = "Ended";
                                                                        }
                                                                    }

                                                                    $count = 1;
                                                                    $totalcharity = 0;
                                                                    if ($result):
                                                                        foreach ($result as $results):
                                                                            $booking_belongs = $results->conference_booking;
                                                                            if ($booking_belongs == "conference_booking"):

                                                                                $diff = $results->estimated_length;
                                                                                $conference_datetime = $results->conference_datetime;
                                                                                $booking_time_str = strtotime($conference_datetime);
                                                                                $normal_date = date('Y/m/d', $booking_time_str);
                                                                                $start_time = date('h:i A', $booking_time_str);
                                                                                $estimate_seconds = $diff * 60;
                                                                                $end_booking_str = $booking_time_str + $estimate_seconds;
                                                                                $end_time = date('h:i A', $end_booking_str);
                                                                                $type = $results->conference_type;
                                                                                if ($type == "Voice") {
                                                                                    $user_price = $price = $wpdb->get_var($wpdb->prepare("SELECT price FROM $pricetable WHERE user_id= %d", $userid));
                                                                                } else if ($type == "Video") {
                                                                                    $user_price = $price = $wpdb->get_var($wpdb->prepare("SELECT video_min_price FROM $pricetable WHERE user_id= %d", $userid));
                                                                                } else if ($type == "Chat") {
                                                                                    $user_price = $price = $wpdb->get_var($wpdb->prepare("SELECT chat_price FROM $pricetable WHERE user_id= %d", $userid));
                                                                                } else if ($type == "SMS") {
                                                                                    $user_price = $price = $wpdb->get_var($wpdb->prepare("SELECT sms_price FROM $pricetable WHERE user_id= %d", $userid));
                                                                                }
                                                                                $full_price = ($diff * $user_price);
                                                                                $coupon_value = $results->coupone_code;
                                                                                $mypost = get_page_by_title($coupon_value, OBJECT, 'request_coupon');
                                                                                $post_id = $mypost->ID;
                                                                                $coupon_type = get_post_meta($post_id, '_coupon_type', true);
                                                                                if ($coupon_type == "percentage") {
                                                                                    $percentage = get_post_meta($post_id, '_coupon_percentage', true);
                                                                                    $amount_percentage = ($full_price * $percentage) / 100;
                                                                                    $final_amount = ($amount - $amount_percentage);
                                                                                    $final_amount = sprintf('%0.2f', $final_amount);
                                                                                } else {
                                                                                    $percentage = get_post_meta($post_id, '_coupon_amount', true);
                                                                                }
                                                                                if ($coupon_value == "NULL" || $coupon_value == "") {
                                                                                    $payment = $full_price;
                                                                                    $charity_amount = ($payment * $final_percentage) / 100;
                                                                                } else {
                                                                                    $payment = $final_amount;
                                                                                    $charity_amount = ($payment * $final_percentage) / 100;
                                                                                }
                                                                            else:
                                                                                $usertime = $results->estimated_length;
                                                                                $timeexpload = explode("  ", $usertime);
                                                                                $userextradate = $timeexpload[0];
                                                                                $userextractetime = $timeexpload[1];
                                                                                $userextractetime = explode("-", $userextractetime);
                                                                                $userexstart = $userextradate . " " . $userextractetime[0];
                                                                                $userexend = $userextradate . " " . $userextractetime[1];
                                                                                $userexstartstr = strtotime($userexstart);
                                                                                $normal_date = date('Y/m/d', $userexstartstr);
                                                                                $start_time = date('h:i A', $userexstartstr);
                                                                                $userexendstr = strtotime($userexend);
                                                                                $end_time = date('h:i A', $userexendstr);
                                                                                $diff = abs($userexstartstr - $userexendstr) / 60;
                                                                                $payment = $results->amount;
                                                                                $charity_amount = ($payment * $final_percentage) / 100;
                                                                            endif;

                                                                            $count++;
                                                                            $total_charity += $charity_amount;
                                                                        endforeach;
                                                                    endif;
                                                                endforeach;
                                                            endif;
                                                            $total_charityy = number_format((float) $total_charity, 2, '.', '');
                                                            if ($total_charityy != '0.00'):
                                                                $total_charity = '<div class="ep-charContribution"><span>Charity Contribution: </span>CR ' . $total_charityy . '</div>';
                                                            else:
                                                                $total_charity = '';
                                                            endif;
                                                            /* Custom Code For Total Donation Amount */
                                                            if (!empty($get_charity)) {
                                                                $donation_id = $get_charity[0]->donation_id;
                                                                $titles = get_the_title($donation_id);
                                                                $post_url = get_post_permalink($donation_id);
                                                                $image_url = get_the_post_thumbnail_url($donation_id, $size = 'post-thumbnail');
                                                                echo $total_charity;
                                                                echo '<div class="doneImgPge"><div class="cltCurrLogo"><a class="custom_tooltip" title="' . $titles . '" href="' . $post_url . '"><img width="77" height="80" src="' . $image_url . '" class="attachment-thumbnail size-thumbnail wp-post-image" alt=""/></a></div><div class="chClDetail"><span class="chtNameDonate">' . $firstname . '&nbsp; donates to</span><span class="chtPercentage">UTICA ' . $get_charity[0]->donation_percentage . '%</span></div></div>';
                                                            }
                                                            ?>
                                                            <strong class="actual-price"><?php echo $expertprices; ?>&nbsp;CR/minute</strong>
                                                        </span>
                                                    </div>
                                                    <div class="expRating">                                                    
                                                        <?php
                                                        $average = $wpdb->get_var("SELECT Avg(totalrating) FROM $ratingtable WHERE expertid = $userid");
                                                        $average2 = number_format((float) $average, 2, '.', '');
                                                        if ($average2 > 4.5) {
                                                            echo '<img src="/wp-content/themes/boss-child/images/rating/five-star.png" title="Awesome - 5 stars"/>';
                                                            echo '<br/>';
                                                            /* echo $average2.' out of 5 stars'; */
                                                        } elseif ($average2 > 3.5) {
                                                            echo '<img src="/wp-content/themes/boss-child/images/rating/four-star.png" title="Pretty good - 4 stars"/>';
                                                            echo '<br/>';
                                                            /* echo $average2.' out of 5 stars'; */
                                                        } elseif ($average2 > 2.5) {
                                                            echo '<img src="/wp-content/themes/boss-child/images/rating/three-star.png" title="Average - 3 stars"/>';
                                                            echo '<br/>';
                                                            /* echo $average2.' out of 5 stars'; */
                                                        } elseif ($average2 > 1.5) {
                                                            echo '<img src="/wp-content/themes/boss-child/images/rating/two-star.png" title="Bad - 2 stars"/>';
                                                            echo '<br/>';
                                                            /* echo $average2.' out of 5 stars'; */
                                                        } elseif ($average2 > 0.5) {
                                                            echo '<img src="/wp-content/themes/boss-child/images/rating/one-star.png" title="Very Poor - 1 star"/>';
                                                            echo '<br/>';
                                                            /* echo $average2.' out of 5 stars'; */
                                                        } else {
                                                            echo "<small>No Rating For This Expert</small>";
                                                        }
                                                        ?>
                                                    </div>
                                                </div>
                                            </div>
                                            <!-- Expert Category Sub Div -->
                                        </div>
                                        <!-- Expert  Category Main Div -->
                                    </td>
                                    <!-- Table Column -->
                                    <!-- Rating td -->
                                    <td class="hide">
                                        <p><?php echo $average2; ?></p>
                                    </td>
                                    <!-- Price td -->
                                    <td class="hide">
                                        <p><?php echo $expertprices; ?></p>
                                    </td>
                                    <!-- Reputataion td -->
                                    <td class="hide">
                                        <p><?php echo get_user_meta($userid, 'ap_reputation', TRUE); ?></p>
                                    </td>
                                    <!-- Charity td -->
                                    <td class="hide">
                                        <?php
                                        $todaydate = date("m/d/Y");
                                        $get_charity = $wpdb->get_var("SELECT `donation_percentage` FROM `$donation_table` WHERE `start_time` <= '$todaydate' AND `end_time` >= '$todaydate' AND user_id=$userid ORDER BY `donation_percentage` DESC");
                                        echo $userTotalCharity = ($get_charity) ? $get_charity : 0;
                                        ?>
                                    </td>
                                    <td class="hide">
                                        <?php
                                        if ($city) {
                                            echo $city;
                                        }
                                        ?> 
                                    </td>
                                    <!-- State td -->
                                    <td class="hide">
                                        <?php
                                        if ($state) {
                                            echo $state;
                                        }
                                        ?>
                                    </td>
                                    <td class="hide" >
                                        <?php
                                        if ($Country) {
                                            echo getCountryISOCODE($Country) . " " . $Country;
                                        }
                                        ?>
                                        <?php
                                        //if($Country){
                                        // echo $Country;
                                        //  }
                                        ?>
                                    </td>
                                    <td class="hide">
                                        <?php
                                        if ($JobTitle):echo $JobTitle;
                                        endif;
                                        ?>
                                    </td>
                                    <td class="hide">
                                        <?php
                                        $catArray = array();
                                        $tabledata = $wpdb->prefix . 'cat_';
                                        $category = $wpdb->get_results("SELECT * FROM $metatable WHERE `user_id` = '$userid' AND `meta_key` LIKE '%$tabledata%'");
                                        if ($category):
                                            foreach ($category as $categories):
                                                $cat_key = $categories->meta_key;
                                                $newkey = str_replace($tabledata, "", $cat_key);
                                                $category_name = $wpdb->get_var("SELECT `category_name` FROM $usercategory WHERE `category_key`='$newkey'");
                                                $sub_cat = $categories->meta_value;
                                                $catArray[] = $category_name . '&nbsp;' . $sub_cat;
                                            endforeach;
                                        endif;
                                        $catsubcate = implode(" ", $catArray);
                                        echo $catsubcate;
                                        ?>
                                    </td>
                                    <td class="hide">
                                        <?php
                                        if ($Company):echo $Company;
                                        endif;
                                        ?> 
                                    </td>
                                </tr>
                                <!-- Table Row -->
                                <?php
                            endif;
                        endforeach;
                    endif;
                    ?>                
                </tbody>
                <!-- Table Body Section -->
            </table>
            <script>
                var allExistingUsers = "<?php echo join(",", $invitedusers); ?>";
            </script>
            <!-- Expert Table Data -->            
        </div>
        <div class="schedule_meeting">
            <a href="javascript:void(0);" class="AddUsers addtolist" id="AddExpertList" onclick="addExpertList()">Add to Expert Team</a>
            <a id="schedulemeeting" href="/my-expert-teams/">Return To  Team</a>
        </div>
    </div>

    <div id="graphViewEdit" class="tab-pane graphView">
        <div class="clearfix">
            <svg  class="teamMemberSvg"></svg>

            <div  class="filterContainer">
                <h3>Data Filters</h3>
                <div>
                    <div class=" filter">
                        <h3>Show people with pay rate</h3>
                        <div id="priceFilter" class='iis-slider priceFilter' data-min='0' data-max='100' data-value='0'>
                            <div  class="ui-slider-handle"></div>
                        </div>
                    </div>
                    <!--price-filter_END-->
                    <div class="wealth-filter filter">
                        <h3>Show people with Reputation</h3>
                        <div id="wealthFilterNetwork" class="wealthFilterNetwork"></div>
                        <input type="button" id="clearNetworkWealthFilter" value="Clear" class="btn btn-danger clearNetworkWealthFilter" />
                    </div>                            
                </div>

                <h3>Category Filters</h3>
                <div>                        
                    <div class="category-filter"> 
                        <div class="action-filter">
                            <input  type="button" value="All" class="btn btn-primary selectAllTeam">
                            <input  type="button" value="Clear" class="btn btn-danger clearAllTeams">
                            <input  type="button" value="Invert" class="btn btn-info invertTeam">
                        </div> <!--action-filter_END-->
                        <ul id="categoryList" class="categoryList"></ul>
                    </div>
                </div>

                <h3>Graph Filters</h3>
                <div>
                    <div class="sticky-filter filter">
                        <input type="checkbox" class="stickyDrag" />
                        <span>Mark Sticky</span>
                        <input type="button" value="Clear Sticky" class="clearStickyDrag">
                    </div>

                    <div class="zoom-filter filter">
                        <input type="checkbox" class="fishEye" />
                        <span>Zoomed Lens</span>                
                    </div>

                    <div class="text-filter filter">
                        <input type="checkbox" class="textVisibility" />
                        <span>Show Text</span>                
                    </div>

                    <div class="link-dist-filter filter">
                        <h3>Link Distance</h3>
                        <div id="linkDistanceSlider" class='iis-slider linkDistanceSlider' data-min='0' data-max='100' data-value='0'>
                            <div  class="ui-slider-handle"></div>
                        </div>
                    </div>

                    <div class="node-dist-filter filter">
                        <h3>Node Distance</h3>
                        <div id="nodeDistanceSlider" class='iis-slider nodeDistanceSlider' data-min='-60' data-max='0' data-value='-20'>
                            <div  class="ui-slider-handle"></div>
                        </div>
                    </div>

                    <div class="node-visible-filter filter">
                        <h3>Filter Node</h3>
                        <div id="filterNodeSlider" class='iis-slider filterNodeSlider' data-min='0' data-max='100' data-value='0'>
                            <div  class="ui-slider-handle"></div>
                        </div>
                    </div>

                    <div class="link-visible-filter filter">
                        <h3>Filter Links</h3>
                        <div id="filterLinkSlider" class='iis-slider filterLinkSlider' data-min='0' data-max='100' data-value='0'>
                            <div  class="ui-slider-handle"></div>
                        </div>
                    </div>
                </div>

                <h3>Selected Users</h3>
                <div>
                    <div class="filter">
                        <ul id="selectedMembers" class="selectedMembers">
                        </ul>
                    </div>
                </div>
            </div>

            <div class="network-graph-container">
                <div class="middleContainer clearfix">
                    <div id="networkGraph"></div>
                </div>
                <div id="networkDateOpt" class="clearfix">
                    <div class="mapSlideWrapper">
                        <span><input type="checkbox" id="activeNetUserSlider" class="activeNetUserSlider"/> Filter User</span>
                        <div id="networkUserSlider" class="networkUserSlider"></div>
                    </div>
                    <div class="mapSlideWrapper">
                        <span><input type="checkbox" id="activeNetFriendSlider"  class="activeNetFriendSlider"/> Filter Friend</span>
                        <div id="networkFriendSlider" class="networkFriendSlider"></div>
                    </div>
                </div>
                <!--networkDateOpt_END-->
            </div>
            <!--network-graph-container_END-->
        </div>
        <div class="schedule_meeting">
            <a href="javascript:void(0);" class="AddUsers addtolist AddExpertGraph" id="AddExpertGraph" onclick="addExpertGraph()">Add to Expert Team</a>
            <a id="schedulemeeting" href="/my-expert-teams/">Return To Team</a>
        </div>
    </div>
</div>
