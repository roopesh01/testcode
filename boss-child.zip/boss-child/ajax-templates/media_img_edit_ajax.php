<?php
include '../../../../wp-config.php';
global $current_user, $wpdb;
$user_id = $current_user->ID;
$currentdirectory = get_stylesheet_directory_uri();
$posttable = $wpdb->prefix.'posts';

if(isset($_POST['deletpostid'])):
    $deletpostid = $_POST['deletpostid'];
    $directory = $_SERVER['DOCUMENT_ROOT'] . '/wp-content/themes/boss-child/';
    $path = get_post_meta($deletpostid,'img_path_name', $single=true);
    $unlinkfile =  unlink($directory.$path);
    if($unlinkfile):
        wp_delete_post($deletpostid);    
        echo '<span class="deleted">Successfully Deleted</span>';
        else:
        echo "Error In Delete post";
    endif;
endif;

if(isset($_FILES["file1"]["type"]) && isset( $_POST['cpt_nonce_field'] ) && wp_verify_nonce( $_POST['cpt_nonce_field'], 'cpt_nonce_action' ) )
{
    $validextensions = array("jpeg", "jpg", "png", "JPG","JPEG","PNG");
    $temp1 = $_FILES["file1"]["name"];
    $post_name = $_POST['post_name'];
    $post_title = $_POST['post_title']; 
    $temporary = explode(".", $_FILES["file1"]["name"]);    
    $getname = $temporary[0];
    $getext =  $temporary[1];
    if($getext=='jpg'):
        $getext ='jpeg';
    endif; 
    $newfile = $getname.'.'.$getext;      
    ///echo($temp1);    
    $type = $_POST['mimetype'];
    $imgtypes = explode("/",$type);
    $imgtype =   $imgtypes[1];
    $postimgname =  $post_title.'.'.$imgtype;
    if($newfile!=$postimgname):
        echo "File Name Not Same As Previous Uploaded File";
        die();
    endif;

    $file_extension = end($temporary);
    if ((($_FILES["file1"]["type"] == "image/png") || ($_FILES["file1"]["type"] == "image/jpg") || ($_FILES["file1"]["type"] == "image/jpeg") || ($_FILES["file1"]["type"] == "image/JPG") || ($_FILES["file1"]["type"] == "image/JPEG") || ($_FILES["file1"]["type"] == "image/PNG") ) && ($_FILES["file1"]["size"] < 1097152)//Approx. 1mb files can be uploaded.
    && in_array($file_extension, $validextensions)) 
    {
        if ($_FILES["file1"]["error"] > 0)
        {
            echo "Return Code: " . $_FILES["file1"]["error"] . "<br/><br/>";
        }
        else
        {
            /*chagne file name */                
            $fileData = pathinfo(basename($_FILES["file1"]["name"]));
            $fileName =  $post_name. '.' . $fileData['extension'];
            /*chagne file name */
            $cyear = date("Y");
            $cmonth = date("m");
            $directory = $_SERVER['DOCUMENT_ROOT'] . '/wp-content/themes/boss-child/media_images/users/'.$user_id.'/'.$cyear.'/'.$cmonth.'/';            
            if (wp_mkdir_p($directory)) 
            {
                //echo 'It worked <br/>';
            }
            if (file_exists($directory.$fileName))
            {
                $unlinkfile =  unlink($directory.$fileName);
                if($unlinkfile):                         
                $sourcePath = $_FILES['file1']['tmp_name']; // Storing source path of the file in a variable                             
                $targetPath =  $directory.$fileName;// Target path where file is to be stored                
                $uploadedfile =  move_uploaded_file($sourcePath,$targetPath); // Moving Uploaded file
                $imgurl = $currentdirectory.'/media_images/users/'.$user_id.'/'.$cyear.'/'.$cmonth.'/'.$fileName;
                //echo $imgurl;
                if($uploadedfile):                                
                    $post_information = array
                    (
                        'ID' => $_POST['clonepostid2'],
                        'post_title' =>  $_POST['post_title'],
                        'post_name' => $_POST['post_name'],
                        'post_type' => 'media_attachment',
                        'post_mime_type' => $_FILES["file1"]["type"],
                        'post_author' => $_POST['author_id'], 
                        'guid'  =>  $imgurl
                    );
                    $post_id = wp_update_post( $post_information );                     
                        if($post_id):
                            echo "<span id='success'>Image Updated Successfully...!!</span><br/>";       
                        endif; 
                        $path = 'media_images/users/'.$user_id.'/'.$cyear.'/'.$cmonth.'/'.$fileName;
                        update_post_meta($cpt_id, 'img_path_name', $path);         
                    endif;
                 endif;              
            }     
        }
    }
    else
    {
        echo "<span id='invalid'>***Invalid file Size or Type***<span>";
    }
}
?>