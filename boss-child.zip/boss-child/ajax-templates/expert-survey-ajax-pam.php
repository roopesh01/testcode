<?php
    include '../../../../wp-config.php';
    global $wpdb, $current_user;
    $userid = $current_user->ID;
    echo $userid;    
    if(isset($_POST['Court_Judges']) || isset($_POST['Prosecution']) || isset($_POST['Victim_Services']))
    {
        $Court_Judges = $_POST['Court_Judges'];
        $Prosecution =  $_POST['Prosecution'];
        $Law_Enforcement =  $_POST['Law_Enforcement'];
        $Private_Investigators =  $_POST['Private_Investigators'];
        $Forensic_Science_Experts = $_POST['Forensic_Science_Experts'];
        $Media = $_POST['Media'];
        $Victim_Services = $_POST['Victim_Services'];
        $Trial_Lawyers = $_POST['Trial_Lawyers'];
        $keyvalue = 'submitsurvey';    
        $submitsurveykey = 'submitsurveykey';        
        
        $metas = array
        ( 
            'Court_Judges'               => $Court_Judges,
            'Prosecution'                => $Prosecution, 
            'Law_Enforcement'            => $Law_Enforcement,
            'Private_Investigators'      => $Private_Investigators,
            'Forensic_Science_Experts'   =>  $Forensic_Science_Experts, 
            'Media'                      => $Media,
            'Victim_Services'            => $Victim_Services,
            'Trial_Lawyers'              => $Trial_Lawyers,
            'submitsurveykey'            =>  $keyvalue
        );
        foreach($metas as $option_name => $value) 
        {
            //update_user_meta( $userid, $key, $value );
            update_user_option($userid, $option_name, $value);           
        }
    }
?>