<?php
include '../../../../wp-config.php';
global $current_user, $wpdb;
$user_id = $current_user->ID;
$video_rate = $_POST['video_rate'];
$chat_rate = $_POST['chat_rate'];
$sms_rate = $_POST['sms_rate'];
$price = $_POST['price'];
$minimumValue = $_POST['minimumValue'];
$fieldValue = $_POST['fieldValue'];
$minut_rate = $_POST['minut_rate'];
$table = $wpdb->prefix . 'expert_price';
$result = $wpdb->get_var($wpdb->prepare("SELECT user_id FROM $table WHERE user_id= %d", $user_id));
if ($result) {
    $update_record = $wpdb->query($wpdb->prepare("UPDATE $table SET price= %s, hourly_price= %s, video_min_price= %s, chat_price= %s, sms_price= %s WHERE user_id= %d", $price, $minut_rate, $video_rate, $chat_rate, $sms_rate, $user_id));
    update_user_meta( $user_id, 'minimumValue', $minimumValue);
    update_user_meta( $user_id, 'fieldValue', $fieldValue);
    echo "Price Successfully Updated";
} else {
    $wpdb->insert(
            $table, array
        (
        'user_id' => $user_id,
        'price' => $price,
        'hourly_price' => $minut_rate,
        'video_min_price' => $video_rate,
        'chat_price' => $chat_rate,
        'sms_price' => $sms_rate,
            ), array('%d', '%s', '%s', '%s', '%s', '%s'));
 
    $awesome_level = 1000;
    add_user_meta( $user_id, 'minimumValue', $minimumValue);
    add_user_meta( $user_id, 'fieldValue', $fieldValue);
    echo "Price Successfully Saved";
}