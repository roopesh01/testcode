jQuery(document).ready(function($) {
    var navListItems = $('ul.setup-panel li a'),
        allWells = $('.setup-content');

    allWells.hide();

    navListItems.click(function(e) {
        e.preventDefault();
        var $target = $($(this).attr('href')),
            $item = $(this).closest('li');

        if (!$item.hasClass('disabled')) {
            navListItems.closest('li').removeClass('active');
            $item.addClass('active');
            allWells.hide();
            $target.show();
        }
    });
    $(document).on('click', '.panel-title a', function(e) {
        $(this).toggleClass('panOpen');
        $(this).parent('.panel-title').parent('.panel-heading').parent('.panel-default').toggleClass('panelOpen');
    });
    // check div size is resize or not 
    $("div#userProles").bind("resize", function() {
        $("div#step-2 div.joinbtn-wrap").removeClass('offscreenbtns');
        if ($("div#userProles .panel-title a").hasClass("panOpen")) {
            var ourStatus = $('div#step-2 #activate-step-3').isOnScreen();
            if (ourStatus == false) {
                $("div#step-2 div.joinbtn-wrap").addClass('offscreenbtns');
            }
        }
    })

    $.fn.isOnScreen = function() {

        var win = $(window);

        var viewport = {
            top: win.scrollTop(),
            left: win.scrollLeft()
        };
        viewport.right = viewport.left + win.width();
        viewport.bottom = viewport.top + win.height();

        var bounds = this.offset();
        bounds.right = bounds.left + this.outerWidth();
        bounds.bottom = bounds.top + this.outerHeight();

        return (!(viewport.right < bounds.left || viewport.left > bounds.right || viewport.bottom < bounds.top || viewport.top > bounds.bottom));


    }
    $('ul.setup-panel li.active a').trigger('click');

    // DEMO ONLY //
    $('#activate-step-2').on('click', function(e) {

        // $('html body').animate({ scrollTop: $('div.userRole-wrap').offset().top }, 'fast');
        if (!$('ul.user_primary_category li input[name=user-role]:checked').val()) {
            $("div.action_message").html("Choose any primary market.");
            $("div.action_message").addClass("alert-danger");
            $("div.action_message").removeClass("hide");
            $(window).scrollTop($('.userRole-wrap').offset().top);
            return false;
        } else {
            $("div.action_message").removeClass("alert-danger");
            $("div.action_message").addClass("hide");
            $("div.action_message").html("");
        }

        $('ul.setup-panel li:eq(1)').removeClass('disabled');
        // get_user_sub_category();
        $('ul.setup-panel li a[href="#step-2"]').trigger('click');
        //$(this).remove();
        // $(this).addClass('hide');
    })

    $('#activate-step-3').on('click', function(e) {
        var primary_roles = new Array();
        $("div#userProles input:checked").each(function() {
            primary_roles.push($(this).val());
        });

        if (primary_roles.length == 0) {
            $("div.action_message").html("Choose atleast one primary role.");
            $("div.action_message").addClass("alert-danger");
            $("div.action_message").removeClass("hide");
            $(window).scrollTop($('.userRole-wrap').offset().top);

            return false;
        } else {
            $("div.action_message").removeClass("alert-danger");
            $("div.action_message").addClass("hide");
            $("div.action_message").html("");
        }

        $('ul.setup-panel li:eq(2)').removeClass('disabled');
        $('ul.setup-panel li a[href="#step-3"]').trigger('click');
        // $(this).remove();
    })

    $('#activate-step-4').on('click', function(e) {
        $('ul.setup-panel li:eq(3)').removeClass('disabled');
        $('ul.setup-panel li a[href="#step-4"]').trigger('click');
        // $(this).remove();

    })

    $('#previous-step-1').on('click', function(e) {
        $("ul.setup-panel li a#step-1-li").trigger("click");
    })

    $('#previous-step-2').on('click', function(e) {
        $("ul.setup-panel li a#step-2-li").trigger("click");
    })

    $("ul.user_primary_category li").on('click', function(e) {
        $("ul.user_primary_category li").find('input[type="radio"]').removeAttr('checked');
        $(this).find('input[type="radio"]').attr('checked', 'checked');
    });

    $("#submit_user_form").submit(function(event) {

        /* stop form from submitting normally */
        event.preventDefault();
        var first_name = $.trim($("input#first_name").val());
        var last_name = $.trim($("input#last_name").val());
        var email_id = $.trim($("input#email_id").val());
        var username = $.trim($("input#username").val());
        var pwd = $.trim($("input#pwd").val());
        var mobileno = $.trim($("input#mobileno").val());
        var filter = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
        var primary_market = $('ul.user_primary_category li input[name=user-role]:checked').val();
        var primary_roles = new Array();
        $("div#userProles input:checked").each(function() {
            primary_roles.push($(this).val());
        });
        var primary_skills = new Array();
        $("div.user_primary_skills input:checked").each(function() {
            primary_skills.push($(this).val());
        });
        $("#submit_user_form input").removeClass("input-error");
        $("#submit_user_form p.errorMsg").html('');
        var validation_status = true;

        if (primary_market == '') {
            $('div.error_message_box').html("Choose any primary market.");
            $('div.error_message_box').addClass('alert-danger');
            $('div.error_message_box').removeClass('hide');
            $(window).scrollTop($('div.error_message_box').offset().top);
            return false;
        } else if (primary_roles.length === 0) {
            $('div.error_message_box').html("Choose atleast one primary role.");
            $('div.error_message_box').addClass('alert-danger');
            $('div.error_message_box').removeClass('hide');
            $(window).scrollTop($('div.error_message_box').offset().top);
            return false;
        } else {
            $('div.error_message_box').html("");
            $('div.error_message_box').removeClass('alert-danger');
            $('div.error_message_box').addClass('hide');
        }
        // form validation
        if (first_name == '') {
            var first_name_error = "first_name_error";
            $("#submit_user_form p." + first_name_error).html('<i class="fa fa-exclamation-triangle" aria-hidden="true"></i> Please enter first name.');
            $("#submit_user_form input#first_name").addClass("input-error");
            validation_status = false;
        }
        if (last_name == '') {
            var last_name_error = "last_name_error";
            $("#submit_user_form p." + last_name_error).html('<i class="fa fa-exclamation-triangle" aria-hidden="true"></i> Please enter last name.');
            $("#submit_user_form input#last_name").addClass("input-error");
            validation_status = false;
        }
        if (email_id == '') {
            var email_id_error = "email_id_error";
            $("#submit_user_form p." + email_id_error).html('<i class="fa fa-exclamation-triangle" aria-hidden="true"></i> Enter your email address.');
            $("#submit_user_form input#email_id").addClass("input-error");
            validation_status = false;
        } else if (!filter.test(email_id)) {

            var email_id_error = "email_id_error";
            $("#submit_user_form p." + email_id_error).html('<i class="fa fa-exclamation-triangle" aria-hidden="true"></i> Enter valid email address.');
            $("#submit_user_form input#email_id").addClass("input-error");
            validation_status = false;
        }
        if (username == '') {
            var username_error = "username_error";
            $("#submit_user_form p." + username_error).html('<i class="fa fa-exclamation-triangle" aria-hidden="true"></i> Enter your username.');
            $("#submit_user_form input#username").addClass("input-error");
            validation_status = false;
        }
        if (mobileno == '') {
            var mobileno_error = "mobileno_error";
            $("#submit_user_form p." + mobileno_error).html('<i class="fa fa-exclamation-triangle" aria-hidden="true"></i> Enter your mobile number for verification.');
            $("#submit_user_form input#mobileno").addClass("input-error");
            validation_status = false;
        } else if (mobileno.length < 8) {
            var mobileno_error = "mobileno_error";
            $("#submit_user_form p." + mobileno_error).html('<i class="fa fa-exclamation-triangle" aria-hidden="true"></i> Enter valid mobile number ');
            $("#submit_user_form input#mobileno").addClass("input-error");
            validation_status = false;
        } else if (mobileno.length > 16) {
            var mobileno_error = "mobileno_error";
            $("#submit_user_form p." + mobileno_error).html('<i class="fa fa-exclamation-triangle" aria-hidden="true"></i> Enter valid mobile number ');
            $("#submit_user_form input#mobileno").addClass("input-error");
            validation_status = false;
        } else if (mobileno.substr(0, 1) != '+') {
            var mobileno_error = "mobileno_error";
            $("#submit_user_form p." + mobileno_error).html('<i class="fa fa-exclamation-triangle" aria-hidden="true"></i> Mobile number should be like +4451485665. ');
            $("#submit_user_form input#mobileno").addClass("input-error");
            validation_status = false;
        }

        if (pwd == '') {
            var pwd_error = "pwd_error";
            $("#submit_user_form p." + pwd_error).html('<i class="fa fa-exclamation-triangle" aria-hidden="true"></i> Enter you secure password');
            $("#submit_user_form input#pwd").addClass("input-error");
            validation_status = false;
        } else if (pwd.length < 7) {
            var pwd_error = "pwd_error";
            $("#submit_user_form p." + pwd_error).html('<i class="fa fa-exclamation-triangle" aria-hidden="true"></i> Password length minimum 7 digit.');
            $("#submit_user_form input#pwd").addClass("input-error");
            validation_status = false;
        }
        if (validation_status == false) {
            return false;
        }
        var wp_nonce = $("input[name=wp_join_nonce]").val();
        $("html").addClass("overlay");
        $.ajax({
            type: "POST",
            url: ajaxurl,
            async: false,
            dataType: 'json',
            data: {
                first_name: first_name,
                last_name: last_name,
                email_id: email_id,
                username: username,
                pwd: pwd,
                mobileno: mobileno,
                primary_market: primary_market,
                primary_roles: primary_roles,
                primary_skills: primary_skills,
                wp_join_nonce: wp_nonce,
                action: 'vl_join_new_user',
            },

            success: function(data) {

                if (data == 'login_error') {
                    setTimeout(function() { window.location.href = '<?php echo site_url(); ?>/registration-page/login/'; }, 3000);
                }
                if (data['success'] == 1) {
                    $('div.error_message_box').removeClass('alert-danger');
                    $('div.error_message_box').addClass("alert-success");
                    $('div.error_message_box').show();
                    $('div.error_message_box').html(data['message']);
                    $(window).scrollTop($('div.error_message_box').offset().top);
                    var redirectURL = data['redirect_url'];
                    setTimeout(function() { window.location.href = redirectURL; }, 3000);
                } else if (data['field_error'] != '') {
                    var field_error = data['field_error'];
                    var alertMessage = data['message'];
                    $("#submit_user_form p." + field_error).html('<i class="fa fa-exclamation-triangle" aria-hidden="true"></i>' + alertMessage);
                    var fieldName = field_error.replace('_error', '');
                    $("#submit_user_form input#" + fieldName).addClass("input-error");
                    validation_status = false;

                } else {

                    $('div.error_message_box').html("");
                    $('div.error_message_box').removeClass('alert-success');
                    $('div.error_message_box').removeClass('hide');
                    $('div.error_message_box').addClass("alert-danger");
                    $('div.error_message_box').html(data['message']);
                    $(window).scrollTop($('div.error_message_box').offset().top);
                }
                $("html").removeClass("overlay");

            },
            error: function(error) {
                $("html").removeClass("overlay");
                $(".action_status").html(error);

            }
        });
    });

    $("#update_form_button").on("click", function(event) {
        /* stop form from submitting normally */
        event.preventDefault();
        var first_name = $("input#first_name").val();
        var last_name = $("input#last_name").val();
        var mobileno = $("input#mobileno").val();
        var get_user_email = $("input#get_user_email").val();
        var primary_market = $('ul.user_primary_category li input[name=user-role]:checked').val();
        var primary_roles = new Array();
        $("div#userProles input:checked").each(function() {
            primary_roles.push($(this).val());
        });
        var primary_skills = new Array();
        $("div.user_primary_skills input:checked").each(function() {
            primary_skills.push($(this).val());
        });
        var validation_status = false;
        if (first_name == '') {
            var first_name_error = "first_name_error";
            $("#update_user_form p." + first_name_error).html('<i class="fa fa-exclamation-triangle" aria-hidden="true"></i> Please enter first name.');
            $("#update_user_form input#first_name").addClass("input-error");
            validation_status = false;
        }
        if (last_name == '') {
            var last_name_error = "last_name_error";
            $("#update_user_form p." + last_name_error).html('<i class="fa fa-exclamation-triangle" aria-hidden="true"></i> Please enter last name.');
            $("#update_user_form input#last_name").addClass("input-error");
            validation_status = false;
        }
        if (mobileno == '') {
            var mobileno_error = "mobileno_error";
            $("#update_user_form p." + mobileno_error).html('<i class="fa fa-exclamation-triangle" aria-hidden="true"></i> Enter your mobile number for verification.');
            $("#update_user_form input#mobileno").addClass("input-error");
            validation_status = false;
        } else if (mobileno.length < 8) {
            var mobileno_error = "mobileno_error";
            $("#update_user_form p." + mobileno_error).html('<i class="fa fa-exclamation-triangle" aria-hidden="true"></i> Enter valid mobile number ');
            $("#update_user_form input#mobileno").addClass("input-error");
            validation_status = false;
        } else if (mobileno.length > 16) {
            var mobileno_error = "mobileno_error";
            $("#update_user_form p." + mobileno_error).html('<i class="fa fa-exclamation-triangle" aria-hidden="true"></i> Enter valid mobile number ');
            $("#update_user_form input#mobileno").addClass("input-error");
            validation_status = false;
        } else if (mobileno.substr(0, 1) != '+') {
            var mobileno_error = "mobileno_error";
            $("#update_user_form p." + mobileno_error).html('<i class="fa fa-exclamation-triangle" aria-hidden="true"></i> Mobile number should be like +4451485665. ');
            $("#update_user_form input#mobileno").addClass("input-error");
            validation_status = false;
        }
        if (primary_market == '') {
            $('div.error_message_box').html("Choose any primary market.");
            $('div.error_message_box').addClass('alert-danger');
            $('div.error_message_box').removeClass('hide');
            $(window).scrollTop($('div.error_message_box').offset().top);
            return false;
        } else if (primary_roles.length === 0) {
            $('div.error_message_box').html("Choose atleast one primary role.");
            $('div.error_message_box').addClass('alert-danger');
            $('div.error_message_box').removeClass('hide');
            $(window).scrollTop($('div.error_message_box').offset().top);
            return false;
        } else {
            $('div.error_message_box').html("");
            $('div.error_message_box').removeClass('alert-danger');
            $('div.error_message_box').addClass('hide');
        }
        var wp_nonce = $("input[name=wp_join_nonce]").val();
        $("html").addClass("overlay");
        $.ajax({
            type: "POST",
            url: ajaxurl,
            async: false,
            dataType: 'json',
            data: {
                first_name: first_name,
                last_name: last_name,
                mobileno: mobileno,
                get_user_email: get_user_email,
                primary_market: primary_market,
                primary_roles: primary_roles,
                primary_skills: primary_skills,
                wp_join_nonce: wp_nonce,
                action: "vl_update_join_user_ajax",
            },

            success: function(data) {

                if (data == 'login_error') {
                    setTimeout(function() { window.location.href = '<?php echo site_url(); ?>/registration-page/login/'; }, 3000);
                }
                if (data['success'] == 1) {
                    $('div.error_message_box').removeClass('alert-danger');
                    $('div.error_message_box').addClass("alert-success");
                    $('div.error_message_box').show();
                    $('div.error_message_box').html(data['message']);
                    $(window).scrollTop($('div.error_message_box').offset().top);
                    var redirectURL = data['redirect_url'];
                    setTimeout(function() { window.location.href = redirectURL; }, 3000);
                } else if (data['field_error'] != '') {
                    var field_error = data['field_error'];
                    var alertMessage = data['message'];
                    $("#update_user_form p." + field_error).html('<i class="fa fa-exclamation-triangle" aria-hidden="true"></i>' + alertMessage);
                    var fieldName = field_error.replace('_error', '');
                    $("#update_user_form input#" + fieldName).addClass("input-error");


                } else {
                    $('div.error_message_box').html("");
                    $('div.error_message_box').removeClass('alert-success');
                    $('div.error_message_box').removeClass('hide');
                    $('div.error_message_box').addClass("alert-danger");
                    $('div.error_message_box').html(data['message']);
                    $(window).scrollTop($('div.error_message_box').offset().top);
                }

                $("html").removeClass("overlay");


            },
            error: function(error) {
                $("html").removeClass("overlay");
                $(".action_status").html(error);

            }
        });
    });
});