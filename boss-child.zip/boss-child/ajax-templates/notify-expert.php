<?php
include '../../../../wp-config.php';
global $wpdb;

$expertid = $_POST['expertid'];
$notifymsg = $_POST['notifymsg'];
//echo $expertid;

$getdata = get_userdata( $expertid );
$useremail = $getdata->user_email;
$username  =  $getdata->user_login;


                    $message = "$notifymsg";
                    /* $message =
                    "First Name: $first_name
                    Last Name:$last_name
                    Phone: $cell_phone
                    Email: $user_email
                    Property: $tittle";*/
                    $subject = "Notification Reminder";
                    $headers .= 'From: <admin@justiceforus.net' . "\r\n";
                    
                    function yoursite_wp_mail_from_name() 
                    {
                        return 'Justice For Us Notification';
                    }            
                    add_filter('wp_mail_from_name','yoursite_wp_mail_from_name');
                    $mail_done = wp_mail($useremail,$subject,$message,$headers);
?>