<?php
include '../../../../wp-config.php';
global $wpdb;
$venuetable = $wpdb->prefix.'venuemeetingdetail';
$currentuserid = get_current_user_id();
    if(isset($_POST['inviteduser']))
    {
        $inviteduser = $_POST['inviteduser'];
        $usercount = $_POST['usercount'];
        $invitedarray = explode(",",$inviteduser);        
        $existuser  = $wpdb->get_results("SELECT * FROM `$venuetable` WHERE `currentuserid`='$currentuserid' AND `scheduledmeeting` IS NULL ORDER BY `id` DESC LIMIT 1");
        $inviteduserrr =  $existuser[0]->invitedusers;        
        if($inviteduserrr==NULL)
        {
            $wpdb->query("UPDATE $venuetable SET `invitedusers` ='$inviteduser' WHERE `currentuserid`='$currentuserid' AND `scheduledmeeting` IS NULL ORDER BY `id` DESC LIMIT 1");        
        }
        else
        { 
                   
            for($i=0;$i<$usercount;$i++)
            {   
                $existuser  = $wpdb->get_results("SELECT * FROM $venuetable WHERE `currentuserid`='$currentuserid' AND ((`invitedusers` LIKE  '%,$invitedarray[$i]' OR (`invitedusers` LIKE '%,$invitedarray[$i],%' OR (`invitedusers` LIKE '$invitedarray[$i],%'))) AND `scheduledmeeting` IS NULL) ORDER BY `id` DESC LIMIT 1");               
                if(!$existuser)
                {
                    $wpdb->query("UPDATE $venuetable SET `invitedusers` = CONCAT(invitedusers,',$invitedarray[$i]') WHERE `currentuserid`='$currentuserid' AND `scheduledmeeting` IS NULL ORDER BY `id` DESC LIMIT 1");            
                }
            }
        } 
    }
?>
    
    




