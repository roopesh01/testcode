<?php
include '../../../../../wp-config.php';
global $wpdb;

if ( isset( $_POST['search_value'] ) ) {
	$search_value = vl_sanitize_unsalsh( 'search_value' );
	$results      = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM `{$wpdb->vl_user_category}` WHERE `category_name` LIKE %s", '%s' . $wpdb->esc_like( $search_value ) . '%' ) );

	if ( $results ) :
		echo '<ul>';
		foreach ( $results as $result ) :
			$category_name = $result->category_name;
			$category_id   = $result->id;
			$subcategory   = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM `{$wpdb->vl_user_sub_category}` WHERE `category_id` = %d ", $category_id ) );
			?>
				<li><strong>Category:</strong><?php echo esc_html( $category_name ); ?>
				<?php
				if ( $subcategory ) :
					foreach ( $subcategory as $subid ) :
						$name = $subid->sub_category_name;
						echo '<ul><li>&nbsp;&nbsp;&nbsp;&nbsp;<strong>' . esc_attr( $name ) . '</strong></li></ul>';
						endforeach;
					endif;
				?>

				</li>
			<?php

		endforeach;
		echo '</ul>';
		echo '<i>Search Result For</i>&nbsp;<strong>' . esc_attr( $search_value ) . '</strong>';
	endif;
}
