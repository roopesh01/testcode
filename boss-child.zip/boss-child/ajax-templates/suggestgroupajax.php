<?php
include '../../../../wp-config.php';
global $wpdb;

if(isset($_POST['username']) || ($_POST['emails']) || ($_POST['suggestcategory']))
{
    $username = $_POST['username'];
    $usermail = $_POST['emails'];
    $suggestcategory = $_POST['suggestcategory'];
    //$admin_email = get_option( 'admin_email' );
    $admin_email ='support@justiceforpamkrusevanek.com'; 
    function groupsuggest() 
    {
        return 'Group Suggestion Notification';
    }
    add_filter('wp_mail_from_name','groupsuggest');
                    
    $subject = "Group Suggestion";
    $message = '<h4 style="text-align:center;">New Group Suggestion</h4>';    
    $message .='<p><strong>Name&nbsp;</strong>'.$username.'</p>
                <p><strong>Email&nbsp;</strong>'.$usermail.'</p>
                <p><strong>Group Name&nbsp;</strong>'.$suggestcategory.'</p>'; 
    
    $headers  = 'From: <webtest2105@gmail.com' . "\r\n";
    $headers .= array('Content-Type: text/html; charset=UTF-8');
    wp_mail($admin_email,$subject,$message,$headers);
    
}
?>