<?php
if ( ! is_user_logged_in() ) {
	$url = site_url( '/registration-page/login/' );
	wp_redirect( $url );
	exit;
}
?>
<?php
// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Template Name: Chat Save Pdf
 *
 */

require_once 'dompdf/autoload.inc.php';

// reference the Dompdf namespace
use Dompdf\Dompdf;

// instantiate and use the dompdf class\
$condition_modifiers = get_post_meta( '350', 'product_condition_modifiers', true );
$blog_title          = get_bloginfo( 'name' );
$customer_orders     = get_posts(
	array(
		'numberposts' => -1,
		'meta_key'    => '_customer_user',
		'meta_value'  => get_current_user_id(),
		'post_type'   => 'shop_order',
		'post_status' => array_keys( wc_get_order_statuses() ),
	)
);
global $wpdb;
$conference_id = $_GET['conference_id'];
$user_name     = $_GET['username'];
$userdetails   = get_user_by( 'login', $user_name );
$user_id       = $userdetails->ID;

$upload_dir            = wp_upload_dir();
$image_basedir         = $upload_dir['basedir'];
$image_baseurl         = $upload_dir['baseurl'];
$current_user_timezone = unserialize( get_user_meta( get_current_user_id(), 'user_timezone_detail', true ) );
// $mytimezone_id = get_timee($country,$city);
$mytimezone_id        = $current_user_timezone['timeZoneId'];
$chat_conference_data = $wpdb->prefix . 'chat_conference_data';
$dompdf               = new Dompdf();
$pdf_content          = '
	<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
	<html xmlns="http://www.w3.org/1999/xhtml">
		<title>Chat Download</title>
		<head>
			<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
			<link href="https://fonts.googleapis.com/css?family=Open+Sans:400,600,700" rel="stylesheet">
			<style type="text/css">
			.messageBox {color: #fff; margin: 5px 0; width: 85%;}
			.chatme {display: block; margin-right: 5px; padding: 0 50px 0 0; text-align: right; color: #1b5a79; font-size: 12px; font-weight: 600; line-height: 20px;}
			 
			span.chatOther {color: #1b5a79; display: block; font-size: 12px; font-weight: 600; line-height: 20px; margin-right: 5px; padding:0 0 0 50px;}
			.currentChannel p img {border-radius: 50%; -webkit-border-radius: 50%; -moz-border-radius: 50%; float: right; margin-left: 10px; width: 45px; height:auto;}
			.otherChannel p img {border-radius: 50%; -webkit-border-radius: 50%; -moz-border-radius: 50%;  margin-right: 10px; width: 45px; height:auto;float:left;}
			.meChannelChat .meChatmessage {background-color: #5caed4; border: 1px solid #489cc4; color: #fff; display:inline-block; text-align:left;}
			.meChatmessage {background-color: #fff; border: 1px solid #d9d9d9; border-radius: 5px; color: #333; padding: 10px; width: 70%; display:block;}
			.chat_time {width: 40%;margin-left:22%; display:block;text-align: left; color: #1b5a79; font-size: 12px; font-weight: 600; line-height: 20px;}
			.other_chat_time{width: 78%; display:block;text-align: right; color: #1b5a79; font-size: 12px; font-weight: 600; line-height: 20px;
			}
			      body { background-image: url(http://iisv2.crmmasterdev.wpengine.com/wp-content/themes/boss-child/images/bg-Chat.jpg); background-size:cover; background-repeat: repeat-y;
			      	padding:10px;
			      }

			</style>
		</head>
		<body>
			<div id="chatWrapper" style="width:100%;">';

				$sql_query          = "SELECT * FROM $chat_conference_data WHERE conference_id = '$conference_id'";
				$setup_call_results = $wpdb->get_results( $sql_query );
				$pdf_content       .= '<div class="chatContainer">';
foreach ( $setup_call_results  as $key => $call_result ) {
	$chatusername  = $call_result->FromName;
	$usermessage   = $call_result->Message;
	$chat_datetime = $call_result->datetime;
	$userInfo      = get_user_by( 'login', $chatusername );
	$userimage     = bp_get_activity_avatar( array( 'user_id' => $userInfo->ID ) );
	$src           = (string) reset( simplexml_import_dom( DOMDocument::loadHTML( $userimage ) )->xpath( '//img/@src' ) );
	$image_url     = $src;
	$temp_string   = 'avatars/' . $userInfo->ID;
	$explode_url   = explode( $temp_string, $image_url );
	$userImageURL  = $image_basedir . '/' . $temp_string . '' . $explode_url[1];
	 // get chat time according to user
	$userTimeZone   = $mytimezone_id;
	$user_chat_time = new DateTime( $chat_datetime, new DateTimeZone( 'UTC' ) );
	$user_chat_time->format( 'Y-m-d H:i:s' );
	$user_chat_time->setTimezone( new DateTimeZone( $userTimeZone ) );
	$chat_time = $user_chat_time->format( 'h:i A' );
	// $userImageURL = str_replace($image_baseurl, $image_basedir, $image_url);
	if ( $chatusername == $user_name ) {

		$pdf_content .= '<div class="currentChannel messageBox" style="width:85%;">
							   <span class="chat_time">' . $chat_time . '</span>
								<span class="chatusername chatme" >' . $chatusername . '</span>
								
								<p class="meChannelChat">

									<img src="' . $userImageURL . '" style="width:45px;margin-left:10px;" />
								    <span class="meChatmessage" style="width:70%;margin-left:auto;margin-right:55px;">' . $usermessage . '</span>
								</p>
							</div>';
	} else {
		$pdf_content .= '<div class="messageBox otherChannel" style="width:85%;">
								<span class="chatusername chatOther">' . $chatusername . '</span>
								<span class="other_chat_time" style="">' . $chat_time . '</span>
								<p class="chatOther">
									<img src="' . $userImageURL . '" style="margin-right:10px;" />
								   <span style="margin-left:55px;" class="meChatmessage">' . $usermessage . '</span>
								</p>
							</div>';
	}
}
			$pdf_content .= '
                    </div>
                </div>';
 $pdf_content            .= '
 </body>
	</html>';

$dompdf->loadHtml( $pdf_content );
// (Optional) Setup the paper size and orientation
$dompdf->setPaper( 'A3', 'letter' );

// Render the HTML as PDF
$dompdf->render();
// Output the generated PDF to Browser
//$dompdf->stream();

// Output the generated PDF (1 = download and 0 = preview)
$dompdf->stream( 'codex', array( 'Attachment' => 0 ) );

