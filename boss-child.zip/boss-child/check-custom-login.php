<?php

/*
Template Name: Check Custom Login
 */

get_header();
$user_id = 125;
$user    = get_user_by( 'id', $user_id );
echo $user->user_email;
echo $user->display_name;
/*
if( $user )
{
	wp_set_current_user( $user_id, $user->user_login );
	wp_set_auth_cookie( $user_id );
	//do_action( 'wp_login', $user->user_login );
}*/
get_footer();

