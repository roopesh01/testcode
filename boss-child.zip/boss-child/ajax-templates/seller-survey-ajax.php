<?php
include '../../../../wp-config.php';
global $wpdb, $current_user;
$userid = $current_user->ID;
echo $userid;

if ( isset( $_POST['surveyrelation'] ) || isset( $_POST['firstmet'] ) || isset( $_POST['childrelation'] ) || isset( $_POST['childtouch'] ) || isset( $_POST['activityshare'] ) || isset( $_POST['childfriend'] ) ) {

	$surveyrelation = vl_sanitize_unslash( 'surveyrelation' );
	$activityshare  = vl_sanitize_unslash( 'activityshare' );
	$firstmet       = vl_sanitize_unslash( 'firstmet' );
	$childfriend    = vl_sanitize_unslash( 'childfriend' );
	$childrelation  = vl_sanitize_unslash( 'childrelation' );
	$childtouch     = vl_sanitize_unslash( 'childtouch' );


	$surveyrelationkey = 'surveyrelation';
	$activitysharekey  = 'activityshare';
	$firstmetkey       = 'firstmet';
	$childfriendkey    = 'childfriend';
	$childrelationkey  = 'childrelation';
	$childtouchkey     = 'childtouch';
	$submitsurveykey   = 'submitsurveykey';
	$keyvalue          = 'submitsurvey';

	$metas = array(
		$surveyrelationkey => $surveyrelation,
		$activitysharekey  => $activityshare,
		$firstmetkey       => $firstmet,
		$childfriendkey    => $childfriend,
		$childrelationkey  => $childrelation,
		$childtouchkey     => $childtouch,
		$submitsurveykey   => $keyvalue,
	);
	foreach ( $metas as $key => $value ) {
		update_user_meta( $userid, $key, $value );
	}
}



