<?php 
include '../../../../wp-config.php';
global $wpdb,$current_user; 
$available_table = $wpdb->prefix.'expert_avilability_calender';
$timeslots_table = $wpdb->prefix.'timeslotdetails';
$booking_table = $wpdb->prefix.'BillingInformation';
$expertid = $_POST["expertid"]; 
$timezone = $_POST["timezone"];

$user_id = get_current_user_id();
if ($user_id == 0) 
{
	$redirect = site_url()."/registration-page/login/";
	echo json_encode(array('login_error'=>1,'redirect'=>$redirect));	
	exit; 
}

$booking_detail = $wpdb->get_results("SELECT $available_table.available_date, $available_table.status, $timeslots_table.value FROM $available_table INNER JOIN $timeslots_table ON $available_table.timeslotid=$timeslots_table.timeslotid Where $available_table.expert_id = '$expertid' AND $available_table.status IN ('available')"); 
$slot = null;
$intialslot = null;
$listSlots = array();
$status = array(); 
foreach($booking_detail as $key=>$booking_details)
{
	$title = ($status == "booked") ? "Slot Booked" : "Booking Available";
	$get_time = $booking_details->value;
	$get_date = $booking_details->available_date;
	$status = $booking_details->status;
	date_default_timezone_set($timezone);
	$spiltarray =  explode("-",$get_time);
	$initstartdatetime = $get_date." ". $spiltarray[0];
	$startdatetime = date(DATE_RFC2822, strtotime($initstartdatetime));
	$enddatetime = $get_date." ". $spiltarray[1];
	$endvalue = end($booking_detail);
	$final_value = $endvalue->value;
	$final_key = "available-".$key;
	if($slot == $spiltarray[0] || $slot == null)
	{
		if($slot == null)
		{
			$slot = $spiltarray[1];
			$intialslot = $initstartdatetime;
		}
		else
		{
			$slot = date('H:i',strtotime($slot . ' +15 minutes'));
			
		}
	}
	else
	{
		if($slot != null) 
		{
			$listSlots[$final_key] = $intialslot."-".$slot;
			$slot=null; 
			$intialslot = null; 
			$slot = $spiltarray[1];
			$intialslot = $initstartdatetime;	
		}
	}
	if($final_value == $get_time)
	{
		if($slot != null) 
		{
			$listSlots[$final_key] = $intialslot."-".$slot;
			$slot=null; 
			$intialslot = null; 
			$slot = $spiltarray[1];
			$intialslot = $initstartdatetime;	
		}
	}
	$enddatetime = date(DATE_RFC2822, strtotime($enddatetime));
}

$bookslot = null;
$bookintialslot = null;
$booklistSlots = array();
$bookedstatus = array();
$confidarray = array();
$booked_detail = $wpdb->get_results("SELECT conference_id, usertime, gmt_starttime, gmt_endtime, user_timezone FROM $booking_table WHERE conference_id IN (SELECT DISTINCT conference_id FROM $available_table WHERE expert_id = '$expertid' AND status = 'booked')");
foreach($booked_detail as $bookedkey=>$booked_details)
{
	date_default_timezone_set($timezone);
	$booked_time_value = $booked_details->usertime;
	$gmt_starttime = $booked_details->gmt_starttime;
	$conference_id =  $booked_details->conference_id;
	$gmt_endtime = $booked_details->gmt_endtime;
	$bookfinal = "booked-".$bookedkey;
	$timesplit =  explode(" ",$gmt_endtime);
	$endtimeslot = $timesplit[1];
	$booklistSlots[$bookfinal] = $gmt_starttime."-".$endtimeslot;
	$confidarray[$bookfinal] = $conference_id;
}
$new_array = array_merge($booklistSlots,$listSlots);
foreach($new_array as $bookkey=>$bookingslots)
{
	$confid = $confidarray[$bookkey];
	if(empty($confid))
	{
		$eventid = $bookkey;
	}
	else
	{
		$eventid = $confid;
	}
	$keyexpload =  explode("-",$bookkey);
	$status = $keyexpload[0];
	$spiltboookings =  explode(" ",$bookingslots);
	$spilttime =  explode("-",$spiltboookings[1]);
	$starttime = $spiltboookings[0]." ". $spilttime[0];
	$startisotime = date(DATE_RFC2822, strtotime($starttime));
	$endtime = $spiltboookings[0]." ". $spilttime[1];
	$endisotime = date(DATE_RFC2822, strtotime($endtime));
	$title = ($status == "booked") ? "Slot Booked" : "Booking Available";
	$color = ($status == "booked") ? '#da4638' : '#199070';
	$event_array[] = array(
            'id' => $eventid,
            'title' => $title,
            'start' => $startisotime,
            'end' => $endisotime,
            'allDay' => false,
			'color' => $color
    ); 
}
echo json_encode($event_array);	 
exit; 