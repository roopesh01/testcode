<?php
	include '../../../../wp-config.php';
	global $wpdb;
	$filename   = 'case_evidence_level1.csv';
	$header_row = array(
		0  => 'id',
		1  => 'wp_evidence_table_id',
		2  => 'fmp_evidence_table_id',
		3  => 'investigator_case_number',
		4  => 'item_title',
		5  => 'item_description',
		6  => 'item_type',
		7  => 'item_subtype',
		8  => 'item_discovered_account',
		9  => 'item_found_date',
		10 => 'item_found_time',
		11 => 'number_photos_taken',
		12 => 'photo1_url',
		13 => 'photo2_url',
		14 => 'photo3_url',
		15 => 'photo4_url',
		16 => 'photo5_url',
		17 => 'category',
		18 => 'subcategory',
		19 => 'tags',
	);
	$data_rows  = array();
	$table      = $wpdb->prefix . 'case_evidence_level1';
	$result     = $wpdb->get_results( "SELECT * FROM $table" );
	foreach ( $result as $results ) {
		$row         = array();
		$row[0]      = $results->post_title;
		$row[1]      = $results->post_name;
		$row[2]      = $results->post_content;
		$row[3]      = $results->post_author;
		$row[4]      = $results->comment_count;
		$row[5]      = $results->post_status;
		$data_rows[] = $row;
	}
	$fh = @fopen( 'php://output', 'w' );
	fprintf( $fh, chr( 0xEF ) . chr( 0xBB ) . chr( 0xBF ) );
	header( 'Cache-Control: must-revalidate, post-check=0, pre-check=0' );
	header( 'Content-Description: File Transfer' );
	header( 'Content-type: text/csv' );
	header( "Content-Disposition: attachment; filename={$filename}" );
	header( 'Expires: 0' );
	header( 'Pragma: public' );
	fputcsv( $fh, $header_row );
	foreach ( $data_rows as $data_row ) {
		fputcsv( $fh, $data_row );
	}
	fclose( $fh );
	die();



