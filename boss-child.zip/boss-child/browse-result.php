<?php
/*
 * Template Name: Browse Results
 *
 */
	?>
 <style>
	.backtosearch > a {
	color: blue;
	text-decoration: underline;
}
.backtosearch {
	margin-bottom: 20px;
}

 </style>
	<?php
	get_header();
	if ( isset( $_GET['subcatid'] ) ) :
		global $wpdb,$current_user;
		$table     = $wpdb->prefix . 'user_sub_category';
		$metatable = 'wp68_usermeta';
		$subcatid  = $_GET['subcatid'];
		$catname   = $wpdb->get_var( "SELECT `sub_category_name` FROM $table WHERE `id`=$subcatid" );
		//echo $catname;
	?>
	<div class="page-full-width">
		<div id="primary" class="site-content">
			<div id="content" role="main">
			<div class="expertbycategorytags">
			<?php
				echo '<h4 class="backtosearch"><a href="/browse-by-categories/">Back To Search</a></h4>';
				$catname = $wpdb->get_results( "SELECT * FROM $metatable WHERE `meta_value` LIKE '%$catname%'" );
			if ( $catname ) {
				$single = true;
				foreach ( $catname as $result ) :
					$userid        = $result->user_id;
					$firstname     = get_user_meta( $userid, 'first_name', $single );
					$lastname      = get_user_meta( $userid, 'last_name', $single );
					$AboutYourSelf = bp_get_profile_field_data( 'field=AboutYourSelf&user_id=' . $userid );
					$title         = bp_get_profile_field_data( 'field=Title&user_id=' . $userid );
					$city          = bp_get_profile_field_data( 'field=City&user_id=' . $userid );
					$state         = bp_get_profile_field_data( 'field=State&user_id=' . $userid );
					?>
				   <div class="row buser">
						<div class="col-sm-3 col-md-2 user-image">
							<a href="<?php echo site_url(); ?>/user-basic-profile/?ExpertId=<?php echo $userid; ?>">
								<?php
								echo get_avatar( $userid );
								?>
							  </a>
						</div>
						<div class="col-sm-9 col-md-10 user-details">
							  <h3 class="user-name"><a href="<?php echo site_url(); ?>/user-basic-profile/?ExpertId=<?php echo $userid; ?>"><?php echo $firstname . '&nbsp;' . $lastname; ?></a></h3>
							  <h4 class="user-meta">
								<small class="user-cvr"><?php echo $title; ?></small>
								<small class="user-location"><i class="fa fa-map-marker" aria-hidden="true"></i><?php echo $city . ',&nbsp;' . $state; ?></small></h4>        					 
							  <p><?php echo $AboutYourSelf; ?></p>
						</div>
					</div>
					<?php
				endforeach;
			} else {
				echo '<h4 class="backtosearch">Oops! No Result Found</h4>';

			}
				?>
			   </div>
			   </div><!-- #content -->
		   </div><!-- #primary -->
	   </div><!-- .page-full-width -->    
	<?php
endif;
	get_footer();
	?>
