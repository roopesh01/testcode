
(function($){
$(document).ready(function()
{
    //alert("hello");
    $(document).on('click', '.sendnotify', function(e)
    {
    
        $('.notificationbox').hide();
        $(this).parent('td').parent('tr').find('.notificationbox').show();
        //alert(notification);
        /*var confirmsend =  confirm('Are You Sure');
        if(confirmsend==true)
        {
           var expertid =  jQuery(this).attr("data-id");
           // alert(expertid);
            $.ajax
            ({
                type: 'POST',
                url: '/wp-content/themes/boss-child/ajax-templates/notify-expert.php',
                data:
                {
                    expertid: expertid
                },
                success: function(html)
                { 
                    //alert(html);   
                },
                error: function(MLHttpRequest, textStatus, errorThrown)
                {
                }
            });
        }*/
    });
    
    $(document).on('click','.submit_notify', function(e)
    {
        var notifymsg = $(this).parent('.notificationbox').find('.notifymsgs').val();
        var emptymsg = $(this).parent('.notificationbox').find('.notifymsgs');
        var expertid = $(this).attr("id");
        
        var confirmsend =  confirm('Are You Sure');
        if(confirmsend==true)
        {
           
           
           // alert(expertid);
            $.ajax
            ({
                type: 'POST',
                url: '/wp-content/themes/boss-child/ajax-templates/notify-expert.php',
                data:
                {
                    expertid: expertid,
                    notifymsg: notifymsg
                },
                success: function(html)
                { 
                    
                    alert("successfuly Sent");
                    $('.notificationbox').fadeOut();
                    $(emptymsg).val("");
                    //alert(html);   
                },
                error: function(MLHttpRequest, textStatus, errorThrown)
                {
                }
            });
        }
        //alert(ids);        
    });

});
})(jQuery);