<?php
    include '../../../../wp-config.php';
    global $wpdb, $current_user;
    $userid = $current_user->ID;
    $category_approve_table = $wpdb->vl_category_admin_approve;
    $usermeta_table = 'wp68_usermeta';
    $prefix = 'wp68_8_';
    $primary_cat_approve = $prefix.'primary_category';    
    
    if(isset($_POST['select_category']))
    {
        $select_category = $_POST['select_category'];
        $category_approve_exist = $wpdb->get_results("SELECT * FROM `$primary_cat_approve` WHERE `user_id` ='$userid'");
        if($category_approve_exist)
        {
            $wpdb->query("UPDATE `$primary_cat_approve` SET `primary_category` ='$select_category', `admin_approve`= NULL WHERE `user_id` ='$userid'");   
        }
        else
        {
            $wpdb->insert($primary_cat_approve, 
            array
            (
                'user_id' => $userid,
                'primary_category' =>$select_category                				
            ),
            array('%d','%s')
            ); 
        }      
    }
    if(isset($_POST['subcategoriess']) || isset($_POST['allmetakey']) || isset($_POST['uncheckedvalue']))
    {
        $subcategory = $_POST['subcategoriess'];
        $categorykey =  $_POST['allmetakey'];
        $uncheckedvalue = $_POST['uncheckedvalue'];
        /*  new functionality for unchecked array */
         echo $uncheckedvalue;
         if($uncheckedvalue)
         {
              $catsubcat = explode(",&&,",$uncheckedvalue);         
              $i=0;
              $totalcatsubcat = count($catsubcat);              
              for($i=0;$i<$totalcatsubcat;$i++)
              {
                   //$filter_catsubcat = rtrim($catsubcatvalue,',&&');
                   $separatecat_subcat = explode("##",$catsubcat[$i]);                    
                   $filtered_category =   rtrim($separatecat_subcat[1],',&&'); 
                   $filtered_subcategory = $separatecat_subcat[0];     
                    //echo $filter_catsubcat;
                    $already_exist = $wpdb->get_results("SELECT * FROM `$category_approve_table` WHERE `category`='$filtered_category' AND `user_id` ='$userid' AND `subcategory` ='$filtered_subcategory'");
                    if(!$already_exist)
                    {
                      $wpdb->insert( 
            				$category_approve_table,
            				array(
                				'user_id' => $userid,
                				'category' =>$filtered_category,
                				'subcategory' =>$separatecat_subcat[0],
                                'request_to' =>'remove'      						
            				),
            				array('%d','%s','%s','%s')
            			);
                    }
                    else
                    {
                        $wpdb->query("UPDATE $category_approve_table SET `request_to` ='remove', `approve` = NULL WHERE `category`='$filtered_category' AND `user_id` ='$userid' AND `subcategory` ='$filtered_subcategory'");                        
                    }              
              }
          }
          //die();     
        /*  new functionality for unchecked array */       
            
        /* Convert String To Array */           
        $subcategories = explode("##,",$subcategory);
        $filteredcategories = array_filter($subcategories);
        
        function myFilter($string) 
        {
            return strpos($string, '##') === false;
        }
        $newArray = array_filter($filteredcategories, 'myFilter');
        $keyarray = explode(",",$categorykey);                    
        foreach($newArray as $key=>$value) {
            $subcategoryvalues = $newArray[$key];
            $subcategoryvalue  = rtrim($subcategoryvalues,',');             
            $categoryvalue= $keyarray[$key];
            $subcategoryvaluearray = explode(",",$subcategoryvalue);
                foreach($subcategoryvaluearray as $value) {
                    echo $categoryvalue.'&nbsp;&nbsp;&nbsp;';
                    echo $value;
                    echo '<br/>';
                $metakey =  $prefix.$categoryvalue;
                $exist_in_database = $wpdb->get_results("SELECT * FROM `$usermeta_table` WHERE `meta_key`='$metakey' AND `user_id` ='$userid' AND `meta_value` LIKE '%$value%'");          
                $category_approve_exist = $wpdb->get_results("SELECT * FROM `$category_approve_table` WHERE `category`='$categoryvalue' AND `user_id` ='$userid' AND `subcategory` ='$value'");
                if(!$category_approve_exist && !$exist_in_database)
                {
                        $wpdb->insert( 
                    	$category_approve_table,
                    	array
                        (
                        	'user_id' => $userid,
                        	'category' =>$categoryvalue,
                        	'subcategory' =>$value,
                            'request_to' =>'add'         						
                    	),
                    	array('%d','%s','%s','%s')
                    );                        
                }
                else
                {
                    $wpdb->query("UPDATE $category_approve_table SET `request_to` ='add', `approve` = NULL WHERE `category`='$categoryvalue' AND `user_id` ='$userid' AND `subcategory` ='$value'");                        
                }
            } 
        }
    }
?>