(function ($)
{

    function simple_tooltip(target_items, name)
    {
        $(target_items).each(function (i)
        {
            $("body").append("<div class='" + name + "' id='" + name + i + "'><p>" + $(this).attr('title') + "</p></div>");
            var my_tooltip = $("#" + name + i);

            $(this).removeAttr("title").mouseover(function ()
            {
                my_tooltip.css({opacity: 0.8, display: "none"}).show();
            }).mousemove(function (kmouse)
            {
                my_tooltip.css({left: kmouse.pageX + 15, top: kmouse.pageY + 15});
            }).mouseout(function ()
            {
                my_tooltip.hide();
            });
        });
    }
    $(document).ready(function ()
    {
        simple_tooltip(".custom_tooltip", "tooltip");
        $("#keywordList span").remove();
        $("#tags span").not(".caret").remove();
        var my_table;
        $("#my_favorite_expert_list").DataTable
                ({
                    "language": {"search": " ", "searchPlaceholder": "Search..."}
                });
        my_table = $('#ExpertByCategory').DataTable
                ({
                    "language":
                            {
                                "search": " ",
                                "searchPlaceholder": "Search Experts..."
                            }
                });
        $('#ExpertByCategory_filter').addClass('hide');
        /* custom sorting by datatable */

        /* custom sorting by datatable */


        $(document).on('click', '.my_team_list', function (e)
        {
            $(".team_list").toggle();
        });
        /* search by categories through text box */
        var searchRequest = null;
        var minlength = 1;
        $(".search_by_categories").keyup(function ()
        {
            var that = this,
                    value = $(this).val();

            if (value.length >= minlength)
            {
                if (searchRequest != null)
                    searchRequest.abort();
                searchRequest = $.ajax({
                    type: "POST",
                    url: '/wp-content/themes/boss-child/ajax-templates/sortings/category_search.php',
                    data:
                            {
                                'search_value': value
                            },
                    dataType: "text",
                    success: function (html)
                    {
                        //we need to check if the value is the same
                        if (value == $(that).val())
                        {
                            $('.search_result').html(html);
                        }
                    }
                });
            } else
            {
                $('.search_result').html("");
            }
        });
        /* search by categories through text box */
        $(document).on('click', '.search_by_team', function (e)
        {
            var search_by_team = $(this).attr("data-id");
            $("#keywordList span").remove();
            //$("#tags span").remove();
            $("html").addClass("overlay");
            $.ajax
                    ({
                        type: 'POST',
                        url: '/wp-content/themes/boss-child/ajax-templates/sortings/sort_by_teams.php',
                        data:
                                {
                                    search_by_team: search_by_team
                                },
                        success: function (html)
                        {
                            $("html").removeClass("overlay");
                            $('#ExpertByCategory').DataTable().destroy();
                            $('.tablebodyhtml').html(html);
                            my_table = '';
                            my_table = $('#ExpertByCategory').DataTable
                                    ({
                                        /*"bLengthChange": false,
                                         "bSort" : false,*/
                                        "language":
                                                {
                                                    "search": " ",
                                                    "searchPlaceholder": "Search Experts..."
                                                }
                                    });
                            $('#ExpertByCategory_filter').addClass('hide');
                            $('.apicon-check').remove();
                            $('.team_list').hide();
                        }
                    });
        });
        $(document).on('click', '.my_friend_list', function (e)
        {
            var useridforfriend = $(this).attr("data-id");
            $("#keywordList span").remove();
            //$("#tags span").remove();
            $("html").addClass("overlay");
            $.ajax
                    ({
                        type: 'POST',
                        url: '/wp-content/themes/boss-child/ajax-templates/sortings/sort_by_friends.php',
                        data:
                                {
                                    useridforfriend: useridforfriend
                                },
                        success: function (html)
                        {
                            $("html").removeClass("overlay");
                            $('#ExpertByCategory').DataTable().destroy();
                            $('.tablebodyhtml').html(html);
                            my_table = '';
                            my_table = $('#ExpertByCategory').DataTable
                                    ({
                                        /* "bLengthChange": false,
                                         "bSort" : false,*/
                                        "language":
                                                {
                                                    "search": " ",
                                                    "searchPlaceholder": "Search Experts..."
                                                }
                                    });
                            $('#ExpertByCategory_filter').addClass('hide');
                            $('.apicon-check').remove();
                            $('.custom_tooltip').each(function (i)
                            {
                                $("body").append("<div class='tooltip' id='tooltip" + i + "'><p>" + $(this).attr('title') + "</p></div>");
                                var my_tooltip = $("#tooltip" + i);

                                $(this).removeAttr("title").mouseover(function ()
                                {
                                    my_tooltip.css({opacity: 0.8, display: "none"}).fadeIn(400);
                                }).mousemove(function (kmouse)
                                {
                                    my_tooltip.css({left: kmouse.pageX + 15, top: kmouse.pageY + 15});
                                }).mouseout(function ()
                                {
                                    my_tooltip.fadeOut(400);
                                });
                            });
                        }
                    });
        });
        $(document).on('click', '.sortings', function (e)
        {
            $(".sorting_options").toggle();
        });
        /* clear all categories */
        $(document).on('click', '.clear_all', function (e)
        {
            $(".sorting_options").hide();
            $("#keywordList span").remove();
            //$("#tags span").remove();
            $("html").addClass("overlay");
            var clearvalue = $(this).attr("data-value");
            $.ajax
                    ({
                        type: 'POST',
                        url: '/wp-content/themes/boss-child/ajax-templates/sortings/clear_categories.php',
                        data:
                                {
                                    clearvalue: clearvalue
                                },
                        success: function (html)
                        {
                            $("html").removeClass("overlay");
                            $('#ExpertByCategory').DataTable().destroy();
                            $('.tablebodyhtml').html(html);
                            my_table = '';
                            my_table = $('#ExpertByCategory').DataTable
                                    ({
                                        /* "bLengthChange": false,
                                         "bSort" : false,*/
                                        "language":
                                                {
                                                    "search": " ",
                                                    "searchPlaceholder": "Search Experts..."
                                                }
                                    });
                            $('#ExpertByCategory_filter').addClass('hide');
                            $('.apicon-check').remove();
                            $('.custom_tooltip').each(function (i)
                            {
                                $("body").append("<div class='tooltip' id='tooltip" + i + "'><p>" + $(this).attr('title') + "</p></div>");
                                var my_tooltip = $("#tooltip" + i);

                                $(this).removeAttr("title").mouseover(function ()
                                {
                                    my_tooltip.css({opacity: 0.8, display: "none"}).fadeIn(400);
                                }).mousemove(function (kmouse)
                                {
                                    my_tooltip.css({left: kmouse.pageX + 15, top: kmouse.pageY + 15});
                                }).mouseout(function ()
                                {
                                    my_tooltip.fadeOut(400);
                                });
                            });
                        }
                    });
        });
        /* clear all categories */


        $(document).on('click', '.browse_cats,.browse_cat', function (e)
        {
            $("#keywordList span").remove();
            //$("#tags span").remove();          
            var subcatid = $(this).attr("data-id");
            var subcatclass = $(this).parent('li').parent('ul').parent('li').find('.catelink').attr("id");
            var classadd = 'browseTitle' + subcatclass;
            $('.catelink').removeClass('addcolor');
            $('.browse_cat').removeClass('addcolor');
            $('.browse_cats').removeClass('addcolor');
            $(this).addClass('addcolor');
            $(".maincatdiv").removeClass(function (index, classNames)
            {
                var current_classes = classNames.split(" "),
                        classes_to_remove = [];
                $.each(current_classes, function (index, class_name)
                {
                    if (/browseTitle.*/.test(class_name))
                    {
                        classes_to_remove.push(class_name);
                    }
                });
                return classes_to_remove.join(" ");
            });
            $('.maincatdiv').addClass(classadd);
            $("html").addClass("overlay");
            $.ajax
                    ({
                        type: 'POST',
                        url: '/wp-content/themes/boss-child/ajax-templates/sortings/sort_by_subcategory.php',
                        data:
                                {
                                    subcatid: subcatid
                                },
                        success: function (html)
                        {
                            $("html").removeClass("overlay");
                            var divs = html.split('<hr/>');
                            var url = divs[0];
                            var subcat = divs[1]
                            var users = divs[2];
                            var image = $('.catsubcat');
                            image.css('background-image', 'url(' + url + ')');
                            $('.catsubcat').html(divs[1]);
                            $('#ExpertByCategory').DataTable().destroy();
                            $('.tablebodyhtml').html(users);
                            my_table = '';
                            my_table = $('#ExpertByCategory').DataTable
                                    ({
                                        /*"bLengthChange": false,
                                         "bSort" : false,*/
                                        "language":
                                                {
                                                    "search": " ",
                                                    "searchPlaceholder": "Search..."
                                                }
                                    });
                            $('#ExpertByCategory_filter').addClass('hide');
                            $('.apicon-check').remove();
                            $(".sorting_options").hide();
                            $('.custom_tooltip').each(function (i)
                            {
                                $("body").append("<div class='tooltip' id='tooltip" + i + "'><p>" + $(this).attr('title') + "</p></div>");
                                var my_tooltip = $("#tooltip" + i);

                                $(this).removeAttr("title").mouseover(function ()
                                {
                                    my_tooltip.css({opacity: 0.8, display: "none"}).fadeIn(400);
                                }).mousemove(function (kmouse)
                                {
                                    my_tooltip.css({left: kmouse.pageX + 15, top: kmouse.pageY + 15});
                                }).mouseout(function ()
                                {
                                    my_tooltip.fadeOut(400);
                                });
                            });
                        },
                        error: function (MLHttpRequest, textStatus, errorThrown)
                        {

                        }
                    });
        });
        $(document).on('click', '.catelink', function (e)
        {
            $("#keywordList span").remove();
            //$("#tags span").remove();
            var categorykey = $(this).attr("id");
            var categoryid = $(this).attr("data-id");
            $('.catelink').removeClass('addcolor');
            $(this).addClass('addcolor');
            //alert(categoryid);
            var subcatclass = 'browseTitle' + categorykey;
            $(".maincatdiv").removeClass(function (index, classNames)
            {
                var current_classes = classNames.split(" "),
                        classes_to_remove = [];
                $.each(current_classes, function (index, class_name)
                {
                    if (/browseTitle.*/.test(class_name))
                    {
                        classes_to_remove.push(class_name);
                    }
                });
                return classes_to_remove.join(" ");
            });
            $('.maincatdiv').addClass(subcatclass);
            $("html").addClass("overlay");
            $.ajax
                    ({
                        type: 'POST',
                        url: '/wp-content/themes/boss-child/ajax-templates/sortings/sort_by_category.php',
                        data:
                                {
                                    categorykey: categorykey,
                                    categoryid: categoryid
                                },
                        success: function (html)
                        {
                            $("html").removeClass("overlay");
                            var divs = html.split('<hr/>');
                            var url = divs[0];
                            var subcat = divs[1];
                            var users = divs[2];
                            var image = $('.catsubcat');
                            image.css('background-image', 'url(' + url + ')');
                            $('.catsubcat').html(subcat);
                            $('#ExpertByCategory').DataTable().destroy();
                            $('.tablebodyhtml').html(users);
                            my_table = '';
                            my_table = $('#ExpertByCategory').DataTable
                                    ({
                                        /*"bLengthChange": false,
                                         "bSort" : false,,*/
                                        "language":
                                                {
                                                    "search": " ",
                                                    "searchPlaceholder": "Search..."
                                                }
                                    });
                            $('#ExpertByCategory_filter').addClass('hide');
                            $('.apicon-check').remove();
                            $('.custom_tooltip').each(function (i)
                            {
                                $("body").append("<div class='tooltip' id='tooltip" + i + "'><p>" + $(this).attr('title') + "</p></div>");
                                var my_tooltip = $("#tooltip" + i);

                                $(this).removeAttr("title").mouseover(function ()
                                {
                                    my_tooltip.css({opacity: 0.8, display: "none"}).fadeIn(400);
                                }).mousemove(function (kmouse)
                                {
                                    my_tooltip.css({left: kmouse.pageX + 15, top: kmouse.pageY + 15});
                                }).mouseout(function ()
                                {
                                    my_tooltip.fadeOut(400);
                                });
                            });
                        },
                        error: function (MLHttpRequest, textStatus, errorThrown)
                        {
                        }
                    });
        });
        $("div#sort_box_id ul li a").on("click", function ()
        {
            var currentID = $(this).attr('id');


            // desc order by name
            if (currentID == "alpha_desc")
            {
                my_table.order([0, 'desc']).draw();

                //  my_table.fnSort( [ [0,'desc'] ] );

            } else if (currentID == "alpha_asc")
            {
                // asc order by name
                my_table.order([0, 'asc']).draw();

            } else if (currentID == "totalrating")
            {
                // desc order by rating
                // my_table.order( [ 2, 'desc' ] ).draw(); 


                $.fn.dataTable.ext.search.push(
                        function (settings, data, dataIndex) {
                            return parseFloat(data[2]) > 0
                                    ? true
                                    : false
                        }
                );
                my_table.draw();
                my_table.order([2, 'desc']).draw();
                $.fn.dataTable.ext.search.pop();

            } else if (currentID == "valuehigh")
            {
                // desc order by price
                my_table.order([3, 'desc']).draw();
            } else if (currentID == "valuelow")
            {
                // asc order by price
                my_table.order([3, 'asc']).draw();
            } else if (currentID == "ap_reputation")
            {
                // desc order by reputation
                my_table.order([4, 'desc']).draw();
            } else if (currentID == "high_charity")
            {
                $.fn.dataTable.ext.search.push(
                        function (settings, data, dataIndex) {
                            return parseFloat(data[5]) > 0
                                    ? true
                                    : false
                        }
                );
                my_table.draw();
                my_table.order([5, 'desc']).draw();
                $.fn.dataTable.ext.search.pop();

            } else if (currentID == "low_charity")
            {
                $.fn.dataTable.ext.search.push(
                        function (settings, data, dataIndex) {
                            return parseFloat(data[5]) > 0
                                    ? true
                                    : false
                        }
                );
                my_table.draw();
                my_table.order([5, 'asc']).draw();
                $.fn.dataTable.ext.search.pop();
            }
        });
        /* custom js */

        function searchByCommonFilter(search_by, search_in, data)
        {
            var search_by = search_by;
            var search_in = search_in;
            var whatsSelected = [];
            var expertValue = $.trim($("input#" + search_by).val());
            $("#tags span." + search_by).each(function (index) {
                var spanText = $(this).text();
                whatsSelected.push(spanText);
            });
            if (data && data != "") {
                whatsSelected.push(data);
            }
            console.log(whatsSelected, search_in);
            if (expertValue != '')
            {
                whatsSelected.push(expertValue);
            }
//        console.log(whatsSelected);
            my_table
                    .columns(search_in)
                    .search(whatsSelected.join('|'), true).draw();
        }
        $('#search_by_expert').live('keyup change', function () {
            searchByCommonFilter("search_by_expert", 0);
        });
        $('#search_by_cities').live('keyup change', function () {
            searchByCommonFilter("search_by_cities", 6);
        });
        $('#search_by_state').live('keyup change', function () {
            searchByCommonFilter("search_by_state", 7);
        });
        $('#search_by_country').live('keyup change', function () {
            searchByCommonFilter("search_by_country", 8);
        });
        $('#search_by_jobtitle').live('keyup change', function () {
            searchByCommonFilter("search_by_jobtitle", 9);
        });
        $('#search_by_market').live('keyup change', function () {
            searchByCommonFilter("search_by_market", 10);
        });

        $('#search_by_company').live('keyup change', function () {
            searchByCommonFilter("search_by_company", 11);
        });


        $(document).on('catValueAdded', function (e, data) {
            searchByCommonFilter("search_by_market", 10, data);
        });


        $("a.clear-all-input-box").on("click", function ()
        {
            $("#search_by_expert").val('');
            $("#search_by_cities").val('');
            $("#search_by_state").val('');
            $("#search_by_country").val('');
            $("#search_by_jobtitle").val('');
            $("#search_by_market").val('');
            $("#search_by_company").val('');

            var press = jQuery.Event("keyup");
            press.ctrlKey = false;
            press.which = 40;
            $("#search_by_expert").keypress(function () {

            }).trigger(press);

            var press1 = jQuery.Event("keyup");
            press1.ctrlKey = false;
            press1.which = 40;
            $("#search_by_country").keypress(function () {

            }).trigger(press1);

            var press2 = jQuery.Event("keyup");
            press2.ctrlKey = false;
            press2.which = 40;
            $("#search_by_state").keypress(function () {

            }).trigger(press2);

            var press3 = jQuery.Event("keyup");
            press3.ctrlKey = false;
            press3.which = 40;
            $("#search_by_cities").keypress(function () {

            }).trigger(press3);

            var press4 = jQuery.Event("keyup");
            press4.ctrlKey = false;
            press4.which = 40;
            $("#search_by_jobtitle").keypress(function () {

            }).trigger(press4);

            var press5 = jQuery.Event("keyup");
            press5.ctrlKey = false;
            press5.which = 40;
            $("#search_by_market").keypress(function () {

            }).trigger(press5);

            var press6 = jQuery.Event("keyup");
            press6.ctrlKey = false;
            press6.which = 40;
            $("#search_by_company").keypress(function () {
            }).trigger(press6);

        });

        $("#tags input").on({
            focusout: function () {
                var currentClass = $(this).attr("id");
                // var txt = this.value.replace(/[^a-z0-9\+\-\.\#]/ig,''); // allowed characters
                var str1 = $.trim($(this).val()); // allowed characters
                var txt = str1.replace(/\,/g, "");
                if (txt)
                {
                    $('#keywordList').append('<span class="' + currentClass + '">' + txt.toLowerCase() + '</span>');
                    $('#tags').append('<span class="' + currentClass + '">' + txt.toLowerCase() + '</span>');
                }

                this.value = "";
                if (currentClass == "search_by_expert")
                {
                    searchByCommonFilter(currentClass, 0);
                } else if (currentClass == "search_by_jobtitle")
                {
                    searchByCommonFilter(currentClass, 9);
                } else if (currentClass == "search_by_country")
                {
                    searchByCommonFilter(currentClass, 8);
                } else if (currentClass == "search_by_state")
                {
                    searchByCommonFilter(currentClass, 7);
                } else if (currentClass == "search_by_cities")
                {
                    searchByCommonFilter(currentClass, 6);
                } else if (currentClass == "search_by_market")
                {
                    searchByCommonFilter(currentClass, 10);
                } else if (currentClass == "search_by_company")
                {
                    searchByCommonFilter(currentClass, 11);
                }
            },
            keyup: function (ev) {
                // if: comma|enter (delimit more keyCodes with | pipe)
                if (/(188|13)/.test(ev.which))
                    $(this).focusout();
            }
        });

        $('#keywordList').on('click', 'span', function () {
            var currentClass = $(this).attr('class');
            var currentText = $(this).text();

            $("#tags").find("span." + currentClass).each(function ()
            {
                var spanValue = $(this).text();
                if (spanValue == currentText)
                {
                    $(this).remove();
                }
            });
            $(this).remove();
            $(document).trigger("chopremoved");
            if (currentClass == "search_by_expert")
            {
                searchByCommonFilter(currentClass, 0);
            } else if (currentClass == "search_by_jobtitle")
            {
                searchByCommonFilter(currentClass, 9);
            } else if (currentClass == "search_by_country")
            {
                searchByCommonFilter(currentClass, 8);
            } else if (currentClass == "search_by_state")
            {
                searchByCommonFilter(currentClass, 7);
            } else if (currentClass == "search_by_cities")
            {
                searchByCommonFilter(currentClass, 6);
            } else if (currentClass == "search_by_market")
            {
                searchByCommonFilter(currentClass, 10);
            } else if (currentClass == "search_by_company")
            {
                searchByCommonFilter(currentClass, 11);
            }
        });

        /* custom js */
    });


})(jQuery);