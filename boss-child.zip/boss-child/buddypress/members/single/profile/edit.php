<?php
/**
 * BuddyPress - Members Single Profile Edit
 *
 * @package BuddyPress
 * @subpackage bp-legacy
 */

/**
 * Fires after the display of member profile edit content.
 *
 * @since 1.1.0
 */
do_action( 'bp_before_profile_edit_content' );

if ( bp_has_profile( 'profile_group_id=' . bp_get_current_profile_group_id() ) ) :
	while ( bp_profile_groups() ) :
		bp_the_profile_group(); ?>
<style type="text/css">
.editfield{min-height: 122px;}
.editfield #field_903 label{padding-left: 24px;}
.editfield #field_903 label strong:before{left: -25px!important;top: 5px!important;}
#buddypress .editfield .optionPro {background-color: #ffffff;left: 50%;margin-left: -140px;position: absolute;top: 65px;width: 280px;z-index: 5;-webkit-border-radius: 6px;-moz-border-radius: 6px;border-radius: 6px;-webkit-box-shadow: 0 0 8px 0 rgba(0, 0, 0, 0.5);-moz-box-shadow: 0 0 8px 0 rgba(0, 0, 0, 0.5);box-shadow: 0 0 8px 0 rgba(0, 0, 0, 0.5);}
.optionPro:before{content:".";width: 0; height: 0; border-left: 7px solid transparent;border-right: 7px solid transparent;border-bottom: 7px solid #48a5d1;left: 10%;position: absolute;top: -7px;width: 0;font-size:0;}
.optionPro legend{background-color:#48a5d1; color:#ffffff; padding:8px 15px;-webkit-border-radius: 6px 6px 0 0;-moz-border-radius: 6px 6px 0 0;border-radius: 6px 6px 0 0;}
.optionPro .field-visibility-settings-close {color: #fff;position: absolute;right: 15px;top: 8px;}
.optionPro ul{margin:0; padding:0 15px 20px;}
.optionPro ul li{padding:4px 4px 8px;}
.optionPro ul li:nth-child(2n){background-color:#f6f6f6;}
.optionPro ul li strong:before{top:5px!important;}
.optionPro ul li .field-visibility-text{display: inline-block;text-indent: 10px;}
</style>
<form action="<?php bp_the_profile_group_edit_form_action(); ?>" method="post" id="profile-edit-form" class="standard-form <?php bp_the_profile_group_slug(); ?>">

	<?php

		/** This action is documented in bp-templates/bp-legacy/buddypress/members/single/profile/profile-wp.php */
		do_action( 'bp_before_profile_field_content' );
		?>

		<h4><?php printf( __( "Editing '%s' Profile Group", 'buddypress' ), bp_get_the_profile_group_name() ); ?></h4>

		<?php if ( bp_profile_has_multiple_groups() ) : ?>
			<ul class="button-nav">

				<?php bp_profile_group_tabs(); ?>

			</ul>
		<?php endif; ?>

		<div class="clear"></div>
		
		<div id="profileEdit-wb" class="row">
		<?php
		$cflag = 0;
		while ( bp_profile_fields() ) :
			bp_the_profile_field();
			$cflag++;
?>

			<div 
			<?php
			if ( $cflag == 8 || $cflag == 9 ) {
				bp_field_css_class( 'editfield col-sm-12' );
			} else {
				bp_field_css_class( 'editfield col-md-6 col-lg-4' );}
?>
 data-col="<?php echo $cflag; ?>">

						<?php
						$field_type = bp_xprofile_create_field_type( bp_get_the_profile_field_type() );
						$field_type->edit_field_html();

						/**
				 * Fires before the display of visibility options for the field.
				 *
				 * @since 1.7.0
				 */
						do_action( 'bp_custom_profile_edit_fields_pre_visibility' );
						?>

						<?php if ( bp_current_user_can( 'bp_xprofile_change_field_visibility' ) ) : ?>
					<p class="field-visibility-settings-toggle" id="field-visibility-settings-toggle-<?php bp_the_profile_field_id(); ?>">
						<?php
						printf(
							__( 'This field can be seen by: %s', 'buddypress' ),
							'<span class="current-visibility-level">' . bp_get_the_profile_field_visibility_level_label() . '</span>'
						);
						?>
						<a href="#" class="visibility-toggle-link"><?php _e( 'Change', 'buddypress' ); ?></a>
					</p>

					<div class="optionPro field-visibility-settings" id="field-visibility-settings-<?php bp_the_profile_field_id(); ?>">
						<fieldset>
							<legend><?php _e( 'Who can see this field?', 'buddypress' ); ?></legend>

							<?php bp_profile_visibility_radio_buttons(); ?>

						</fieldset>
						<a class="field-visibility-settings-close" href="#"><?php _e( 'Close', 'buddypress' ); ?></a>
					</div>
				<?php else : ?>
					<div class="field-visibility-settings-notoggle" id="field-visibility-settings-toggle-<?php bp_the_profile_field_id(); ?>">
						<p class="field-visibility-info">
						<?php
						printf(
							__( 'This field can be seen by: %s', 'buddypress' ),
							'<span class="current-visibility-level">' . bp_get_the_profile_field_visibility_level_label() . '</span>'
						);
						?>
						</p>
					</div>
				<?php endif ?>

						<?php

						/**
				 * Fires after the visibility options for a field.
				 *
				 * @since 1.1.0
				 */
						do_action( 'bp_custom_profile_edit_fields' );
						?>

						<p class="description"><?php bp_the_profile_field_description(); ?></p>
					</div>

				<?php endwhile; ?>
		</div>
	<?php

	/** This action is documented in bp-templates/bp-legacy/buddypress/members/single/profile/profile-wp.php */
	do_action( 'bp_after_profile_field_content' );
	?>

	<div class="submit">
		<input type="submit" name="profile-group-edit-submit" id="profile-group-edit-submit" value="<?php esc_attr_e( 'Save Changes', 'buddypress' ); ?> " />
	</div>

	<input type="hidden" name="field_ids" id="field_ids" value="<?php bp_the_profile_field_ids(); ?>" />

	<?php wp_nonce_field( 'bp_xprofile_edit' ); ?>

</form>

<?php
endwhile;
endif;
?>

<?php

/**
 * Fires after the display of member profile edit content.
 *
 * @since 1.1.0
 */
do_action( 'bp_after_profile_edit_content' ); ?>
