<?php
include '../../../../wp-config.php';
global $wpdb;
$table = $wpdb->prefix."CallingInformation";
$callsid = $_REQUEST['callsid'];
$statusquery = $wpdb->get_results( $wpdb->prepare("SELECT * FROM $table WHERE callsid= %s", $callsid) );
$main = array();
if(!empty($statusquery))
{
	foreach($statusquery as $row)
	{
		$status = $row->call_status;
		$main['status'] = $status;
	}
}
else 
{
    $main['status'] = '0';
}
echo json_encode($main);
?>
