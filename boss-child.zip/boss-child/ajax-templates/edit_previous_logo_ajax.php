<?php
include '../../../../wp-config.php';
global $current_user, $wpdb,$post;
$user_id = $current_user->ID;
$currentdirectory = get_stylesheet_directory_uri();
$posttable = $wpdb->prefix.'posts';
$blockchain_setting =  get_option('update_user_profile_bc');

if(isset($_POST['deletpostid']))
{
    $deletpostid = $_POST['deletpostid'];
    $directory = $_SERVER['DOCUMENT_ROOT'] . '/wp-content/themes/boss-child/';    
    $path = get_post_meta($deletpostid,'prev_logo_path', $single=true);   
    $full_path = $directory.$path;    
    $unlinkfile =  unlink($full_path);
    if($unlinkfile):
        wp_delete_post($deletpostid);  
        echo json_encode(array('status' => 1, 'message' => 'Successfully Deleted.'));
        if($blockchain_setting == "enable")
        {
            blockchain_updates();
        }
        exit();
        else:
        echo json_encode(array('status' => 1, 'message' => 'Error In Delete post.'));
        exit();
        endif; 
}

if(isset($_POST["edit_imggid"] ))
{
    $imggid= $_POST['edit_imggid'];    
    $file_name = 'edit_logo'.$imggid;   
    $validextensions = array("jpeg", "jpg", "png", "JPG","JPEG","PNG");
    $temps = $_FILES[$file_name]["name"];
    $temporary = explode(".", $_FILES[$file_name]["name"]);    
    $file_title = $temporary[0];
    $file_names = sanitize_title($file_title);
    $getext =  $temporary[1];
    $newfile = $temporary[0].'.'.$getext;     
    $file_type = $_FILES[$file_name]["type"];
    $file_extension = end($temporary);
     $company_logo_namee =  'edit_company_name'.$imggid;
    $company_logo_name = $_POST[$company_logo_namee];
    if ((($_FILES[$file_name]["type"] == "image/png") || ($_FILES[$file_name]["type"] == "image/jpg") || ($_FILES[$file_name]["type"] == "image/jpeg") || ($_FILES[$file_name]["type"] == "image/JPG") || ($_FILES[$file_name]["type"] == "image/JPEG") || ($_FILES[$file_name]["type"] == "image/PNG") )&& ($_FILES[$file_name]["size"] < 1097152)//Approx. 1mb files can be uploaded.
    && in_array($file_extension, $validextensions)) 
    {
        if ($_FILES[$file_name]["error"] > 0)
        {
            $errorMessage = $_FILES[$file_name]["error"];
            echo json_encode(array("status" => 0 , 'message' => $errorMessage));
                exit(); 
        }
        else
        {
            /*chagne file name */                
                $fileData = pathinfo(basename($_FILES[$file_name]["name"]));
                $fileName =  $file_title. '.' . $getext;
            /*chagne file name */
            $directory = $_SERVER['DOCUMENT_ROOT'] . '/wp-content/themes/boss-child/iis/company_logo/users/'.$user_id.'/previous_company/';            
            if (wp_mkdir_p($directory)) 
            {
                //echo 'It worked <br/>';
            }
             if (file_exists($directory.$fileName))
            {
                echo json_encode(array("status" => 0 , 'message' => "File already exists."));
                exit(); 
            }       
            else
            {
                    $logo_idd = 'prev_logo_id'.$imggid;
                    $logo_id = $_POST[$logo_idd];
                    $logopath = get_post_meta($logo_id,'prev_logo_path', $single=true);
                    $logo_directory = $_SERVER['DOCUMENT_ROOT'] . '/wp-content/themes/boss-child/'.$logopath; 
                    $unlinkfile =  unlink($logo_directory);
                    if($unlinkfile):        
                            $sourcePath = $_FILES[$file_name]['tmp_name']; // Storing source path of the file in a variable                             
                            $targetPath =  $directory.$fileName;// Target path where file is to be stored               
                            $uploadedfile =  move_uploaded_file($sourcePath,$targetPath); // Moving Uploaded file
                            $imgurl = $currentdirectory.'/iis/company_logo/users/'.$user_id.'/previous_company/'.$fileName;
                            //echo $imgurl;
                            if($uploadedfile):                                
                                $post_mime_type = $_FILES[$file_name]["type"];
                                $today = date("Y-m-d H:i:s");                          
                                $update = $wpdb->query("UPDATE `$posttable` SET `post_title` ='$file_title', `post_name`='$file_names',`post_mime_type`='$post_mime_type', `guid`='$imgurl',`post_modified`='$today',`post_modified_gmt`='$today' WHERE `ID` = $logo_id AND `post_author` = $user_id AND `post_type`='prev_company_logo'");
                                $path = 'iis/company_logo/users/'.$user_id.'/previous_company/'.$fileName;
                                update_post_meta($logo_id, 'prev_logo_path', $path);
                                update_post_meta($logo_id, 'company_logo_name', $company_logo_name);
                                echo json_encode(array("status" => 1 , 'message' => "Image Uploaded Successfully...!!",'logo_id' => $logo_id, 'imageURL' => $imgurl, 'logoTitle' => $company_logo_name, 'imagIcon' => get_stylesheet_directory_uri().'/media_images/icon-upload.png'));
                                if($blockchain_setting == "enable")
                                {
                                    blockchain_updates();
                                }
                                exit();                                        
                            endif; 
                    endif; 
            }             
          
        }
    }
    else
    {
       echo json_encode(array("status" => 0 , 'message' => "Invalid file Size or Type."));
        exit(); 
    }   
}
?>