<?php
    include '../../../../wp-config.php';
    global $wpdb, $current_user;
    $userid = $current_user->ID;
    echo $userid;
    
    if(isset($_POST['ContentProduction']) || isset($_POST['ContentCreation']) || isset($_POST['ChannelServed']))
    {
        $ContentProduction = $_POST['ContentProduction'];
        $ContentCreation =  $_POST['ContentCreation'];
        $ChannelServed =  $_POST['ChannelServed'];   
        
        //echo $CourtSurvey.$Prosecution.$LawEnforcement.$LawOperation;
       
        $ContentProductionkey = 'ContentProduction';
        $ContentCreationkey = 'ContentCreation';
        $ChannelServedkey = 'ChannelServed';
        $submitsurveykey = 'submitsurveykey';
        $keyvalue = 'submitsurvey';
        
        $metas = array
        ( 
            $ContentProductionkey   => $ContentProduction,
            $ContentCreationkey    => $ContentCreation, 
            $ChannelServedkey         => $ChannelServed,            
            $submitsurveykey     => $keyvalue
        );
        foreach($metas as $key => $value) 
        {
            update_user_meta( $userid, $key, $value );
        }
    }
?>