<?php
/**
 * Iis ajax method class file
 *
 * PHP Version 5.2
 *
 * @category Issajaxmethod
 * @package  Issajaxmethod
 * @author   Lorna Jane Mitchell <lorna@ibuildings.com>
 * @license  http://opensource.org/licenses/gpl-license.php GNU Public License
 * @link     http://example.com/Issajaxmethod
 */

/**
 * Issajaxmethod class
 *
 * The class holding the root Issajaxmethod class definition
 *
 * @category Issajaxmethod
 * @package  Issajaxmethod
 * @author   Lorna Jane Mitchell <lorna@ibuildings.com>
 * @license  http://iisv2.crmmasterdev.wpengine.com/ GNU Public License
 * @link     http://example.com/Issajaxmethod/Issajaxmethod
 */
class Iis_Ajax_Method {
	/**
	 * Get the __construct
	 *
	 * @return array An array of __construct objects
	 */
	public function __construct() {
		add_action( 'wp_ajax_iis_nominee_user_status', array( $this, 'iis_nominee_user_status' ) );
		add_action( 'wp_ajax_iis_credit_to_currency', array( $this, 'iis_credit_to_currency' ) );
		add_action( 'wp_ajax_user_nomination_activation', array( $this, 'user_nomination_activation' ) );
		add_action( 'wp_ajax_vl_saved_credit_cards_ajax1', array( $this, 'vl_saved_credit_cards_ajax1' ) );
	}
	/**
	 * Insert/update nominee users status
	 * Admin will change nominee users status and can give comment to user
	 *
	 * @return void An string of nominee user status
	 */
	public function iis_nominee_user_status() {
		global $wpdb,$current_user;
		$table           = $wpdb->prefix . 'nominee_details';
		$list_table      = $wpdb->prefix . 'nominee_list';
		$list_vote_table = $wpdb->prefix . 'nominee_list_vote';
		$user_id         = $current_user->ID;
		if ( isset( $_POST['user_role'], $_POST['wp_nominee_nonce'] )
			&& wp_verify_nonce( $_POST['wp_nominee_nonce'], 'iis-nominee-security' )
		) {
			$role = sanitize_text_field( wp_unslash( $_POST['user_role'] ) );
		}
		if ( isset( $_POST['email'] ) ) {
			$email = sanitize_text_field( wp_unslash( $_POST['email'] ) );
		}
		if ( isset( $_POST['row_id'] ) ) {
			$row_id = sanitize_text_field( wp_unslash( $_POST['row_id'] ) );
		}
		if ( isset( $_POST['review_admin'] ) ) {
			$admin_note = sanitize_text_field( wp_unslash( $_POST['review_admin'] ) );
		}
		if ( email_exists( $email ) ) {
			echo "Already IIS user. So you can't change user status.";
			exit();
		}
		if ( isset( $_POST['user_status'] ) ) {
			$user_status = sanitize_text_field( wp_unslash( $_POST['user_status'] ) );
		}
		if ( isset( $_POST['action'] ) ) {
			$action = sanitize_text_field( wp_unslash( $_POST['action'] ) );
		}
		if ( isset( $_POST['record_id'] ) ) {
			$recordid = sanitize_text_field( wp_unslash( $_POST['record_id'] ) );
		}
		if ( isset( $_POST['review'] ) ) {
			$review = sanitize_text_field( wp_unslash( $_POST['review'] ) );
		}
		if ( 'iis_nominee_user_status' == $action ) {

			if ( 'accept' == $user_status ) {
					$user_detail = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}nominee_details WHERE emailid = %s AND id = %d", $email, $row_id ) );

				$first_name         = $user_detail[0]->firstname;
				$middlename         = $user_detail[0]->middlename;
				$lastname           = $user_detail[0]->lastname;
				$company            = $user_detail[0]->company;
				$job_title          = $user_detail[0]->jobtitle;
				$bio                = $user_detail[0]->description;
				$file_name          = $user_detail[0]->profile_url;
				$work_experience    = $user_detail[0]->work_experience;
				$nominator_id       = $user_detail[0]->member_id;

				if ( '' != $middlename ) {
					$middlename = $middlename;
				} else {
					$middlename = '';
				}
				$update             = $wpdb->query( $wpdb->prepare( "UPDATE {$wpdb->prefix}nominee_details SET user_status = %s, admin_review_note = %s WHERE emailid = %s AND id = %d ", $user_status, $admin_note, $email, $row_id ) );
				$data               = array(
					'firstname'        => $first_name,
					'middlename'       => $middlename,
					'lastname'         => $lastname,
					'emailid'          => $email,
					'company'          => $company,
					'jobtitle'         => $job_title,
					'description'      => $bio,
					'work_experience'  => $work_experience,
					'profile_url'      => $file_name,
					'user_status'      => $user_status,
					'nominee_decision' => '',
					'nominator_id'     => $nominator_id,
				);
				$format             = array(
					'%s',
					'%s',
					'%s',
					'%s',
					'%s',
					'%s',
					'%s',
					'%s',
					'%s',
					'%s',
					'%s',
					'%s',
				);
				$get_nominator_data = $wpdb->get_var( $wpdb->prepare( "SELECT * FROM {$wpdb->vl_nominee_list} WHERE emailid = %s", $email ) );
				if ( $get_nominator_data >= 1 ) {
					$update_nominator_data = $wpdb->query( $wpdb->prepare( "UPDATE {$wpdb->vl_nominee_list} SET user_status = %s WHERE emailid = %s", $user_status, $email ) );
				} else {
					$insert_sql = $wpdb->insert( $list_table, $data, $format );
				}
				if ( $update >= 1 ) {
					echo 'Comment Saved Successfully.';
					exit();
				} else {
					echo 'Record Not Updatedd.';
					exit();
				}
			} else {
				if ( 'declined' == $user_status ) {
					$update = $wpdb->query( $wpdb->prepare( "UPDATE {$wpdb->prefix}nominee_details SET user_status = %s, admin_review_note = %s WHERE emailid = %s AND id = %d ", $user_status, $admin_note, $email, $row_id ) );
					$delete = $wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->prefix}nominee_list WHERE emailid = %s", $email ) );

					if ( $update >= 1 ) {
						echo 'Status Changed Successfully.';
						exit();
					} else {
						echo 'Changes Not Saved.';
						exit();
					}
				} else {
					$update = $wpdb->query( $wpdb->prepare( "UPDATE {$wpdb->prefix}nominee_details SET user_status = %s , admin_review_note = %s WHERE emailid = %s AND id = %d ", $user_status, $admin_note, $email, $row_id ) );
					$delete = $wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->prefix}nominee_list WHERE emailid = %s ", $email ) );

					if ( $update >= 1 ) {
						echo 'Comment Saved Successfully.';
						exit();
					} else {
						echo 'Record Not Updated.';
						exit();
					}
				}
			}
		} elseif ( 'second_user' == $action ) {
			$update = $wpdb->query( $wpdb->prepare( "UPDATE {$wpdb->prefix}nominee_list_vote SET review_status = %s WHERE id = %d ", $review, $recordid ) );
			if ( 1 == $update ) {
				echo 'Changes Saved Successfully.';
				exit();
			} else {
				echo 'Changes Not Updated.';
				exit();
			}
		}
	}
	/**
	 * Convert credits to currency
	 *
	 * @return void An void of iis_credit_to_currency objects
	 */
	public function iis_credit_to_currency() {
		global $wpdb,$current_user;
		$user_id = $current_user->ID;
		if ( 0 == $user_id ) {
			$redirect_url = site_url() . '/registration-page/login/';
			echo wp_json_encode(
				array(
					'login_error'  => 1,
					'redirect_url' => $redirect_url,
				)
			);
			exit;
		}
		if ( isset( $_POST['conversion_type'], $_POST['convert_credits'], $_POST['cpt_nonce_field'] )
		&& wp_verify_nonce( $_POST['cpt_nonce_field'], 'iis_currency_action' )
		) {
			$conversion_type            = trim( sanitize_text_field( wp_unslash( $_POST['conversion_type'] ) ) );
			$convert_credits            = number_format( trim( sanitize_text_field( wp_unslash( $_POST['convert_credits'] ) ) ), 2 );
			$blog_id                    = get_current_blog_id();
			$my_credit_meta_key         = 'wp68_' . $blog_id . '_user_points';
			$conversion_rate_list       = unserialize( get_option( 'convertCreditsIntoCurrency' ) );
			$user_account_credits_point = get_user_meta( $user_id, $my_credit_meta_key, true );
			$table_log                  = $wpdb->prefix . 'credit_currency_conversion_log';
			$conversion_rate            = '';
			$conversion_rate            = ( ( 'cc' == $conversion_type ) ? $conversion_rate_list['cc_conversion_rate'] :
									( ( 'paypal' == $conversion_type ) ? $conversion_rate_list['paypal_conversion_rate'] :
									( ( 'token' == $conversion_type ) ? $conversion_rate_list['token_conversion_rate'] : '' ) )
									);

			if ( '0' >= $conversion_rate ) {
				echo wp_json_encode(
					array(
						'success'      => 0,
						'messgae'      => 'Conversion rate is not found!',
						'redirect_url' => $redirect_url,
					)
				);
				exit;
			}
			// check convert credits less or more.
			if ( $user_account_credits_point < $convert_credits ) {
				$redirect_url = site_url( 'my-account/credits_to_currency' );
				echo wp_json_encode(
					array(
						'success'      => 0,
						'messgae'      => 'CR ' . $convert_credits . ' is not avaialble in your account.',
						'redirect_url' => $redirect_url,
					)
				);
				exit;
			} elseif ( '0' >= $convert_credits ) {
				$redirect_url = site_url( 'my-account/credits_to_currency' );
				echo wp_json_encode(
					array(
						'success'      => 0,
						'messgae'      => 'You can not CR ' . $convert_credits . ' into currency.',
						'redirect_url' => $redirect_url,
					)
				);
				exit;
			} else {
				$redirect_url     = site_url( 'my-account/credits_to_currency' );
				$converted_amount = $convert_credits * $conversion_rate;
				// insert into database.
				$transaction_id = 'ch_' . uniqid();
				$insert_result  = $wpdb->insert(
					$table_log, array(
						'user_id'          => $user_id,
						'conversion_type'  => $conversion_type,
						'conversion_rate'  => $conversion_rate,
						'credits'          => $convert_credits,
						'converted_amount' => $converted_amount,
						'currency_name'    => 'usd',
						'entry_time'       => date( 'Y-m-d h:i:s' ),
						'transaction_id'   => $transaction_id,
					)
				);
				if ( $insert_result ) {
						$last_remaining_credits = ( $user_account_credits_point - $convert_credits );
						update_user_meta( $user_id, $my_credit_meta_key, $last_remaining_credits );
						echo wp_json_encode(
							array(
								'success'      => 1,
								'messgae'      => 'Credits successfully converted into currency.',
								'redirect_url' => $redirect_url,
							)
						);
						exit;
				} else {
					echo wp_json_encode(
						array(
							'success'      => 0,
							'messgae'      => 'Credits into currency conversion failed!',
							'redirect_url' => $redirect_url,
						)
					);
						exit;
				}
			}
		} else {
			$redirect_url = site_url( 'my-account/credits_to_currency' );
			echo wp_json_encode(
				array(
					'success'      => 0,
					'messgae'      => 'Invalid request!.',
					'redirect_url' => $redirect_url,
				)
			);
			exit;
		}
	}
	/**
	 * User Activation in Nomination Browser
	 */
	public function user_nomination_activation() {
		global $wpdb,$current_user;

		if ( isset( $_POST['id'], $_POST['emailid'], $_POST['code'], $_POST['send'], $_POST['nomination_activation_nonce_field'] ) && wp_verify_nonce( $_POST['nomination_activation_nonce_field'], 'user_nomination_activation' ) ) {

			$table       = $wpdb->prefix . 'nominee_list';
			$vote_table  = $wpdb->prefix . 'nominee_list_vote';
			$id          = sanitize_text_field( wp_unslash( $_POST['id'] ) );
			$email       = sanitize_email( wp_unslash( $_POST['emailid'] ) );
			$action      = sanitize_text_field( wp_unslash( $_POST['action'] ) );
			$coupon_code = sanitize_text_field( wp_unslash( $_POST['code'] ) );
			$send        = sanitize_text_field( wp_unslash( $_POST['send'] ) );
			if ( email_exists( $email ) ) {
				// this user is iis user.
				echo "Already IIS user. So you can't change user status.";
				exit();
			}
			$user_detail   = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$wpdb->vl_nominee_list} WHERE id= %d", $id ) );
			$link_page_yes = get_site_url() . '/nominee-confirmation-page/?id=' . $id . '&email=' . $email . '&des=yes';
			$link_page_no  = get_site_url() . '/nominee-confirmation-page/?id=' . $id . '&email=' . $email . '&des=no';

			foreach ( $user_detail as $user_details ) {
				$firstname  = $user_details->firstname;
				$middlename = $user_details->middlename;
				$lastname   = $user_details->lastname;
				$userrole   = $user_details->role_selected;
			}

			if ( ! empty( $middlename ) ) {
				$full_name = $firstname . ' ' . $middlename . ' ' . $lastname;
			} else {
				$full_name = $firstname . ' ' . $lastname;
			}
			/**
			 * User Activation in Notification
			 */
			function user_activation_notification() {
				return 'User Activation Notification';
			}
			add_filter( 'wp_mail_from_name', 'user_activation_notification' );

			if ( ! empty( $action ) ) {
				if ( ! empty( $send ) ) {
					$updatevote = $wpdb->query( $wpdb->prepare( "UPDATE {$wpdb->vl_nominee_list_vote} SET admin_override= 'yes', nominee_decision = 'Pending', send_coupon= %s, coupon_code= %s WHERE list_id = %d AND email_id= %s", $send, $coupon_code, $id, $email ) );
				} else {
					$updatevote = $wpdb->query( $wpdb->prepare( "UPDATE {$wpdb->vl_nominee_list_vote} SET admin_override= 'yes', nominee_decision = 'Pending' WHERE list_id = %d AND email_id= %s", $id, $email ) );
				}
				$updatelist = $wpdb->query( $wpdb->prepare( "UPDATE {$wpdb->vl_nominee_list} SET admin_override= 'yes', nominee_decision = 'Pending' WHERE id = %d AND emailid= %s", $id, $email ) );
				include 'email-template/user_activation_email.php';
				die();
			} else {
				if ( ! empty( $send ) ) {
					$updatevote = $wpdb->query( $wpdb->prepare( "UPDATE {$wpdb->vl_nominee_list_vote} SET send_coupon= %s, coupon_code= %s WHERE list_id = %d AND email_id= %s", $send, $coupon_code, $id, $email ) );
				}
				include 'email-template/user_activation_email.php';
				die();
			}
		}
		
	}

	/**
	 * Add credit card details 
	 */
	public function vl_saved_credit_cards_ajax1()
	{
		global $wpdb;
        $short_name = vl_sanitize_unslash( 'short_name_card' );
        $user_id = get_current_user_id();
        if ( 0 == $user_id ) {
            $redirect = site_url( '/registration-page/login/' );
            echo json_encode(
                array(
                    'login_error' => 1,
                    'redirect' => $redirect,
                )
            );
            exit;
        }
        $blockchain_setting = get_option( 'update_woo_cards_info_bc' );
        $woocommerce_pay_tokens = $wpdb->prefix . 'woocommerce_payment_tokens';
        $woocommerce_pay_tokenmeta = $wpdb->prefix . 'woocommerce_payment_tokenmeta';
        $currency = 'usd';

        $stripe_test_secret_key = 'sk_test_3FzCERrVWNI0du0Pbb9hlqYp';
        require_once VL_THEME_DIR . '/Stripe/init.php';
        \Stripe\Stripe::setApiKey( $stripe_test_secret_key );

        $current_user = wp_get_current_user();
        $userid = $current_user->ID;
        $email_id = $current_user->user_email;
        // get stripe customer id from usermeta.
        $woo_stripe_customer_id = get_user_meta( $userid, '_stripe_customer_id', true );
        // check userID.
        if ( $userid < 1 ) {
            echo json_encode(
                array(
                    'stripe_error' => 1,
                    'messgae' => 'This is not IIS user.',
                )
            );
            exit;
        }

        // send detele card request.
        if ( isset( $_POST['deleteCard'], $_POST['token_id'], $_POST['wpnonce'], $_POST['wp_delete_nonce'] ) && wp_verify_nonce( $_POST['wp_delete_nonce'], 'delete_vl_credit_card' ) ) {
            $useid = $userid;
            $token_id = vl_sanitize_unslash( 'token_id' );
            $wpnonce = str_replace( 'wpnonce=', '', vl_sanitize_unslash( 'wpnonce' ) );
            $token    = WC_Payment_Tokens::get( $token_id );

            if ( is_null( $token ) || get_current_user_id() !== $token->get_user_id() || false === wp_verify_nonce( $wpnonce, 'delete-payment-method-' . $token_id ) ) {

                $redirect = site_url( 'my-account/payment_methods' );
                        echo json_encode(
                            array(
                                'stripe_error' => 1,
                                'message' => 'Invalid payment method.',
                                'redirect' => $redirect,
                            )
                        );
                    exit;
            } else {
                WC_Payment_Tokens::delete( $token_id );
                $redirect = site_url( 'my-account/payment_methods' );
                echo json_encode(
                    array(
                        'success' => 1,
                        'message' => 'Card deleted successfully',
                        'redirect' => $redirect,
                    )
                );
                if ( 'enable' == $blockchain_setting ) {
                    blockchain_updates();
                }
                        exit();
            }

        }
        // if send update card details request.
        if ( isset( $_POST['update_card'], $_POST['card_token_id'], $_POST['card_expiry_month'], $_POST['card_expiry_year'], $_POST['card_name'], $_POST['update_wp_nonce'] ) && wp_verify_nonce( $_POST['update_wp_nonce'], 'update_vl_credit_card' ) ) {
            $useid = $userid;
            $card_token_id = vl_sanitize_unslash( 'card_token_id' );
			$exp_month = vl_sanitize_unslash( 'card_expiry_month' );
			$exp_year = vl_sanitize_unslash( 'card_expiry_year' );
            $card_short_name = vl_sanitize_unslash( 'card_short_name' );
            $card_name = vl_sanitize_unslash( 'card_name' );
            $stripe_card_row_id = 'stripe_card_holder_name' . $card_token_id;
            $stripe_short_row_id = 'stripe_card_short_name' . $card_token_id;
            update_user_meta( $useid, $stripe_card_row_id, $card_name );
            update_user_meta( $useid, $stripe_short_row_id, $card_short_name );
            $sql_string = $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}woocommerce_payment_tokens WHERE `token_id` = %s ", $card_token_id );
            $result = $wpdb->get_row( $sql_string );
            $card_id = $result->token;
            // retrieve customer data and update his card details.
            try {

                $customer = \Stripe\Customer::retrieve( $woo_stripe_customer_id );
                $card = $customer->sources->retrieve( $card_id );
                $card->exp_month = $exp_month;
                $card->exp_year = $exp_year;
                $card->save();
                $wpdb->update(
                $woocommerce_pay_tokenmeta,
                array(
				'meta_value' => $exp_month,
			),
                array( 'payment_token_id' => $card_token_id, 'meta_key' => 'expiry_month' ));

                $wpdb->update(
                $woocommerce_pay_tokenmeta,
                array(
                'meta_value' => $exp_year,
                ),
                array( 'payment_token_id' => $card_token_id, 'meta_key' => 'expiry_year' ));
                // call blockchain api.

                echo json_encode(
                    array(
                        'success' => 1,
                        'message' => 'Card Updated successfully',
                    )
                );
                if ( 'enable' == $blockchain_setting ) {
                    blockchain_updates();
                }
                exit();
            }
            catch( Exception $e ) {
                echo json_encode(
                    array(
                        'success' => 0,
                        'message' => $e->getMessage(),
                    )
                );
                exit();
            }

        }
       
    if ( isset( $_POST['stripe_customer_id'], $_POST['name_on_card'], $_POST['user_card_number'], $_POST['user_card_expire_month'], $_POST['user_card_expire_year'], $_POST['user_card_cvv_number'], $_POST['card_type'], $_POST['short_name_card'], $_POST['wp_nonce'] ) && wp_verify_nonce( $_POST['wp_nonce'], 'add_vl_credit_card' ) ) {
        $stripe_customer_id = vl_sanitize_unslash( 'stripe_customer_id' );
        $name_on_card       = vl_sanitize_unslash( 'name_on_card' );
        $user_card_number   = vl_sanitize_unslash( 'user_card_number' );
		$exp_month = vl_sanitize_unslash( 'user_card_expire_month' );
		$exp_year = vl_sanitize_unslash( 'user_card_expire_year' );
        $cvc                = vl_sanitize_unslash( 'user_card_cvv_number' );
        $card_type          = vl_sanitize_unslash( 'card_type' );
        $default_card       = 1;
        $short_name         = vl_sanitize_unslash( 'short_name_card' );

        // generate token
        try
            {
                $result = \Stripe\Token::create(
                        array(
                            'card' => array(
                            'name' => $name_on_card,
                            'number' => $user_card_number,
                            'exp_month' => $exp_month,
                            'exp_year' => $exp_year,
                            'cvc' => $cvc
                            )
                        )
                        );
                $token = $result->id;
                if ( '' == $woo_stripe_customer_id ) {

                    $customer_detail = \Stripe\Customer::create(array(
                    "source" => $token,
                    "email" => $email_id,
                            )
                    );
                    $customer_id = $customer_detail->id;
                    $cardid = $customer_detail->sources->data[0]->id;
                    $tt = \Stripe\Customer::retrieve( $customer_id );
                    $customer_last4 = $tt->sources->data[0]->last4;
                    $card_brand = strtolower($tt->sources->data[0]->brand);
                    $funding  = $tt->sources->data[0]->funding;
                    // get funding type debit/credit/prepaid/unknown , OC means other card.
                    $funding_type =  (
                                    ($funding == 'debit') ? 'DC' :
                                    (($funding == 'credit') ? 'CC' :
                                    (($funding == 'prepaid') ? 'PC' :
                                    (($funding == 'unknown') ? 'UC' : 'OC')))
                                    );
                    $exp_month = $tt->sources->data[0]->exp_month;
                    $exp_year = $tt->sources->data[0]->exp_year;
                    $is_default = 1 ; // this is default
                                    // customer id in user meta
                    delete_user_meta( $userid, '_stripe_customer_id' );
                    add_user_meta( $userid, '_stripe_customer_id', $customer_id );

                    $query_response = $this->Save_woocommerce_card_stripe( $userid, $cardid, $funding_type, $is_default, $card_brand, $customer_last4, $exp_month, $exp_year, $name_on_card, $short_name );
                    echo json_encode( $query_response );
                    exit();

                }
                $info_status =  \Stripe\Customer::retrieve( $woo_stripe_customer_id );

                // check customer is deteled or not
                if(isset($info_status['deleted']))
                {

                    $customer_detail = \Stripe\Customer::create(array(
                    "source" => $token,
                    "email" => $email_id,
                            )
                    );
                    $customer_id = $customer_detail->id;
                    $cardid = $customer_detail->sources->data[0]->id;
                    $tt = \Stripe\Customer::retrieve($customer_id);
                    $customer_last4 = $tt->sources->data[0]->last4;
                    $card_brand = strtolower($tt->sources->data[0]->brand);
                    $funding  = $tt->sources->data[0]->funding;
                    // get funding type debit/credit/prepaid/unknown , OC means other card
                    $funding_type =  (
                                    ($funding == "debit") ? "DC" :
                                    (($funding == "credit") ? "CC" :
                                    (($funding == "prepaid") ? "PC" :
                                    (($funding == "unknown") ? "UC" : "OC")))
                                    );
                    $exp_month = $tt->sources->data[0]->exp_month;
                    $exp_year = $tt->sources->data[0]->exp_year;
                    $is_default = 1 ; // this is default
                                    // customer id in user meta
                    delete_user_meta($userid, "_stripe_customer_id");
                    add_user_meta($userid, "_stripe_customer_id", $customer_id);
                    $query_response = $this->Save_woocommerce_card_stripe($userid, $cardid, $funding_type, $is_default, $card_brand, $customer_last4, $exp_month, $exp_year, $name_on_card, $short_name);
                    echo json_encode($query_response);
                    exit();
                }else
                {

                    // means user is already exists then add new card
                        $customer_id = $info_status->id;
                        $customer = \Stripe\Customer::retrieve($customer_id);
                        $card_detail = $customer->sources->create(array("source" => $token));
                        $cardid = $card_detail->id;
                        $customer_last4 = $card_detail->last4;
                        $card_brand = strtolower($card_detail->brand);
                        $funding  = $card_detail->funding;
                        // get funding type debit/credit/prepaid/unknown , OC means other card
                        $funding_type = (
                                                ($funding == "debit") ? "DC" :
                                                (($funding == "credit") ? "CC" :
                                                (($funding == "prepaid") ? "PC" :
                                                (($funding == "unknown") ? "UC" : "OC")))
                                            );
                        $exp_month = $card_detail->exp_month;
                        $exp_year = $card_detail->exp_year;
                        if(!isset($customer->default_source))
                        {
                            $is_default = 1; // this is default
                        }else
                        {
                        $is_default = 0 ; // this is not default
                        }
                        $query_response = $this->Save_woocommerce_card_stripe($userid, $cardid, $funding_type, $is_default, $card_brand, $customer_last4, $exp_month, $exp_year, $name_on_card, $short_name);
                        echo json_encode($query_response);
                        exit();
                }
                echo json_encode(array('stripe_error' => 1,'messgae' => "Something wrong!"));
                exit;

                // echo json_encode(array('stripe_error' => 1,'messgae' => $token));
        //       exit;
            }
        catch(Exception $e)
            {


                            //customer create new customer
                if ( preg_match( '/No such customer:/', $e->getMessage() ) ) {

                    $customer_detail = \Stripe\Customer::create(array(
                    "source" => $token,
                    "email" => $email_id,
                            )
                    );
                    $customer_id = $customer_detail->id;
                    $cardid = $customer_detail->sources->data[0]->id;
                    $tt = \Stripe\Customer::retrieve($customer_id);
                    $customer_last4 = $tt->sources->data[0]->last4;
                    $card_brand = strtolower($tt->sources->data[0]->brand);
                    $funding  = $tt->sources->data[0]->funding;
                    // get funding type debit/credit/prepaid/unknown , OC means other card
                    $funding_type =  (
                                    ($funding == "debit") ? "DC" :
                                    (($funding == "credit") ? "CC" :
                                    (($funding == "prepaid") ? "PC" :
                                    (($funding == "unknown") ? "UC" : "OC")))
                                    );
                    $exp_month = $tt->sources->data[0]->exp_month;
                    $exp_year = $tt->sources->data[0]->exp_year;
                    $is_default = 1 ; // this is default
                                    // customer id in user meta
                    delete_user_meta($userid, "_stripe_customer_id");
                    add_user_meta($userid, "_stripe_customer_id", $customer_id);
                    $query_response  = $this->Save_woocommerce_card_stripe($userid, $cardid, $funding_type, $is_default, $card_brand, $customer_last4, $exp_month, $exp_year, $name_on_card, $short_name);
                    echo json_encode($query_response);
                    exit();
                }


                echo json_encode(array('stripe_error' => 1,'messgae' => $e->getMessage()));
                exit;
            }

        }  
        echo json_encode(array('stripe_error' => 1,'messgae' => 'Invalid Request'));
                exit;  
	}
	public function Save_woocommerce_card_stripe( $userid, $cardid, $funding_type, $is_default, $card_brand, $last4, $exp_month, $expiry_year, $card_holder, $short_name ) {
		global $wpdb;
		$woocommerce_pay_tokens = $wpdb->prefix . 'woocommerce_payment_tokens';
		$woocommerce_pay_tokenmeta = $wpdb->prefix . 'woocommerce_payment_tokenmeta';

		$cardsaved = $wpdb->insert( $woocommerce_pay_tokens,
			array(
				'user_id'    => trim( $userid ),
				'gateway_id' => 'stripe',
				'token'      => trim( $cardid ),
				'type'       => trim( $funding_type ),
				'is_default' => trim( $is_default ),
			),
			array(
				'%d',
				'%s',
				'%s',
				'%s',
				'%d',
			)
		);

		if ( $cardsaved ) {
			$last_row_id =  $wpdb->insert_id;
			$stripe_card_row_id =  'stripe_card_holder_name' . $last_row_id;
			$stripe_short_row_id =  'stripe_card_short_name' . $last_row_id;
			add_user_meta( $userid, $stripe_card_row_id, $card_holder );
			add_user_meta( $userid, $stripe_short_row_id, $short_name );
			$wpdb->insert( $woocommerce_pay_tokenmeta,
							array(
								'payment_token_id' => trim( $last_row_id ),
								'meta_key' => 'card_type',
								'meta_value' => trim( $card_brand )
							),
							array(
								'%d',
								'%s',
								'%s'
							)
						);
			$wpdb->insert( $woocommerce_pay_tokenmeta,
							array(
								'payment_token_id' => trim( $last_row_id ),
								'meta_key' => 'last4',
								'meta_value' => trim( $last4 )
							),
							array(
								'%d',
								'%s',
								'%s'
							)
						);
			$wpdb->insert( $woocommerce_pay_tokenmeta,
							array(
								'payment_token_id' => trim( $last_row_id ),
								'meta_key' => 'expiry_month',
								'meta_value' => trim( $exp_month )
							),
							array(
								'%d',
								'%s',
								'%s'
							)
						);
			$wpdb->insert( $woocommerce_pay_tokenmeta,
							array(
								'payment_token_id' => trim( $last_row_id ),
								'meta_key' => 'expiry_year',
								'meta_value' => trim( $expiry_year )
							),
							array(
								'%d',
								'%s',
								'%s'
							)
						);

			$redirect = site_url( 'my-account/payment_methods' );
			// call blockchain api.
			if ( 'enable' == $blockchain_setting ) {
				blockchain_updates();
			}
			return  array(
				'success' => 1 ,
				'redirect' => $redirect,
				'insert' => $cardsaved,
				'cardname' => $card_brand,
			);
			exit;
		}else
		{
			return array(
				'stripe_error' => 1 ,
				'messgae' => 'Card details is not saving into database',
			);
			exit;
		}

	}
}


	/**
	 * Get the all class fucntion
	 *
	 * @return array An array of iisNomineeEntry objects
	 */
	$iis_ajax_obj = new Iis_Ajax_Method();

