<?php
include '../../../../wp-config.php';
global $wpdb,$current_user;
$user_id = $current_user->ID;
if ($user_id == 0) 
{
	$redirect_url = site_url()."/registration-page/login/";
	echo json_encode(array('login_error' => 1, 'redirect_url' => $redirect_url));	
           exit;
} 
if(isset( $_POST['conversion_type'] ) && !empty($_POST['conversion_type']) && isset($_POST['convert_credits']) && !empty($_POST['convert_credits']) && isset($_POST['action']) && $_POST['action'] == "save_conversion" ) 
{
	$conversion_type = trim($_POST['conversion_type']); 
	$convert_credits = number_format(trim($_POST['convert_credits']), 2);
	$blog_id = get_current_blog_id();
    $my_credit_meta_key = "wp68_".$blog_id."_user_points";
    $conversion_rate_list = unserialize(get_option("convertCreditsIntoCurrency"));
    $user_account_credits_point = get_user_meta($user_id, $my_credit_meta_key, TRUE);
    $table_log = $wpdb->prefix."credit_currency_conversion_log";
    $conversion_rate = '';
    // $conversion_name =   (($conversion_type == "cc") ? $conversion_rate_list['cc_conversion_rate'] :
				// 			(($conversion_type == "paypal") ? $conversion_rate_list['paypal_conversion_rate'] :
				// 			(($conversion_type == "token") ? $conversion_rate_list['token_conversion_rate'] : "" ))
				// 			);
    $conversion_rate =   (($conversion_type == "cc") ? $conversion_rate_list['cc_conversion_rate'] :
							(($conversion_type == "paypal") ? $conversion_rate_list['paypal_conversion_rate'] :
							(($conversion_type == "token") ? $conversion_rate_list['token_conversion_rate'] : "" ))
							);
	if($conversion_rate <= '0')
	{
		echo json_encode(array('success' => 0,'messgae' => "Conversion rate is not found!", 'redirect_url' => $redirect_url));	
           exit;
	} 
	// check convert credits less or more
	if($user_account_credits_point < $convert_credits)
	{
		$redirect_url = site_url('my-account/credits_to_currency');
		echo json_encode(array('success' => 0,'messgae' => "CR ".$convert_credits." is not avaialble in your account.", 'redirect_url' => $redirect_url));	
           exit;
	}else if($convert_credits <= '0')
	{
		$redirect_url = site_url('my-account/credits_to_currency');
		echo json_encode(array('success' => 0,'messgae' => "You can not CR ".$convert_credits." into currency.", 'redirect_url' => $redirect_url));	
           exit;
	}else{
           $redirect_url = site_url('my-account/credits_to_currency');
		   $converted_amount  = $convert_credits * $conversion_rate;
           // insert into database
           $transaction_id = "ch_".uniqid();
		   $insertResult = $wpdb->insert( $table_log, array("user_id" => $user_id, "conversion_type" => $conversion_type, "conversion_rate" => $conversion_rate, "credits" => $convert_credits, "converted_amount" => $converted_amount, "currency_name" => "usd", 'entry_time' => date("Y-m-d h:i:s"), 'transaction_id' => $transaction_id  ));
		   if($insertResult)
		   {  
		   	     $last_remaining_credits = ($user_account_credits_point - $convert_credits);
		   	     update_user_meta($user_id, $my_credit_meta_key, $last_remaining_credits);
		   	     echo json_encode(array('success' => 1,'messgae' => "Credits successfully converted into currency.", 'redirect_url' => $redirect_url));	
                 exit;
		   }else
		   {
		   	   echo json_encode(array('success' => 0,'messgae' => "Credits into currency conversion failed!", 'redirect_url' => $redirect_url));	
                 exit;
		   }
		   
	}
    //blockchain_updates();	
	 
}else
{
	$redirect_url = site_url('my-account/credits_to_currency');
    echo json_encode(array('success' => 0,'messgae' => "Invalid request!.", 'redirect_url' => $redirect_url));	
           exit;
}	
