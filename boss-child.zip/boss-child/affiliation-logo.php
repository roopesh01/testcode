<?php
/**
 *Template Name: Affiliation Logo
 */

global $current_user, $wpdb;
$userid = get_current_user_id();

// Redirect to login if not logged in.
if ( ! is_user_logged_in() ) {
	auth_redirect();
}

$current_logo = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->posts} WHERE  `post_type`='company_logo' AND `post_author`=%d LIMIT 1", $userid ) );

$previous_logo = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$wpdb->posts} WHERE  `post_type`='prev_company_logo' AND `post_author`= %d", $userid ) );

get_header();
?>

<script src="<?php echo esc_url( get_stylesheet_directory_uri() ); ?>/js/logo_js.js"></script>
<div class="page-full-width">
	<div id="primary" class="site-content">
		<div id="content" role="main">
			<?php

			if ( $current_logo ) :
				echo '<h2 class="update_media">Company Logo</h2>';
				echo '<div class="img_sec"><img src="' . esc_url( $current_logo->guid ) . '" height="150" width="150"/><a href="javascript:void(0);" class="edit_img edit_links"><span class="edit_imgg">Edit Logo</span></a><a href="javascript:void(0);" class="delete_img delete_links" data-id="' . (int) $current_logo->ID . '"><span class="delete_imgg">Delete Logo</span></a></div>';
				?>
				<div class="img_edit_section" style="display: none;">
						<div id="logo_form">
							<form id="upload_edit_logo" action="" method="post" enctype="multipart/form-data" class="logo_forms">
									<input type="hidden" name="edit_post_type" id="edit_post_type" value="company_logo"/>
									<input type="hidden" name="logo_id" id="logo_id" value="<?php echo esc_attr( $logoid ); ?>"/>
								<?php wp_nonce_field( 'cpt_nonce_action', 'cpt_nonce_field' ); ?>
								<div class="large-12 columns">
										<div id="image_preview1">
											<img id="previewing1" src="<?php echo esc_url( get_stylesheet_directory_uri() ); ?>/media_images/no-image.png"/>
										</div>
										<label for="select_image">Select Your Image</label>
										<input type="file" name="edit_logo" id="edit_logo" />
										<input type="submit" value="Submit" class="submit" />
									<div id="message1"></div>
								</div>
							</form>
						</div>
						<a href="javascript:void(0);" class="cancel_img edit_links"><span class="edit_imgg">Cancel</span></a>
					</div>
					<?php
					else :
					?>
						<h2 class="update_media">Add Current Company Logo</h2>
						<div id="logo_form">
						<form id="upload_logo" action="" method="post" enctype="multipart/form-data" class="logo_forms">
							<input type="hidden" name="author_id" value="<?php echo esc_attr( $userid ); ?>"/>
							<input type="hidden" name="post_type" id="post_type" value="company_logo"/>
							<?php wp_nonce_field( 'cpt_nonce_action', 'cpt_nonce_field' ); ?>
							<div class="large-12 columns">
									<div id="image_preview1">
										<img id="previewing1" src="<?php echo esc_url( get_stylesheet_directory_uri() ); ?>/media_images/no-image.png"/>
									</div>
										<label for="select_image">Select Your Image</label>
										<input type="file" name="logo_file" id="logo_file" />
										<input type="submit" value="Submit" class="submit" />
									<div id="message1"></div>
							</div>
						</form>
						</div>
						<?php
			endif;
			?>

						<input type="hidden" id="url_img" value="<?php echo esc_url( get_stylesheet_directory_uri() ); ?>/media_images/no-image.png"/>
						<div class="prev_company_logos">
						<?php
						if ( $previous_logo ) :
							echo '<h2 class="update_media">Previous Company Logo</h2>';
							$count    = 0;
							$counting = count( $previous_logo );
							foreach ( $previous_logo as $previous ) :
								$prev_logoid = $previous->ID;
								$guid        = $previous->guid;
								?>
								<div class="previous_logos">
									<img src="<?php echo esc_url( $guid ); ?>" height="150" width="150"/>
									<a href="javascript:void(0);" class="edit_prev_logo edit_links">
										<span class="edit_imgg">Edit Logo</span>
									</a>
									<a href="javascript:void(0);" class="delete_previous delete_links" data-id="<?php echo (int) $prev_logoid; ?>">
										<span class="delete_imgg">Delete Logo</span>
									</a>
									</div>

								<div class="prev_logo_edit" style="display: none;">
									<div id="logo_form<?php echo (int) $count; ?>">
									<form id="edit_prev_logo<?php echo (int) $count; ?>" action="" method="post" enctype="multipart/form-data" class="logo_forms">
										<input type="hidden" name="prev_logo_id<?php echo (int) $count; ?>" id="prev_logo_id<?php echo (int) $count; ?>" value="<?php echo (int) $prev_logoid; ?>"/>
										<?php wp_nonce_field( 'cpt_nonce_action', 'cpt_nonce_field' ); ?>
										<div class="large-12 columns">
												<div id="image_preview1<?php echo (int) $count; ?>" class="img_src_preview">
													<img id="previewing1<?php echo (int) $count; ?>" src="<?php echo esc_url( get_stylesheet_directory_uri() ); ?>/media_images/no-image.png" class="img_url_preview"/>
												</div>
												<label for="select_image">Select Your Image</label>
												<input type="hidden" class="logono" name="edit_imggid" value="<?php echo (int) $count; ?>"/>
												<input type="file" name="edit_logo<?php echo (int) $count; ?>" id="edit_logo<?php echo (int) $count; ?>" class="prev_logo_img"/>
												<input type="submit" value="Submit" class="submit submit_prev_logo" />
											<div id="message1<?php echo (int) $count; ?>" class="error_msg"></div>
										</div>
									</form>
									</div>
								<a href="javascript:void(0);" class="cancel_previous edit_links"><span class="edit_imgg">Cancel</span></a>
							</div>
								<?php
								$count++;
								endforeach;
							echo '<input type="hidden" value="' . (int) $count . '" id="total_logo"/>';
							if ( 5 !== $counting ) :
								echo '<div class="add_other">
                                    <h2 class="update_media">Add Other Logos</h2>
                               </div>
                               <button class="add_previous" id="add_other_logo" type="button">+ Add Logo</button>';
								endif;
							else :
							?>
								<div class="previous_company">
								<input type="hidden" value="0" id="total_logo"/>
								<h2 class="update_media">Add Previous Company Logo</h2>
							</div>
								<button class="add_previous" id="add_prev_logo" type="button">+ Add Logo</button>
							<?php
							endif;
							?>
						</div>
		</div><!-- #content -->
	</div><!-- #primary -->
</div><!-- .page-full-width -->
<?php get_footer(); ?>
