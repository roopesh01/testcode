<?php
include '../../../../wp-config.php';
	global $wpdb;

if ( isset( $_POST['catid'] ) ) {
	$catid   = vl_sanitize_unslash( 'catid' );
	$results = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM $wpdb->vl_user_sub_category WHERE `category_id`= %d", $catid ) );

	foreach ( $results as $result ) {
		echo '<li><a href="javascript:;">' . esc_html( $result->sub_category_name ) . '</a></li>';
	}
}
