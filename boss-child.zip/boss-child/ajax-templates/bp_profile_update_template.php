<?php 
include '../../../../wp-config.php';
 global $wpdb,$current_user,$bp;

$user_id = $current_user->ID;
$table = $wpdb->prefix.'expert_price';
$blockchain_setting =  get_option('update_user_profile_bc');
$prefix = $wpdb->prefix;

// duplicate email id
if(isset($_POST['action']) && $_POST['action'] == "CheckDuplicateEmail")
{

	if($current_user->user_email == $_POST['email_id'])
	{
		echo json_encode(array("status" => 1, "message" => "same email id"));
		exit(); 
	}else{
		$exists = email_exists( $_POST['email_id'] );
		if ( $exists ) {
		   echo json_encode(array("status" => 0, "message" => "This email already exists."));
		     exit(); 
		} else {
		     echo json_encode(array("status" => 1, "message" => "you can change this email"));
		     exit(); 
		}

	}
}

if(isset($_POST['firstName_Friendd']) && isset($_POST['lastName']) && isset($_POST['companyName']) && isset($_POST['jobTitle']))
{
    
    $firstName_Friend = trim($_POST['firstName_Friendd']);
    $lastName = trim($_POST['lastName']);
    $companyName = trim($_POST['companyName']);
    $jobTitle = trim($_POST['jobTitle']);
    $cityName = trim($_POST['cityName']);
    $stateName= trim($_POST['stateName']);
    $countryName = trim($_POST['countryName']);
    $zipCode = trim($_POST['zipCode']);
    $bio = trim($_POST['bio']);
    $profile_friend = $_POST['profile_friend'];
    $show_company_logo_frnd = $_POST['show_company_logo_frnd'];
    $show_prev_company_logo_frnd = $_POST['show_prev_company_logo_frnd'];
    
    
    $metas = array( 
    $prefix.'friend_first_hidden_name' => $firstName_Friend,
    $prefix.'friend_last_hidden_name' => $lastName, 
    $prefix.'friend_company_hidden_name' => $companyName, 
    $prefix.'friend_job_title_hidden_name' => $jobTitle, 
    $prefix.'friend_city_hidden_name' => $cityName,
    $prefix.'friend_state_hidden_name' => $stateName,    
    $prefix.'friend_country_hidden_name' => $countryName,
    $prefix.'friend_zip_hidden_name' => $zipCode,
    $prefix.'friend_bio_hidden_name' => $bio,
    $prefix.'friend_profile_hidden' => $profile_friend,
    $prefix.'friend_company_logo_hidden' => $show_company_logo_frnd,
    $prefix.'friend_prev_company_logo_hidden' => $show_prev_company_logo_frnd
    );
    foreach($metas as $key => $value) 
    {
        update_user_meta( $user_id, $key, $value );
    }
    $output = array("status"=>1, "validate"=>1, "message"=>'friend data updated');
    echo json_encode($output);
}
elseif(isset($_POST['firstName_Memberr']) && isset($_POST['lastName']) && isset($_POST['companyName']) && isset($_POST['jobTitle']))
{
    
    $firstName_Member = trim($_POST['firstName_Memberr']);
    $lastName = trim($_POST['lastName']);
    $companyName = trim($_POST['companyName']);
    $jobTitle = trim($_POST['jobTitle']);
    $cityName = trim($_POST['cityName']);
    $stateName= trim($_POST['stateName']);
    $countryName = trim($_POST['countryName']);
    $zipCode = trim($_POST['zipCode']);
    $bio = trim($_POST['bio']);
    $profile_member = $_POST['profile_member'];
    $show_prev_company_logo_member = $_POST['show_prev_company_logo_member'];
    $show_company_logo_member = $_POST['show_company_logo_member'];
    
    $metas = array( 
    $prefix.'member_first_hidden_name' => $firstName_Member,
    $prefix.'member_last_hidden_name' => $lastName, 
    $prefix.'member_company_hidden_name' => $companyName, 
    $prefix.'member_job_title_hidden_name' => $jobTitle, 
    $prefix.'member_city_hidden_name' => $cityName,
    $prefix.'member_state_hidden_name' => $stateName,    
    $prefix.'member_country_hidden_name' => $countryName,
    $prefix.'member_zip_hidden_name' => $zipCode,
    $prefix.'member_bio_hidden_name' => $bio,
    $prefix.'member_profile_hidden' => $profile_member,
    $prefix.'member_company_logo_hidden' => $show_prev_company_logo_member,
    $prefix.'member_prev_company_logo_hidden' => $show_company_logo_member
    );
    foreach($metas as $key => $value) 
    {
        update_user_meta( $user_id, $key, $value );
    }
    $output = array("status"=>1, "validate"=>1, "message"=>'member data updated');
    echo json_encode($output);
}
else
{

if(isset($_POST['Myaction']))
{
	$profile_user_id = base64_decode(trim($_POST['profile_user_id']));
	$Myaction = $_POST['Myaction'];
	if($profile_user_id == $user_id && $Myaction == "delete_profile_photo")
	{
		$upload_dir   = wp_upload_dir();
        $image_basedir = $upload_dir['basedir'];
        $file_path = $image_basedir.'/avatars/'.$profile_user_id.'/*';
		$files = glob($file_path); // get all file names
		foreach($files as $file){ // iterate files
		if(is_file($file))
		   unlink($file); // delete file
		}
		$userimage = bp_get_activity_avatar(array('user_id' => $profile_user_id,'type' => "full")); 

        $src = (string) reset(simplexml_import_dom(DOMDocument::loadHTML($userimage))->xpath("//img/@src"));
		echo json_encode(array("status" => 1,"message" => "Profile image successfully deleted.", "imgaeURL" => $src));
		if($blockchain_setting == "enable")
		{
			blockchain_updates();
		}
        exit();
	}else
	{
		echo json_encode(array("status" => 0,"message" => "Invalid Request."));
        exit();
	}
}

$action = "UpdateBP_Profile";
$locationArray = array();
$cityName = trim($_POST['cityName']);

// Start validation 
$validation_array = array();



if(count($validation_array) > 0)
{
    echo json_encode(array("status" => 0,"validate" => 0 ,"message" => $validation_array));
    exit();
}
// End validation 

if(strlen($cityName) > 0)
{
	array_push($locationArray, $cityName);
}
$cityName_visibility = trim($_POST['field_5_visibility']);
$update_status = xprofile_set_field_data( 5, $user_id, $cityName);
xprofile_set_field_visibility_level( 5, $user_id, $cityName_visibility ); /*  Update user field visibility */

$stateName = trim($_POST['stateName']);
if(strlen($stateName) > 0)
{
	array_push($locationArray, $stateName);
}
$stateName_visibility = trim($_POST['field_6_visibility']);
$update_status = xprofile_set_field_data( 6, $user_id, $stateName);
xprofile_set_field_visibility_level( 6, $user_id, $stateName_visibility );

$companyName = $_POST['companyName'];
$companyName_visibility = trim($_POST['field_623_visibility']);
$update_status = xprofile_set_field_data( 623, $user_id, $companyName);
xprofile_set_field_visibility_level( 623, $user_id, $companyName_visibility );

$jobTitle = trim($_POST['jobTitle']);
$jobTitle_visibility = trim($_POST['field_624_visibility']);
$update_status = xprofile_set_field_data( 624, $user_id, $jobTitle);
xprofile_set_field_visibility_level( 624, $user_id, $jobTitle_visibility );

$zipCode = trim($_POST['zipCode']);
$zipCode_visibility = trim($_POST['field_375_visibility']);
$update_status = xprofile_set_field_data( 375, $user_id, $zipCode);
xprofile_set_field_visibility_level( 375, $user_id, $zipCode_visibility );

$countryName = trim($_POST['countryName']);
if(strlen($countryName) > 0)
{
	array_push($locationArray, $countryName);
}
$countryName_visibility = trim($_POST['field_376_visibility']);
$update_status = xprofile_set_field_data( 376, $user_id, $countryName);
xprofile_set_field_visibility_level( 376, $user_id, $countryName_visibility );

$userbiography = $_POST['userbiography'];
$userbiography_visibility = trim($_POST['field_241_visibility']);
$update_status = xprofile_set_field_data( 241, $user_id, $userbiography);
xprofile_set_field_visibility_level( 241, $user_id, $userbiography_visibility );

if( !is_user_logged_in())
{  
	$redirect_url = site_url('login');
	$outpout = array("status" => 0,"validate" => 1, "message" => $user_id, "redirect_url" => $redirect_url);
	echo  json_encode($outpout);
	exit();
}
 
if($action == "UpdateBP_Profile")
{
	
	$fullLocation =  implode(' , ',$locationArray);
	$vd_price = number_format($video_rate, 2, '.', '');
    $vd_price = ($vd_price == 0.00) ? "NA" : $vd_price;
    $vc_price = number_format($voice_rate, 2, '.', '');
    $vc_price = ($vc_price == 0.00) ? "NA" : $vc_price;
    $ct_price = number_format($chat_rate, 2, '.', '');
    $ct_price = ($ct_price == 0.00) ? "NA" : $ct_price;
    $sm_price = number_format($sms_rate, 2, '.', '');
    $sm_price = ($sm_price == 0.00) ? "NA" : $sm_price;

	$user_output_array = array(
		'job' => $jobTitle,
		'biography' => $userbiography,
		'company' => $companyName,
	  'video_rate' => $vd_price ."/min",
	  'voice_rate'  => $vc_price ."/min",
	  'chat_rate' => $ct_price ."/msg",
	  'sms_rate' => $sm_price ."/msg",
	  'location' => $fullLocation

	);
	 
	 $result = $wpdb->get_var( $wpdb->prepare("SELECT user_id FROM $table WHERE user_id= %d", $user_id) );
	if($result)
	{
		$update_record = $wpdb->query( $wpdb->prepare("UPDATE $table SET price= %s, hourly_price= %s, video_min_price= %s, chat_price= %s, sms_price= %s WHERE user_id= %d", $voice_rate, $voice_rate, $video_rate, $chat_rate, $sms_rate, $user_id) );
		$redirect_url = site_url("my-account/user_profile");
		
		$outpout = array("status" => 1, "validate" => 1, "message" => "Information successfully updated", "redirect_url" => $redirect_url, 'response' => $user_output_array);
	    echo  json_encode($outpout);
	    if($blockchain_setting == "enable")
		{
			blockchain_updates();
		}
	   exit();

	}
	else
	{
		$wpdb->insert(
				$table,
				array
				(
					'user_id'=> $user_id,
					'price' => $voice_rate,
					'hourly_price' => $voice_rate,
					'video_min_price' => $video_rate,
					'chat_price' => $chat_rate,
					'sms_price' => $sms_rate,
				),
				array('%d','%s','%s','%s','%s','%s'));
		
		$redirect_url = site_url("my-account/user_profile");
		$outpout = array("status" => 1, "validate" => 1, "message" => "Information successfully updated", "redirect_url" => $redirect_url, 'response' => $user_output_array);
	    echo  json_encode($outpout);
	    if($blockchain_setting == "enable")
		{
			blockchain_updates();
		}
	   exit();		 
	}
}
}


 
 