<?php
if ( ! is_user_logged_in() ) {
	$url = site_url( '/registration-page/login/' );
	wp_redirect( $url );
	exit;
}
?>
<?php
/*
 * Template Name: Expert Call Dashboard
 *
 */
include TWSCC_PLUGIN_PATH . 'twilio-php/Services/Twilio/Capability.php';

global $wpdb;

$result          = $wpdb->get_row( "SELECT * FROM {$wpdb->vl_twilio_detail} LIMIT 1" );
$app_sid         = 'APa7b51affc8dde1e0602bc360e76fc375';
$current_user_id = get_current_user_id();
$user_info       = get_userdata( $current_user_id );
$user_roles      = implode( ', ', $user_info->roles );
$client_name     = $user_info->user_login;

// Get the Twilio Client name from the page request parameters, if given.
if ( vl_sanitize_unslash( 'client' ) ) {
	$client_name = vl_sanitize_unslash( 'client' );
}

$capability = new Services_Twilio_Capability( $result->account_sid, $result->auth_token );
$capability->allowClientOutgoing( $app_sid );
$capability->allowClientIncoming( $client_name );
$token = $capability->generateToken();

get_header();
?>

<script src="http://thorst.github.io/jquery-idletimer/prod//src/idle-timer.js"></script>

<link rel="stylesheet" href="<?php bloginfo( 'stylesheet_directory' ); ?>/css/jquery-ui.css">

<script src="https://code.jquery.com/ui/1.12.0/jquery-ui.js"></script>
<script src="<?php echo esc_url( VL_THEME_URL ); ?>/js/jquery.validate.min.js"></script>
<script src="<?php echo esc_url( VL_THEME_URL ); ?>/js/jquery.payment.js"></script>
<script src="<?php echo esc_url( VL_THEME_URL ); ?>/js/bootbox.min.js"></script>
<script src="<?php echo esc_url( VL_THEME_URL ); ?>/js/moment.min.js"></script>
<script src="<?php echo esc_url( VL_THEME_URL ); ?>/js/moment-timezone-with-data.js"></script>
<script src="<?php echo esc_url( VL_THEME_URL ); ?>/js/ifvisible.js"></script>

<script type="text/javascript">
	jQuery(document).ready(function()
	{
		var userid = jQuery('.expertid').val();
		var username = jQuery('.expertname').val();
		var userstatus = "1";
		jQuery.ajax
			({
				type: "POST",
				url: "<?php echo esc_url( VL_THEME_URL ); ?>/ajax-templates/expert_status.php",
				async:false,
				data: {expertid:userid, expername:username, status:userstatus},
				success: function(msg)
				{

				}
			});
	});
	jQuery('.answer').hide();
	Twilio.Device.setup("<?php echo esc_attr( $token ); ?>");
	Twilio.Device.ready(function (device)
	{
			jQuery("#log").text("ready");
			jQuery('.hangup').hide();
			jQuery('.answer').hide();
	});

	Twilio.Device.error(function (error)
	{
		alert("Error: " + error.message);
	});

	Twilio.Device.cancel(function(conn)
	{
		location.reload();
		console.log(conn.parameters.From); // who canceled the call
		conn.status // => "closed"
	});

	Twilio.Device.connect(function (conn){
		alert("Successfully established call");
	});

	Twilio.Device.disconnect(function (conn)
	{
		alert("Call ended");
		jQuery('.call').show();
		jQuery('.hangup').hide();
		jQuery('.answer').hide();
		jQuery('#number').show();
		Twilio.Device.setup("<?php echo esc_attr( $token ); ?>");
		Twilio.Device.ready(function (device)
		{
			jQuery("#log").text("ready");
			jQuery('.hangup').hide();
			jQuery('.answer').hide();
		});
		location.reload();
	});

	Twilio.Device.incoming(function (conn)
	{
		alert("Incoming connection from " + conn.parameters.From);
		// accept the incoming connection and start two-way audio
		jQuery('.answer').show();
		jQuery('.hangup').show();
		jQuery('.call').hide();
		jQuery('.answer').click(function()
		{
			jQuery('.answer').hide();
			jQuery('.call').hide();
			jQuery('#number').hide();
			answer(conn);
		})

	});
	function answer(conn)
	{
		conn.accept();
	}

	function call()
	{
		// get the phone number to connect the call to
		params = {"PhoneNumber": jQuery("#number").val()};
		Twilio.Device.connect(params);
		jQuery('.hangup').show();
		jQuery('.call').hide();
	}

	function hangup()
	{
		Twilio.Device.disconnectAll();
		jQuery('.call').show();
		jQuery('.hangup').hide();
		jQuery('.answer').hide();
		jQuery('#number').show();
		Twilio.Device.setup("<?php echo esc_attr( $token ); ?>");
		Twilio.Device.ready(function (device)
		{
			jQuery("#log").text("ready");
			jQuery('.hangup').hide();
			jQuery('.answer').hide();
		});
		location.reload();
	}
	function d(el){
				return document.getElementById(el);
			}
			ifvisible.setIdleDuration(20);

			ifvisible.on('statusChanged', function(e){
				//d("result").innerHTML += (e.status+"<br>");
				if(e.status == "hidden")
				{

				var userid = jQuery('.expertid').val();
				var username = jQuery('.expertname').val();
				var userstatus = "0";
				$.ajax
				({
					type: "POST",
					url: "<?php echo esc_url( VL_THEME_URL ); ?>/ajax-templates/expert_status.php",
					async:false,
					data: {expertid:userid, expername:username, status:userstatus},
					success: function(msg)
					{
					}
				});
				}
			});

			ifvisible.wakeup(function(){
				//d("result2").innerHTML = "(O_o) Hey!, you woke me up.";
				document.body.style.opacity = 1;
				var userid = jQuery('.expertid').val();
				var username = jQuery('.expertname').val();
				var userstatus = "1";
				$.ajax
				({
					type: "POST",
					url: "<?php echo esc_url( VL_THEME_URL ); ?>/ajax-templates/expert_status.php",
					async:false,
					data: {expertid:userid, expername:username, status:userstatus},
					success: function(msg)
					{

					}
				});
			});


			ifvisible.onEvery(0.5, function(){
				// Clock, as simple as it gets
				var h = (new Date()).getHours();
				var m = (new Date()).getMinutes();
				var s = (new Date()).getSeconds();
				h = h < 10? "0"+h : h;
				m = m < 10? "0"+m : m;
				s = s < 10? "0"+s : s;
			});

			setInterval(function(){
				var info = ifvisible.getIdleInfo();
				// Give 3% margin to stabilaze user output
				if(info.timeLeftPer < 3){
					info.timeLeftPer = 0;
					info.timeLeft = ifvisible.getIdleDuration();
				}
				d("seconds").innerHTML = parseInt(info.timeLeft / 1000), 10;
				d("idlebar").style.width = info.timeLeftPer+'%';
			}, 100);
</script>
<?php
if ( 'experts' === $user_roles ) {
?>
<div class="container-fluid">
	<div class="row">
		<div class="col-md-3">
		<div class="page_status"></div>
			<h3>Welcome  { Expert }</h3>
			<input type="hidden" value="<?php echo (int) $current_user_id; ?>" class="expertid" name="expertid"/>
			<input type="hidden" value="<?php echo esc_attr( $client_name ); ?>" class="expertname" name="expertname"/>
			<input type="hidden" id="number" class="form-control" name="number" placeholder="Enter employee code to call"/><br>
			<input type="hidden" value="<?php echo esc_attr( $user_roles ); ?>"/>
			<button class="btn-success call" >Waiting for call...</button>
			<button class="btn-success answer" style="display: none">Answer</button>&nbsp;&nbsp;
			<button class="btn-danger hangup"  onclick="hangup();" style="display: none">Hangup</button>

		</div>
	</div><br>
	<div class="row">
		<div class="col-md-3">

			<div id="log" class="alert alert-info">Loading...</div>

		</div>
	</div>
	<div class="well" style="display:none;">
						If you wait <span class="label label-warning" id="seconds">00</span> seconds I'll sleep.
						<div class="progress">
							<div class="bar" id="idlebar" style="width: 0%;"></div>
						</div>
						<div id="result2">(^_^) Hey, there.</div>
					</div>

</div>


<?php
} else {
	echo "<div class='login_error_msg'>you are not authorize to view this page please login as expert to view this page</div>";
}
?>
<script type="text/javascript">
	var validNavigation = false;
	function wireUpWindowUnloadEvents()
	{
		$(document).on('keypress', function(e)
		{
			if (e.keyCode == 116)
			{
				validNavigation = true;
			}
		});

		$(document).on("click", "a" , function()
		{
			validNavigation = true;
		});

		$(document).on("submit", "form" , function()
		{
			validNavigation = true;
		});

		$(document).bind("click", "input[type=submit]" , function()
		{
			validNavigation = true;
		});

		$(document).bind("click", "button[type=submit]" , function()
		{
			validNavigation = true;
		});

	}

	window.onbeforeunload=goodbye;
	window.onload = function() {
		alert('window - onload');
	};
	var dont_confirm_leave = 0;
	var leave_message = 'You sure you want to leave?'
	function goodbye(e)
	{
		if (!validNavigation)
		{
			if (dont_confirm_leave!==1)
			{
				if(!e) e = window.event;
				e.cancelBubble = true;
				e.returnValue = leave_message;
				if (e.stopPropagation)
				{
					e.stopPropagation();
					e.preventDefault();
				}
				var userid = jQuery('.expertid').val();
				var username = jQuery('.expertname').val();
				var userstatus = "0";
				$.ajax
				({
					type: "POST",
					url: "<?php echo esc_url( VL_THEME_URL ); ?>/ajax-templates/expert_status.php",
					async:false,
					data: {expertid:userid, expername:username, status:userstatus},
					success: function(msg)
					{

					}
				});
				return leave_message;
			}
		}
	}
		var dur = (ifvisible.getIdleDuration() / 1000);
		d('seconds').innerHTML =  dur;
		d('idleTime').innerHTML = dur + " seconds";
</script>
<?php get_footer();
