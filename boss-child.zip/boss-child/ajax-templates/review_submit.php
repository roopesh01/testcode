<?php
include '../../../../wp-config.php';
global $wpdb;
$table = $wpdb->prefix.'addtofavorite';
$ratingtable = $wpdb->prefix.'ratings';
$teamdetail_table = $wpdb->prefix.'expert_team_detail';
$friend_table = 'wp68_bp_friends';
$notification_table = 'wp68_bp_notifications';
$visitorid = get_current_user_id();
if ($visitorid == 0) 
{
		$redirect = site_url()."/registration-page/login/";
		echo json_encode(array('login_error'=>1,'redirect'=>$redirect));	
		exit; 
}
if(isset($_POST))
{
    $private_rating = $_POST['private_rating'];
	$private_review = $_POST['private_review'];
	$public_rating = $_POST['public_rating'];
	$public_review = $_POST['public_review'];
    $reviewd_expert = $_POST['reviewd_expert'];
	$expert_name = $_POST['reviewd_expertname'];
	$conference_id = $_POST['conference_id'];
	$current_time = date('Y-m-d H:i:s');
	$operationtype = $_POST['operationtype'];
	if($operationtype == "feedbackupdate")
	{
		$edit_private_rating = $_POST['edit_private_rating'];
		$edit_private_review = $_POST['edit_private_review'];
		$edit_public_rating = $_POST['edit_public_rating'];
		$edit_public_review = $_POST['edit_public_review'];
		$private_review_details = $wpdb->get_results("SELECT * FROM $ratingtable WHERE `expertid` = '$reviewd_expert' AND `conference_id` = '$conference_id' AND `currentuserid` = '$visitorid' AND feedbacktype = 'Private'");
		if($private_review_details)
		{
			$wpdb->query("UPDATE $ratingtable SET `totalrating`='$edit_private_rating', reviewmessage = '$edit_private_review', feedbackupdate = '$current_time' WHERE `currentuserid`='$visitorid' AND `expertid`='$reviewd_expert' AND conference_id='$conference_id' AND feedbacktype = 'Private'");
		}
		else
		{
			$private_rating_insert = $wpdb->insert
				(
					$ratingtable,
					array(
					'currentuserid'=> $visitorid,
					'expertid' => $reviewd_expert,
					'totalrating' =>$edit_private_rating,
					'conference_id' =>$conference_id,
					'reviewmessage' => $edit_private_review,
					'feedbacktype' => 'Private',
					'feedbacktime' => $current_time
					),
					array(
					'%d','%d','%d','%s','%s','%s','%s'
					)
				);
		}
		$public_review_details = $wpdb->get_results("SELECT * FROM $ratingtable WHERE `expertid` = '$reviewd_expert' AND `conference_id` = '$conference_id' AND `currentuserid` = '$visitorid' AND feedbacktype = 'Public'");
		if($public_review_details)
		{
			$wpdb->query("UPDATE $ratingtable SET `totalrating`='$edit_public_rating', reviewmessage = '$edit_public_review', feedbackupdate = '$current_time' WHERE `currentuserid`='$visitorid' AND `expertid`='$reviewd_expert' AND conference_id='$conference_id' AND feedbacktype = 'Public'");
		}
		else
		{
			$public_rating_insert = $wpdb->insert
				(
					$ratingtable,
					array(
					'currentuserid'=> $visitorid,
					'expertid' => $reviewd_expert,
					'totalrating' =>$edit_public_rating,
					'conference_id' =>$conference_id,
					'reviewmessage' => $edit_public_review,
					'feedbacktype' => 'Public',
					'feedbacktime' => $current_time,
					'admindecision' => 'not_reviewed'
					),
					array(
					'%d','%d','%d','%s','%s','%s','%s','%s'
					)
				);
		}
		echo json_encode(array('success'=>1,'private_rating'=>$private_rating_insert,'public_rating'=>$public_rating_insert));
	}
	else
	{
		if(empty($private_rating) && empty($private_review) && empty($public_rating) && empty($public_review))
		{
			echo json_encode(array('success'=>0,'message'=>'All Fields Are Empty'));
		}
		else
		{
			
			if(isset($public_rating))
			{
			   $public_rating_insert = $wpdb->insert
				(
					$ratingtable,
					array(
					'currentuserid'=> $visitorid,
					'expertid' => $reviewd_expert,
					'totalrating' =>$public_rating,
					'conference_id' =>$conference_id,
					'reviewmessage' => $public_review,
					'feedbacktype' => 'Public',
					'feedbacktime' => $current_time,
					'admindecision' => 'not_reviewed'
					),
					array(
					'%d','%d','%d','%s','%s','%s','%s','%s'
					)
				);
			}
		
			if(isset($private_rating))
			{
				$private_rating_insert = $wpdb->insert
				(
					$ratingtable,
					array(
					'currentuserid'=> $visitorid,
					'expertid' => $reviewd_expert,
					'totalrating' =>$private_rating,
					'conference_id' =>$conference_id,
					'reviewmessage' => $private_review,
					'feedbacktype' => 'Private',
					'feedbacktime' => $current_time
					),
					array(
					'%d','%d','%d','%s','%s','%s','%s'
					)
				);
			}	
			echo json_encode(array('success'=>1,'private_rating'=>$private_rating_insert,'public_rating'=>$public_rating_insert));
		}
	}
}