// (function($) {
jQuery(document).ready(function($) {
    $("input[name='show_public_realname']").on("change", function() {
        var status_info = $(this).val();
        if (status_info == "no") {
            $("input.public_hidden_name").show();
            $("p.public_hidden_name").hide();
        } else {
            $("input.public_hidden_name").hide();
            $("p.public_hidden_name").show();
        }
    });
    $("input[name='show_member_realname']").on("change", function() {
        var status_info = $(this).val();
        if (status_info == "no") {
            $("input.member_hidden_name").show();
            $("p.member_hidden_name").hide();
        } else {
            $("input.member_hidden_name").hide();
            $("p.member_hidden_name").show();
        }
    });

    $('#ajax-woocommerce-edit-form').submit(function(event) {
        $("div.modal-body #show_response_status").html('');
        $("div.modal-body #show_response_status").removeClass();
        event.preventDefault();
        var FormData = $("#ajax-woocommerce-edit-form").serialize(); // serializes the form's elements.
        // remove old validations
        $("form span.form-error").text('');
        $("form input").removeClass("form-error");
        $("html").addClass("overlay");
        $.ajax({
            url: ajaxurl,
            type: "POST",
            dataType: "json",
            data: FormData,
            success: function(data) {

                if (data['validate'] == 0) {
                    var error_Array = data['message'];
                    $.each(error_Array, function(index, value) {
                        if (index != "password") {
                            $("form input#" + index).addClass('form-error');
                        }
                        $("form span." + index + "_error").text(value);
                    });

                } else if (data['status'] == 1) {

                    var errorMessage = data['message'];
                    $("div.modal-body #show_response_status").addClass('alert alert-success');
                    $("div.modal-body #show_response_status").html(errorMessage);
                    $("form input#password_current").val('');
                    $("form input#password_1").val('');
                    $("form input#password_2").val('');
                    var Name = data['response']['fullname'];
                    $("div.header-account-login a.user-link p span.name").text(Name);
                    // set all fields
                    $("h5.display-fullname").text(data['response']['salutation'] + ' ' + data['response']['fullname']);
                    $("p.display-email").text(data['response']['email']);
                    $("p.display-mobile").text(data['response']['mobile']);
                    $("p.display-public").text(data['response']['public']);
                    $("p.display-member").text(data['response']['member']);
                    $("p.display-friends").text(data['response']['fullname']);
                    $(window).scrollTop($('div#show_response_status').offset().top);
                    setTimeout(function() {
                        $("div.modal-body #show_response_status").html('');
                        $("div.modal-body #show_response_status").removeClass();
                        $("div.modal-header button.close").click();
                    }, 3000);
                } else {

                    var errorMessage = data['message'];
                    $("div.modal-body #show_response_status").addClass('alert alert-danger');
                    $("div.modal-body #show_response_status").html(errorMessage);
                }
                $("html").removeClass("overlay");
            }
        });
    });
});

jQuery(document).ready(function($) {
    $('.edAcButton').on('click', function() {
        $('html').css('overflow', 'hidden');
    });
    $('#editAccountModal .close').on('click', function() {
        $('html').css('overflow', 'auto');
    });

    $('#editAccountModal').modal({
        show: false,
        backdrop: 'static',
        keyboard: false
    });
});

// })(jQuery);