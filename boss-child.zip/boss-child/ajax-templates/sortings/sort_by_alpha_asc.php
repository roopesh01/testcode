<?php

include '../../../../../wp-config.php';
global $wpdb,$current_user;

$curentuserid    = $current_user->ID;
$metatable       = 'wp68_usermeta';
$catetable       = $wpdb->prefix . 'user_category';
$table           = $wpdb->prefix . 'user_sub_category';
$tagtable        = $wpdb->prefix . 'user_tags';
$ratingtable     = $wpdb->prefix . 'ratings';
$pricetable      = $wpdb->prefix . 'expert_price';
$usertable       = 'wp68_users';
$prefix          = $wpdb->prefix;
$single          = true;
$post_table      = $wpdb->prefix . 'posts';
$post_meta_table = $wpdb->prefix . 'postmeta';
$logo_type       = 'company_logo';
$prev_logo_type  = 'prev_company_logo';

if ( isset( $_POST['alpha_asc'] ) ) {
	$subcategoryid = vl_sanitize_unslash( 'subcategoryid' );

	if ( $subcategoryid == '01' ) { // for category
		$catkey = vl_sanitize_unslash( 'catkey' );

		$catname = $wpdb->get_results( $wpdb->prepare( 'SELECT DISTINCT m.* FROM wp68_usermeta m INNER JOIN wp68_users u ON m.user_id = u.ID WHERE m.meta_key= %s ORDER BY u.user_login ASC', $catkey ) );

		if ( $catname ) :
			foreach ( $catname as $result ) :
				$userid = $result->user_id;
				//echo $userid;
				if ( $userid != $curentuserid ) :
					$firstname     = get_user_meta( $userid, 'first_name', $single );
					$lastname      = get_user_meta( $userid, 'last_name', $single );
					$expertPrice   = $wpdb->get_var( "SELECT `price` FROM $pricetable WHERE `user_id`='$userid'" );
					$AboutYourSelf = bp_get_profile_field_data( 'field=AboutYourSelf&user_id=' . $userid );
					$title         = bp_get_profile_field_data( 'field=Title&user_id=' . $userid );
					$city          = bp_get_profile_field_data( 'field=City&user_id=' . $userid );
					$state         = bp_get_profile_field_data( 'field=State&user_id=' . $userid );
					$salutation    = bp_get_profile_field_data( 'field=salutation&user_id=' . $userid );
					?>
					<tr> <!-- Table Row -->
					   <td> <!-- Table Column -->
						   <div class="expertbycategorytags"> <!-- Expert  Category Main Div -->
							   <div class="row customexpert">  <!-- Expert Category Sub Div -->
							   <div class="col-md-3 col-lg-2 ce-image">
								   <a href="<?php echo site_url(); ?>/user-basic-profile/?ExpertId=<?php echo $userid; ?>"><?php echo get_avatar( $userid, $size ); ?></a>
								   <div class="clientNameWrap">
								   <h4 class="ce-title"><a href="<?php echo site_url(); ?>/user-basic-profile/?ExpertId=<?php echo $userid; ?>">
									<?php
									if ( $salutation ) {
										echo $salutation . '&nbsp;';
									}echo $firstname . '&nbsp;' . $lastname;
									?>
</a></h4>
									<p class="ce-info"><span>
									<?php
									if ( $city ) {
										echo $city;
									} if ( $city && $state ) {
										echo ',&nbsp';
									} if ( $state ) {
										echo $state;}
?>
</span></p>
								   </div>
							   </div>
							   <div class="col-md-6 col-lg-7 ce-content">
								   <div class="clientBriefInfo">
										<?php
											 $logo_img_url = $wpdb->get_var( $wpdb->prepare( "SELECT guid FROM $post_table WHERE `post_author`= %d AND `post_type` = %s LIMIT 1", $userid, $logo_type ) );

										   $prev_company_logo = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM $post_table WHERE `post_author`= %d AND `post_type`= %s", $userid, $prev_logo_type ) );
										if ( $logo_img_url ) :
											echo '<div class="clientCurrentLogo"><img src="' . esc_url( $logo_img_url ) . '"/></div>';
												   else :
														echo '<div class="clientCurrentLogo"><img src="../wp-content/themes/boss-child/images/no_logo.png"/></div>';
											endif;
										?>

										<p class="ce-details"><?php echo $AboutYourSelf; ?></p>
													   <div class="previousOrgLogo">
													   <ul>
										   <li class="prevEmpText"><span>Previous Affiliation</span></li>
											<?php
											if ( $prev_company_logo ) :
												foreach ( $prev_company_logo as $logos ) :
													$prev_img_url = $logos->guid;
													echo '<li><img src="' . $prev_img_url . '"></li>';
													endforeach;
												else :
														echo '<li><img src="' . VL_THEME_URL . '/images/no_logo.png"></li>';
												endif;
											?>
										</ul>
										</div>
									</div>
								</div>
								<div class="col-md-3 col-lg-3 ce-action">
									<div class="ce-pricing">
										<span class="profile-detail profile-stat price">
										<input type="hidden" name="basic_amount"/>
										<?php
										   $expertprices = number_format( (float) $expertPrice, 2, '.', '' );
										?>
										<strong class="actual-price"><?php echo $expertprices; ?></strong>
													   <small>Credits per minute</small>
													   </span>
												   </div>
												   <a href="/request-a-call/?ExpertId=<?php echo $userid; ?>" class="call_link">Request A Call</a>
												   <div class="expRating">
														<?php
														$average  = $wpdb->get_var( $wpdb->prepare( "SELECT Avg(totalrating) FROM $ratingtable WHERE expertid = %d", $userid ) );
														$average2 = number_format( (float) $average, 2, '.', '' );
														if ( $average2 > 4.5 ) {
															echo '<img src="/wp-content/themes/boss-child/images/rating/five-star.png" title="Awesome - 5 stars"/>';
															echo '<br/>';
															echo $average2 . ' out of 5 stars';
														} elseif ( $average2 > 3.5 ) {
															echo '<img src="/wp-content/themes/boss-child/images/rating/four-star.png" title="Pretty good - 4 stars"/>';
															echo '<br/>';
															echo $average2 . ' out of 5 stars';
														} elseif ( $average2 > 2.5 ) {
															echo '<img src="/wp-content/themes/boss-child/images/rating/three-star.png" title="Average - 3 stars"/>';
															echo '<br/>';
															echo $average2 . ' out of 5 stars';
														} elseif ( $average2 > 1.5 ) {
															echo '<img src="/wp-content/themes/boss-child/images/rating/two-star.png" title="Bad - 2 stars"/>';
															echo '<br/>';
															echo $average2 . ' out of 5 stars';
														} elseif ( $average2 > 0.5 ) {
															echo '<img src="/wp-content/themes/boss-child/images/rating/one-star.png" title="Very Poor - 1 star"/>';
															echo '<br/>';
															echo $average2 . ' out of 5 stars';
														} else {
															echo '<small>No Rating For This Expert</small>';
														}
										?>
									</div>
								</div>
							</div> <!-- Expert Category Sub Div -->
							</div> <!-- Expert  Category Main Div -->
										</td> <!-- Table Column -->
									</tr> <!-- Table Row -->
									<?php
								endif;
			endforeach;
		endif;
	} elseif ( $subcategoryid == '0' ) { // for all
					$single = true;
		 $blog_id           = get_current_blog_id();
		$roles              = array( 'administrator', 'experts' );
		$users              = array();
		foreach ( $roles as $role ) {
			$args               = array(
				'blog_id' => $blog_id,
				'role'    => $role,
				'orderby' => 'user_nicename',
				'order'   => 'ASC',
			);
			$current_role_users = get_users( $args );
			$users              = array_merge( $current_role_users, $users );
		}
		$allexpert = get_users( $users );
		if ( $allexpert ) :
			foreach ( $allexpert as $result ) :
				$userid = $result->ID;
				//echo $userid;
				if ( $userid != $curentuserid ) :
					$firstname     = get_user_meta( $userid, 'first_name', $single );
					$lastname      = get_user_meta( $userid, 'last_name', $single );
					$expertPrice   = $wpdb->get_var( "SELECT `price` FROM $pricetable WHERE `user_id`='$userid'" );
					$AboutYourSelf = bp_get_profile_field_data( 'field=AboutYourSelf&user_id=' . $userid );
					$title         = bp_get_profile_field_data( 'field=Title&user_id=' . $userid );
					$city          = bp_get_profile_field_data( 'field=City&user_id=' . $userid );
					$state         = bp_get_profile_field_data( 'field=State&user_id=' . $userid );
					$salutation    = bp_get_profile_field_data( 'field=salutation&user_id=' . $userid );
					?>
					<tr> <!-- Table Row -->
					   <td> <!-- Table Column -->
						   <div class="expertbycategorytags"> <!-- Expert  Category Main Div -->
							   <div class="row customexpert">  <!-- Expert Category Sub Div -->
								   <div class="col-md-3 col-lg-2 ce-image">
									   <a href="<?php echo site_url(); ?>/user-basic-profile/?ExpertId=<?php echo $userid; ?>"><?php echo get_avatar( $userid, $size ); ?></a>
								   </div>
								   <div class="col-md-6 col-lg-7 ce-content">
									   <h4 class="ce-title"><a href="<?php echo site_url(); ?>/user-basic-profile/?ExpertId=<?php echo $userid; ?>">
																				<?php
																				if ( $salutation ) {
																					echo $salutation . '&nbsp;';
																				}echo $firstname . '&nbsp;' . $lastname;
?>
</a></h4>
										<p class="ce-info"><span>
										<?php
										if ( $city ) {
											echo $city;
										} if ( $city && $state ) {
											echo ',&nbsp';
										} if ( $state ) {
											echo $state;}
	?>
	</span></p>
									   <p class="ce-details"><?php echo $AboutYourSelf; ?></p>
								   </div>
								   <div class="col-md-3 col-lg-3 ce-action">
									   <div class="ce-pricing">
										   <span class="profile-detail profile-stat price">
										   <input type="hidden" name="basic_amount"/>
											<?php
											   $expertprices = number_format( (float) $expertPrice, 2, '.', '' );
											?>
											<strong class="actual-price"><?php echo $expertprices; ?></strong>
														   <small>Credits per minute</small>
														   </span>
													   </div>
													   <a href="/request-a-call/?ExpertId=<?php echo $userid; ?>" class="call_link">Request A Call</a>
													   <div class="expRating">
														<?php
														$average  = $wpdb->get_var( "SELECT Avg(totalrating) FROM $ratingtable WHERE expertid = $userid" );
														$average2 = number_format( (float) $average, 2, '.', '' );
														if ( $average2 > 4.5 ) {
															echo '<img src="/wp-content/themes/boss-child/images/rating/five-star.png" title="Awesome - 5 stars"/>';
															echo '<br/>';
															echo $average2 . ' out of 5 stars';
														} elseif ( $average2 > 3.5 ) {
															echo '<img src="/wp-content/themes/boss-child/images/rating/four-star.png" title="Pretty good - 4 stars"/>';
															echo '<br/>';
															echo $average2 . ' out of 5 stars';
														} elseif ( $average2 > 2.5 ) {
															echo '<img src="/wp-content/themes/boss-child/images/rating/three-star.png" title="Average - 3 stars"/>';
															echo '<br/>';
															echo $average2 . ' out of 5 stars';
														} elseif ( $average2 > 1.5 ) {
															echo '<img src="/wp-content/themes/boss-child/images/rating/two-star.png" title="Bad - 2 stars"/>';
															echo '<br/>';
															echo $average2 . ' out of 5 stars';
														} elseif ( $average2 > 0.5 ) {
															echo '<img src="/wp-content/themes/boss-child/images/rating/one-star.png" title="Very Poor - 1 star"/>';
															echo '<br/>';
															echo $average2 . ' out of 5 stars';
														} else {
															echo '<small>No Rating For This Expert</small>';
														}
										?>
									</div>
									</div>
								</div> <!-- Expert Category Sub Div -->
							</div> <!-- Expert  Category Main Div -->
										</td> <!-- Table Column -->
									</tr> <!-- Table Row -->
									<?php
								endif;
			endforeach;
		endif;
	} else // for subcategory
					{
		$sub_categoryname = $wpdb->get_var( $wpdb->prepare( "SELECT `sub_category_name` FROM $table WHERE `id`= %d", $subcategoryid ) );
		$catid            = $wpdb->get_var( $wpdb->prepare( "SELECT `category_id` FROM $table WHERE `id`= %d", $subcategoryid ) );
		$category_name    = $wpdb->get_var( $wpdb->prepare( "SELECT `category_name` FROM $catetable WHERE `id`= %d", $catid ) );
		$categoryy_name   = $prefix . 'cat_' . $category_name;

		$catname = $wpdb->get_results( $wpdb->prepare( "SELECT DISTINCT m.* FROM $metatable m INNER JOIN `$usertable` u ON m.user_id = u.ID WHERE m.meta_value LIKE %s AND m.meta_key= %s ORDER BY u.user_login ASC", '%' . $wpdb->esc_like( $sub_categoryname ) . '%', $categoryy_name ) );

		if ( $catname ) :
			foreach ( $catname as $result ) :
				$userid = $result->user_id;
				//echo $userid;
				if ( $userid != $curentuserid ) :
					$firstname     = get_user_meta( $userid, 'first_name', $single );
					$lastname      = get_user_meta( $userid, 'last_name', $single );
					$expertPrice   = $wpdb->get_var( "SELECT `price` FROM $pricetable WHERE `user_id`='$userid'" );
					$AboutYourSelf = bp_get_profile_field_data( 'field=AboutYourSelf&user_id=' . $userid );
					$title         = bp_get_profile_field_data( 'field=Title&user_id=' . $userid );
					$city          = bp_get_profile_field_data( 'field=City&user_id=' . $userid );
					$state         = bp_get_profile_field_data( 'field=State&user_id=' . $userid );
					$salutation    = bp_get_profile_field_data( 'field=salutation&user_id=' . $userid );
					?>
					<tr> <!-- Table Row -->
					   <td> <!-- Table Column -->
						   <div class="expertbycategorytags"> <!-- Expert  Category Main Div -->
							   <div class="row customexpert">  <!-- Expert Category Sub Div -->
								   <div class="col-md-3 col-lg-2 ce-image">
									   <a href="<?php echo site_url(); ?>/user-basic-profile/?ExpertId=<?php echo $userid; ?>"><?php echo get_avatar( $userid, $size ); ?></a>
								   </div>
								   <div class="col-md-6 col-lg-7 ce-content">
									   <h4 class="ce-title"><a href="<?php echo site_url(); ?>/user-basic-profile/?ExpertId=<?php echo $userid; ?>">
																				<?php
																				if ( $salutation ) {
																					echo $salutation . '&nbsp;';
																				}echo $firstname . '&nbsp;' . $lastname;
?>
</a></h4>
										<p class="ce-info"><span>
										<?php
										if ( $city ) {
											echo $city;
										} if ( $city && $state ) {
											echo ',&nbsp';
										} if ( $state ) {
											echo $state;}
	?>
	</span></p>
									   <p class="ce-details"><?php echo $AboutYourSelf; ?></p>
								   </div>
								   <div class="col-md-3 col-lg-3 ce-action">
									   <div class="ce-pricing">
										   <span class="profile-detail profile-stat price">
										   <input type="hidden" name="basic_amount"/>
											<?php
											   $expertprices = number_format( (float) $expertPrice, 2, '.', '' );
											?>
											<strong class="actual-price"><?php echo $expertprices; ?></strong>
														   <small>Credits per minute</small>
														   </span>
													   </div>
													   <a href="/request-a-call/?ExpertId=<?php echo $userid; ?>" class="call_link">Request A Call</a>
													   <div class="expRating">
														<?php
														$average  = $wpdb->get_var( "SELECT Avg(totalrating) FROM $ratingtable WHERE expertid = $userid" );
														$average2 = number_format( (float) $average, 2, '.', '' );
														if ( $average2 > 4.5 ) {
															echo '<img src="/wp-content/themes/boss-child/images/rating/five-star.png" title="Awesome - 5 stars"/>';
															echo '<br/>';
															echo $average2 . ' out of 5 stars';
														} elseif ( $average2 > 3.5 ) {
															echo '<img src="/wp-content/themes/boss-child/images/rating/four-star.png" title="Pretty good - 4 stars"/>';
															echo '<br/>';
															echo $average2 . ' out of 5 stars';
														} elseif ( $average2 > 2.5 ) {
															echo '<img src="/wp-content/themes/boss-child/images/rating/three-star.png" title="Average - 3 stars"/>';
															echo '<br/>';
															echo $average2 . ' out of 5 stars';
														} elseif ( $average2 > 1.5 ) {
															echo '<img src="/wp-content/themes/boss-child/images/rating/two-star.png" title="Bad - 2 stars"/>';
															echo '<br/>';
															echo $average2 . ' out of 5 stars';
														} elseif ( $average2 > 0.5 ) {
															echo '<img src="/wp-content/themes/boss-child/images/rating/one-star.png" title="Very Poor - 1 star"/>';
															echo '<br/>';
															echo $average2 . ' out of 5 stars';
														} else {
															echo '<small>No Rating For This Expert</small>';
														}
										?>
									</div>
									</div>
								</div> <!-- Expert Category Sub Div -->
							</div> <!-- Expert  Category Main Div -->
										</td> <!-- Table Column -->
									</tr> <!-- Table Row -->
									<?php
								endif;
			endforeach;
		endif;
	}
}
?>
