<?php 
include '../../../../wp-config.php';
global $wpdb,$current_user;
$user_id = $current_user->ID;
$pic = $_POST['nominee_photo'];
$table = $wpdb->prefix."pmpro_memberships_users";
$filename= $_FILES["nominee_photo"]["tmp_name"];			
		if($_FILES["nominee_photo"]["size"] > 0)
		{
			if (($handle = fopen($filename, "r")) !== FALSE) 
			{
				fgetcsv($handle); 
				$total_count = 0;				
				while (($getData = fgetcsv($handle, 10000, ",")) !== FALSE)
				{
					$c_user_id = $getData[1];
					$membership_charge = $getData[4];
					$blog_id = get_current_blog_id();
					$my_meta_key = "wp68_".$blog_id."_user_points";
					$user_credits = get_user_meta( $c_user_id, $my_meta_key, true);
					if($user_credits <= $membership_charge)
					{
						echo "User ID ".$c_user_id." does not have enough credit balance to purchase Membership Level ID ".$getData[2]."</br>"; 
					}
					else
					{
						$status = "admin_changed";
						$previous_status = "active";
						$enddate = $getData[14];
						$updatestatus = $wpdb->query("UPDATE $table SET status='$status', enddate='$enddate' WHERE user_id= '$c_user_id' AND status='$previous_status' AND membership_id != '$getData[2]'");
						$data = array( 
						'user_id' => $getData[1], 
						'membership_id' => $getData[2],
						'code_id' => $getData[3],
						'initial_payment' => $getData[4],
						'billing_amount' => $getData[5],
						'cycle_number' => $getData[6],
						'cycle_period' => $getData[7],
						'billing_limit' => $getData[8],
						'trial_amount' => $getData[9],
						'trial_limit' => $getData[10],
						'status' => $getData[11],
						'startdate' => $getData[12],
						'enddate' => $getData[13],
						'modified' =>$getData[14]
						);

						$format = array( 
								'%d',
								'%d', 
								'%d',
								'%s',
								'%s',
								'%d',
								'%s',
								'%d',
								'%s',
								'%d',
								'%s',
								'%s',
								'%s',
								'%s'
						);
						if($updatestatus ==1)
						{
							$insert_sql = $wpdb->insert($table, $data, $format);
						}
						else
						{
							echo "Error in Importing Membership Level for User ID ".$c_user_id." already has active membership level </br>";
						}
						
						if($updatestatus == 1 && $insert_sql == 1)
						{
							$total_count = $total_count + $insert_sql;
							$update_credit = $user_credits - $membership_charge;
							$update = update_user_meta($c_user_id, $my_meta_key, $update_credit);
						}
					}
				}
			echo $total_count. "Users Membership has been imported sucessfully";
	        fclose($file);	
			}
		}