(function ($) {
function simple_tooltip(target_items, name)
    {
        $(target_items).each(function(i)
        {
            $("body").append("<div class='"+name+"' id='"+name+i+"'><p>"+$(this).attr('title')+"</p></div>");
            var my_tooltip = $("#"+name+i);

            $(this).removeAttr("title").mouseover(function()
            {
                my_tooltip.css({opacity:0.8, display:"none"}).fadeIn(400);
            }).mousemove(function(kmouse)
            {
                my_tooltip.css({left:kmouse.pageX+15, top:kmouse.pageY+15});
            }).mouseout(function()
            {
                my_tooltip.fadeOut(400);
            });
        });
    }
    $(document).ready(function()
    {
		 simple_tooltip(".custom_tooltip","tooltip");
        /* Add Friend Function */
        $(document).on('click','.friend_add',function(e)
        {
                var initiator_user_id_add = $('#current_user_id').val();
                var friend_user_id_add = $('#expertid').val();
                $(this).removeClass('friend_add');
                $(this).addClass('friend_remove');
                $(this).html('<i class="fa fa-user-times" aria-hidden="true"></i>Cancel Friendship');
                $("html").addClass("overlay");
                $.ajax
                ({
                    type:'POST',
                    url: ajaxurl,
                    data:
                    {
                        action: 'vl_add_to_favorite',
                        initiator_user_id_add: initiator_user_id_add,
                        friend_user_id_add: friend_user_id_add
                    },
                    success: function(html)
                    {
                        $("html").removeClass("overlay");
                        alert("Request Sent");
                    },
                    error: function(MLHttpRequest, textStatus, errorThrown)
                    {

                    }
                });
        });
        /* Add Friend Function */

        /* Remove Friend Function */
        $(document).on('click','.friend_remove',function(e)
        {
            var initiator_user_id_remove = $('#current_user_id').val();
            var friend_user_id_remove = $('#expertid').val();
            $(this).removeClass('friend_remove');
            $(this).addClass('friend_add');
            $(this).html('<i class="fa fa-user-plus" aria-hidden="true"></i>Add Friend');
            $("html").addClass("overlay");
            $.ajax
            ({
                type:'POST',
                url: ajaxurl,
                data:
                {
                    action: 'vl_add_to_favorite',
                    initiator_user_id_remove: initiator_user_id_remove,
                    friend_user_id_remove: friend_user_id_remove
                },
                success: function(html)
                {

                    $("html").removeClass("overlay");
                    alert("Request Cancel");
                },
                error: function(MLHttpRequest, textStatus, errorThrown)
                {

                }

            });
        });
        /* Remove Friend Function */
       
        /* Schedule a Session Message For Expert*/
        $(document).on('click', '.ratingradio', function(e)
        {
            $("html").addClass("overlay");
            var ratingid = $(this).attr('data-id');
            var expertid = $("#expertid").val();
            $.ajax
                ({
                    type:'POST',
                    url: ajaxurl,
                    data:
                    {
                        action: 'vl_add_to_favorite',
                        ratingid: ratingid,
                        expertid: expertid
                    },
                    success: function(html)
                    {

                        $("html").removeClass("overlay");
                        alert("Your Rating Successfully Saved");
                        window.location.assign('/user-basic-profile/?ExpertId='+expertid);
                    },
                    error: function(MLHttpRequest, textStatus, errorThrown)
                    {
                    }
                });
        });

        

    $(document).on('click', '#remove_favorite', function(e)
    {
       if ($("#remove_favorite").is(":checked"))
        {
            $('.favorite_team').hide();
            $('.create_new_team_div').hide();
            $('.submit_message').addClass('remove_expert');
        }
    });
    $(document).on('click', '#add_favorite', function(e)
    {
       if ($("#add_favorite").is(":checked"))
        {
            $('.favorite_team').hide();
            $('.create_new_team_div').hide();
            $('.submit_message').addClass('fav_expert');
        }
    });
    $(document).on('click', '.fav_expert', function(e)
    {
       var expertid = $('#expertid').val();
       var current_user_id = $('#current_user_id').val();
       var confirmadd = confirm("Are You Sure");
       if(confirmadd==true)
       {
            $("html").addClass("overlay");
            $.ajax
            ({
                type:'POST',
                url: ajaxurl,
                data:
                {
                    action: 'vl_add_to_favorite',
                    expertidfav: expertid,
                    current_user_id: current_user_id
                },
                success: function(html)
                {
                   $("html").removeClass("overlay");
                   alert(html);
                   ///window.location.href = "/user-basic-profile/?ExpertId="+expertid;
                },
                error: function(MLHttpRequest, textStatus, errorThrown)
                {

                }
            });
         }
    });
    $(document).on('click', '.remove_expert', function(e)
    {
        var expertid = $('#expertid').val();
        var current_user_id = $('#current_user_id').val();
        var confirmadd = confirm("Are You Sure");
        if(confirmadd==true)
        {
                $("html").addClass("overlay");
                $.ajax
                ({
                    type:'POST',
                    url: ajaxurl,
                    data:
                    {
                        action: 'vl_remove_from_favorite',
                        expertidrem: expertid,
                        current_user_id: current_user_id
                    },
                    success: function(html)
                    {
                       $("html").removeClass("overlay");
                       alert(html);
                      ///window.location.href = "/user-basic-profile/?ExpertId="+expertid;
                    },
                    error: function(MLHttpRequest, textStatus, errorThrown)
                    {

                    }
                });
        }
    });
    });
})(jQuery);