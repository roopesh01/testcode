<?php
include '../../../../wp-config.php';
global $wpdb;
$table           = $wpdb->prefix . 'venuemeetingdetail';
$membershiptable = $wpdb->prefix . 'pmpro_memberships_users';
$currentuserid   = get_current_user_id();

if ( isset( $_POST['deletevalue'] ) || isset( $_POST['tableid'] ) ) {
	$val            = vl_sanitize_unslash( 'deletevalue' );
	$dataid         = vl_sanitize_unslash( 'tableid' );
	$userdeletarray = explode( ',', $val );

	$usersexist     = $wpdb->get_var( $wpdb->prepare( "SELECT `invitedusers` FROM $table WHERE `currentuserid`= %d AND `id`= %d", $currentuserid, $dataid ) );

	$userexistarray = explode( ',', $usersexist );
	$removeselected = array_diff( $userexistarray, $userdeletarray );
	$updateuser     = implode( ',', $removeselected );

	$update = $wpdb->update(
		$table,
		array(
			'invitedusers' => $updateuser,
		),
		array(
			'currentuserid' => $currentuserid,
			'id'            => $dataid,
		)
	);

	if ( $update ) {
		echo 'Selected Users Deleted Successfully';
	}
}
if ( isset( $_POST['venuedate'] ) || isset( $_POST['venuetime'] ) ) {
	$venuedate       = vl_sanitize_unslash( 'venuedate' );
	$venuetime       = vl_sanitize_unslash( 'venuetime' );
	$timeformat      = vl_sanitize_unslash( 'timeformat' );
	$meetinglocation = vl_sanitize_unslash( 'meetinglocation' );
	$address         = vl_sanitize_unslash( 'address' );
	$virtualdetail   = vl_sanitize_unslash( 'virtualdetail' );
	$meetingdetail   = vl_sanitize_unslash( 'meetingdetail' );
	$radioValue      = vl_sanitize_unslash( 'radioValue' );
	$meeting_title   = vl_sanitize_unslash( 'meeting_title' );
	$meeting_desc    = vl_sanitize_unslash( 'meeting_desc' );
	$timezones       = vl_sanitize_unslash( 'timezones' );

	$userexist = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM $table WHERE `currentuserid`=%d AND `scheduledmeeting` IS NULL ORDER BY `id` DESC LIMIT 1", $currentuserid ) );


	if ( 'livevenue' === $radioValue ) {
		if ( $userexist ) {
			$update = $wpdb->update(
				$table,
				array(
					'meetingname'        => $meeting_title,
					'description'        => $meeting_desc,
					'venuedate'          => $venuedate,
					'venuetime'          => $venuetime,
					'venuetype'          => $radioValue,
					'virtualmeetinginfo' => $virtualdetail,
					'howtofind'          => $meetingdetail,
					'timezone'           => $timezones,
				),
				array(
					'currentuserid' => $currentuserid,
				)
			);
		} else {
			$wpdb->insert(
				$table,
				array(
					'currentuserid' => $currentuserid,
					'venuedate'     => $venuedate,
					'venuetype'     => $radioValue,
					'venuetime'     => $venuetime,
					'timeformat'    => $timeformat,
					'venuename'     => $meetinglocation,
					'address'       => $address,
					'howtofind'     => $meetingdetail,
					'meetingname'   => $meeting_title,
					'description'   => $meeting_desc,
					'timezone'      => $timezones,
				),
				array(
					'%d',
					'%s',
					'%s',
					'%s',
					'%s',
					'%s',
					'%s',
					'%s',
					'%s',
					'%s',
					'%s',
				)
			);
			 //echo "successfully insert";
		}
	} elseif ( 'virtualvenue' === $radioValue ) {
		if ( $userexist ) {
			$update = $wpdb->update(
				$table,
				array(
					'meetingname'        => $meeting_title,
					'description'        => $meeting_desc,
					'venuedate'          => $venuedate,
					'venuetime'          => $venuetime,
					'venuetype'          => $radioValue,
					'virtualmeetinginfo' => $virtualdetail,
					'howtofind'          => $meetingdetail,
					'timezone'           => $timezones,
				),
				array(
					'currentuserid' => $currentuserid,
				)
			);
		} else {
			$wpdb->insert(
				$table,
				array(
					'currentuserid'      => $currentuserid,
					'venuedate'          => $venuedate,
					'venuetime'          => $venuetime,
					'timeformat'         => $timeformat,
					'venuetype'          => $radioValue,
					'virtualmeetinginfo' => $virtualdetail,
					'howtofind'          => $meetingdetail,
					'meetingname'        => $meeting_title,
					'description'        => $meeting_desc,
					'timezone'           => $timezones,
				),
				array(
					'%d',
					'%s',
					'%s',
					'%s',
					'%s',
					'%s',
					'%s',
					'%s',
					'%s',
					'%s',
				)
			);
			 //echo "successfully insert";
		}
	}
}
if ( isset( $_POST['meetingnotify'] ) ) {
	include VL_THEME_DIR . '/email-template/schedule_meeting.php';
}
