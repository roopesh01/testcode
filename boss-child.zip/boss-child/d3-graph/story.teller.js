(function($) {
  "use strict";
  $.fn.buildNetwork = function(options) {
    $(this).each(function(index, elem) {
      var self = null;
      function plugIn($el, options, elCount) {
        self = this;
        self.defaults = {
          width: 500,
          height: 500,
          nodes: [],
          links: [],
          isAdmin:true,
          enableNodeText: true,
          nodeTextAnchor: "end",
          nodeFontSize: 10,
          colorCategory: "schemeCategory20",

          nodeRadius: 5,
          nodeOpacity: 0.7,
          enableNodeDrag: true,
          enableStickyMode: false,
          nodeStrokeWidth: 2,
          nodeStrokeColor: "#fff",
          activeNodeRadius: 7,
          activeNodeStrokeWidth: 3,
          activeNodeStrokeColor: "#5f5f5f",

          linkType: "line",
          linkWidth: 1,
          activeLinkWidth: 2,
          linkColor: "#999",
          linkOpacity: 0.2,
          activeLinkColor: "#999",
          enableLinkArrow: false,
          linkArrowColor: "#999",

          maxZoom: 8,
          minZoom: 1,
          enableZoom: true,
          enableDblcZoom: false,
          storyDelay: 1000,
          animationDelay: 3000,
          storyHolder: {
            steps: [],
            title: ""
          },
          autoPlayStory: false
        };
        self.defaults = $.extend(self.defaults, options);
        self.svg = d3.select($el);
        self.svg.html("");
        self.elCount = elCount;
        self.simulation = null;
        self.defaults.width = $($el).width() || self.defaults.width;
        self.defaults.height = $($el).height() || self.defaults.height;
        self.nodeContainer = null;
        self.graphZoom = d3
          .zoom()
          .scaleExtent([self.defaults.minZoom, self.defaults.maxZoom])
          .on("zoom", self.zoomed);

        self.nodeDrag = d3
          .drag()
          .on("start", self.dragstarted)
          .on("drag", self.dragged)
          .on("end", self.dragended);

        self.color = d3.scaleOrdinal(d3[self.defaults.colorCategory]);
        self.state = {
          ids: [],
          title: "",
          content: "",
          footer: ""
        };
        self.storyText = "";
        self.stateCounter = 0;
        self.nodeLayer = [];
        self.links = [];
        self.texts = [];
        self.init();
      }

      $.extend(plugIn.prototype, {
        init: function() {
          if(self.defaults.isAdmin){            
          }
          self.setupForce();
          self.buildElements();
          self.registerListener();
        },

        setupForce: function() {
          self.simulation = d3
            .forceSimulation()
            .force(
              "link",
              d3.forceLink().id(function(d) {
                return d.id;
              })
            )
            .force(
              "charge",
              d3
                .forceManyBody()
                .strength(
                  -(
                    self.defaults.nodeRadius * self.defaults.nodeRadius +
                    self.defaults.nodeStrokeWidth
                  )
                )
            )
            .force(
              "center",
              d3.forceCenter(self.defaults.width / 2, self.defaults.height / 2)
            );
        },

        buildElements: function() {
          if (self.defaults.enableZoom) {
            var rect = self.svg
              .append("rect")
              .attr("width", self.defaults.width)
              .attr("height", self.defaults.height)
              .style("fill", "none")
              .style("pointer-events", "all")
              .call(self.graphZoom);
            if (!self.defaults.enableDblcZoom) {
              rect.on("dblclick.zoom", null);
            }
          }

          self.nodeContainer = self.svg.append("g").classed("g-main", true);

          var linkLayer = self.nodeContainer.append("g").attr("class", "links");

          self.nodeLayer = self.nodeContainer
            .append("g")
            .attr("class", "nodes")
            .selectAll(".node")
            .data(self.defaults.nodes)
            .enter()
            .append("g")
            .attr("class", "node")
            .on("dblclick", self.markToState);

          if (self.defaults.enableNodeDrag) {
            self.nodeLayer.call(self.nodeDrag);
          }

          if (self.defaults.enableNodeText) {
            self.texts = self.nodeLayer
              .append("text")
              .style("text-anchor", self.defaults.nodeTextAnchor)
              .attr("y", -self.defaults.nodeRadius)
              .text(function(d) {
                return d.id;
              });
          }

          var nodes = self.nodeLayer
            .append("circle")
            .style("r", self.defaults.nodeRadius)
            .style("stroke-width", self.defaults.nodeStrokeWidth)
            .style("stroke", self.defaults.nodeStrokeColor)
            .style("stroke-opacity", self.defaults.nodeOpacity)
            .style("fill-opacity", self.defaults.nodeOpacity)
            .style("fill", function(d) {
              return self.color(d.group);
            });

          self.links = linkLayer
            .selectAll("line")
            .data(self.defaults.links)
            .enter()
            .append("line")
            .style("stroke", self.defaults.linkColor)
            .style("stroke-width", function(d) {
              return Math.sqrt(d.value);
            });
          var marker = self.svg
            .append("defs")
            .append("marker")
            .attr("id", "storyTriangle" + self.elCount)
            .attr("refX", 0)
            .attr("refX", self.defaults.nodeRadius * 2)
            .attr("refY", self.defaults.nodeRadius / 2)
            .attr("markerUnits", "userSpaceOnUse")
            .attr("markerWidth", self.defaults.nodeRadius)
            .attr("markerHeight", self.defaults.nodeRadius)
            .attr("orient", "auto")
            .attr("fill", self.defaults.linkArrowColor)
            .attr("stroke-width", "1")
            .append("path")
            //.attr("d", "M 0 0 12 6 0 12 3 6");
            .attr(
              "d",
              "M 0 0 " +
                self.defaults.nodeRadius +
                " " +
                self.defaults.nodeRadius / 2 +
                " 0 " +
                self.defaults.nodeRadius +
                " 1 " +
                self.defaults.nodeRadius / 2
            );

          if (self.defaults.enableLinkArrow) {
            self.links.attr(
              "marker-end",
              "url(#storyTriangle" + self.elCount + ")"
            );
          }

          nodes.on("mouseenter", function(data, index) {
            if (d3.select(this).attr("class") == "active") {
            }
          });

          self.simulation.nodes(self.defaults.nodes).on("tick", tick);
          self.simulation.force("link").links(self.defaults.links);
          function tick() {
            self.links
              .attr("x1", function(d) {
                return d.source.x;
              })
              .attr("y1", function(d) {
                return d.source.y;
              })
              .attr("x2", function(d) {
                return d.target.x;
              })
              .attr("y2", function(d) {
                return d.target.y;
              });

            self.nodeLayer.attr("transform", function(d) {
              return "translate(" + d.x + "," + d.y + ")";
            });
          }
        },
        registerListener: function() {
          $(self.svg.node()).on("story.shortSteps", function(
            event,
            { data: short }
          ) {
            var temp = self.defaults.storyHolder.steps[short.startIndex];
            self.defaults.storyHolder.steps.splice(short.startIndex, 1);
            self.defaults.storyHolder.steps.splice(short.endIndex, 0, temp);
            /*console.log(
              self.defaults.storyHolder.steps
                .map(function(i) {
                  console.log(i);
                  return i;
                })
                .join(", ")
            );*/
            self.preventEvent(event);
          });

          $(self.svg.node()).on("story.stepRemoved", function(
            event,
            { data: index }
          ) {
            console.log(index);
            self.defaults.storyHolder.steps.splice(index, 1);
            self.preventEvent(event);
          });

          $(self.svg.node()).on("story.next", function(event, data) {
            self.defaults.autoPlayStory = false;
            self.next();
            self.preventEvent(event);
          });

          $(self.svg.node()).on("story.previous", function(event, data) {
            self.defaults.autoPlayStory = false;
            self.previous();
            self.preventEvent(event);
          });

          if (self.defaults.enableNodeText) {
            $(self.svg.node()).on("story.enableNodeText", function(
              event,
              data
            ) {
              if (data.checked) {
                self.texts.style("display", "block");
              } else {
                self.texts.style("display", "none");
              }
              self.preventEvent(event);
            });
          }
          $(self.svg.node()).on("story.stateElemRemove", function(
            event,
            { data: id }
          ) {
            var index = self.state.ids.indexOf(id);
            if (index > -1) {
              self.state.ids.splice(index, 1);
            }
            self.preventEvent(event);
          });

          $(self.svg.node()).on("story.enableStickyMode", function(
            event,
            data
          ) {
            if (data.checked) {
              self.defaults.enableStickyMode = true;
            } else {
              self.defaults.enableStickyMode = false;
            }
            self.preventEvent(event);
          });

          $(self.svg.node()).on("story.enableLinkArrow", function(event, data) {
            if (data.checked) {
              self.links.attr(
                "marker-end",
                "url(#storyTriangle" + self.elCount + ")"
              );
            } else {
              self.links.attr("marker-end", "");
            }
            self.preventEvent(event);
          });

          $(self.svg.node()).on("story.pushState", function(
            event,
            { data: step }
          ) {
            $.extend(self.state, step);
            self.markToStory();
            self.preventEvent(event);
          });

          $(self.svg.node()).on("story.playStory", function(event, data) {
            self.defaults.autoPlayStory = true;
            self.stateCounter = -1;
            self.next();
            self.preventEvent(event);
          });
        },
        next: function() {          
          self.stateCounter++;
          if (self.stateCounter >= self.defaults.storyHolder.steps.length) {
            self.stateCounter = 0;
          }
          self.svg.call(self.transition);
        },
        previous: function() {
          self.stateCounter--;
          if (self.stateCounter < 0) {
            self.stateCounter = self.defaults.storyHolder.steps.length - 1;
          }
          self.svg.call(self.transition);
        },
        markToState: function(d) {
          self.state.ids.push(d.id);
          $(self.svg.node()).trigger("story.graphStateAdded", {
            data: d
          });
        },
        markToStory: function() {
          
          self.defaults.storyHolder.steps.push(self.state);
          self.state = {
            ids: [],
            title: "",
            content: "",
            footer: ""
          };
        },
        transform: function(a, index, graph) {
          var pointArr = [];
          var totalNodes = self.defaults.nodes.length;
          self.svg.selectAll(".node").classed("active", false);
          self.links
            .style("stroke", self.defaults.linkColor)
            .attr("marker-end", "")
            .style("stroke-opacity", self.defaults.linkOpacity);
          self.nodeLayer
            .select("circle")
            .style("stroke", self.defaults.nodeStrokeColor);

          /*var lengthRandom = Math.floor(Math.random() * 5) + 1;
              for (var i = 0; i < lengthRandom; i++) {
                  var tempRandom = Math.floor(Math.random() * totalNodes);
                  var tNode = d3.select(nodeLayer.nodes()[tempRandom]);
                  tNode.classed("active", true);
                  tNode.select("circle").style("stroke", defaults.activeNodeStrokeColor);
                  story += "<span>" + tNode.datum().id + "</span><br/>";
                  pointArr.push(tNode);
                  pointArrData.push(tNode.datum());
              }*/
          var step = self.defaults.storyHolder.steps[self.stateCounter];
          if (!step) {
            return;
          }
          var tNodes = step.ids;
          if (tNodes.length <= 0) {
            return false;
          }
          var filterNodes = self.nodeLayer.filter(function(d) {
            if (tNodes.includes(d.id)) {
              pointArr.push(d);
              return true;
            } else {
              return false;
            }
          });
          filterNodes
            .classed("active", true)
            .select("circle")
            .style("stroke", self.defaults.activeNodeStrokeColor);
          var connectedLinks = self.links.filter(function(d) {
            return pointArr.includes(d.source) && pointArr.includes(d.target);
          });

          connectedLinks
            .style("stroke", self.defaults.activeLinkColor)
            .attr("marker-end", "url(#storyTriangle" + self.elCount + ")")
            .style("stroke-opacity", "1");
          var xc = d3.extent(pointArr, function(d) {
            return d.x;
          });

          var yc = d3.extent(pointArr, function(d) {
            return d.y;
          });

          var dx = xc[1] - xc[0],
            dy = yc[1] - yc[0],
            x = (xc[0] + xc[1]) / 2,
            y = (yc[0] + yc[1]) / 2,
            scale = Math.max(
              1,
              Math.min(
                8,
                0.9 /
                  Math.max(dx / self.defaults.width, dy / self.defaults.height)
              )
            ),
            translate = [
              self.defaults.width / 2 - scale * x,
              self.defaults.height / 2 - scale * y
            ];
          $(self.svg.node()).trigger("story.stepChanged", {
            data: step
          });
          return d3.zoomIdentity
            .translate(translate[0], translate[1])
            .scale(scale);
        },
        transition: function(svg) {
          svg
            .transition()
            .delay(self.defaults.storyDelay)
            .duration(self.defaults.animationDelay)
            .call(self.graphZoom.transform, self.transform)
            .on("end", function() {
              if (self.defaults.autoPlayStory) {
                if (
                  self.stateCounter ===
                  self.defaults.storyHolder.steps.length - 1
                ) {
                  self.defaults.autoPlayStory = false;
                } else {
                  self.next();
                }
              }
            });
        },
        phyllotaxis: function(radius) {
          var theta = Math.PI * (3 - Math.sqrt(5));
          return function(i) {
            var r = radius * Math.sqrt(i),
              a = theta * i;
            return [
              self.defaults.width / 2 + r * Math.cos(a),
              self.defaults.height / 2 + r * Math.sin(a)
            ];
          };
        },
        zoomed: function() {
          self.nodeContainer.attr("transform", d3.event.transform);
        },
        dragstarted: function(d) {
          if (!d3.event.active) self.simulation.alphaTarget(0.3).restart();
          d.fx = d.x;
          d.fy = d.y;
        },
        dragged: function(d) {
          d.fx = d3.event.x;
          d.fy = d3.event.y;
        },
        dragended: function(d) {
          if (!d3.event.active) self.simulation.alphaTarget(0);
          if (self.defaults.enableStickyMode) {
            d.fixed = true;
          } else {
            d.fx = null;
            d.fy = null;
          }
        },
        preventEvent: function(event) {
          event.stopPropagation();
          event.preventDefault();
        }        
      });
      new plugIn(elem, $.extend(true, {}, options), index);
    });
    return this;
  };
})(jQuery);
