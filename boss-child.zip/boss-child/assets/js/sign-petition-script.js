jQuery(document).ready(function(){
    jQuery('#bar4').barfiller({ barColor: '#ff6060', duration: 3000 });
    jQuery('.form_error').hide();
    jQuery(document).on('click', '.js-sign-button', function(e){
        e.preventDefault();
        var firstname = jQuery('.js-first-name').val();
        var lastname = jQuery('.js-last-name').val();
           var email = jQuery('.js-email-sign').val();
           var city = jQuery('.js-city-sign').val();
           var postal_code = jQuery('.js-postcode-sign').val();
        if(firstname== '')
        {
              jQuery('.js-first-name').next().show();
        }else{

            jQuery('.js-first-name').next().hide();
        }

        if(lastname== '')
        {
              jQuery('.js-last-name').next().show();
        }else{

            jQuery('.js-last-name').next().hide();
        }


        if(email== '')
        {
               jQuery('.js-email-sign').next().show();

        }else{

            jQuery('.js-email-sign').next().hide();
        }

        if(IsEmail(email)==false)
        {
            jQuery('#invalid_email').show();

        }else{

            jQuery('#invalid_email').hide();
        }

        if(city== '')
        {
            jQuery('.js-city-sign').next().show();
        }else{

            jQuery('.js-city-sign').next().hide();
        }

        if(postal_code== ''){
            jQuery('.js-postcode-sign').next().show();
        }else{

            jQuery('.js-postcode-sign').next().hide();
        }

         if(postal_code== '' || city== '' || email== '' || IsEmail(email)==false || lastname== '' || firstname== ''){
            return false;
        }

        function IsEmail(email) {
            var regex = /^([a-zA-Z0-9_\.\-\+])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
            if(!regex.test(email)) {
                   return false;
               }else{
                   return true;
            }
          }
        var data = new FormData(document.getElementById("sign_petition"));
        data.append('action', 'vl_sign_petition');
        jQuery.ajax({
            type: "POST",
            url: ajaxurl,
            data: data,
            contentType: false,
            cache: false,
            processData:false,
            success: function (data)
            {
            var str = data;
            var res = str.replace('{"', '');
            var another = res.replace('":"', '');
            var another_re = another.replace('"}', '');
            var res_remove = another_re.replace('result', '');
            var one_remove = res_remove.replace('1', '');
            var fail_remove = one_remove.replace('failure","messages":["', '');
            var final_remove = fail_remove.replace('"]}', '');
            jQuery(".my_form_error").html(final_remove);
            window.location.reload();
            },
            error: function (error)
            {
              jQuery(".my_form_error").html(error);
                jQuery(".my_form_error").css("display","block");
            }
        });
    });
});