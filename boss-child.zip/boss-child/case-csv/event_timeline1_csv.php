<?php
	include '../../../../wp-config.php';
	global $wpdb;
	$filename   = 'case_events_timeline_level1.csv';
	$header_row = array(
		0  => 'id',
		1  => 'event_id',
		2  => 'title',
		3  => 'start_date',
		4  => 'duration',
		5  => 'end_date',
		6  => 'color',
		7  => 'tags',
		8  => 'links',
		9  => 'summary',
		10 => 'complete',
		11 => 'category',
		12 => 'person',
	);
	$data_rows  = array();
	$table      = $wpdb->prefix . 'case_events_timeline_level1';
	$result     = $wpdb->get_results( "SELECT * FROM $table WHERE `post_type`='question'" );
	foreach ( $result as $results ) {
		$row         = array();
		$row[0]      = $results->id;
		$row[1]      = $results->event_id;
		$row[2]      = $results->title;
		$row[3]      = $results->start_date;
		$row[4]      = $results->duration;
		$row[5]      = $results->end_date;
		$row[6]      = $results->color;
		$row[7]      = $results->tags;
		$row[8]      = $results->links;
		$row[9]      = $results->summary;
		$row[10]     = $results->complete;
		$row[11]     = $results->category;
		$row[12]     = $results->person;
		$data_rows[] = $row;
	}
	$fh = @fopen( 'php://output', 'w' );
	fprintf( $fh, chr( 0xEF ) . chr( 0xBB ) . chr( 0xBF ) );
	header( 'Cache-Control: must-revalidate, post-check=0, pre-check=0' );
	header( 'Content-Description: File Transfer' );
	header( 'Content-type: text/csv' );
	header( "Content-Disposition: attachment; filename={$filename}" );
	header( 'Expires: 0' );
	header( 'Pragma: public' );
	fputcsv( $fh, $header_row );
	foreach ( $data_rows as $data_row ) {
		fputcsv( $fh, $data_row );
	}
	fclose( $fh );
	die();



