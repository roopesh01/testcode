var caseNewsL2;
var caseNewsL1;
var caseNewsL3
var search_by;
var search_in;
var fitler_value;
(function($) {
    jQuery(document).ready(function() {
        jQuery('.listsearch').keyup(function() {
            var searchText = jQuery(this).val().toUpperCase();
            var parentid = jQuery(this).closest(".options_box").prop("id");
            jQuery('#' + parentid + ' .filterlistul').show();
            jQuery('#' + parentid + ' ul.filterlistul > li').each(function() {
                var currentLiText = jQuery(this).text(),
                    showCurrentLi = currentLiText.toUpperCase().indexOf(searchText) > -1;
                jQuery(this).toggle(showCurrentLi);
            });
        });
        var caseNewsL2 = jQuery('#case-news-l2').DataTable({
            dom: 'lrtip',
            "lengthChange": false,
            initComplete: function() {}
        });
        var caseNewsL1 = jQuery('#case-news-l1').DataTable({
            dom: 'lrtip',
            "lengthChange": false,
            initComplete: function() {}
        });
        var caseNewsL3 = jQuery('#case-news-l3').DataTable({
            dom: 'lrtip',
            "lengthChange": false,
            initComplete: function() {}
        });
        jQuery(".int_filter_option").click(function() {
            jQuery(".title_options").hide();
            jQuery(".tag_options").hide();
            jQuery(".sort_options").hide();
            jQuery(".author_options").hide();
            jQuery(".date_options").hide();
            jQuery(".format_options").hide();
            jQuery(".sort_options").hide();
            var filter = jQuery(this).attr('data-filter-attr');
            var alfilter = jQuery(".checkfilter").attr('data-cfname-attr');
            var afilvalue = jQuery(".checkfilter").val();
            if (filter == "reset") {
                window.location.href = 'intelligence';
            } else {
                if (filter == "tag") {
                    jQuery(".tag_options").show();
                    jQuery(".sort_options").hide();
                    jQuery(".author_options").hide();
                    jQuery(".date_options").hide();
                    jQuery(".title_options").hide();
                    jQuery(".format_options").hide();
                    jQuery(".sort_options").hide();
                } else if (filter == "author") {
                    jQuery(".tag_options").hide();
                    jQuery(".sort_options").hide();
                    jQuery(".author_options").show();
                    jQuery(".date_options").hide();
                    jQuery(".title_options").hide();
                    jQuery(".format_options").hide();
                    jQuery(".sort_options").hide();
                } else if (filter == "date") {
                    jQuery(".tag_options").hide();
                    jQuery(".sort_options").hide();
                    jQuery(".author_options").hide();
                    jQuery(".date_options").show();
                    jQuery(".title_options").hide();
                    jQuery(".format_options").hide();
                    jQuery(".sort_options").hide();
                } else if (filter == "title") {
                    jQuery(".tag_options").hide();
                    jQuery(".sort_options").hide();
                    jQuery(".author_options").hide();
                    jQuery(".date_options").hide();
                    jQuery(".title_options").show();
                    jQuery(".format_options").hide();
                    jQuery(".sort_options").hide();
                } else if (filter == "sort") {
                    jQuery(".tag_options").hide();
                    jQuery(".sort_options").hide();
                    jQuery(".author_options").hide();
                    jQuery(".date_options").hide();
                    jQuery(".title_options").hide();
                    jQuery(".format_options").hide();
                    jQuery(".sort_options").show();
                } else if (filter == "format") {
                    jQuery(".tag_options").hide();
                    jQuery(".sort_options").hide();
                    jQuery(".author_options").hide();
                    jQuery(".date_options").hide();
                    jQuery(".title_options").hide();
                    jQuery(".format_options").show();
                    jQuery(".sort_options").hide();
                }
            }
        });
        jQuery(document).click(function(e) {
            if (!jQuery(e.target).hasClass("int_filter_option") &&
                jQuery(e.target).parents(".options_box").length === 0) {
                jQuery(".options_box").hide();
            }
        });
        jQuery('.options_box ul li').on('click', function() {
            jQuery('.options_box ul li').removeClass("active");
            var levelinfo = jQuery('.current_level').val();
            var whatsSelected = [];
            var currentClass = jQuery(this).closest(".options_box").prop("id");
            var str1 = jQuery.trim(jQuery(this).attr('data-filter-value'));
            jQuery(this).addClass("active");
            var txt = str1.replace(/\,/g, "");
            if (txt) {
                jQuery('#keywordList').append('<span class="' + currentClass + '">' + txt.toLowerCase() + '</span>');
                jQuery('#tags').append('<span class="' + currentClass + '">' + txt.toLowerCase() + '</span>');
            }
            jQuery('.myInput').val("");
            if (currentClass == "sort_filter") {
                search_in = 9;
            } else if (currentClass == "tag_filter") {
                search_in = 3;
            } else if (currentClass == "author_filter") {
                search_in = 2;
            } else if (currentClass == "date_filter") {
                search_in = 4;
            } else if (currentClass == "format_filter") {
                search_in = 7;
            }
            search_by = currentClass;
            fitler_value = txt;
            jQuery("#tags span." + search_by).each(function(index) {
                var spanText = jQuery(this).text();
                whatsSelected.push(spanText);
            });
            if (fitler_value != '') {
                whatsSelected.push(fitler_value);
            }
            console.log(whatsSelected);
            if (levelinfo === 'Level 3') {
                caseNewsL3.columns(search_in).search(whatsSelected.join('|'), true).draw();
            } else if (levelinfo === 'Level 2') {
                caseNewsL2.columns(search_in).search(whatsSelected.join('|'), true).draw();
            } else if (levelinfo === 'Level 1') {
                caseNewsL1.columns(search_in).search(whatsSelected.join('|'), true).draw();
            } else {
                alert('Error in FInding Result');
            }
        });
        jQuery(".category_filter").click(function() {
            var whatsSelected = [];
            var levelinfo = jQuery('.current_level').val();
            var currentClass = jQuery(this).attr("class");
            var buttonid = jQuery(this).attr('id');
            var str1 = jQuery.trim(jQuery('#' + buttonid).attr('data-term-id'));
            var txt = str1.replace(/\,/g, "");
            search_in = 5;
            if (txt) {
                jQuery('#keywordList').append('<span class="' + currentClass + '">' + txt.toLowerCase() + '</span>');
                jQuery('#tags').append('<span class="' + currentClass + '">' + txt.toLowerCase() + '</span>');
            }
            search_by = currentClass;
            fitler_value = txt;
            jQuery("#tags span." + search_by).each(function(index) {
                var spanText = jQuery(this).text();
                whatsSelected.push(spanText);
            });
            if (fitler_value != '') {
                whatsSelected.push(fitler_value);
            }
            console.log(whatsSelected);
            if (levelinfo === 'Level 3') {
                caseNewsL3.columns(search_in).search(whatsSelected.join('|'), true).draw();
            } else if (levelinfo === 'Level 2') {
                caseNewsL2.columns(search_in).search(whatsSelected.join('|'), true).draw();
            } else if (levelinfo === 'Level 1') {
                caseNewsL1.columns(search_in).search(whatsSelected.join('|'), true).draw();
            } else {
                alert('Error in FInding Result');
            }
        });
        jQuery('.ap-search-input').focusout(function() {
            var levelinfo = jQuery('.current_level').val();
            var whatsSelected = [];
            var currentClass = jQuery(this).attr("class");
            var str1 = jQuery.trim(jQuery(this).val());
            var txt = str1.replace(/\,/g, "");
            search_in = 1;
            if (txt) {
                jQuery('#keywordList').append('<span class="' + currentClass + '">' + txt.toLowerCase() + '</span>');
                jQuery('#tags').append('<span class="' + currentClass + '">' + txt.toLowerCase() + '</span>');
            }
            jQuery(this).val("");
            search_by = currentClass;
            fitler_value = txt;
            jQuery("#tags span." + search_by).each(function(index) {
                var spanText = jQuery(this).text();
                whatsSelected.push(spanText);
            });
            if (fitler_value != '') {
                whatsSelected.push(fitler_value);
            }
            console.log(whatsSelected);
            if (levelinfo === 'Level 3') {
                caseNewsL3.columns(search_in).search(whatsSelected.join('|'), true).draw();
            } else if (levelinfo === 'Level 2') {
                caseNewsL2.columns(search_in).search(whatsSelected.join('|'), true).draw();
            } else if (levelinfo === 'Level 1') {
                caseNewsL1.columns(search_in).search(whatsSelected.join('|'), true).draw();
            } else {
                alert('Error in FInding Result');
            }
        });
        jQuery('#keywordList').on('click', 'span', function() {
            var levelinfo = jQuery('.current_level').val();
            var whatsSelected = [];
            var currentClass = jQuery(this).attr('class');
            var currentText = jQuery(this).text();
            jQuery("#tags").find("span." + currentClass).each(function() {
                var spanValue = jQuery(this).text();
                if (spanValue == currentText) {
                    jQuery(this).remove();
                }
            });
            jQuery(this).remove();
            if (currentClass == "sort_filter") {
                search_in = 9;
            } else if (currentClass == "tag_filter") {
                search_in = 3;
            } else if (currentClass == "author_filter") {
                search_in = 2;
            } else if (currentClass == "date_filter") {
                search_in = 4;
            } else if (currentClass == "format_filter") {
                search_in = 7;
            }
            search_by = currentClass;
            jQuery("#tags span." + search_by).each(function(index) {
                var spanText = jQuery(this).text();
                whatsSelected.push(spanText);
            });
            if (levelinfo === 'Level 3') {
                caseNewsL3.columns(search_in).search(whatsSelected.join('|'), true).draw();
            } else if (levelinfo === 'Level 2') {
                caseNewsL2.columns(search_in).search(whatsSelected.join('|'), true).draw();
            } else if (levelinfo === 'Level 1') {
                caseNewsL1.columns(search_in).search(whatsSelected.join('|'), true).draw();
            } else {
                alert('Error in FInding Result');
            }
        });
        jQuery('#sort_filter ul li').on('click', function() {
            var levelinfo = jQuery('.current_level').val();
            jQuery('#sort_filter ul li').removeClass("active");
            var sortvalue = jQuery(this).attr('data-sortvalue-attr');
            jQuery(this).addClass("active");
            console.log(sortvalue);
            if (sortvalue == "newest") {
                if (levelinfo === 'Level 3') {
                    caseNewsL3.order([9, 'desc']).draw();
                } else if (levelinfo === 'Level 2') {
                    caseNewsL2.order([9, 'desc']).draw();
                } else if (levelinfo === 'Level 1') {
                    caseNewsL1.order([9, 'desc']).draw();
                } else {
                    alert('Error in FInding Result');
                }

            } else if (sortvalue == "oldest") {
                if (levelinfo === 'Level 3') {
                    caseNewsL3.order([9, 'asc']).draw();
                } else if (levelinfo === 'Level 2') {
                    caseNewsL2.order([9, 'asc']).draw();
                } else if (levelinfo === 'Level 1') {
                    caseNewsL1.order([9, 'asc']).draw();
                } else {
                    alert('Error in FInding Result');
                }
            } else {
                if (levelinfo === 'Level 3') {
                    caseNewsL3.order([9, 'desc']).draw();
                } else if (levelinfo === 'Level 2') {
                    caseNewsL2.order([9, 'desc']).draw();
                } else if (levelinfo === 'Level 1') {
                    caseNewsL1.order([9, 'desc']).draw();
                } else {
                    alert('Error in FInding Result');
                }
            }
        });
    });

})(jQuery);