<?php
require( '../../../../wp-load.php' );
global $wpdb;

$user_id        = get_current_user_id();
$expertid       = vl_sanitize_unslash( 'id' );
$date           = vl_sanitize_unslash( 'date' );
$time           = vl_sanitize_unslash( 'time' );
$action         = vl_sanitize_unslash( 'performaction' );
$expert_country = vl_sanitize_unslash( 'country' );
$expert_city    = vl_sanitize_unslash( 'city' );

if ( $action == 'deletebooking' ) {
	echo $delete_query = $wpdb->delete(
		$wpdb->vl_expert_avilability_calender,
		array(
			'expert_id'      => $expertid,
			'available_time' => $time,
			'available_date' => $date,
		)
	);

	die();
}

if ( empty( $user_id ) ) {
	wp_send_json( array(
		'login_error' => 1,
		'redirect'    => wp_login_url(),
	) );
}

$user_timezone = maybe_unserialize( get_user_meta( $user_id, 'user_timezone_detail', true ) );

if ( ! empty( $user_timezone['timeZoneId'] ) ) {
	$success        = 0;
	$insert_message = 'Timezone id is not found. Please set timezone ';
	wp_send_json( array(
		'success'       => $success,
		'insertmessage' => $insert_message,
		'query'         => 'Timezone is not set.',
	) );
}

$timezoneid       = $user_timezone['timeZoneId'];
$newcreatedDate   = date( 'd-m-Y', strtotime( $date ) );
$mycall_timings   = explode( '-', $time );
$only_start_time  = $mycall_timings[0];
$only_end_time    = $mycall_timings[1];
$start_timed      = $newcreatedDate . ' ' . $mycall_timings[0];
$end_timed        = $newcreatedDate . ' ' . $mycall_timings[1];
$newdate          = new DateTime( $start_timed, new DateTimeZone( $timezoneid ) );
$date             = $newdate->format( 'd-m-Y' );
$convertedtime    = $newdate->format( 'h:i A' );
$con_start        = $newdate->format( 'H:i:s' );
$new_date         = $newdate->format( 'F j, Y' );
$avail_date       = $newdate->format( 'Y-m-d' );
$new_format_date  = $newdate->format( 'm/d/Y' );
$enddated         = new DateTime( $end_timed, new DateTimeZone( $timezoneid ) );
$convertedendtime = $enddated->format( 'h:i A' );
$time             = $convertedtime . '-' . $convertedendtime;
$estimate_time    = $new_date . ' ' . $time;
$avail_start_date = $avail_date . ' ' . $con_start;

$timestamp        = strtotime( $date );

$insert_sql = $wpdb->insert(
	$wpdb->vl_expert_avilability_calender,
	array(
		'expert_id'               => $expertid,
		'available_date'          => $date,
		'available_time'          => $time,
		'timestamp'               => $timestamp,
		'datetimeavailable'       => $estimate_time,
		'availability_start_time' => $avail_start_date,
	),
	array(
		'%d',
		'%s',
		'%s',
		'%d',
		'%s',
		'%s',
	)
);

if ( false !== $insert_sql ) {
	$request_data  = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM $wpdb->vl_request_appointment WHERE timestarted >= %s AND timestarted <= %s AND dateselected= %s AND expertid = %d", $only_start_time, $only_end_time, $new_format_date, $expertid ) );

	function appointment_confirmation_notification() {
		return 'Request Appointment Confirmation';
	}

	add_filter( 'wp_mail_from_name', 'appointment_confirmation_notification' );
	require '../email-template/appointment_confirmation_mail.php';
	$redirect       = home_url( '/expert-availability-calendar/' );
	$success        = 1;
	$insert_message = 'Availability Set Successfully.';

	wp_send_json( array(
		'success'       => $success,
		'insertmessage' => $insert_message,
		'redirect'      => $redirect,
		'mail_message'  => $mail_message,
	) );
}

wp_send_json( array(
	'success'       => 0,
	'insertmessage' => 'Error in Request appointment',
	'query'         => 'Error in cancellation of booking',
) );
