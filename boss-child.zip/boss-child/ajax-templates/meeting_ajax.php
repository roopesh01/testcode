<?php
include '../../../../wp-config.php';
global $wpdb;
$table = $wpdb->prefix.'venuemeetingdetail';
$currentuserid = get_current_user_id();    
    if(isset($_POST['ids']))
    {
        $id = $_POST['ids'];
        $result = $wpdb->get_results("SELECT * FROM $table WHERE `id`= '$id'");
        $inviteduser = $result[0]->invitedusers;
        $invite_accepted_user = $result[0]->invite_accepted_user;
        if($invite_accepted_user):
        $userarray = explode(",",$invite_accepted_user);
        endif;       
        $datetime = $result[0]->venuedate.'&nbsp;'.$result[0]->venuetime.'&nbsp;'.$result[0]->timeformat;
        $title = $result[0]->meetingname;
        $desc = $result[0]->description;
        ?>        
        <div class="recent_meetups_container">
            <h2>Recent Meetups</h2>
            <div class="recent_meetups_entry">
                <div class="rme-datetime">
                    <?php echo $datetime;?>
                </div>
                <div class="rme-header">
                    <div class="rme-title">
                    <h2><?php echo $title;?></h2>
                    </div>
                    <?php
                        if($invite_accepted_user)
                        {
                            ?>
                    <div class="rme-avtar">                        
                        <?php
                        foreach($userarray as $user_id):
                        $userdata = get_userdata($user_id);
                        $username = $userdata->user_login;
                        echo '<a href="#" title="'.$username.'">'.get_avatar($user_id, 32 ).'</a>'; 
                        echo '&nbsp;';
                        endforeach;
                        
                        ?>
                    </div>
                    <div class="rme-count">                    
                        <?php echo '<strong>'.count($userarray).'&nbsp;user accepted invitation</strong>';
                        ?>
                    </div>
                    <?php
                    }
                    else
                    {
                        echo '<strong>No User Accepted Invitation</strong>';
                    }
                    ?>
                </div>
                <div class="rme-content">
                    <p>
                    <?php
                    echo $desc;
                    ?> 
                    <a href="/meeting-description/?id=<?php echo $id;?>">Learn More</a>
                    </p>
                </div>
            </div>
        </div>           
    <?php
    }
    if(isset($_POST['reminder_id']))
    {
        include $_SERVER['DOCUMENT_ROOT'] . '/wp-content/themes/boss-child/email-template/reminder_meeting.php';        
    }    
    if(isset($_POST['cancel_id']))
    {
       include $_SERVER['DOCUMENT_ROOT'] . '/wp-content/themes/boss-child/email-template/cancel_meeting.php';         
    }
    
    if(isset($_POST['delete_id']))
    {
        $delete_id = $_POST['delete_id'];
        $wpdb->delete( $table, array( 'id' => $delete_id,'currentuserid'=>$currentuserid));
    }
   




