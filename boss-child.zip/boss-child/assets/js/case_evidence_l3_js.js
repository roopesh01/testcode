(function ($) {
	$(document).ready(function (e) {
		$("#evidenceSlider").ionImageSlider({
			startFrom: 0,
			slideShow: false
		});
		$('.tabSearch').insertAfter('.list_view_section_length');
		$("#gallery_view_section").DataTable
			({
				"lengthMenu": [8, 12, 24, 36],
				"pagingType": "full_numbers",
				"aaSorting": [],
				"bSort": false,
				"bFilter": false,
				"language": { "search": " ", "searchPlaceholder": "Search..." }
			});
		$("#list_view_section").DataTable
			({
				"lengthMenu": [8, 12, 24, 36],
				"pagingType": "full_numbers",
				"aaSorting": [],
				"bSort": false,
				"bFilter": false,
				"language": { "search": " ", "searchPlaceholder": "Search..." }
			});

		$(document).on('click', '.copy_url', function (e) {
			var PageURL = window.location.href;
			$('.copy_url2').focus();
			$('.copy_url2').val(PageURL)
			$('.copy_url2').select();
			document.execCommand('copy');

		});
		$(document).on('click', '.url_copy', function (e) {
			var PageURL = $(this).parent('td').find('.copy_urls').val();
			$('.url_copy2').focus();
			$('.url_copy2').val(PageURL);
			$('.url_copy2').select();
			document.execCommand('copy');
		});

		$(document).on('click', '.url_copy_img', function (e) {
			var imgURL = $(this).parent('td').find('.copy_urls_image').val();
			$('.url_copy2').focus();
			$('.url_copy2').val(imgURL);
			$('.url_copy2').select();
			document.execCommand('copy');
		});

		$(document).on('click', '.imglink, .evidence_id', function (e) {
			var caseid = $(this).attr("data-id");
			$("html").addClass("overlay");
			$.ajax
				({
					type: 'POST',
					url: ajaxurl,
					data:
						{
							action: 'vl_case_evidence_l3_ajax',
							caseid: caseid
						},
					success: function (html) {

						$("html").removeClass("overlay");
						$(".content_view_section").html(html);
						$('.nav-tabs li').each(function () {
							$(this).removeClass('active');
						});
						$('.tab-content div').each(function () {
							$(this).removeClass('active in');
						});
						$('.nav-tabs .case_content_view').addClass('active');
						$('#content_view').addClass('active in');
					},
					error: function (MLHttpRequest, textStatus, errorThrown) {

					}
				});
		});

		$(document).on('click', '.contact_id, .contactimg', function (e) {
			var contactid = $(this).attr("data-id");
			$("html").addClass("overlay");
			$.ajax
				({
					type: 'POST',
					url: ajaxurl,
					data:
						{
							action: 'vl_case_contact',
							contactid: contactid
						},
					success: function (html) {

						$("html").removeClass("overlay");
						$(".content_view_section").html(html);
						$('.nav-tabs li').each(function () {
							$(this).removeClass('active');
						});
						$('.tab-content div').each(function () {
							$(this).removeClass('active in');
						});
						$('.nav-tabs .case_content_view').addClass('active');
						$('#content_view').addClass('active in');
					},
					error: function (MLHttpRequest, textStatus, errorThrown) {

					}
				});
		});

		$(document).on('click', '.timelineid, .titleid', function (e) {
			var titleid = $(this).attr("data-id");
			$("html").addClass("overlay");
			$.ajax
			({
				type: 'POST',
				url: ajaxurl,
				data:
				{
					action: 'vl_case_events_timeline_ajax',
					titleid: titleid
				},
				success: function (html) {

					$("html").removeClass("overlay");
					$(".content_view_section").html(html);
					$('.nav-tabs li').each(function () {
						$(this).removeClass('active');
					});
					$('.tab-content div').each(function () {
						$(this).removeClass('active in');
					});
					$('.nav-tabs .case_content_view').addClass('active');
					$('#content_view').addClass('active in');
				},
				error: function (MLHttpRequest, textStatus, errorThrown) {
				}
			});
		});


		$(document).on('click', '.blog_id, .blogimg', function (e) {
			var blogid = $(this).attr("data-id");
			$("html").addClass("overlay");
			$.ajax
				({
					type: 'POST',
					url: ajaxurl,
					data:
						{
							action: 'vl_case_blog',
							blogid: blogid
						},
					success: function (html) {

						$("html").removeClass("overlay");
						$(".content_view_section").html(html);
						$('.nav-tabs li').each(function () {
							$(this).removeClass('active');
						});
						$('.tab-content div').each(function () {
							$(this).removeClass('active in');
						});
						$('.nav-tabs .case_content_view').addClass('active');
						$('#content_view').addClass('active in');
					},
					error: function (MLHttpRequest, textStatus, errorThrown) {
					}
				});
		});

		$(document).on('click', '.timeline_img, .timeline_id', function (e) {
			var timeline_id = $(this).attr("data-id");
			$("html").addClass("overlay");
			$.ajax
			({
				type: 'POST',
				url: ajaxurl,
				data:
				{
					action: 'vl_case_timeline_ajax',
					timeline_id: timeline_id
				},
					
				success: function (html) {
					$("html").removeClass("overlay");
					$(".content_view_section").html(html);
					$('.nav-tabs li').each(function () {
						$(this).removeClass('active');
					});
					$('.tab-content div').each(function () {
						$(this).removeClass('active in');
					});
					$('.nav-tabs .case_content_view').addClass('active');
					$('#content_view').addClass('active in');
				},
				error: function (MLHttpRequest, textStatus, errorThrown) {
				}
			});
		});

		$(document).on('click', '.contentimg, .content_id', function (e) {
			var content_id = $(this).attr("data-id");
			$("html").addClass("overlay");
			$.ajax
				({
					type: 'POST',
					url: ajaxurl,
					data:
					{
						action: 'vl_case_content_data_l3',
						content_id: content_id
					},
					success: function (html) {

						$("html").removeClass("overlay");
						$(".content_view_section").html(html);
						$('.nav-tabs li').each(function () {
							$(this).removeClass('active');
						});
						$('.tab-content div').each(function () {
							$(this).removeClass('active in');
						});
						$('.nav-tabs .case_content_view').addClass('active');
						$('#content_view').addClass('active in');
					},
					error: function (MLHttpRequest, textStatus, errorThrown) {

					}
				});
		});

		$(document).on('click', '.expense_id, .expenseimg', function (e) {
			var expense_id = $(this).attr("data-id");
			$("html").addClass("overlay");
			$.ajax
				({
					type: 'POST',
					url: ajaxurl,
					data:
						{
							action: 'vl_case_expense',
							expense_id: expense_id
						},
					success: function (html) {

						$("html").removeClass("overlay");
						$(".content_view_section").html(html);
						$('.nav-tabs li').each(function () {
							$(this).removeClass('active');
						});
						$('.tab-content div').each(function () {
							$(this).removeClass('active in');
						});
						$('.nav-tabs .case_content_view').addClass('active');
						$('#content_view').addClass('active in');
					},
					error: function (MLHttpRequest, textStatus, errorThrown) {

					}
				});
		});

		$(document).on('click', '.evidence_img, .evidence_id', function (e) {
			var evidence_id = $(this).attr("data-id");
			$("html").addClass("overlay");
			$.ajax
			({
				type: 'POST',
				url: ajaxurl,
				data:
				{
					action: 'vl_case_evidence_ajax',
					evidence_id: evidence_id
				},
				success: function (html) {
					$("html").removeClass("overlay");
					$(".content_view_section").html(html);
					$('.nav-tabs li').each(function () {
						$(this).removeClass('active');
					});
					$('.tab-content div').each(function () {
						$(this).removeClass('active in');
					});
					$('.nav-tabs .case_content_view').addClass('active');
					$('#content_view').addClass('active in');
				},
				error: function (MLHttpRequest, textStatus, errorThrown) {

				}
			});
		});

		$(document).on('click', '.search_desc', function (e) {
			var search_keyword = $('.search_keyword').val();
		});

		/* Search Case */
		$(document).on('click', '.search_by_evidence', function (e) {
			var search_keyword = $('.search_evidence').val();
			$("html").addClass("overlay");
			$.ajax
				({
					type: 'POST',
					url: ajaxurl,
					data:
					{
						action: 'vl_search_case_evidence',
						search_keyword: search_keyword
					},
					success: function (html) {

						$("html").removeClass("overlay");
						$(".search_result").html(html);

					},
					error: function (MLHttpRequest, textStatus, errorThrown) {

					}
				});
		});


		$(document).on('click', '.search_by_events_timeline', function (e) {
			var search_keyword = $('.search_events_timeline').val();
			$("html").addClass("overlay");
			$.ajax
				({
					type: 'POST',
					url: ajaxurl,
					data:
					{
						action: 'vl_search_case_events_timeline',
						search_keyword: search_keyword
					},
					success: function (html) {

						$("html").removeClass("overlay");
						$(".search_result").html(html);

					},
					error: function (MLHttpRequest, textStatus, errorThrown) {

					}
				});
		});

		$(document).on('click', '.search_by_content', function (e) {
			var search_keyword = $('.search_content').val();
			$("html").addClass("overlay");
			$.ajax
				({
					type: 'POST',
					url: ajaxurl,
					data:
					{
						action: 'vl_search_case_content',
						search_keyword: search_keyword
					},
					success: function (html) {

						$("html").removeClass("overlay");
						$(".search_result").html(html);

					},
					error: function (MLHttpRequest, textStatus, errorThrown) {

					}
				});
		});

		$(document).on('click', '.search_by_contacts', function (e) {
			var search_keyword = $('.search_contacts').val();
			$("html").addClass("overlay");
			$.ajax
				({
					type: 'POST',
					url: ajaxurl,
					data:
					{
						action: 'vl_search_case_contacts',
						search_keyword: search_keyword
					},
					success: function (html) {

						$("html").removeClass("overlay");
						$(".search_result").html(html);

					},
					error: function (MLHttpRequest, textStatus, errorThrown) {

					}
				});
		});

		$(document).on('click', '.search_by_blog', function (e) {
			var search_keyword = $('.search_blog').val();
			$("html").addClass("overlay");
			$.ajax
				({
					type: 'POST',
					url: ajaxurl,
					data:
					{
						action: 'vl_search_case_blog',
						search_keyword: search_keyword
					},
					data:
						{
							search_keyword: search_keyword
						},
					success: function (html) {

						$("html").removeClass("overlay");
						$(".search_result").html(html);

					},
					error: function (MLHttpRequest, textStatus, errorThrown) {

					}
				});
		});

		$(document).on('click', '.search_by_expense', function (e) {
			var search_keyword = $('.search_expense').val();
			$("html").addClass("overlay");
			$.ajax
				({
					type: 'POST',
					url: ajaxurl,
					data:
					{
						action: 'vl_search_case_expense',
						search_keyword: search_keyword
					},
					success: function (html) {

						$("html").removeClass("overlay");
						$(".search_result").html(html);

					},
					error: function (MLHttpRequest, textStatus, errorThrown) {
					}
				});
		});
	});

})(jQuery);
