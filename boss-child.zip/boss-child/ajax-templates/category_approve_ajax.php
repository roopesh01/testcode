<?php
	include '../../../../wp-config.php';
	global $wpdb, $current_user;
	$prefixx     = $wpdb->prefix;
	$table       = $wpdb->prefix . 'category_admin_approve';
	$usermeta    = 'wp68_usermeta';
	$primary_cat = $wpdb->prefix . 'primary_category';

if ( isset( $_POST['approvevalue'] ) ) {
	//$approvearray = explode( ',', vl_sanitize_unslash( 'approvevalue' ) );
	$approvearray = explode( ',', 'approvevalue' );
	
	if ( ! empty( $approvearray ) ) {

		foreach ( $approvearray as $approveid ) {
			$rcategory = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->vl_category_admin_approve} WHERE id= %d LIMIT 1", $approveid ) );

			$userid            = $rcategory->user_id;
			$category          = $rcategory->category;
			$subcategory       = $rcategory->subcategory;
			$metakeywithprefix = $prefixx . $category;

			$usermetaexist     = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM `$usermeta` WHERE `meta_key`= %s AND `user_id` = %d", $metakeywithprefix, $userid ) );

			if ( $usermetaexist ) {
				$wpdb->update(
					$usermeta,
					array(
						'meta_value' => implode( ',', $subcategory ),
					),
					array(
						'user_id'  => $userid,
						'meta_key' => $metakeywithprefix,
					)
				);
			} else {
				$wpdb->insert(
					$usermeta,
					array(
						'user_id'    => $userid,
						'meta_key'   => $metakeywithprefix,
						'meta_value' => $subcategory,
					),
					array( '%d', '%s', '%s' )
				);
			}

			$wpdb->update(
				$table,
				array(
					'approve' => 'yes',
				),
				array(
					'user_id' => $userid,
					'id'      => $approveid,
				)
			);

		}
	}
}

if ( isset( $_POST['declinevalue'] ) ) {
	$declinevalue = vl_sanitize_unslash( 'declinevalue' );
	$declinearray = explode( ',', $declinevalue );

	foreach ( $declinearray as $declineid ) {
		$rcategory = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $table WHERE `id`= %d LIMIT 1", $declineid ) );
		$userid    = $rcategory->user_id;
		$wpdb->update(
			$table,
			array(
				'approve' => 'no',
			),
			array(
				'user_id' => $userid,
				'id'      => $declineid,
			)
		);
	}
}

if ( isset( $_POST['approvevalue_remove'] ) ) {
	$approvevalue_remove = vl_sanitize_unslashs( 'approvevalue_remove' );
	
	$approvearray        = explode( ',', $approvevalue_remove );

	foreach ( $approvearray as $arrayapprove ) {
		$rcategory    = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $table WHERE `id`= %d", $arrayapprove ) );
		$category     = $rcategory->category;
		$subcategory  = $rcategory->subcategory;
		$category_key = $prefixx . $category;
		$user_id      = $rcategory->user_id;

		$usermetafind = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM `$usermeta` WHERE `meta_key`= %d AND `meta_value` LIKE %s AND `user_id` = %d", $category_key, '%s' . $wpdb->esc_like( $subcategory ) . '%s', $user_id ) );

		$meta_value   = $usermetafind->meta_value;
		$metaarray    = explode( ',', $meta_value );

		$count        = count( $metaarray );

		if ( $metaarray ) {
			for ( $i = 0;$i < $count;$i++ ) {
				if ( $metaarray[ $i ] == $subcategory ) {
					unset( $metaarray[ $i ] );
				}
			}
		}

		$metastring = implode( ',', $metaarray );
		$wpdb->update(
			$usermeta,
			array(
				'meta_value' => $metastring,
			),
			array(
				'user_id'  => $user_id,
				'meta_key' => $category_key,
			)
		);

		$wpdb->update(
			$table,
			array(
				'approve' => 'yes',
			),
			array(
				'user_id' => $user_id,
				'id'      => $arrayapprove,
			)
		);

	}
}

if ( isset( $_POST['declinevalue_remove'] ) ) {
	$declinevalue = vl_sanitize_unslash( 'declinevalue_remove' );
	$declinearray = explode( ',', $declinevalue );

	foreach ( $declinearray as $declineid ) {
		$user_id = $wpdb->get_var( $wpdb->prepare( "SELECT user_id FROM $table WHERE `id`= %d", $declineid ) );
		$wpdb->update(
			$table,
			array(
				'approve' => 'no',
			),
			array(
				'user_id' => $user_id,
				'id'      => $declineid,
			)
		);
	}
}

if ( isset( $_POST['approve_primary_val'] ) ) {
	$approve_primary_val = vl_sanitize_unslash( 'approve_primary_val' );
	$approve_id          = explode( ',', $approve_primary_val );
	foreach ( $approve_id as $approve_ids ) {
		$userid = $wpdb->get_var( $wpdb->prepare( "SELECT user_id FROM $primary_cat WHERE `id`= %d LIMIT 1", $approve_ids ) );
		$wpdb->update(
			$primary_cat,
			array(
				'admin_approve' => 'yes',
			),
			array(
				'user_id' => $userid,
				'id'      => $approve_ids,
			)
		);
	}
}

if ( isset( $_POST['decline_primary_val'] ) ) {
	$decline_primary_val = vl_sanitize_unslash( 'decline_primary_val' );
	$decline_id          = explode( ',', $decline_primary_val );

	foreach ( $decline_id as $decline_ids ) {
		$user_id = $wpdb->get_var( $wpdb->prepare( "SELECT user_id FROM $primary_cat WHERE `id`= %d", $decline_ids ) );
		$wpdb->update(
			$primary_cat,
			array(
				'admin_approve' => 'no',
			),
			array(
				'user_id' => $user_id,
				'id'      => $decline_ids,
			)
		);
	}
}

