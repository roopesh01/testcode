<?php
add_action( 'admin_menu', 'category_admin_approve' );
function category_admin_approve() {
	add_menu_page( 'Category Approve', 'Category Approves', 'manage_options', 'Category_Settings_Approval', 'category_admin_approve_function' );
}
/*-------------------------------- Section For Approval ----------------------------------*/
function category_admin_approve_function() {
?>
	<div class="PollQuestions">
		<h3>Categories For Approval</h3>
		<div class="category_actions">
			<?php
			$home_url = get_home_url();
			$ajax_nonce = wp_create_nonce( "survey-nonce" );
			?>
			<input type="button" class="approve_selected_add" value="Approve Selected"/>
			<input type="button" class="decline_selected_add" value="Decline Selected"/>
			<input type="hidden" class="home_url" value="<?php echo esc_attr( $home_url ); ?>"/>
			<input type="hidden" class="wp_nonce" value="<?php echo esc_attr( $ajax_nonce ); ?>"/>
		</div>
		<table align="center" border="2"  class="std" id="category_approve_add">
					<thead>
						<tr>
							<th>User Id</th>
							<th>User Name</th>
							<th>Category</th>
							<th>Sub Category</th>
							<th>Request To </th>
							<th><input type="checkbox" id="selectunselect"/><br /><label for="selectunselect">Select/Unselect All</label></th>
						</tr>
					</thead>
				   <tbody>                                    
						<?php
							global $wpdb;
							$table  = $wpdb->prefix . 'category_admin_approve';
							$result = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM `{$wpdb->vl_category_admin_approve}` WHERE `approve` IS NULL AND `request_to`= %s",'add' ) );
						    if ( $result ) {
							foreach ( $result as $results ) {
								$id       = $results->id;
								$userid   = $results->user_id;
								$userdata = get_userdata( $userid );
								$username = $userdata->user_login;
								$request  = $results->request_to;
								$user_category = get_user_custom_category( $results->category );
								$user_sub_category = get_user_custom_sub_category( $results->subcategory );
								?>
								<tr>
                                        <td><?php echo esc_attr( $userid ); ?></td>
                                        <td><?php echo esc_attr( $username ); ?></td>
                                        <td><?php echo esc_attr( $user_category ); ?></td>
                                        <td><?php echo esc_attr( $user_sub_category );?></td>
                                        <td><?php echo esc_attr( $request );?></td>
										<?php
										echo '<td><input type="checkbox" data-id="' . $results->subcategory . '" name="checkuncheck[]" class="cat_subcat"/>
										<input type="hidden" value="'.$userid.'" class="user_idd"/>
										</td>
                                    </tr>';
							}
						} else {
							echo '<tr>
                                    <td>No User Category Found</td><td></td><td></td><td></td><td></td><td></td>
                                </tr>';
						}
						?>
					</tbody>
				</table>
	</div>
	<?php
}


/* Section For Primary Category Approve */
add_action( 'admin_menu', 'primary_cat_admin' );
function primary_cat_admin() {
	add_menu_page( 'Primary Category Approve', 'Primary Category Approve', 'manage_options', 'Primary_Category', 'primary_cat_admin_function' );
}
function primary_cat_admin_function() {
	?>
	<div class="PollQuestions"> 
				<h3>Primary Categories</h3>
				<div class="category_actions">
				<?php
			$home_url = get_home_url();
			$ajax_nonce = wp_create_nonce( "survey-nonce" );
			?>
					<input type="button" class="approve_primary" value="Approve Selected"/>
					<input type="button" class="decline_primary" value="Decline Selected"/>
					<input type="hidden" class="home_url" value="<?php echo esc_attr( $home_url ); ?>"/>
			<input type="hidden" class="wp_nonce" value="<?php echo esc_attr( $ajax_nonce ); ?>"/>
				</div>
				<table align="center" border="2"  class="std2" id="primary_cat_approve">
					<thead>
						<tr>
							<th>User Id</th>
							<th>User Name</th>
							<th>Primary Category</th>
							<th><input type="checkbox" id="check_primary"/><br /><label for="selectunselect">Select/Unselect All</label></th>
						</tr>
					</thead>
				   <tbody>                                    
						<?php
							global $wpdb;
							$table1 = $wpdb->prefix . 'primary_category';
							$result = $wpdb->get_results ( "SELECT * FROM `{$wpdb->vl_primary_category}` WHERE `admin_approve` IS NULL" );							
							if ( $result ) {

							foreach ( $result as $results ) {
								$id               = $results->id;
								$userid           = $results->user_id;
								$userdata         = get_userdata( $userid );
								$username         = $userdata->user_login;
								$primary_category = $results->primary_category;

								echo
								'<tr>
                                        <td>' . $userid . '</td>
                                        <td>' . $username . '</td>
                                        <td>' . $primary_category . '</td>                                        
                                        <td><input type="checkbox" data-id="' . $userid . '" name="checkuncheck[]" class="primary_cat"/></td>
                                    </tr>';
							}
						} else {
							echo '<tr>
                                    <td>No User Category Found</td><td></td><td></td><td></td>
                                </tr>';
						}
						?>
					</tbody>
				</table>
	</div>
	<?php
}
/* Section For Primary Category Approve */
