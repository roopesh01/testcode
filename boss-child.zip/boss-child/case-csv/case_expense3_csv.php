<?php
	include '../../../../wp-config.php';
	global $wpdb;
	$filename   = 'case_expense_level3.csv';
	$header_row = array(
		0  => 'id',
		1  => 'expense_id',
		2  => 'title',
		3  => 'location',
		4  => 'purpose',
		5  => 'date',
		6  => 'contact_id',
		7  => 'approval_date',
		8  => 'review_by_id',
		9  => 'item_description',
		10 => 'approval',
	);
	$data_rows  = array();
	$table      = $wpdb->prefix . 'case_expense_level1';
	$result     = $wpdb->get_results( "SELECT * FROM $table WHERE `post_type`='question'" );
	foreach ( $result as $results ) {
		$row         = array();
		$row[0]      = $results->id;
		$row[1]      = $results->expense_id;
		$row[2]      = $results->title;
		$row[3]      = $results->location;
		$row[4]      = $results->purpose;
		$row[5]      = $results->date;
		$row[0]      = $results->contact_id;
		$row[1]      = $results->approval_date;
		$row[2]      = $results->title;
		$row[3]      = $results->location;
		$row[4]      = $results->purpose;
		$row[5]      = $results->date;
		$data_rows[] = $row;
	}
	$fh = @fopen( 'php://output', 'w' );
	fprintf( $fh, chr( 0xEF ) . chr( 0xBB ) . chr( 0xBF ) );
	header( 'Cache-Control: must-revalidate, post-check=0, pre-check=0' );
	header( 'Content-Description: File Transfer' );
	header( 'Content-type: text/csv' );
	header( "Content-Disposition: attachment; filename={$filename}" );
	header( 'Expires: 0' );
	header( 'Pragma: public' );
	fputcsv( $fh, $header_row );
	foreach ( $data_rows as $data_row ) {
		fputcsv( $fh, $data_row );
	}
	fclose( $fh );
	die();



