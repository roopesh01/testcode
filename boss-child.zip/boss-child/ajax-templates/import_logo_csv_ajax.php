<?php 
include '../../../../wp-config.php';
global $wpdb,$current_user;
$user_id = $current_user->ID;
$post_table = $wpdb->prefix.'posts';
$filename= $_FILES["logo_csv"]["tmp_name"];			
		if($_FILES["logo_csv"]["size"] > 0)
		{
			if (($handle = fopen($filename, "r")) !== FALSE) 
			{
				fgetcsv($handle); 
				$total_count = 0;				
				while (($getData = fgetcsv($handle, 10000, ",")) !== FALSE)
				{
                        $data = array( 
						'ID' => $getData[0], 
						'post_author' => $getData[1],
						'post_date' => $getData[2],
						'post_date_gmt' => $getData[3],
						'post_content' => $getData[4],
						'post_title' => $getData[5],
						'post_excerpt' => $getData[6],
						'post_status' => $getData[7],
                        'comment_status' =>$getData[8],
						'ping_status' => $getData[9],
                        'post_password' => $getData[10],
						'post_name' => $getData[11],
						'to_ping' => $getData[12],
						'pinged' => $getData[13],
						'post_modified' => $getData[14],
						'post_modified_gmt' =>$getData[15],
                        'post_content_filtered' =>$getData[16],
                        'post_parent' =>$getData[17],
                        'guid' =>$getData[18],
                        'menu_order' =>$getData[19],
                        'post_type' =>$getData[20],
                        'post_mime_type' =>$getData[21],
                        'comment_count' =>$getData[22]
						);

						$format = array( 
								'%d',
								'%d', 
								'%s',
								'%s',
								'%s',
								'%s',
								'%s',
								'%s',
								'%s',
								'%s',
								'%s',
								'%s',
								'%s',
								'%s',
                                '%s',
								'%s', 
								'%s',
								'%d',
								'%s',
								'%d',
								'%s',
								'%s',
								'%d'							
						);				
                        $insert_sql = $wpdb->insert($post_table, $data, $format);
                        if($insert_sql== 1)
                        {
                            
                        }
                        else
                        {
                            echo 'Error Occured In Inserting Post No'.$getData[0].'<br/>';
                        }                                             
                        $total_count++;
                }					
            }
    			echo "Total Post Updated".$total_count;
    	        fclose($file);	
    }
		