var primary_user_list = $("#primary-user-list").DataTable({
    "language": {
        "search": " ",
        "searchPlaceholder": "Search..."
    }
});

var secondary_user_list = $("#secondary-user-list").DataTable({
    "language": {
        "search": " ",
        "searchPlaceholder": "Search..."
    }
});
$("#final-user-list").DataTable({
    "language": {
        "search": " ",
        "searchPlaceholder": "Search..."
    }
});

var layoutType = "";
var stepType = '';
var logged_user_id = 2;

function ChangeTablesStep(stepType) {
    var progressSteps = stepType.replace("step", "");
    $("ul.user-steps li").removeClass('active done');
    $("ul.user-steps li div.TooltipWrapper").addClass("hide");
    for (var i = 1; i <= progressSteps; i++) {
        if (progressSteps == i) {
            $("ul.user-steps li.step" + i).addClass('active');
            $("ul.user-steps li.step" + i + " div.TooltipWrapper").removeClass("hide");
        } else {
            $("ul.user-steps li.step" + i).addClass('done');
        }
    }
    if (stepType == "step3") {
        $("div.primary-users").addClass('hide');
        $("div.secondary-users").addClass('hide');
        $("div.final-users").removeClass("hide");
    } else if (stepType == "step2") {
        $("div.final-users").addClass("hide");
        $("div.primary-users").addClass('hide');
        $("div.secondary-users").removeClass('hide');
    } else {
        $("div.secondary-users").addClass('hide');
        $("div.final-users").addClass("hide");
        $("div.primary-users").removeClass('hide');
    }
}
// ChangeTablesStep(stepType);
function ChangeTablesLayout(layoutType) {
    $("ul.layout-type li").removeClass('active');
    $("ul.layout-type li#" + layoutType).addClass('active');
    $("#content table").removeClass("active-grid active-list");
    // default layout is list
    if (layoutType == "graph") {
        $("#content .table-wrapper").hide();
        $("#content .graph-view").show();
    } else if (layoutType == "grid") {
        // primary table
        $("#content .table-wrapper").show();
        $("#content .graph-view").hide();
        $("#content table").addClass("active-grid");
        $("table tr th.list-th").addClass("hide");
        $("table tr td.list-td").addClass("hide");
        $("table tr th.grid-th").removeClass("hide");
        $("table tr td.grid-td").removeClass("hide");
    } else {
        // primary table
        $("#content .table-wrapper").show();
        $("#content .graph-view").hide();
        $("#content table").addClass("active-list");
        $("table tr th.grid-th").addClass("hide");
        $("table tr td.grid-td").addClass("hide");
        $("table tr th.list-th").removeClass("hide");
        $("table tr td.list-td").removeClass("hide");
    }
}
// change layout grid and list
$("ul.layout-type li").click(function(event) {
    event.preventDefault();
    var layoutType = $(this).attr('id');
    if (layoutType == "content-view") {
        // user click on actived LayOut 
        return false;
    }
    // check content view tab is opend if open then remove this tab
    if ($("ul.layout-type li#content-view").length) {
        $("div#view-full-profile").addClass("hide");
        $("div#view-full-profile").html("");
        $("ul.layout-type li#content-view").remove();
        $("h1.entry-title").text($("h1.entry-title").attr("alt"));
        // check current step
        checkCookieStep(stepType);
    }
    checkCookie(layoutType);
});
// change steps
$("ul.user-steps li a").click(function(event) {
    event.preventDefault();
    var stepType = $(this).attr('href');
    stepType = stepType.replace('#', '');
    stepType = stepType.replace('-', '');
    // check content view tab is opend if open then remove this tab
    if ($("ul.layout-type li#content-view").length) {

        $("div#view-full-profile").addClass("hide");
        $("div#view-full-profile").html("");
        $("ul.layout-type li#content-view").remove();
        $("h1.entry-title").text($("h1.entry-title").attr("alt"));
    }
    checkCookieStep(stepType);
});

function getCookie(cname) {
    var name = cname + "=";
    var decodedCookie = decodeURIComponent(document.cookie);
    var ca = decodedCookie.split(';');
    for (var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
            return c.substring(name.length, c.length);
        }
    }
    return "";
}

function setCookie(cname, cvalue, exdays) {
    var d = new Date();
    d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
    var expires = "expires=" + d.toGMTString();
    document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
}
// check and if cookies not set then set cookies
function checkCookie(layoutType) {
    var tableLayoutName = getCookie("tableLayoutName");
    if (tableLayoutName != "" && layoutType == tableLayoutName) {
        ChangeTablesLayout(layoutType);
    } else if (tableLayoutName != "" && (layoutType.length == 4 || layoutType.length == 5)) {
        // first delete cookies
        var value = '';
        var expires = '';
        document.cookie = tableLayoutName + "=" + value + expires + "; path=/";
        setCookie("tableLayoutName", layoutType, 30);
        ChangeTablesLayout(layoutType);
    } else if (tableLayoutName != '' && layoutType == '') {
        ChangeTablesLayout(tableLayoutName);
    } else {
        layoutType = "list";
        setCookie("tableLayoutName", layoutType, 30);
        ChangeTablesLayout(layoutType);
    }
}

checkCookie(layoutType);

function getCookieStep(cname) {
    var name = cname + "=";
    var decodedCookie = decodeURIComponent(document.cookie);
    var ca = decodedCookie.split(';');
    for (var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
            return c.substring(name.length, c.length);
        }
    }
    return "";
}

function setCookieStep(cname, cvalue, exdays) {
    var d = new Date();
    d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
    var expires = "expires=" + d.toGMTString();
    document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
}
// check and if cookies not set then set cookies
function checkCookieStep(stepType) {
    var tableStepName = getCookieStep("tableStepName");
    if (tableStepName != "" && stepType == tableStepName) {
        ChangeTablesStep(stepType);
    } else if (tableStepName != "" && stepType.length == 5) {
        // first delete cookies
        var value = '';
        var expires = '';
        document.cookie = tableStepName + "=" + value + expires + "; path=/";
        setCookieStep("tableStepName", stepType, 30);
        ChangeTablesStep(stepType);
    } else if (tableStepName != '' && stepType == '') {
        ChangeTablesStep(tableStepName);
    } else {
        stepType = "step1";
        setCookieStep("tableStepName", stepType, 30);
        ChangeTablesStep(stepType);
    }
}
checkCookieStep(stepType);
$("button.next-previous-btn").on("click", function() {
    var id = $(this).attr('id');
    $("ul.user-steps li." + id + " a").trigger("click");
});
// when user see full profile details
$("table tr td a.view-profile").live("click", function() {
    $('ul.layout-type li').removeClass("active");
    $('ul.layout-type').prepend('<li id="content-view" class="active"><a href="#"><i class="fa fa-address-card-o" aria-hidden="true"></i> Content View</a> </li>');
    $("div.primary-users").addClass("hide");
    $("div.secondary-users").addClass("hide");
    $("div.final-users").addClass("hide");
    $("div#view-full-profile").removeClass("hide");
    var userID = $(this).attr('alt');
    getProfileContent(userID);
});

function getProfileContent(userID) {
    var wp_nonce = $("input[name=profile_wp_nonce]").val();
    $("html").addClass("overlay");
    $.ajax({
        url: ajaxurl,
        type: "POST",
        data: {
            action: "vl_view_nominee_profile",
            nominee: userID,
            wp_nonce: wp_nonce
        },
        success: function(data) {
            $("h1.entry-title").text("Nominee Profile");
            $('div#view-full-profile').html(data);
        },
        complete: function() {
            $("html").removeClass("overlay");
        },
        error: function(error) {
            $('div#view-full-profile').html(error);
            setTimeout(function() {
                backNomineeList();
            }, 3000);
        }
    });
}
// when user click on back button
function backNomineeList() {
    $("ul.layout-type li#content-view").remove();
    $("div.primary-users").removeClass("hide");
    $("div.secondary-users").removeClass("hide");
    $("div.final-users").removeClass("hide");
    $("div#view-full-profile").addClass("hide");
    $("div#view-full-profile").html("");

}
$("button.back-nomiee-list").live("click", function() {
    backNomineeList();
    $("h1.entry-title").text($("h1.entry-title").attr("alt"));
    checkCookie(layoutType);
    checkCookieStep(stepType);
});

/*   Change/give vote functionality */
$("a.apply_vote_button").live("click", function(event) {
    event.preventDefault();
    var dataValue = $(this).attr("alt");
    var dataString = decodeURIComponent(escape(window.atob(dataValue)));
    var res = dataString.split("-");
    var customClass = res[0] + "_list_vote_" + res[1];
    if ($("div." + customClass).hasClass('hide')) {
        $("div." + res[0] + "_list_vote").addClass("hide");
        $("div." + customClass).removeClass("hide");
    } else {
        $("div." + res[0] + "_list_vote").addClass("hide");
    }
    // $(res[0]+"_list_vote_"+res[1]).toggle();
    // console.log(customClass); 
});

$("input.primary_user_vote").live("change", function() {

    var vote = $(this).val();
    var alt_data = $(this).attr('alt');
    var dataString = decodeURIComponent(escape(window.atob(alt_data)));
    var res = dataString.split("-");
    // var customClass = res[0] + "_list_vote_" + res[1];
    // var last_vote = $("div." + customClass + " .last_vote").val();
    var alertMessage = "Are your sure ?";
    var list_column_id = res[0] + '-6-' + res[1];
    var list_column_id_1 = res[0] + '-9-' + res[1];
    var grid_column_id = res[0] + '-10-' + res[1];
    var comment = '';
    var comment_type = ''; // if comment type blanck mean user is not updating comment
    // if (last_vote == 'yes' || last_vote == 'no')
    // {
    //     alertMessage = "You want to change your vote ?";
    // }
    // if (confirm(alertMessage))
    // {
    updatePrimaryUsersVote(vote, alt_data, list_column_id, list_column_id_1, grid_column_id, comment, comment_type);
    // }


});

function updatePrimaryUsersVote(curent_vote, vote_string, list_column_id, list_column_id_1, grid_column_id, comment, comment_type) {

    $("html").addClass("overlay");
    var action_type = "voteNow";
    var wp_nonce = $("input[name=primary_wp_nonce]").val();
    var FormData = "current_vote=" + curent_vote + "&vote_string=" + vote_string + "&action_type=" + action_type + "&voteStep=primary&comment=" + comment + "&comment_type=" + comment_type + '&wp_nonce=' + wp_nonce + '&action=vl_set_nominee_users_vote';
    $("html").addClass("overlay");
    $.ajax({
        url: ajaxurl,
        type: "POST",
        dataType: "json",
        data: FormData,
        success: function(data) {
            if (data['status'] == 0) {
                alert(data['message']);
                return false;
            }
            var row_id = data['response']['id'];
            var user_current_vote = data['response']['current_vote'];
            var tt_yes_vote = data['response']['yes_vote'];
            var tt_no_vote = data['response']['no_vote'];
            var default_yes_input = '';
            var default_no_input = '';
            if (user_current_vote == "yes") {
                default_yes_input = "checked";
            } else {
                default_no_input = "checked";
            }
            var tt = parseInt(tt_yes_vote) + parseInt(tt_no_vote);
            // console.log(list_column_id);
            // console.log(tt);
            var theHTML = $('td#' + grid_column_id + ' div.topContentWrap').eq(0).html();
            // console.log(theHTML); 
            /* Start - Generate html for grid */
            var gridHtml = "<div class='nominee_repeting_div NominationBrowser'>" +
                "<div class='topContentWrap'>" + theHTML + "</div>" +
                "<div class='btmContentWrap pieChartWrapper'>" +
                "<div id='user_information-" + row_id + "' class='voteContainer'>" +
                "<div class='user_votes_section'><span class='all_vote'>You voted: " + user_current_vote + " </span><a href='#' class='apply_vote_button' alt='" + vote_string + "'>Change Now</a>" +
                "<div class='primary_list_vote_" + row_id + " primary_list_vote hide'>Yes : <input " + default_yes_input + " class='primary_user_vote styled' name='primary_grid_user_vote_" + row_id + "' alt='" + vote_string + "' value='yes' type='radio'><strong></strong> No : <input class='primary_user_vote styled' " + default_no_input + " name='primary_grid_user_vote_" + row_id + "' alt='" + vote_string + "' value='no' type='radio'><input type='hidden' name='last_vote' class='last_vote value='" + user_current_vote + "' /> </div>" +
                "</div>" +
                "</div>" +
                "<div class='totalNumber text-center' id='Question_count_graph_primary-" + row_id + "'>" +
                "</div>" +
                "</div>"
            "</div>";

            var listHtml = "<a class='view-profile' alt='" + vote_string + "' href='#'>View Profile</a> / <a href='#'' class='apply_vote_button' alt='" + vote_string + "'>Change Now</a>" +
                "<div class='primary_list_vote_" + row_id + " primary_list_vote hide'>" +
                "Yes : <input " + default_yes_input + " class='primary_user_vote styled' name='primary_list_user_vote_" + row_id + "' alt='" + vote_string + "' value='yes' type='radio'><strong></strong>" +
                "No : <input " + default_no_input + " class='primary_user_vote styled' name='primary_list_user_vote_" + row_id + "' alt='" + vote_string + "' value='no' type='radio'><strong></strong>" +
                "<input name='last_vote' class='last_vote' value='" + user_current_vote + "' type='hidden'>" +
                "</div>";

            function drawChart() {
                var dataArray = [
                    ['Yes', tt_yes_vote],
                    ['No', tt_no_vote],
                    ['Total', 0],
                ];
                var total = getTotal(dataArray);
                for (var i = 0; i < dataArray.length; i++) {
                    dataArray[i].push(customTooltip(dataArray[i][0], dataArray[i][1], total));
                }
                for (var i = 0; i < dataArray.length; i++) {
                    if (dataArray[i][0] == "Total") {
                        dataArray[i][0] = dataArray[i][0] + "  " + total + " Votes " + ((total / total) * 100).toFixed(1) + "%  ";
                    } else {
                        dataArray[i][0] = dataArray[i][0] + "  " + dataArray[i][1] + " Votes " + ((dataArray[i][1] / total) * 100).toFixed(1) + "% ";
                    }
                }
                dataArray.unshift(['Vote Type', 'Number of Vote', 'Tooltip']);
                var data = google.visualization.arrayToDataTable(dataArray);
                data.setColumnProperty(2, 'role', 'tooltip');
                data.setColumnProperty(2, 'html', true);
                var options = {
                    'width': 320,
                    'height': 200,
                    chartArea: {
                        left: 0,
                        top: 20,
                        width: '100%',
                        height: '100%'
                    },
                    is3D: true,
                    //legend:{position: 'top'},
                    backgroundColor: 'transparent',
                    slices: {
                        0: {
                            color: '#1a8ec5'
                        },
                        1: {
                            color: '#da4638'
                        }
                    },
                    pieSliceText: 'value-and-percentage',
                    sliceVisibilityThreshold: 0,
                    tooltip: {
                        isHtml: true
                    }
                };
                var chart = new google.visualization.PieChart(document.getElementById('Question_count_graph_primary-' + row_id));
                chart.draw(data, options);
            }

            function customTooltip(name, value, total) {
                if (name == "Total") {
                    return name + '<br/><b>' + total + '  ' + ((total / total) * 100).toFixed(1) + '%</b>';
                } else {
                    return name + '<br/><b>' + value + '  ' + ((value / total) * 100).toFixed(1) + '%</b>';
                }
            }

            function getTotal(dataArray) {
                var total = 0;
                for (var i = 0; i < dataArray.length; i++) {
                    if (dataArray[i][0] == "Total") {} else {
                        total += dataArray[i][1];
                    }
                }
                return total;
            }
            google.load('visualization', '1', {
                packages: ['corechart'],
                callback: drawChart
            });
            /* End - Generate html for grid */
            console.log(list_column_id_1);
            primary_user_list.cell('#' + list_column_id).data(tt);
            primary_user_list.cell('#' + list_column_id_1).data(listHtml);
            primary_user_list.cell('#' + grid_column_id).data(gridHtml);
            alert(data['message']);
        },
        complete: function() {

            $("html").removeClass("overlay");

        },
        error: function(error) {
            // $('#action_status_'+rowid).html(error);
        }
    });
}

/*   Change/give vote functionality  for secondary users  */
$("a.apply_secondary_vote_button").live("click", function(event) {
    event.preventDefault();
    var dataValue = $(this).attr("alt");
    var dataString = decodeURIComponent(escape(window.atob(dataValue)));
    var res = dataString.split("-");
    var customClass = res[0] + "_list_vote_" + res[1];
    if ($("div." + customClass).hasClass('hide')) {
        $("div." + res[0] + "_list_vote").addClass("hide");
        $("div." + customClass).removeClass("hide");
    } else {
        $("div." + res[0] + "_list_vote").addClass("hide");
    }

});

// user will submit vote for secondary users 
$("input.secondary_user_vote").live("change", function() {

    var vote = $(this).val();
    var alt_data = $(this).attr('alt');
    var dataString = decodeURIComponent(escape(window.atob(alt_data)));
    var res = dataString.split("-");
    var alertMessage = "Are your sure ?";
    var list_column_id = res[0] + '-5-' + res[1];
    var list_column_id_1 = res[0] + '-6-' + res[1];
    var grid_column_id = res[0] + '-7-' + res[1];
    var comment = "";

    // if (confirm(alertMessage))
    // {
    updateSecondaryUsersVote(vote, alt_data, comment, list_column_id, list_column_id_1, grid_column_id);
    // }

});
// when user submit comment with vote from profile detais page for secondary user
$("input#submitSecondaryVote").live("click", function() {
    var vote = '';
    if ($('input[name=secondaryUserVote]').is(':checked')) {
        vote = $('input:radio[name=secondaryUserVote]:checked').val()
    } else {
        alert("Please choose your vote");
        return false;
    }
    if (vote == '') {
        alert("Please choose your vote");
        return false;
    }
    var comment = $("textarea[name=secondaryUsercomment]").val();
    var alt_data = $("input[name=secondaryUserHistory]").val();
    var dataString = decodeURIComponent(escape(window.atob(alt_data)));
    var res = dataString.split("-");
    var alertMessage = "Are your sure ?";
    var list_column_id = res[0] + '-5-' + res[1];
    var list_column_id_1 = res[0] + '-6-' + res[1];
    var grid_column_id = res[0] + '-7-' + res[1];
    // if (confirm(alertMessage))
    // {
    updateSecondaryUsersVote(vote, alt_data, comment, list_column_id, list_column_id_1, grid_column_id);
    // }
    getProfileContent(alt_data);
});

// when user submit comment with vote from profile detais page for secondary user
$("input#submitPrimaryVote").live("click", function() {
    var vote = '';
    if ($('input[name=primaryUserVote]').is(':checked')) {
        vote = $('input:radio[name=primaryUserVote]:checked').val()
    } else {
        alert("Please choose your vote");
        return false;
    }
    if (vote == '') {
        alert("Please choose your vote");
        return false;
    }
    var comment = $("textarea[name=primaryUsercomment]").val();
    var alt_data = $("input[name=primaryUserHistory]").val();
    var dataString = decodeURIComponent(escape(window.atob(alt_data)));

    var res = dataString.split("-");
    var alertMessage = "Are your sure ?";
    var list_column_id = res[0] + '-6-' + res[1];
    var list_column_id_1 = res[0] + '-9-' + res[1];
    var grid_column_id = res[0] + '-10-' + res[1];
    var comment_type = 'useComment'; // if comment type is 'useComment' mean user want to update/insert comment
    // if (confirm(alertMessage))
    // {
    updatePrimaryUsersVote(vote, alt_data, list_column_id, list_column_id_1, grid_column_id, comment, comment_type);

    // }
    getProfileContent(alt_data);
});

// insert/update secondary users vote
function updateSecondaryUsersVote(curent_vote, vote_string, comment, list_column_id, list_column_id_1, grid_column_id) {

    $("html").addClass("overlay");
    var action_type = "voteNow";
    var wp_nonce = $("input[name=secondary_wp_nonce]").val();
    var FormData = "current_vote=" + curent_vote + "&vote_string=" + vote_string + "&action_type=" + action_type + "&voteStep=secondary" + "&comment=" + comment + '&wp_nonce=' + wp_nonce + '&action=vl_set_secondary_nominee_users_vote';
    $("html").addClass("overlay");
    $.ajax({
        url: ajaxurl,
        type: "POST",
        dataType: "json",
        data: FormData,
        success: function(data) {

            if (data['status'] == 0) {
                alert(data['message']);
                return false;
            }
            var row_id = data['response']['id'];
            var user_current_vote = data['response']['current_vote'];
            var tt_yes_vote = parseInt(data['response']['yes_vote']);
            var tt_no_vote = parseInt(data['response']['no_vote']);
            var default_yes_input = '';
            var default_no_input = '';
            if (user_current_vote == "yes") {
                default_yes_input = "checked";
            } else {
                default_no_input = "checked";
            }
            var tt = parseInt(tt_yes_vote) + parseInt(tt_no_vote);
            // console.log(list_column_id);
            // console.log(tt);
            var theHTML = $('td#' + grid_column_id + ' div.topContentWrap').eq(0).html();

            /* Start - Generate html for grid */
            var gridHtml = "<div class='nominee_repeting_div NominationBrowser'>" +
                "<div class='topContentWrap clearfix'>" + theHTML + "</div>" +
                "<div class='btmContentWrap pieChartWrapper'>" +
                "<div id='user_information-" + row_id + "' class='voteContainer'>" +
                "<div class='user_votes_section'><span class='all_vote'>You voted: " + user_current_vote + " </span><a href='#' class='apply_secondary_vote_button' alt='" + vote_string + "'>Change Now</a>" +
                "<div class='secondary_list_vote_" + row_id + " secondary_list_vote hide'>Yes : <input " + default_yes_input + " class='secondary_user_vote styled' name='secondary_grid_user_vote_" + row_id + "' alt='" + vote_string + "' value='yes' type='radio'><strong></strong> No : <input class='secondary_user_vote styled' " + default_no_input + " name='secondary_grid_user_vote_" + row_id + "' alt='" + vote_string + "' value='no' type='radio'><input type='hidden' name='last_vote' class='last_vote value='" + user_current_vote + "' /> </div>" +
                "</div>" +
                "</div>" +
                "<div class='totalNumber text-center' id='Question_count_graph_secondary-" + row_id + "'>" +
                "</div>" +
                "</div>"
            "</div>";

            var listHtml = "<a class='view-profile' alt='" + vote_string + "' href='#'>View Profile</a> / <a href='#'' class='apply_secondary_vote_button' alt='" + vote_string + "'>Change Now</a>" +
                "<div class='secondary_list_vote_" + row_id + " secondary_list_vote hide'>" +
                "Yes : <input " + default_yes_input + " class='secondary_user_vote styled' name='secondary_list_user_vote_" + row_id + "' alt='" + vote_string + "' value='yes' type='radio'><strong></strong>" +
                "No : <input " + default_no_input + " class='secondary_user_vote styled' name='secondary_list_user_vote_" + row_id + "' alt='" + vote_string + "' value='no' type='radio'><strong></strong>" +
                "<input name='last_vote' class='last_vote' value='" + user_current_vote + "' type='hidden'>" +
                "</div>";

            function getTotal1(dataArray) {
                var total = 0;
                for (var i = 0; i < dataArray.length; i++) {
                    if (dataArray[i][0] == "Total") {} else {
                        total += dataArray[i][1];
                    }
                }
                return total;
            }

            function drawChart() {
                var dataArray = [
                    ['Yes', tt_yes_vote],
                    ['No', tt_no_vote],
                    ['Total', 0],
                ];
                var total = getTotal1(dataArray);
                for (var i = 0; i < dataArray.length; i++) {
                    dataArray[i].push(customTooltip(dataArray[i][0], dataArray[i][1], total));
                }
                for (var i = 0; i < dataArray.length; i++) {
                    if (dataArray[i][0] == "Total") {
                        dataArray[i][0] = dataArray[i][0] + "  " + total + " Votes " + ((total / total) * 100).toFixed(1) + "%  ";
                    } else {
                        dataArray[i][0] = dataArray[i][0] + "  " + dataArray[i][1] + " Votes " + ((dataArray[i][1] / total) * 100).toFixed(1) + "% ";
                    }
                }
                dataArray.unshift(['Vote Type', 'Number of Vote', 'Tooltip']);
                var data = google.visualization.arrayToDataTable(dataArray);
                data.setColumnProperty(2, 'role', 'tooltip');
                data.setColumnProperty(2, 'html', true);
                var options = {
                    'width': 320,
                    'height': 200,
                    chartArea: {
                        left: 0,
                        top: 20,
                        width: '100%',
                        height: '100%'
                    },
                    is3D: true,
                    //legend:{position: 'top'},
                    backgroundColor: 'transparent',
                    slices: {
                        0: {
                            color: '#1a8ec5'
                        },
                        1: {
                            color: '#da4638'
                        }
                    },
                    pieSliceText: 'value-and-percentage',
                    sliceVisibilityThreshold: 0,
                    tooltip: {
                        isHtml: true
                    }
                };
                var chart = new google.visualization.PieChart(document.getElementById('Question_count_graph_secondary-' + row_id));
                chart.draw(data, options);
            }

            function customTooltip(name, value, total) {
                if (name == "Total") {
                    return name + '<br/><b>' + total + '  ' + ((total / total) * 100).toFixed(1) + '%</b>';
                } else {
                    return name + '<br/><b>' + value + '  ' + ((value / total) * 100).toFixed(1) + '%</b>';
                }
            }

            google.load('visualization', '1', {
                packages: ['corechart'],
                callback: drawChart
            });
            /* End - Generate html for grid */

            secondary_user_list.cell('#' + list_column_id).data(tt);
            secondary_user_list.cell('#' + list_column_id_1).data(listHtml);
            secondary_user_list.cell('#' + grid_column_id).data(gridHtml);
            alert(data['message']);
        },
        complete: function() {

            $("html").removeClass("overlay");

        },
        error: function(error) {
            // $('#action_status_'+rowid).html(error);
        }
    });
}