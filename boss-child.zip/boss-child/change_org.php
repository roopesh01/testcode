<?php

add_action( 'admin_menu', 'register_my_custom_menu_page' );
function register_my_custom_menu_page() {
	add_menu_page( 'Petition API Setting', 'Petition API Setting', 'administrator', 'apisetting', 'my_custom_menu_page', 'dashicons-universal-access-alt' );
}

function my_custom_menu_page() {
?>
 <div class="wrap">

  <h2>Change.Org Pettion API Setting</h2>
  <div class="csv_export_main">
	<form method="post" action="options.php">
		<?php
		settings_fields( 'meta-data-group1' );
		do_settings_sections( 'meta-data-group1' );
		?>
		<label>Enter Your API Key</label><br/>
		<input type="text" name="api_key" class="api_key" placeholder="Enter Your API Key" value="<?php echo esc_attr( get_option( 'api_key' ) ); ?>"/><br/>
		<label>Enter Your API Secrete</label><br/>
		<input type="text" name="api_secret" class="api_scecret" placeholder="Enter Your API Scecret" value="<?php echo esc_attr( get_option( 'api_secret' ) ); ?>"/><br/><br/>
		<?php submit_button(); ?>
	</form>
  </div>


<div class="">
	<form action="options.php" method="POST">
		<?php
		settings_fields( 'meta-data-group2' );
		do_settings_sections( 'meta-data-group2' );
		?>
		<h4>Generate Pettion ID</h4>
		<label>Enter the petition url</label><br/>
		<input type="text" name="petition_url" class="petition_url" placeholder="Enter the petition url here" value="<?php echo get_option( 'petition_url' ); ?>" /><br/><br/>
		<?php
		if ( get_option( 'petition_id' ) == '' ) {
			echo '<input type="button" name="Generate ID" class="generate_id" value="Generate ID"/>';}
?>



		<div class="pet_id"
		<?php
		if ( get_option( 'petition_id' ) == '' ) {
			echo 'style="display: none;"';}
?>
>
			<label>Your Petition ID is</label><input type="text" name="petition_id" value="<?php echo get_option( 'petition_id' ); ?>" class="get_pet_id"/>
			<?php submit_button(); ?>
		</div>
	</form>
</div>


<div class="">
	<form action="options.php" method="POST">
		<?php
		settings_fields( 'meta-data-group3' );
		do_settings_sections( 'meta-data-group3' );
		?>
		<h4>Generate Pettion Authorization Key</h4>
		<label>Enter the petition Email</label><br/>
		<input type="email" name="petition_request_email" class="petition_email" placeholder="Enter the Api Requester Email" value="<?php echo get_option( 'petition_request_email' ); ?>" /><br/><br/>
		<?php
		if ( get_option( 'petition_auth_key' ) == '' ) {
			echo '<input type="button" name="Generate ID" class="generate_auth_key" value="Generate Authorization Key"/>';}
?>



		<div class="pet_auth_key"
		<?php
		if ( get_option( 'petition_auth_key' ) == '' ) {
			echo 'style="display: none;"';}
?>
>
			<label>Your Petition Authorization Key</label><input type="text" name="petition_auth_key" class="get_auth_key" value="<?php echo get_option( 'petition_auth_key' ); ?>" />
			<?php submit_button(); ?>
		</div>
	</form>
</div>
</div>
<script>
jQuery(document).ready(function()
{
	jQuery('.pet_save_btn').hide();
	jQuery(document).on('click', '.generate_id', function(e)
	{
		e.preventDefault();
		var pet_url = jQuery('.petition_url').val();
		var performing_action = 'gen_id';
		jQuery.ajax({
			url: ajaxurl,
			type: 'POST',
			data: {action: 'vl_options_save', petitionurl:pet_url, paction:performing_action},
			success: function (data)
			{

				jQuery('.get_pet_id').val(data);
				jQuery('.pet_id').show();
				jQuery('.generate_id').hide();
			},
			error: function (error)
			{
			  jQuery('.pet_id').html(error);
			}
		});
	});

	jQuery(document).on('click', '.generate_auth_key', function(e)
	{
		e.preventDefault();
		var my_pet_id = jQuery('.get_pet_id').val();
		var my_auth_email = jQuery('.petition_email').val();
		alert(my_pet_id+my_auth_email);
		var performing_action = 'generate_auth';
		jQuery.ajax({
			url: ajaxurl,
			type: 'POST',
			data: {action:'vl_options_save', petitionid:my_pet_id, paction:performing_action, email:my_auth_email},
			success: function (data)
			{
				jQuery('.get_auth_key').val(data);
				jQuery('.pet_auth_key').show();
				jQuery('.generate_auth_key').hide();

			},
			error: function (error)
			{
			  jQuery('.get_auth_key').html(error);
			}
		});
	});
});
</script>
<?php
}

add_action( 'admin_init', 'my_plugin_options' );
function my_plugin_options() {
	//register_setting('my_option_group', 'my_option_name','intval');
	register_setting( 'meta-data-group1', 'api_key' );
	register_setting( 'meta-data-group1', 'api_secret' );
	register_setting( 'meta-data-group2', 'petition_url' );
	register_setting( 'meta-data-group2', 'petition_id' );
	register_setting( 'meta-data-group3', 'petition_request_email' );
	register_setting( 'meta-data-group3', 'petition_auth_key' );

}
?>
