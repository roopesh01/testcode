<?php
include '../../../../wp-config.php';
global $wpdb,$current_user;
$role = $_POST['iis_role'];
$permission = $_POST['permission'];
$user_id = $current_user->ID;
if ($user_id == 0) 
{
    $redirect = site_url()."/registration-page/login/";
    echo json_encode(array('login_error'=>1,'redirect'=>$redirect));    
    exit; 
} 
$table = $wpdb->prefix."nomination_vote_permission";
$update = $wpdb->query( $wpdb->prepare("UPDATE $table SET permission= %s WHERE iis_role= %s", $permission, $role) );

if($update == 1)
{
	$redirect = site_url()."/wp-admin/admin.php?page=NominationVotingRights/";
	$success = 1;
	$insert_message = "Settings Updated Sucessfully.";
	echo json_encode(array('success'=>$success, 'insertmessage'=>$insert_message, 'redirect'=>$redirect));
	exit;
}
else
{
	$insert = $wpdb->insert( $table,
                        array
                        (
                            'iis_role' => $role,
                            'permission' =>$permission,                     
                        ),
                        array('%s','%s')
                    );
					
	if($insert == 1)
	{
		$redirect = site_url()."/wp-admin/admin.php?page=NominationVotingRights/";
		$success = 1;
		$insert_message = "Settings Saved Sucessfully.";
		echo json_encode(array('success'=>$success, 'insertmessage'=>$insert_message, 'redirect'=>$redirect));
		exit;
	}
}