<?php
/*
 * Template Name: New User Basic Profile
 *
 */
get_header();
?>
<div id="primary" class="site-content">
<div id="content" role="main">

<?php
if ( isset( $_GET['ExpertId'] ) ) {
	global $wpdb;
	$userid        = vl_sanitize_unslash( 'ExpertId' );
	$currentuserid = get_current_user_id();

	$table           = $wpdb->prefix . 'addtofavorite';
	$pricetable      = $wpdb->prefix . 'expert_price';
	$usermetatable   = 'wp68_usermeta';
	$post_table      = $wpdb->prefix . 'posts';
	$post_meta_table = $wpdb->prefix . 'postmeta';
	$logo_type       = 'company_logo';
	$prev_logo_type  = 'prev_company_logo';

	$single        = true;
	$key           = 'savetofavorite';
	$key2          = 'ratinglikes';
	$firstname     = get_user_meta( $userid, 'first_name', $single );
	$lastname      = get_user_meta( $userid, 'last_name', $single );
	$AboutYourSelf = bp_get_profile_field_data( 'field=AboutYourSelf&user_id=' . $userid );
	$title         = bp_get_profile_field_data( 'field=Title&user_id=' . $userid );
	$city          = bp_get_profile_field_data( 'field=City&user_id=' . $userid );
	$state         = bp_get_profile_field_data( 'field=State&user_id=' . $userid );
	$price         = $wpdb->get_var( $wpdb->prepare( "SELECT price FROM $pricetable WHERE user_id= %d", $userid ) );
	$salutation    = bp_get_profile_field_data( 'field=salutation&user_id=' . $userid );
	$single        = true;
	//$favorite = get_user_meta($userid, $key, $single);
	$addtofavorite = $wpdb->get_var( $wpdb->prepare( "SELECT addtofavorites FROM $table WHERE userid= %d AND visitorid= %d", $userid, $currentuserid ) );
	$rating        = get_user_meta( $userid, $key2, $single );

	//echo $favorite;
	if ( $addtofavorite ) {
		if ( $addtofavorite == 'yes' ) {
			?>
			<script>
			$(document).ready(function()
			{
					var removefavorite = '<span class="removefavorites"><i class="fa fa-trash-o" aria-hidden="true"></i> Remove From Favorites</span>';
					$('.favoriteaddremove').find('span').addClass("removefavorites");
					$('.favoriteaddremove').find('span').removeClass("savefavorites");
					$('.favoriteaddremove').html(removefavorite);
			});
			</script>
			<?php

		} else {
			?>
			<script>
			$(document).ready(function()
			{
						var savefavorite = '<span class="savefavorites"><i class="fa fa-thumbs-o-up" aria-hidden="true"></i> Save to Favorites</span>';
						$('.favoriteaddremove').find('span').addClass("savefavorites");
						$('.favoriteaddremove').find('span').removeClass("removefavorites");
						$('.favoriteaddremove').html(savefavorite);
			});
			</script>
			<?php
		}
	}

	if ( $rating == $currentuserid ) {
		?>
		<script>
		$(document).ready(function()
		{
				var removefavorite = '<span class="dislikearticle">I Dislike This Article</span>';
				$('.likedislike').find('span').addClass("dislikearticle");
				$('.likedislike').find('span').removeClass("likearticle");
				$('.likedislike').html(removefavorite);
		});
		</script>
		<?php

	} else {
		?>
		<script>
		$(document).ready(function()
		{
					var savefavorite = '<span class="likearticle">I Like This Article</span>';
					$('.likedislike').find('span').addClass("likearticle");
					$('.likedislike').find('span').removeClass("dislikearticle");
					$('.likedislike').html(savefavorite);
		});
		</script>
		<?php
	}
	$favorite = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM $table WHERE userid= %d", $userid ) );

	//echo $totalcountforexpert;
?>
	<div class="userbasicprofile">
	<div class="">
		<div class="pinfoTbar">
			<div class="image-sec">
				<?php
				echo get_avatar( $userid );
				?>
			</div>
			<div class="userInfobar">
				<div class="disp-inblock">
					<h3><?php echo $salutation . '&nbsp;' . $firstname . '&nbsp;' . $lastname; ?></h3>
					<h5 class="expert-meta"><?php echo $title; ?></h5>
					<div class="expert-location">
					<?php
					if ( $city ) {
						echo '<i class="fa fa-map-marker" aria-hidden="true"></i>';}
?>

<?php
echo $city;
if ( $city && $state ) {
	echo ',&nbsp;';
} echo $state;
?>
</div>
					<input type="hidden" id="expertid" value="<?php echo $userid; ?>"/>
					<input type="hidden" id="current_user_id" value="<?php echo $currentuserid; ?>"/>
				</div>
				<div class="pinfoAction">
					<!--<div class="session_schedule">
						<input type="button" class="schedule_session btn" value="Request an Appointment"/>
						<div class="message_div" style="display: none;">
							<textarea id="schedule_message" placeholder="Enter Your Message" ></textarea>
							<input type="button" class="sendschedulesmg btn" value="Submit"/>
						</div>
					</div> -->
					<div class="ep-message"><a class="send_msg" href="#" data-toggle="modal" data-target="#sendText" id="send_msg_link">Request an Appointment</a></div>
					<div id="sendText" class="modal fade" role="dialog">
					  <div class="modal-dialog">
						<!-- Modal content-->
						<div class="modal-content">
						  <div class="modal-header">
							<button type="button" class="close" data-dismiss="modal">&times;</button>
							<h4 class="modal-title">Request an Appointment</h4>
						  </div>
						  <div class="modal-body">

							<div class="request_status"></div>
							<div class="formRow modalText">
								<textarea id="messagetoexpert" cols="40" class="messageexpert" placeholder="Message"></textarea>
								<div class="messge_err"></div>
							</div>
							<div class="formRow modalTime hasglIcon">
							  <input id="timepicker1" type="text" class="form-control input-small" placeholder="Time" class="form-control">
								<span class="input-group-addon"><i class="glyphicon glyphicon-time"></i></span>
								<div class="time_err"></div>

							</div>
							<div class="formRow modalLength">
								<select id="estimate_length">
									<option value="" selected="">Select estimate length</option>
									<option value="15">15 Minutes</option>
									<option value="30">30 Minutes </option>
									<option value="60">1 Hour</option>
								</select>
								<input type="hidden" id="s_expertid" value="<?php echo $userid; ?>"/>
								<input type="hidden" id="s_current_id" value="<?php echo $currentuserid; ?>"/>
								<div class="length_err"></div>
							</div>
							<div class="formRow modalDate hasglIcon">
								<input type="text" class="form-control" id="requestDate" placeholder="Date">
								<span class="input-group-addon"><i class="glyphicon glyphicon-calendar"></i></span>
							<div class="date_err"></div>
							</div>
							<div class="formRow modalButton"><a href="javascript:void(0);" class="appointment_request btn" id="">Submit</a></div>
						  </div>
						  <!-- <div class="modal-footer"><button type="button" class="btn btn-default" data-dismiss="modal">Close</button></div> -->
						</div>
					  </div>
					</div>
					<div class="ep-messagebox">
					<?php
					if ( is_user_logged_in() ) {
						echo '<div class="ep-message"><a class="send_msg" href="javascript:void(0);" id="send_msg_link">Send a Message</a></div>';
					} else {
						echo '<div class="ep-message"><a class="send_msg" href="javascript:void(0);" id="non_login_msg_link">Send a Message</a></div>';
					}
						$current_date            = date( 'm/d/Y' );
						$con_date_str            = strtotime( $current_date );
						$converted_estimate_date = date( 'm/d/Y', $con_date_str );
						global $wpdb;
						$donation_table = $wpdb->prefix . 'user_donation_details';
						$donation       = $wpdb->get_var( "SELECT donation_percentage FROM $donation_table WHERE user_id = '$userid' AND start_time <= '$converted_estimate_date' AND end_time >= '$converted_estimate_date'" );
					if ( ! empty( $donation ) ) {
						echo 'Charity Contribution : ' . $donation . '%';
					}
					?>

						<div class="messagesection" style="display: none;">
							<p><textarea id="messagetoexpert" cols="40" class="messageexpert"></textarea><br />
								<a href="javascript:void(0);" class="submit_message" id="msg_submit">Submit Message</a>
							</p>
						</div>
					</div>

				</div>
			</div>
		</div>
		<div class="epinfo-wrap"> <!-- rightlinks -->
			<div class="epinfo-box">
				<?php
				$expertprices = number_format( $price, 2, '.', '' );
				if ( $expertprices == 0.00 ) {
					$expertprices = 'NA';
				}
				?>

				<h3 class="ep-pricing">
				<?php
				if ( $expertprices ) {
					echo $expertprices;}
?>
<small> Credits/min</small></h3>
				<div class="epinfo-rating">
					<?php
					$ratingtable = $wpdb->prefix . 'ratings';
					$average     = $wpdb->get_var( "SELECT Avg(totalrating) FROM $ratingtable WHERE expertid = $userid" );
					//echo $average;
					if ( $average ) {
						$average2 = number_format( (float) $average, 2, '.', '' );
						if ( $average2 > 4.5 ) {
							echo '<div class="clientFeedback"><i class="fa fa-star" aria-hidden="true"></i><i class="fa fa-star" aria-hidden="true"></i><i class="fa fa-star" aria-hidden="true"></i><i class="fa fa-star" aria-hidden="true"><i class="fa fa-star" aria-hidden="true"></div>';
							echo $average2 . ' out of 5 stars';
						}
						if ( $average2 > 4 ) {
							echo '<div class="clientFeedback"><i class="fa fa-star" aria-hidden="true"></i><i class="fa fa-star" aria-hidden="true"></i><i class="fa fa-star" aria-hidden="true"></i><i class="fa fa-star" aria-hidden="true"><i class="fa fa-star-half" aria-hidden="true"></i></div>';
							echo $average2 . ' out of 5 stars';
						} elseif ( $average2 > 3.5 ) {
							echo '<div class="clientFeedback"><i class="fa fa-star" aria-hidden="true"></i><i class="fa fa-star" aria-hidden="true"></i><i class="fa fa-star" aria-hidden="true"></i><i class="fa fa-star" aria-hidden="true"></i><i class="fa fa-star-o" aria-hidden="true"></i></div>';
							echo $average2 . ' out of 5 stars';
						} elseif ( $average2 > 3 ) {
							echo '<div class="clientFeedback"><i class="fa fa-star" aria-hidden="true"></i><i class="fa fa-star" aria-hidden="true"></i><i class="fa fa-star" aria-hidden="true"></i><i class="fa fa-star-half" aria-hidden="true"></i><i class="fa fa-star-o" aria-hidden="true"></i></div>';
							echo $average2 . ' out of 5 stars';
						} elseif ( $average2 > 2.5 ) {
							echo '<div class="clientFeedback"><i class="fa fa-star" aria-hidden="true"></i><i class="fa fa-star" aria-hidden="true"></i><i class="fa fa-star" aria-hidden="true"></i><i class="fa fa-star-half" aria-hidden="true"></i><i class="fa fa-star-o" aria-hidden="true"></i></div>';
							echo $average2 . ' out of 5 stars';
						} elseif ( $average2 > 2 ) {
							echo '<div class="clientFeedback"><i class="fa fa-star" aria-hidden="true"></i><i class="fa fa-star" aria-hidden="true"></i><i class="fa fa-star-half" aria-hidden="true"></i><i class="fa fa-star-o" aria-hidden="true"></i><i class="fa fa-star-o" aria-hidden="true"></i></div>';
							echo $average2 . ' out of 5 stars';
						} elseif ( $average2 > 1.5 ) {
							echo '<div class="clientFeedback"><i class="fa fa-star" aria-hidden="true"></i><i class="fa fa-star" aria-hidden="true"></i><i class="fa fa-star-o" aria-hidden="true"></i><i class="fa fa-star-o" aria-hidden="true"></i><i class="fa fa-star-o" aria-hidden="true"></i></div>';
							echo $average2 . ' out of 5 stars';
						} elseif ( $average2 > 1 ) {
							echo '<div class="clientFeedback"><i class="fa fa-star" aria-hidden="true"></i><i class="fa fa-star-half" aria-hidden="true"></i><i class="fa fa-star-o" aria-hidden="true"></i><i class="fa fa-star-o" aria-hidden="true"></i><i class="fa fa-star-o" aria-hidden="true"></i></div>';
							echo $average2 . ' out of 5 stars';
						} else {
							echo '<div class="clientFeedback"><i class="fa fa-star" aria-hidden="true"></i><i class="fa fa-star-o" aria-hidden="true"></i><i class="fa fa-star-o" aria-hidden="true"></i><i class="fa fa-star-o" aria-hidden="true"></i><i class="fa fa-star-o" aria-hidden="true"></i></div>';
							echo $average2 . ' out of 5 stars';
						}
					} else {
						echo '<div class="noRatingExpert">No Rating For This Expert</div>';

					}

					?>
				</div>
				<div class="ep-charContribution">
				<?php
				/* chet put donation code here */
					   global $wpdb;
						$donation_table = $wpdb->prefix . 'user_donation_details';
						$donation       = $wpdb->get_var( "SELECT donation_percentage FROM $donation_table WHERE user_id = '$userid' AND start_time <= '$converted_estimate_date' AND end_time >= '$converted_estimate_date'" );
				if ( ! empty( $donation ) ) {
					echo 'Charity Contribution : ' . $donation . '%';
				}
				?>
				</div>
				<div class="userProfCurrentLogo">
				<?php
					$current_logo      = $wpdb->get_results( "SELECT * FROM $post_table WHERE `post_author`=$userid AND `post_type`='$logo_type'" );
					$logo_img_url      = $current_logo[0]->guid;
					$prev_company_logo = $wpdb->get_results( "SELECT * FROM $post_table WHERE `post_author`=$userid AND `post_type`='$prev_logo_type'" );
				if ( $current_logo ) :
					echo '<img src="' . $logo_img_url . '"/>';
					else :
						echo '<img src="../wp-content/themes/boss-child/images/no_logo.png"/>';
					endif;
				?>
				</div>
				<div class="ep-actions">
					<?php
					/* if(is_user_logged_in())
					{
					echo '<p class="likedislikep">
					<a class="likethisarticle  likedislike" href="javascript:void(0);"><span class="likearticle">Rate This</span></a>
					</p>';
					}
					else
					{
					echo '<p class="likedislikep">
					<a class="likethisarticle  nonloginaddremove" href="javascript:void(0);"><span class="likearticle">You Rated This</span></a>
					</p>';
					}*/
					?>

					<?php
					if ( is_user_logged_in() ) {
						?>
						<a href="/request-a-call/?ExpertId=<?php echo $userid; ?>" class="call_link">Setup conference</a>

						<?php
					} else {
						?>
						<a href="javascript:void(0);" class="call_link call_not_logged_in">Request A Call</a>
						<?php
					}
					?>

					<div class="customRating">
					<!-- New Rating System-->
					<span class="rateSpan">Rate this Expert</span>
					<?php
					if ( is_user_logged_in() ) {
						$rating_exist = $wpdb->get_var( "SELECT `totalrating` FROM $ratingtable WHERE `currentuserid`=$currentuserid  AND `expertid`=$userid" );
						?>
						<div class="wporg-ratings rating-stars">
							<fieldset class="rating">
								<input type="radio" id="star5" name="rating" value="5" data-id="5" class="ratingradio"
								<?php
								if ( $rating_exist == '5' ) {
									echo 'checked="checked"';}
?>
/><label class = "full" for="star5" title="Awesome - 5 stars"></label>
								<input type="radio" id="star4" name="rating" value="4" data-id="4" class="ratingradio"
								<?php
								if ( $rating_exist == '4' ) {
									echo 'checked="checked"';}
?>
/><label class = "full" for="star4" title="Pretty good - 4 stars"></label>
								<input type="radio" id="star3" name="rating" value="3" data-id="3" class="ratingradio"
								<?php
								if ( $rating_exist == '3' ) {
									echo 'checked="checked"';}
?>
/><label class = "full" for="star3" title="Average - 3 stars"></label>
								<input type="radio" id="star2" name="rating" value="2" data-id="2" class="ratingradio"
								<?php
								if ( $rating_exist == '2' ) {
									echo 'checked="checked"';}
?>
/><label class = "full" for="star2" title="Bad - 2 stars"></label>
								<input type="radio" id="star1" name="rating" value="1" data-id="1" class="ratingradio"
								<?php
								if ( $rating_exist == '1' ) {
									echo 'checked="checked"';}
?>
/><label class = "full" for="star1" title="Very Poor - 1 star"></label>
							</fieldset>
						</div>
						<?php
					}
					?>
					<!-- New Rating System-->
					</div>
					<div class="savefaovritediv">
						<?php

							$bp_friends_table = 'wp68_bp_friends';
							$get_friend       = $wpdb->get_results( "SELECT * FROM $bp_friends_table WHERE `initiator_user_id`=$currentuserid AND `friend_user_id`=$userid AND `is_confirmed`=0" );
						if ( $get_friend ) :
							echo '<a class="link_to_directory ep-btnaddfav addFrnd friend_remove " href="javascript:void(0);"><i class="fa fa-user-times" aria-hidden="true"></i>Cancel Friendship</a>';
							else :
								echo '<a class="link_to_directory ep-btnaddfav addFrnd friend_add" href="javascript:void(0);"><i class="fa fa-user-plus" aria-hidden="true"></i> Add friend</a>';
							endif;
						?>
						<a class="link_to_directory ep-btnaddfav addFrnd friend_add" href="javascript:void(0);"><i class="fa fa-user-plus" aria-hidden="true"></i> Add friend</a>
						<a class="newFavorite ep-btnaddfav" href="javascript:;" data-toggle="modal" data-target="#favModal" id="send_favModal_link"><i class="fa fa-thumbs-up" aria-hidden="true"></i> Save to Favorites</a>
						<div id="favModal" class="modal fade" role="dialog">
						  <div class="modal-dialog">
							<!-- Modal content-->
							<div class="modal-content">
							  <div class="modal-header">
								<button type="button" class="close" data-dismiss="modal">&times;</button>
								<h4 class="modal-title">Save to Favorites</h4>
							  </div>
							  <div class="modal-body">
								<div class="favoList">
									<?php
										$favorite = $wpdb->get_results( "SELECT * FROM `$table` WHERE `visitorid` = '$currentuserid' AND `userid` = '$userid' AND `addtofavorites` = 'yes'" );
									if ( $favorite ) :
										echo '<label><input type="radio" name="optradio" id="remove_favorite" checked="checked"><span>Remove From favorite list</span></label>
									<p class="formRow radioButtonCenter modalButton"><a href="javascript:;" class="submit_message remove_expert" id="fav_submit">Remove</a></p>';
										else :
											echo  '<label><input type="radio" name="optradio" id="add_favorite" checked="checked"><span>Add To favorite list</span></label>
									<p class="formRow radioButtonCenter modalButton"><a href="javascript:;" class="submit_message fav_expert" id="fav_submit">Add</a></p>';
										endif;
									?>
									<?php
										$my_team_detail = $wpdb->prefix . 'expert_team_detail';
										$myteams        = $wpdb->get_results( "SELECT * FROM `$my_team_detail` WHERE `current_user_id` = '$currentuserid' AND (`invited_experts` NOT LIKE '%,$userid%' AND (`invited_experts` NOT LIKE '%$userid,%' AND (`invited_experts` NOT LIKE '%,$userid,%' AND (`invited_experts` != '$userid'))))" );
									?>
								</div>
								<div class="favoTeam">
									<label><input type="radio" name="optradio" id="favorite_add_team"/> <span>Add to my expert team</span></label>
									<div class="favorite_team" style="display: none;">
										<div class="teamSelectBox">
										  <select class="teamSelect">
											<?php
											if ( $myteams ) :
												foreach ( $myteams as $teams ) :
													echo '<option value="' . $teams->id . '">' . $teams->team_name . '</option>';
												endforeach;
											endif;
											?>
										  </select>
											<div class="teamCreateButtonBox">
											  <a class="createTeam add_to_team" href="javascript:;">Add To Team</a>
										   </div>
										</div>
									</div>
										<div class="create_team_new">
											<label><input type="radio" name="optradio" id="create_new_team_chkbox"/> <span>Create new team for this user</span></label>
											<div class="create_new_team_div" style="display: none;">
												<input type="text" class="teamCreateInput" placeholder="Create New Team"/>
												<div class="teamCreateButtonBox">
													<button type="button" class="createTeam" data-dismiss="modal">Cancel</button><a class="createTeam create_to_team" href="javascript:;">Create</a>
												</div>
											</div>
										</div>
								</div>
							  </div>
							  <!-- <div class="modal-footer"><button type="button" class="btn btn-default" data-dismiss="modal">Close</button></div> -->
							</div>
						  </div>
						</div>

						<?php
						 /*
						if(is_user_logged_in())
						{
						echo '<a class="ep-btnaddfav send_msg  favoriteaddremove" href="javascript:void(0);"><span class="savefavorites"><i class="fa fa-thumbs-o-up" aria-hidden="true"></i> Save To Favorites</span></a>';
						}
						else
						{
						echo '<a class="ep-btnaddfav send_msg  nonloginaddremove" href="javascript:void(0);"><span class="savefavorites"><i class="fa fa-thumbs-o-up" aria-hidden="true"></i> Save To Favorites</span></a>';
						} */
						?>
						<p class="ep-saves">Saved <span id="counting">
						<?php
						$initial       = 0;
						$totalfavorite = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM $table WHERE userid= %d AND addtofavorites = 'yes'", $userid ) );
						if ( $totalfavorite ) {
							$counting = count( $totalfavorite );
							echo $counting;
						} else {
							echo $initial;
						}
						?>

						</span> times</p>
						<?php
						$siteurl = get_site_url();
						?>
					</div>
				</div>
			</div>
		<?php
				$video_price     = $wpdb->get_var( $wpdb->prepare( "SELECT video_min_price FROM $pricetable WHERE user_id= %d", $userid ) );

				$video_price = number_format( $video_price, 2, '.', '' );
		if ( $video_price == 0.00 ) {
			$video_price = 'NA';
		}

				$chat_price = $wpdb->get_var( $wpdb->prepare( "SELECT chat_price FROM $pricetable WHERE user_id= %d", $userid ) );

				$chat_price = number_format( $chat_price, 2, '.', '' );
		if ( $chat_price == 0.00 ) {
			$chat_price = 'NA';
		}

				$sms_price = $wpdb->get_var( $wpdb->prepare( "SELECT sms_price FROM $pricetable WHERE user_id= %d", $userid ) );

				$sms_price = number_format( $sms_price, 2, '.', '' );
		if ( $sms_price == 0.00 ) {
			$sms_price = 'NA';
		}
			?>
			<div class="creditsBox">
				<h6><span class="crEmpty">&nbsp;</span> <span class="crHeading">Credits</span></h6>
				<ul class="creditsTable">
					<li><a href="javascript:;"><span class="creditIcons"><i class="fa fa-video-camera" aria-hidden="true"></i></span> <?php echo $video_price; ?>/min <sup>**</sup></a></li>
					<li><a href="javascript:;"><span class="creditIcons"><i class="fa fa-phone" aria-hidden="true"></i></span> <?php echo $expertprices; ?>/min <sup>**</sup></a></li>
					<li><a href="javascript:;"><span class="creditIcons"><i class="fa fa-comments" aria-hidden="true"></i></span> <?php echo $chat_price; ?>/msg <sup>**</sup></a></li>
					<li><a href="javascript:;"><span class="creditIcons"><i class="fa fa-mobile" aria-hidden="true"></i></span> <?php echo $sms_price; ?>/msg <sup>*</sup></a></li>
				</ul>
				<div class="callConditions">
					<p><sup>**</sup> Browser Compatibility<small>Chrome, Firefox</small></p>
					<p><sup>*</sup> SMS Calls<small>Browser to Mobile only</small><small>Mobile to Browser only</small></p>
				</div>
			</div>
		</div>
		<div class="ep-details">
			<div class="profile-info">
			  <p class="profileContent"><?php echo wpautop( $AboutYourSelf ); ?></p><!--profileContent_END-->
			</div>
			<div class="userpreviousOrgLogo">
			<ul>
			<li class="userprevEmpText"><span>Affiliations</span></li>
				<?php
				if ( $prev_company_logo ) :
					foreach ( $prev_company_logo as $logos ) :
						$prev_img_url = $logos->guid;
						echo '<li><img src="' . $prev_img_url . '"></li>';
						endforeach;
					else :
						echo '<li><img src="../wp-content/themes/boss-child/images/no_logo.png"></li>';
					endif;
				?>
			</ul>
			</div>
			<div class="ep-tagbox customtagbox">
				<div class="related-tags related-category">
					<h5 class="tagheading bolds">Related Categories</h5>
					<h6 class="tagheading bolds relatedSubCategory">Primary:</h6>
					<?php
								$primary_table  = $wpdb->prefix . 'primary_category';
								$user_cat_table = $wpdb->prefix . 'user_category';
								$primary_cats   = $wpdb->get_results( "SELECT * FROM $primary_table WHERE `user_id`=$userid AND `admin_approve`='yes'" );
					if ( $primary_cats ) :
						$primary_cat  = $primary_cats[0]->primary_category;
						$get_category = $wpdb->get_var( "SELECT `category_name` FROM $user_cat_table WHERE `category_key`='$primary_cat'" );
						echo '<span class="primary_cat">' . $get_category . '</span>';
								else :
									$no_category = 'No Primary Category Found';
									echo '<span class="primary_cat">' . $no_category . '</span>';
									$get_category = '';
								endif;
					?>
					<div class="alltags">
						<h6 class="tagheading bolds relatedSubCategory">Additional:</h6>
						<?php
							$tabledata    = $wpdb->prefix . 'cat_';
							$usercategory = $wpdb->prefix . 'user_category';
							$rcategory    = $wpdb->get_results( "SELECT * FROM $usermetatable WHERE `user_id` = '$userid' AND `meta_key` LIKE '%$tabledata%'" );
								ob_start();
						if ( $rcategory ) :
							foreach ( $rcategory as $category ) :
								$character     = $category->meta_key;
								$filtered      = str_replace( $tabledata, '', $character );
								$allcategories = $wpdb->get_var( "SELECT `category_name` FROM $usercategory WHERE `category_key` = '$filtered'" );
								if ( $allcategories != $get_category ) :
									echo $allcategories;
									echo ',&nbsp;';
								endif;
							endforeach;
							$output = ob_get_clean();
							echo rtrim( $output, ',&nbsp;' );
							echo '.';
								else :
									echo 'No Additional Category Found';
								endif;
								//endif;
						?>
					</div>
				</div>

				   <div class="related-tags related-category ">
					<h5 class="tagheading bolds">Related Sub Categories</h5>
					<div class="alltags">
						<?php
						$rsubcategory = $wpdb->get_results( "SELECT * FROM $usermetatable WHERE `user_id` = '$userid' AND `meta_key` LIKE '%$tabledata%'" );
						ob_start();
						if ( $rsubcategory ) :
							foreach ( $rsubcategory as $category ) :
								$metavaluess = $category->meta_value;
								if ( $metavaluess != '' ) :
									echo $metavaluess . ',&nbsp;';
								endif;
						endforeach;
						else :
							echo 'No Subcategory Found';
						endif;
						$output = ob_get_clean();
						echo rtrim( $output, ',&nbsp;' );
						echo '.'
						?>
					</div>
				</div>
				  <div class="related-tags">
				<h5 class="tagheading bolds">Related Tags</h5>
				<div class="alltags">
					<?php
						$usertags = get_user_meta( $userid, 'wp68_14_user_tags', $single = true );
						$list     = explode( ',', $usertags );
						$i        = 0;
						ob_start();
					if ( $usertags ) :
						foreach ( $list as $lists ) :
							if ( $i < 10 ) :
								echo $lists . ',';
								endif;
							$i++;
							endforeach;
						 else :
								echo 'No Tags Found';
						endif;
							$output = ob_get_clean();
							echo rtrim( $output, ',' );
						?>
				</div>
			  </div>

			</div> <!--customtagbox_END-->
				<?php
				if ( is_user_logged_in() ) {
					?>
					<div class="review-form">
						<div class="reviews-textarea">
							<!-- <h5>Write a Review</h5> -->
							<textarea class="userreviewform" placeholder="Write a Review" id="reviewformfield"></textarea>
						 </div>
						 <div class="reviewsubmit">
							<p class="characters" style="font-size: 10px;"><span class="char_limit">1000</span> Characters Left</p>
							<a href="javascript:void(0);" id="submit_review" class="submit_reviews">Submit Review</a>

					   </div>
					</div>
					<?php
				}
					?>

					<div class="all_reviews">
						<?php
						$tablename = $wpdb->prefix . 'reviews';
						$results   = $wpdb->get_results( "SELECT * FROM `$tablename` WHERE `expertid` = '$userid'" );
						//print_r($results);
						if ( $results ) :
							foreach ( $results as $result ) {
								$lastid     = $result->id;
								$userids    = $result->currentuserid;
								$ufirstname = get_user_meta( $userids, 'first_name', $single );
								$ulastname  = get_user_meta( $userids, 'last_name', $single );
							?>

							 <div class="userreview">
							 <div class="">
								<div class="image-section image-sec">
								<?php
									$size   = 96;
									echo get_avatar( $userids, $size );
								?>
								</div>
								<div class="message-section">
									 <div class="review-txt">
										<?php
										echo $result->message;
											?>
									 </div>
										 <div class="namesection">
										 <span class="firstlastname">
											<?php
											echo $ufirstname . '&nbsp;' . $ulastname;
											?>
										 </span>
											<span class="currenttime"><?php echo $result->currenttime; ?></span>
										 </div>
									</div>
								</div>
							</div>
							<?php
							}
						?>
					   <div class="show_more_main" id="show_more_main<?php echo $lastid; ?>">
									<?php
									if ( count( $results ) > 10 ) :
										echo '<span class="show_more" id="' . $lastid . '" >Show more</span>';
									endif;
									?>
									<span class="loading" style="display: none;"><span class="loding_txt">Loading....</span></span>
					   </div>
						<?php
					   endif;
						?>

				</div>
		</div>
	</div>


	</div>
	<?php
}
	?>

</div>
</div>
<link href="<?php echo get_stylesheet_directory_uri(); ?>/css/bootstrap.min.css"/>
<link rel="stylesheet" href="<?php echo get_stylesheet_directory_uri(); ?>/css/bootstrap-timepicker.min.css"/>
<link rel="stylesheet" href="<?php echo get_stylesheet_directory_uri(); ?>/css/font-awesome.min.css"/>
<link rel="stylesheet" href="<?php bloginfo( 'stylesheet_directory' ); ?>/css/jquery-ui.css">
<script type="text/javascript" src="<?php echo get_stylesheet_directory_uri(); ?>/js/bootstrap.min.js"></script>
<script src="<?php echo get_stylesheet_directory_uri(); ?>/js/bootstrap-timepicker.min.js"></script>
<script src="<?php echo get_stylesheet_directory_uri(); ?>/js/bootbox.min.js"></script>
<script src="<?php bloginfo( 'stylesheet_directory' ); ?>/js/jquery-ui.js"></script>
<script type="text/javascript">
  $('#timepicker1').timepicker();
</script>
	<?php
	include( 'addtofavoritejs.php' );
	include get_stylesheet_directory() . '/css/ratingcss.php';
	//get_footer();
	?>
