<?php
include '../../../../wp-config.php';
global $current_user;
$user_id = $current_user->ID;
$currentdirectory = get_stylesheet_directory_uri();

if(isset($_POST['clonepostid']) && isset($_POST['pricefield'])):
    $clonepostid = $_POST['clonepostid'];
    $pricefield = $_POST['pricefield'];
    $sucess = update_post_meta($clonepostid,'media_price',$pricefield);
    if($sucess):
    echo "price updated";
    endif;
else:

if(isset($_FILES["file1"]["type"]) && isset( $_POST['cpt_nonce_field'] ) && wp_verify_nonce( $_POST['cpt_nonce_field'], 'cpt_nonce_action' ) )
{
    $validextensions = array("jpeg", "jpg", "png", "JPG","JPEG","PNG");
    $temp1 = $_FILES["file1"]["name"];
    $post_name = $_POST['post_name'];
    $post_title = $_POST['post_title']; 
    $temporary = explode(".", $_FILES["file1"]["name"]);
    $userimage = $temporary[0].'.'.$temporary[1]; 
    $getname = $temporary[0];
    $getext =  $temporary[1];
    if($getext=='jpg' OR $getext=='JPG' OR $getext=='JPEG'):
        $getext ='jpeg';
    endif; 
    $newfile = $temporary[0].'.'.$getext;      
    ///echo($temp1);    
    $type = $_POST['mimetype'];
    $imgtypes = explode("/",$type);
    $imgtype =   $imgtypes[1];
    $postimgname =  $post_title.'.'.$imgtype;
    if($newfile!=$postimgname):
        echo "File Name Should Same As Previous Uploaded File";
        die();
    endif;
    
    //if()
    /*echo '<pre>';
        print_r($temporary);
    echo '<br/>';  */  
    $file_extension = end($temporary);
    if ((($_FILES["file1"]["type"] == "image/png") || ($_FILES["file1"]["type"] == "image/jpg") || ($_FILES["file1"]["type"] == "image/jpeg") || ($_FILES["file1"]["type"] == "image/JPG") || ($_FILES["file1"]["type"] == "image/JPEG") || ($_FILES["file1"]["type"] == "image/PNG") ) && ($_FILES["file1"]["size"] < 1097152)//Approx. 1mb files can be uploaded.
    && in_array($file_extension, $validextensions)) 
    {
        if ($_FILES["file1"]["error"] > 0)
        {
            echo "Return Code: " . $_FILES["file1"]["error"] . "<br/><br/>";
        }
        else
        {
            
            /*chagne file name */                
                $fileData = pathinfo(basename($_FILES["file1"]["name"]));
                $fileName =  $post_name. '.' . $fileData['extension'];
            /*chagne file name */
            $cyear = date("Y");
            $cmonth = date("m");
            $directory = $_SERVER['DOCUMENT_ROOT'] . '/wp-content/themes/boss-child/media_images/users/'.$user_id.'/'.$cyear.'/'.$cmonth.'/';            
            if (wp_mkdir_p($directory)) 
            {
                //echo 'It worked <br/>';
            }
            if (file_exists($directory.$fileName))
            {
                echo "<span id='invalid'><b>File already exists.</b></span> ";
            }
            else
            {             
                $sourcePath = $_FILES['file1']['tmp_name']; // Storing source path of the file in a variable
                //echo $sourcePath;                
                $targetPath =  $directory.$fileName;// Target path where file is to be stored
                //echo $targetPath;
                $uploadedfile =  move_uploaded_file($sourcePath,$targetPath); // Moving Uploaded file
                $imgurl = $currentdirectory.'/media_images/users/'.$user_id.'/'.$cyear.'/'.$cmonth.'/'.$fileName;
                //echo $imgurl;
                if($uploadedfile):
                    echo '<br/>';
                    echo "<span id='success'>Image Uploaded Successfully...!!</span><br/>";
                   /* echo "<br/><b>File Name:</b> " . $_FILES["file1"]["name"] . "<br>";
                    echo "<b>Type:</b> " . $_FILES["file1"]["type"] . "<br>";
                    echo "<b>Size:</b> " . ($_FILES["file1"]["size"] / 1024) . " kB<br>";
                    echo "<b>Temp file:</b> " . $_FILES["file1"]["tmp_name"] . "<br>";  */                  
                    $my_cptpost_args = array
                    (                    
                        'post_title'    => $_POST['post_title'],                    
                        'post_name'    => $_POST['post_name'],                    
                        'post_status'   => 'inherit',                    
                        'post_type' => $_POST['post_type'], 
                        'post_mime_type' => $_FILES["file1"]["type"],                  
                        'post_author' => $user_id,
                        'guid'  =>  $imgurl                
                    );
                    // insert the post into the database                    
                    $cpt_id = wp_insert_post( $my_cptpost_args, $wp_error);
                        if(isset($_POST['media_price'])):
                            $media_price = $_POST['media_price'];                    
                            update_post_meta($cpt_id, 'media_price', $media_price);                            
                        endif;
                        $path = 'media_images/users/'.$user_id.'/'.$cyear.'/'.$cmonth.'/'.$fileName;
                        update_post_meta($cpt_id, 'img_path_name', $path);         
                endif;                
            }
        }
    }
    else
    {
        echo "<span id='invalid'>***Invalid file Size or Type***<span>";
    }
}
endif;
?>