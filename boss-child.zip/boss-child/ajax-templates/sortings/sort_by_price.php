<?php

include '../../../../../wp-config.php';
	 global $wpdb,$current_user;
	 $curentuserid = $current_user->ID;
	 $table        = $wpdb->prefix . 'user_sub_category';
	 $metatable    = 'wp68_usermeta';
	 $catetable    = $wpdb->prefix . 'user_category';
	 $tagtable     = $wpdb->prefix . 'user_tags';
	 $ratingtable  = $wpdb->prefix . 'ratings';
	 $pricetable   = $wpdb->prefix . 'expert_price';
	 $prefix       = $wpdb->prefix;
	 $single       = true;
	 $post_table   = $wpdb->prefix . 'posts';
$post_meta_table   = $wpdb->prefix . 'postmeta';
$logo_type         = 'company_logo';
$prev_logo_type    = 'prev_company_logo';
if ( isset( $_POST['sort_by_price'] ) ) {
	$sortbyprice = $_POST['sort_by_price'];
	$subcatid    = $_POST['subcategoryid'];
	$catkey      = $_POST['catekey'];
	if ( $sortbyprice == 'valuehigh' ) {
		if ( $subcatid == '0' ) {
						$expertprice = $wpdb->get_results( "SELECT * FROM $pricetable ORDER BY `price` DESC" );
			if ( $expertprice ) :
				foreach ( $expertprice as $results ) :
					$userid = $results->user_id;
					if ( $userid != $curentuserid ) :
						$firstname     = get_user_meta( $userid, 'first_name', $single );
						$lastname      = get_user_meta( $userid, 'last_name', $single );
						$expertPrice   = $wpdb->get_var( "SELECT `price` FROM $pricetable WHERE `user_id`='$userid'" );
						$AboutYourSelf = bp_get_profile_field_data( 'field=AboutYourSelf&user_id=' . $userid );
						$title         = bp_get_profile_field_data( 'field=Title&user_id=' . $userid );
						$city          = bp_get_profile_field_data( 'field=City&user_id=' . $userid );
						$state         = bp_get_profile_field_data( 'field=State&user_id=' . $userid );
						$salutation    = bp_get_profile_field_data( 'field=salutation&user_id=' . $userid );
						?>
						<tr><!-- Table Row -->
						<td> <!-- Table Column -->
						   <div class="expertbycategorytags"> <!-- Expert  Category Main Div -->
							   <div class="row customexpert">  <!-- Expert Category Sub Div -->                
								   <div class="col-md-3 col-lg-2 ce-image">
									   <a href="<?php echo site_url(); ?>/user-basic-profile/?ExpertId=<?php echo $userid; ?>"><?php echo get_avatar( $userid, $size ); ?></a>
									   <div class="clientNameWrap">
									   <h4 class="ce-title"><a href="<?php echo site_url(); ?>/user-basic-profile/?ExpertId=<?php echo $userid; ?>">
																				<?php
																				if ( $salutation ) {
																					echo $salutation . '&nbsp;';
																				}echo $firstname . '&nbsp;' . $lastname;
?>
</a></h4>
										   <p class="ce-info"><span>
											<?php
											if ( $city ) {
												echo $city;
											} if ( $city && $state ) {
												echo ',&nbsp';
											} if ( $state ) {
												echo $state;}
?>
</span></p>
									   </div>
								   </div>
								   <div class="col-md-6 col-lg-7 ce-content">
									   <div class="clientBriefInfo">
											<?php
											   $current_logo      = $wpdb->get_results( "SELECT * FROM $post_table WHERE `post_author`=$userid AND `post_type`='$logo_type'" );
											   $logo_img_url      = $current_logo[0]->guid;
											   $prev_company_logo = $wpdb->get_results( "SELECT * FROM $post_table WHERE `post_author`=$userid AND `post_type`='$prev_logo_type'" );
											if ( $current_logo ) :
												echo '<div class="clientCurrentLogo"><img src="' . $logo_img_url . '"/></div>';
													   else :
															echo '<div class="clientCurrentLogo"><img src="../wp-content/themes/boss-child/images/no_logo.png"/></div>';
															endif;
														?>
																												
														<p class="ce-details"><?php echo $AboutYourSelf; ?></p>
														<div class="previousOrgLogo">
														<ul>
													<li class="prevEmpText"><span>Previous Affiliation</span></li>
													<?php
													if ( $prev_company_logo ) :
														foreach ( $prev_company_logo as $logos ) :
															$prev_img_url = $logos->guid;
															echo '<li><img src="' . $prev_img_url . '"></li>';
														endforeach;
														else :
															echo '<li><img src="../wp-content/themes/boss-child/images/no_logo.png"></li>';
														endif;
													?>
												</ul>
												</div>
											</div>
													</div>
													<div class="col-md-3 col-lg-3 ce-action">
											<div class="ce-pricing">
												<span class="profile-detail profile-stat price">
												<input type="hidden" name="basic_amount"/>
												<?php
												$expertprices = number_format( (float) $expertPrice, 2, '.', '' );
												?>
												<strong class="actual-price"><?php echo $expertprices; ?></strong>                                            
													   <small>Credits per minute</small>                                                        
													   </span>
												   </div>
												   <a href="/request-a-call/?ExpertId=<?php echo $userid; ?>" class="call_link">Request A Call</a>
												   <div class="expRating">                                                    
														<?php
														$average  = $wpdb->get_var( "SELECT Avg(totalrating) FROM $ratingtable WHERE expertid = $userid" );
														$average2 = number_format( (float) $average, 2, '.', '' );
														if ( $average2 > 4.5 ) {
															echo '<img src="/wp-content/themes/boss-child/images/rating/five-star.png" title="Awesome - 5 stars"/>';
															echo '<br/>';
															echo $average2 . ' out of 5 stars';
														} elseif ( $average2 > 3.5 ) {
															echo '<img src="/wp-content/themes/boss-child/images/rating/four-star.png" title="Pretty good - 4 stars"/>';
															echo '<br/>';
															echo $average2 . ' out of 5 stars';
														} elseif ( $average2 > 2.5 ) {
															echo '<img src="/wp-content/themes/boss-child/images/rating/three-star.png" title="Average - 3 stars"/>';
															echo '<br/>';
															echo $average2 . ' out of 5 stars';
														} elseif ( $average2 > 1.5 ) {
															echo '<img src="/wp-content/themes/boss-child/images/rating/two-star.png" title="Bad - 2 stars"/>';
															echo '<br/>';
															echo $average2 . ' out of 5 stars';
														} elseif ( $average2 > 0.5 ) {
															echo '<img src="/wp-content/themes/boss-child/images/rating/one-star.png" title="Very Poor - 1 star"/>';
															echo '<br/>';
															echo $average2 . ' out of 5 stars';
														} else {
															echo '<small>No Rating For This Expert</small>';
														}
												?>
											</div>
										</div>                    
												</div> <!-- Expert Category Sub Div -->
											</div> <!-- Expert  Category Main Div -->
										</td> <!-- Table Column -->
									</tr> <!-- Table Row -->
									<?php
								endif;
			endforeach;
						endif;
		} elseif ( $subcatid == '01' ) {
			$catname = $wpdb->get_results( "SELECT DISTINCT `$metatable`.* FROM $metatable INNER JOIN `$pricetable` ON $metatable.user_id =$pricetable.user_id WHERE $metatable.meta_key='$catkey' ORDER BY $pricetable.price DESC" );
			if ( $catname ) :
				foreach ( $catname as $results ) :
					$userid = $results->user_id;
					//echo $userid;
					if ( $userid != $curentuserid ) :
						$firstname     = get_user_meta( $userid, 'first_name', $single );
						$lastname      = get_user_meta( $userid, 'last_name', $single );
						$expertPrice   = $wpdb->get_var( "SELECT `price` FROM $pricetable WHERE `user_id`='$userid'" );
						$AboutYourSelf = bp_get_profile_field_data( 'field=AboutYourSelf&user_id=' . $userid );
						$title         = bp_get_profile_field_data( 'field=Title&user_id=' . $userid );
						$city          = bp_get_profile_field_data( 'field=City&user_id=' . $userid );
						$state         = bp_get_profile_field_data( 'field=State&user_id=' . $userid );
						$salutation    = bp_get_profile_field_data( 'field=salutation&user_id=' . $userid );
						?>
						<tr><!-- Table Row -->
						   <td> <!-- Table Column -->
							   <div class="expertbycategorytags"> <!-- Expert  Category Main Div -->
								   <div class="row customexpert">  <!-- Expert Category Sub Div -->                
									   <div class="col-md-3 col-lg-2 ce-image">
										   <a href="<?php echo site_url(); ?>/user-basic-profile/?ExpertId=<?php echo $userid; ?>"><?php echo get_avatar( $userid, $size ); ?></a>
										   <div class="clientNameWrap">
										   <h4 class="ce-title"><a href="<?php echo site_url(); ?>/user-basic-profile/?ExpertId=<?php echo $userid; ?>">
																					<?php
																					if ( $salutation ) {
																						echo $salutation . '&nbsp;';
																					}echo $firstname . '&nbsp;' . $lastname;
?>
</a></h4>
										   <p class="ce-info"><span>
											<?php
											if ( $city ) {
												echo $city;
											} if ( $city && $state ) {
												echo ',&nbsp';
											} if ( $state ) {
												echo $state;}
?>
</span></p>
										   </div>
									   </div>
									   <div class="col-md-6 col-lg-7 ce-content">
										   <div class="clientBriefInfo">
												<?php
												   $current_logo      = $wpdb->get_results( "SELECT * FROM $post_table WHERE `post_author`=$userid AND `post_type`='$logo_type'" );
												   $logo_img_url      = $current_logo[0]->guid;
												   $prev_company_logo = $wpdb->get_results( "SELECT * FROM $post_table WHERE `post_author`=$userid AND `post_type`='$prev_logo_type'" );
												if ( $current_logo ) :
													echo '<div class="clientCurrentLogo"><img src="' . $logo_img_url . '"/></div>';
														   else :
																echo '<div class="clientCurrentLogo"><img src="../wp-content/themes/boss-child/images/no_logo.png"/></div>';
															endif;
														?>
																												
														<p class="ce-details"><?php echo $AboutYourSelf; ?></p>
														<div class="previousOrgLogo">
														<ul>
														<li class="prevEmpText"><span>Previous Affiliation</span></li>
														<?php
														if ( $prev_company_logo ) :
															foreach ( $prev_company_logo as $logos ) :
																$prev_img_url = $logos->guid;
																echo '<li><img src="' . $prev_img_url . '"></li>';
																endforeach;
															else :
																	echo '<li><img src="../wp-content/themes/boss-child/images/no_logo.png"></li>';
																endif;
															?>
														</ul>
														</div>
													</div>
												</div>
												<div class="col-md-3 col-lg-3 ce-action">
													<div class="ce-pricing">
														<span class="profile-detail profile-stat price">
														<input type="hidden" name="basic_amount"/>
														<?php
														$expertprices = number_format( (float) $expertPrice, 2, '.', '' );
														?>
														<strong class="actual-price"><?php echo $expertprices; ?></strong>                                            
														<small>Credits per minute</small>                                                        
														</span>
													</div>
													<a href="/request-a-call/?ExpertId=<?php echo $userid; ?>" class="call_link">Request A Call</a>
													<div class="expRating">                                                    
														<?php
														$average  = $wpdb->get_var( "SELECT Avg(totalrating) FROM $ratingtable WHERE expertid = $userid" );
														$average2 = number_format( (float) $average, 2, '.', '' );
														if ( $average2 > 4.5 ) {
															echo '<img src="/wp-content/themes/boss-child/images/rating/five-star.png" title="Awesome - 5 stars"/>';
															echo '<br/>';
															echo $average2 . ' out of 5 stars';
														} elseif ( $average2 > 3.5 ) {
															echo '<img src="/wp-content/themes/boss-child/images/rating/four-star.png" title="Pretty good - 4 stars"/>';
															echo '<br/>';
															echo $average2 . ' out of 5 stars';
														} elseif ( $average2 > 2.5 ) {
															echo '<img src="/wp-content/themes/boss-child/images/rating/three-star.png" title="Average - 3 stars"/>';
															echo '<br/>';
															echo $average2 . ' out of 5 stars';
														} elseif ( $average2 > 1.5 ) {
															echo '<img src="/wp-content/themes/boss-child/images/rating/two-star.png" title="Bad - 2 stars"/>';
															echo '<br/>';
															echo $average2 . ' out of 5 stars';
														} elseif ( $average2 > 0.5 ) {
															echo '<img src="/wp-content/themes/boss-child/images/rating/one-star.png" title="Very Poor - 1 star"/>';
															echo '<br/>';
															echo $average2 . ' out of 5 stars';
														} else {
															echo '<small>No Rating For This Expert</small>';
														}
														?>
													</div>
												</div>                    
											</div> <!-- Expert Category Sub Div -->
										</div> <!-- Expert  Category Main Div -->
									</td> <!-- Table Column -->
								</tr> <!-- Table Row -->
								<?php
							endif;
							endforeach;
						endif;

		} else {
			$sub_categoryname = $wpdb->get_var( "SELECT `sub_category_name` FROM $table WHERE `id`=$subcatid" );
			$catid            = $wpdb->get_var( "SELECT `category_id` FROM $table WHERE `id`=$subcatid" );
			$category_name    = $wpdb->get_var( "SELECT `category_name` FROM $catetable WHERE `id`=$catid" );
			$categoryy_name   = $prefix . 'cat_' . $category_name;
			$catname          = $wpdb->get_results( "SELECT DISTINCT `$metatable`.* FROM $metatable INNER JOIN `$pricetable` ON $metatable.user_id =$pricetable.user_id WHERE $metatable.meta_value LIKE '%$sub_categoryname%' AND wp68_usermeta.meta_key='$categoryy_name' ORDER BY $pricetable.price DESC" );
			if ( $catname ) :
				foreach ( $catname as $results ) :
					$userid = $results->user_id;
					//echo $userid;
					if ( $userid != $curentuserid ) :
						$firstname     = get_user_meta( $userid, 'first_name', $single );
						$lastname      = get_user_meta( $userid, 'last_name', $single );
						$expertPrice   = $wpdb->get_var( "SELECT `price` FROM $pricetable WHERE `user_id`='$userid'" );
						$AboutYourSelf = bp_get_profile_field_data( 'field=AboutYourSelf&user_id=' . $userid );
						$title         = bp_get_profile_field_data( 'field=Title&user_id=' . $userid );
						$city          = bp_get_profile_field_data( 'field=City&user_id=' . $userid );
						$state         = bp_get_profile_field_data( 'field=State&user_id=' . $userid );
						$salutation    = bp_get_profile_field_data( 'field=salutation&user_id=' . $userid );

						?>
						<tr><!-- Table Row -->
						   <td> <!-- Table Column -->
							   <div class="expertbycategorytags"> <!-- Expert  Category Main Div -->
								   <div class="row customexpert">  <!-- Expert Category Sub Div -->                
									   <div class="col-md-3 col-lg-2 ce-image">
										   <a href="<?php echo site_url(); ?>/user-basic-profile/?ExpertId=<?php echo $userid; ?>"><?php echo get_avatar( $userid, $size ); ?></a>
										   <div class="clientNameWrap">
										   <h4 class="ce-title"><a href="<?php echo site_url(); ?>/user-basic-profile/?ExpertId=<?php echo $userid; ?>">
																					<?php
																					if ( $salutation ) {
																						echo $salutation . '&nbsp;';
																					}echo $firstname . '&nbsp;' . $lastname;
?>
</a></h4>
										   <p class="ce-info"><span>
											<?php
											if ( $city ) {
												echo $city;
											} if ( $city && $state ) {
												echo ',&nbsp';
											} if ( $state ) {
												echo $state;}
?>
</span></p>
										   </div>
									   </div>
									   <div class="col-md-6 col-lg-7 ce-content">
										   <div class="clientBriefInfo">
												<?php
												   $current_logo      = $wpdb->get_results( "SELECT * FROM $post_table WHERE `post_author`=$userid AND `post_type`='$logo_type'" );
												   $logo_img_url      = $current_logo[0]->guid;
												   $prev_company_logo = $wpdb->get_results( "SELECT * FROM $post_table WHERE `post_author`=$userid AND `post_type`='$prev_logo_type'" );
												if ( $current_logo ) :
													echo '<div class="clientCurrentLogo"><img src="' . $logo_img_url . '"/></div>';
														   else :
																echo '<div class="clientCurrentLogo"><img src="../wp-content/themes/boss-child/images/no_logo.png"/></div>';
															endif;
														?>
																												
														<p class="ce-details"><?php echo $AboutYourSelf; ?></p>
														<div class="previousOrgLogo">
														<ul>
														<li class="prevEmpText"><span>Previous Affiliation</span></li>
														<?php
														if ( $prev_company_logo ) :
															foreach ( $prev_company_logo as $logos ) :
																$prev_img_url = $logos->guid;
																echo '<li><img src="' . $prev_img_url . '"></li>';
																endforeach;
															else :
																	echo '<li><img src="../wp-content/themes/boss-child/images/no_logo.png"></li>';
																endif;
															?>
														</ul>
														</div>
													</div>
												</div>
												<div class="col-md-3 col-lg-3 ce-action">
													<div class="ce-pricing">
														<span class="profile-detail profile-stat price">
														<input type="hidden" name="basic_amount"/>
														<?php
														$expertprices = number_format( (float) $expertPrice, 2, '.', '' );
														?>
														<strong class="actual-price"><?php echo $expertprices; ?></strong>                                            
														<small>Credits per minute</small>                                                        
														</span>
													</div>
													<a href="/request-a-call/?ExpertId=<?php echo $userid; ?>" class="call_link">Request A Call</a>
													<div class="expRating">                                                    
														<?php
														$average  = $wpdb->get_var( "SELECT Avg(totalrating) FROM $ratingtable WHERE expertid = $userid" );
														$average2 = number_format( (float) $average, 2, '.', '' );
														if ( $average2 > 4.5 ) {
															echo '<img src="/wp-content/themes/boss-child/images/rating/five-star.png" title="Awesome - 5 stars"/>';
															echo '<br/>';
															echo $average2 . ' out of 5 stars';
														} elseif ( $average2 > 3.5 ) {
															echo '<img src="/wp-content/themes/boss-child/images/rating/four-star.png" title="Pretty good - 4 stars"/>';
															echo '<br/>';
															echo $average2 . ' out of 5 stars';
														} elseif ( $average2 > 2.5 ) {
															echo '<img src="/wp-content/themes/boss-child/images/rating/three-star.png" title="Average - 3 stars"/>';
															echo '<br/>';
															echo $average2 . ' out of 5 stars';
														} elseif ( $average2 > 1.5 ) {
															echo '<img src="/wp-content/themes/boss-child/images/rating/two-star.png" title="Bad - 2 stars"/>';
															echo '<br/>';
															echo $average2 . ' out of 5 stars';
														} elseif ( $average2 > 0.5 ) {
															echo '<img src="/wp-content/themes/boss-child/images/rating/one-star.png" title="Very Poor - 1 star"/>';
															echo '<br/>';
															echo $average2 . ' out of 5 stars';
														} else {
															echo '<small>No Rating For This Expert</small>';
														}
														?>
													</div>
												</div>                    
											</div> <!-- Expert Category Sub Div -->
										</div> <!-- Expert  Category Main Div -->
									</td> <!-- Table Column -->
								</tr> <!-- Table Row -->
								<?php
							endif;
							endforeach;
						endif;
		}
	} else {
		if ( $subcatid == '0' ) {
					$expertprice = $wpdb->get_results( "SELECT * FROM $pricetable ORDER BY `price` ASC" );
			if ( $expertprice ) :
				foreach ( $expertprice as $results ) :
					$userid = $results->user_id;
					//echo $userid;
					if ( $userid != $curentuserid ) :
						$firstname     = get_user_meta( $userid, 'first_name', $single );
						$lastname      = get_user_meta( $userid, 'last_name', $single );
						$expertPrice   = $wpdb->get_var( "SELECT `price` FROM $pricetable WHERE `user_id`='$userid'" );
						$AboutYourSelf = bp_get_profile_field_data( 'field=AboutYourSelf&user_id=' . $userid );
						$title         = bp_get_profile_field_data( 'field=Title&user_id=' . $userid );
						$city          = bp_get_profile_field_data( 'field=City&user_id=' . $userid );
						$state         = bp_get_profile_field_data( 'field=State&user_id=' . $userid );
						$salutation    = bp_get_profile_field_data( 'field=salutation&user_id=' . $userid );
						?>
						<tr><!-- Table Row -->
						<td> <!-- Table Column -->
						   <div class="expertbycategorytags"> <!-- Expert  Category Main Div -->
							   <div class="row customexpert">  <!-- Expert Category Sub Div -->                
								   <div class="col-md-3 col-lg-2 ce-image">
									   <a href="<?php echo site_url(); ?>/user-basic-profile/?ExpertId=<?php echo $userid; ?>"><?php echo get_avatar( $userid, $size ); ?></a>
									   <div class="clientNameWrap">
									   <h4 class="ce-title"><a href="<?php echo site_url(); ?>/user-basic-profile/?ExpertId=<?php echo $userid; ?>">
																					<?php
																					if ( $salutation ) {
																						echo $salutation . '&nbsp;';
																					}echo $firstname . '&nbsp;' . $lastname;
	?>
	</a></h4>
									   <p class="ce-info"><span>
										<?php
										if ( $city ) {
											echo $city;
										} if ( $city && $state ) {
											echo ',&nbsp';
										} if ( $state ) {
											echo $state;}
	?>
	</span></p>
									   </div>
								   </div>
								   <div class="col-md-6 col-lg-7 ce-content">
									   <div class="clientBriefInfo">
											<?php
											   $current_logo      = $wpdb->get_results( "SELECT * FROM $post_table WHERE `post_author`=$userid AND `post_type`='$logo_type'" );
											   $logo_img_url      = $current_logo[0]->guid;
											   $prev_company_logo = $wpdb->get_results( "SELECT * FROM $post_table WHERE `post_author`=$userid AND `post_type`='$prev_logo_type'" );
											if ( $current_logo ) :
												echo '<div class="clientCurrentLogo"><img src="' . $logo_img_url . '"/></div>';
													   else :
															echo '<div class="clientCurrentLogo"><img src="../wp-content/themes/boss-child/images/no_logo.png"/></div>';
															endif;
														?>
																												
														<p class="ce-details"><?php echo $AboutYourSelf; ?></p>
														<div class="previousOrgLogo">
														<ul>
														<li class="prevEmpText"><span>Previous Affiliation</span></li>
														<?php
														if ( $prev_company_logo ) :
															foreach ( $prev_company_logo as $logos ) :
																$prev_img_url = $logos->guid;
																echo '<li><img src="' . $prev_img_url . '"></li>';
																endforeach;
															else :
																echo '<li><img src="../wp-content/themes/boss-child/images/no_logo.png"></li>';
															endif;
														?>
													</ul>
													</div>
														</div>
													</div>
													<div class="col-md-3 col-lg-3 ce-action">
														<div class="ce-pricing">
													<span class="profile-detail profile-stat price">
													<input type="hidden" name="basic_amount"/>
													<?php
													$expertprices = number_format( (float) $expertPrice, 2, '.', '' );
													?>
													<strong class="actual-price"><?php echo $expertprices; ?></strong>                                            
													   <small>Credits per minute</small>                                                        
													   </span>
													</div>
													<a href="/request-a-call/?ExpertId=<?php echo $userid; ?>" class="call_link">Request A Call</a>
													<div class="expRating">                                                    
														<?php
														$average  = $wpdb->get_var( "SELECT Avg(totalrating) FROM $ratingtable WHERE expertid = $userid" );
														$average2 = number_format( (float) $average, 2, '.', '' );
														if ( $average2 > 4.5 ) {
															echo '<img src="/wp-content/themes/boss-child/images/rating/five-star.png" title="Awesome - 5 stars"/>';
															echo '<br/>';
															echo $average2 . ' out of 5 stars';
														} elseif ( $average2 > 3.5 ) {
															echo '<img src="/wp-content/themes/boss-child/images/rating/four-star.png" title="Pretty good - 4 stars"/>';
															echo '<br/>';
															echo $average2 . ' out of 5 stars';
														} elseif ( $average2 > 2.5 ) {
															echo '<img src="/wp-content/themes/boss-child/images/rating/three-star.png" title="Average - 3 stars"/>';
															echo '<br/>';
															echo $average2 . ' out of 5 stars';
														} elseif ( $average2 > 1.5 ) {
															echo '<img src="/wp-content/themes/boss-child/images/rating/two-star.png" title="Bad - 2 stars"/>';
															echo '<br/>';
															echo $average2 . ' out of 5 stars';
														} elseif ( $average2 > 0.5 ) {
															   echo '<img src="/wp-content/themes/boss-child/images/rating/one-star.png" title="Very Poor - 1 star"/>';
															   echo '<br/>';
															   echo $average2 . ' out of 5 stars';
														} else {
															echo '<small>No Rating For This Expert</small>';
														}
															?>
														</div>
													</div>                    
												</div> <!-- Expert Category Sub Div -->
											</div> <!-- Expert  Category Main Div -->
										</td> <!-- Table Column -->
									</tr> <!-- Table Row -->
									<?php
								endif;
				endforeach;
					endif;
		} elseif ( $subcatid == '01' ) {
			$catname = $wpdb->get_results( "SELECT DISTINCT `$metatable`.* FROM $metatable INNER JOIN `$pricetable` ON $metatable.user_id =$pricetable.user_id WHERE $metatable.meta_key='$catkey' ORDER BY $pricetable.price ASC" );
			if ( $catname ) :
				foreach ( $catname as $results ) :
					$userid = $results->user_id;
					//echo $userid;
					if ( $userid != $curentuserid ) :
						$firstname     = get_user_meta( $userid, 'first_name', $single );
						$lastname      = get_user_meta( $userid, 'last_name', $single );
						$expertPrice   = $wpdb->get_var( "SELECT `price` FROM $pricetable WHERE `user_id`='$userid'" );
						$AboutYourSelf = bp_get_profile_field_data( 'field=AboutYourSelf&user_id=' . $userid );
						$title         = bp_get_profile_field_data( 'field=Title&user_id=' . $userid );
						$city          = bp_get_profile_field_data( 'field=City&user_id=' . $userid );
						$state         = bp_get_profile_field_data( 'field=State&user_id=' . $userid );
						$salutation    = bp_get_profile_field_data( 'field=salutation&user_id=' . $userid );
						?>
						<tr><!-- Table Row -->
						   <td> <!-- Table Column -->
							   <div class="expertbycategorytags"> <!-- Expert  Category Main Div -->
								   <div class="row customexpert">  <!-- Expert Category Sub Div -->                
									   <div class="col-md-3 col-lg-2 ce-image">
										   <a href="<?php echo site_url(); ?>/user-basic-profile/?ExpertId=<?php echo $userid; ?>"><?php echo get_avatar( $userid, $size ); ?></a>
										   <div class="clientNameWrap">
										   <h4 class="ce-title"><a href="<?php echo site_url(); ?>/user-basic-profile/?ExpertId=<?php echo $userid; ?>">
																					<?php
																					if ( $salutation ) {
																						echo $salutation . '&nbsp;';
																					}echo $firstname . '&nbsp;' . $lastname;
?>
</a></h4>
										   <p class="ce-info"><span>
											<?php
											if ( $city ) {
												echo $city;
											} if ( $city && $state ) {
												echo ',&nbsp';
											} if ( $state ) {
												echo $state;}
?>
</span></p>
										   </div>
									   </div>
									   <div class="col-md-6 col-lg-7 ce-content">
										   <div class="clientBriefInfo">
												<?php
												   $current_logo      = $wpdb->get_results( "SELECT * FROM $post_table WHERE `post_author`=$userid AND `post_type`='$logo_type'" );
												   $logo_img_url      = $current_logo[0]->guid;
												   $prev_company_logo = $wpdb->get_results( "SELECT * FROM $post_table WHERE `post_author`=$userid AND `post_type`='$prev_logo_type'" );
												if ( $current_logo ) :
													echo '<div class="clientCurrentLogo"><img src="' . $logo_img_url . '"/></div>';
														   else :
																echo '<div class="clientCurrentLogo"><img src="../wp-content/themes/boss-child/images/no_logo.png"/></div>';
															endif;
														?>
																												
														<p class="ce-details"><?php echo $AboutYourSelf; ?></p>
														<div class="previousOrgLogo">
														<ul>
														<li class="prevEmpText"><span>Previous Affiliation</span></li>
														<?php
														if ( $prev_company_logo ) :
															foreach ( $prev_company_logo as $logos ) :
																$prev_img_url = $logos->guid;
																echo '<li><img src="' . $prev_img_url . '"></li>';
																endforeach;
															else :
																	echo '<li><img src="../wp-content/themes/boss-child/images/no_logo.png"></li>';
																endif;
															?>
														</ul>
														</div>
													</div>
												</div>
												<div class="col-md-3 col-lg-3 ce-action">
													<div class="ce-pricing">
														<span class="profile-detail profile-stat price">
														<input type="hidden" name="basic_amount"/>
														<?php
														$expertprices = number_format( (float) $expertPrice, 2, '.', '' );
														?>
														<strong class="actual-price"><?php echo $expertprices; ?></strong>                                            
														<small>Credits per minute</small>                                                        
														</span>
													</div>
													<a href="/request-a-call/?ExpertId=<?php echo $userid; ?>" class="call_link">Request A Call</a>
													<div class="expRating">                                                    
														<?php
														$average  = $wpdb->get_var( "SELECT Avg(totalrating) FROM $ratingtable WHERE expertid = $userid" );
														$average2 = number_format( (float) $average, 2, '.', '' );
														if ( $average2 > 4.5 ) {
															echo '<img src="/wp-content/themes/boss-child/images/rating/five-star.png" title="Awesome - 5 stars"/>';
															echo '<br/>';
															echo $average2 . ' out of 5 stars';
														} elseif ( $average2 > 3.5 ) {
															echo '<img src="/wp-content/themes/boss-child/images/rating/four-star.png" title="Pretty good - 4 stars"/>';
															echo '<br/>';
															echo $average2 . ' out of 5 stars';
														} elseif ( $average2 > 2.5 ) {
															echo '<img src="/wp-content/themes/boss-child/images/rating/three-star.png" title="Average - 3 stars"/>';
															echo '<br/>';
															echo $average2 . ' out of 5 stars';
														} elseif ( $average2 > 1.5 ) {
															echo '<img src="/wp-content/themes/boss-child/images/rating/two-star.png" title="Bad - 2 stars"/>';
															echo '<br/>';
															echo $average2 . ' out of 5 stars';
														} elseif ( $average2 > 0.5 ) {
															echo '<img src="/wp-content/themes/boss-child/images/rating/one-star.png" title="Very Poor - 1 star"/>';
															echo '<br/>';
															echo $average2 . ' out of 5 stars';
														} else {
															echo '<small>No Rating For This Expert</small>';
														}
														?>
													</div>
												</div>                    
											</div> <!-- Expert Category Sub Div -->
										</div> <!-- Expert  Category Main Div -->
									</td> <!-- Table Column -->
								</tr> <!-- Table Row -->
								<?php
							endif;
							endforeach;
					endif;

		} else {
			$sub_categoryname = $wpdb->get_var( "SELECT `sub_category_name` FROM $table WHERE `id`=$subcatid" );
			$catid            = $wpdb->get_var( "SELECT `category_id` FROM $table WHERE `id`=$subcatid" );
			$category_name    = $wpdb->get_var( "SELECT `category_name` FROM $catetable WHERE `id`=$catid" );
			$categoryy_name   = $prefix . 'cat_' . $category_name;
			$catname          = $wpdb->get_results( "SELECT DISTINCT `$metatable`.* FROM $metatable INNER JOIN `$pricetable` ON $metatable.user_id =$pricetable.user_id WHERE $metatable.meta_value LIKE '%$sub_categoryname%' AND wp68_usermeta.meta_key='$categoryy_name' ORDER BY $pricetable.price ASC" );
			if ( $catname ) :
				foreach ( $catname as $results ) :
					$userid = $results->user_id;
					//echo $userid;
					if ( $userid != $curentuserid ) :
						$firstname     = get_user_meta( $userid, 'first_name', $single );
						$lastname      = get_user_meta( $userid, 'last_name', $single );
						$expertPrice   = $wpdb->get_var( "SELECT `price` FROM $pricetable WHERE `user_id`='$userid'" );
						$AboutYourSelf = bp_get_profile_field_data( 'field=AboutYourSelf&user_id=' . $userid );
						$title         = bp_get_profile_field_data( 'field=Title&user_id=' . $userid );
						$city          = bp_get_profile_field_data( 'field=City&user_id=' . $userid );
						$state         = bp_get_profile_field_data( 'field=State&user_id=' . $userid );
						$salutation    = bp_get_profile_field_data( 'field=salutation&user_id=' . $userid );
						?>
						<tr><!-- Table Row -->
						<td> <!-- Table Column -->
						   <div class="expertbycategorytags"> <!-- Expert  Category Main Div -->
							   <div class="row customexpert">  <!-- Expert Category Sub Div -->                
								   <div class="col-md-3 col-lg-2 ce-image">
									   <a href="<?php echo site_url(); ?>/user-basic-profile/?ExpertId=<?php echo $userid; ?>"><?php echo get_avatar( $userid, $size ); ?></a>
									   <div class="clientNameWrap">
									   <h4 class="ce-title"><a href="<?php echo site_url(); ?>/user-basic-profile/?ExpertId=<?php echo $userid; ?>">
																					<?php
																					if ( $salutation ) {
																						echo $salutation . '&nbsp;';
																					}echo $firstname . '&nbsp;' . $lastname;
	?>
	</a></h4>
										   <p class="ce-info"><span>
											<?php
											if ( $city ) {
													echo $city;
											} if ( $city && $state ) {
												echo ',&nbsp';
											} if ( $state ) {
												echo $state;}
	?>
	</span></p>
									   </div>
								   </div>
								   <div class="col-md-6 col-lg-7 ce-content">
									   <div class="clientBriefInfo">
											<?php
											   $current_logo      = $wpdb->get_results( "SELECT * FROM $post_table WHERE `post_author`=$userid AND `post_type`='$logo_type'" );
											   $logo_img_url      = $current_logo[0]->guid;
											   $prev_company_logo = $wpdb->get_results( "SELECT * FROM $post_table WHERE `post_author`=$userid AND `post_type`='$prev_logo_type'" );
											if ( $current_logo ) :
												echo '<div class="clientCurrentLogo"><img src="' . $logo_img_url . '"/></div>';
													   else :
															echo '<div class="clientCurrentLogo"><img src="../wp-content/themes/boss-child/images/no_logo.png"/></div>';
															endif;
														?>
																												
														<p class="ce-details"><?php echo $AboutYourSelf; ?></p>
														<div class="previousOrgLogo">
														<ul>
														<li class="prevEmpText"><span>Previous Affiliation</span></li>
														<?php
														if ( $prev_company_logo ) :
															foreach ( $prev_company_logo as $logos ) :
																$prev_img_url = $logos->guid;
																echo '<li><img src="' . $prev_img_url . '"></li>';
																endforeach;
															else :
																	echo '<li><img src="../wp-content/themes/boss-child/images/no_logo.png"></li>';
																endif;
															?>
														</ul>
														</div>
													</div>
												</div>
												<div class="col-md-3 col-lg-3 ce-action">
													<div class="ce-pricing">
														<span class="profile-detail profile-stat price">
														<input type="hidden" name="basic_amount"/>
														<?php
														$expertprices = number_format( (float) $expertPrice, 2, '.', '' );
														?>
														<strong class="actual-price"><?php echo $expertprices; ?></strong>                                            
														<small>Credits per minute</small>                                                        
														</span>
													</div>
													<a href="/request-a-call/?ExpertId=<?php echo $userid; ?>" class="call_link">Request A Call</a>
													<div class="expRating">                                                    
														<?php
														$average  = $wpdb->get_var( "SELECT Avg(totalrating) FROM $ratingtable WHERE expertid = $userid" );
														$average2 = number_format( (float) $average, 2, '.', '' );
														if ( $average2 > 4.5 ) {
															echo '<img src="/wp-content/themes/boss-child/images/rating/five-star.png" title="Awesome - 5 stars"/>';
															echo '<br/>';
															echo $average2 . ' out of 5 stars';
														} elseif ( $average2 > 3.5 ) {
															echo '<img src="/wp-content/themes/boss-child/images/rating/four-star.png" title="Pretty good - 4 stars"/>';
															echo '<br/>';
															echo $average2 . ' out of 5 stars';
														} elseif ( $average2 > 2.5 ) {
															echo '<img src="/wp-content/themes/boss-child/images/rating/three-star.png" title="Average - 3 stars"/>';
															echo '<br/>';
															echo $average2 . ' out of 5 stars';
														} elseif ( $average2 > 1.5 ) {
															echo '<img src="/wp-content/themes/boss-child/images/rating/two-star.png" title="Bad - 2 stars"/>';
															echo '<br/>';
															echo $average2 . ' out of 5 stars';
														} elseif ( $average2 > 0.5 ) {
															echo '<img src="/wp-content/themes/boss-child/images/rating/one-star.png" title="Very Poor - 1 star"/>';
															echo '<br/>';
															echo $average2 . ' out of 5 stars';
														} else {
															echo '<small>No Rating For This Expert</small>';
														}
														?>
													</div>
												</div>                    
											</div> <!-- Expert Category Sub Div -->
										</div> <!-- Expert  Category Main Div -->
									</td> <!-- Table Column -->
								</tr> <!-- Table Row -->
								<?php
							endif;
						endforeach;
					endif;
		}
	}
}
