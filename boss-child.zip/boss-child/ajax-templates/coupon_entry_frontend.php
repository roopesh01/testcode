<?php
include '../../../../wp-config.php';
global $wpdb,$current_user;
$user_id = $current_user->ID;
if ($user_id == 0) 
{
	echo 'login_error';    
	exit; 
} 
if(isset( $_POST['cpt_nonce_field'] ) && wp_verify_nonce( $_POST['cpt_nonce_field'], 'cpt_nonce_action' ) && 'POST' == $_SERVER['REQUEST_METHOD'] && !empty( $_POST['action'] ) && $_POST['action'] == "front_post" ) 
{
	$title     = $_POST['post_title'];
	$coupon_membership   = $_POST['coupon_membership'];
	$coupon_userlevel = $_POST['coupon_userlevel']; 
	$percentage = $_POST['percentage'];
	$uselimit = $_POST['uselimit'];
	$expirydate = $_POST['expirydate'];
	$use_coupon = "other";
	$friend = $_POST['coupon_couponfor'];
	$new_post = array(
	'post_title'    => $title,
	'post_status'   => 'publish',
	'post_type' => $_POST['post_type']
	);
	$cpt_id = wp_insert_post( $new_post, $wp_error);
	add_post_meta($cpt_id, '_user_membership', $coupon_membership);
	add_post_meta($cpt_id, '_user_level', $coupon_userlevel);
	add_post_meta($cpt_id, '_coupon_percentage', $percentage);
	add_post_meta($cpt_id, '_usage_limit', $uselimit);
	add_post_meta($cpt_id, '_expiry_date', $expirydate);
	add_post_meta($cpt_id, 'register_for_forum_coupon', $use_coupon);
	add_post_meta($cpt_id, 'coupon_friend', $friend);
		
	echo 'Coupon Generated Successfully';
	exit;
}	
