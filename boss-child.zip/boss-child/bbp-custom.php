<?php
/**
 * @package Boss Child Theme
 * The parent theme functions are located at /boss/buddyboss-inc/theme-functions.php
 * Add your own functions in this file.
 */
/**
 * Sets up theme defaults
 *
 * @since Boss Child Theme 1.0.0
 */

add_action( 'bp_friends_setup_nav', 'bpdev_custom_hide_friends_if_not_self' );

function bpdev_custom_hide_friends_if_not_self() {
	if ( bp_is_my_profile() || is_super_admin() ) {
		return;
	}

	bp_core_remove_nav_item( 'friends' );

}


