<?php
include '../../../../wp-config.php';
global $wpdb;
$venuetable = $wpdb->prefix.'venuemeetingdetail';
$userid = get_current_user_id();

if(isset($_POST['responseyes']))
{
    $responseyes = $_POST['responseyes'];
    $meetid  = $_POST['meetid'];
    $metakey = 'reponse'.$meetid;
    update_user_option($userid, $metakey, $responseyes);    
    $result = $wpdb->get_results("SELECT * FROM $venuetable WHERE `id`='$meetid'");
    $invite_accepted_user = $result[0]->invite_accepted_user;    
    $alreadyexist = $wpdb->get_results("SELECT * FROM $venuetable WHERE `id`='$meetid' AND (`invite_accepted_user` LIKE  '%,$userid' OR (`invite_accepted_user` LIKE '%,$userid,%' OR (`invite_accepted_user` LIKE '$userid,%')))");    
    if($alreadyexist)
    {
        
    }    
    elseif($invite_accepted_user==NULL)
    {
        $update = $wpdb->query("UPDATE $venuetable SET `invite_accepted_user` ='$userid' WHERE `id`=$meetid");        
    }
    else
    {
        $wpdb->query("UPDATE $venuetable SET `invite_accepted_user` = CONCAT(invite_accepted_user,',$userid') WHERE `id`=$meetid"); 
    }
    function meetingresponse() 
    {
        return 'Meeting Confirmation';
    }    
    add_filter('wp_mail_from_name','meetingresponse');
    $userdata = get_userdata($userid);
    $usermail = $userdata->user_email;
    $username = $userdata->user_login;
    $subject = "Invitation Response";
    $message = "Hello <strong>$username</strong><br/>
    You Confirmed 'Yes' For The Meeting Invitation<br/>";                   
    $headers  = 'From: <webtest2105@gmail.com' . "\r\n";
    $headers .= array('Content-Type: text/html; charset=UTF-8');
    $mail_done = wp_mail($usermail,$subject,$message,$headers);
      
}
if(isset($_POST['responseno']))
{
    $responseno = $_POST['responseno'];
    $meetid  = $_POST['meetid'];
    $metakey = 'reponse'.$meetid;
    update_user_option($userid, $metakey, $responseno);
    $result = $wpdb->get_results("SELECT * FROM $venuetable WHERE `id`='$meetid'");
    $invite_accepted_user = $result[0]->invite_accepted_user;
    
    
    $type1 = $wpdb->get_results("SELECT * FROM $venuetable WHERE `id`='$meetid' AND `invite_accepted_user` LIKE  '%,$userid%'");
    $type2 = $wpdb->get_results("SELECT * FROM $venuetable WHERE `id`='$meetid' AND `invite_accepted_user` LIKE '%,$userid,%'");
    $type3 = $wpdb->get_results("SELECT * FROM $venuetable WHERE `id`='$meetid' AND `invite_accepted_user` LIKE '%$userid,%'");
    $type4 = $wpdb->get_results("SELECT * FROM $venuetable WHERE `id`='$meetid' AND `invite_accepted_user`='$userid'");
    
    if($type1)
    {
       $updatevalue = str_replace(",$userid", '', $invite_accepted_user);
       $wpdb->query("UPDATE $venuetable SET `invite_accepted_user` ='$updatevalue' WHERE `id`=$meetid");       
    }
    elseif($type2)
    {
         $updatevalue = str_replace(",$userid", '', $invite_accepted_user);
         $wpdb->query("UPDATE $venuetable SET `invite_accepted_user` ='$updatevalue' WHERE `id`=$meetid");               
    }
    elseif($type3)
    {
        $updatevalue = str_replace("$userid,", '', $invite_accepted_user);
        $wpdb->query("UPDATE $venuetable SET `invite_accepted_user` ='$updatevalue' WHERE `id`=$meetid");             
    }
    elseif($type4)
    {
        $wpdb->query("UPDATE $venuetable SET `invite_accepted_user` = NULL WHERE `id`=$meetid");
    }
    function meetingresponse() 
    {
        return 'Meeting Confirmation';
    }    
    add_filter('wp_mail_from_name','meetingresponse');
    $userdata = get_userdata($userid);
    $usermail = $userdata->user_email;
    $username = $userdata->user_login;
    $subject = "Invitation Response";
    $message = "Hello <strong>$username</strong><br/>
    You Confirmed 'No' For The Meeting Invitation<br/>";                   
    $headers  = 'From: <webtest2105@gmail.com' . "\r\n";
    $headers .= array('Content-Type: text/html; charset=UTF-8');
    $mail_done = wp_mail($usermail,$subject,$message,$headers);
    
    
}

?>