 <script src="ckeditor.js"></script>
 
<?php
if( isset( $_POST['SUbmit'] ) ) {
	 echo $usermessage = $_POST['usermessage'];
	}
?>
 <form method="post" action="#">
<textarea name="usermessage" id="usermessage" rows="5" cols="15">
	<?php
	if ( isset( $_POST['SUbmit'] ) ) {
		 echo $usermessage = $_POST['usermessage'];
	}
?>
</textarea>
 <script>
				// Replace the <textarea id="editor1"> with a CKEditor
				// instance, using default configuration.
				CKEDITOR.replace( 'usermessage' );
			</script>
<input type="submit" name="SUbmit">
			</form>
