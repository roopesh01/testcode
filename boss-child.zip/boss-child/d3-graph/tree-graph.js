function buildTree(parent, basicData, convert, height) {
    var i = 0, duration = 750, filterData;
    //let names = ["buyer", "seller", "experts", "media", "ambassador", "Director", "memeber", "guest"];
    let names = [], searchColor = "red", packageCount = 1, opacityScale = null;
    var margin = {top: 20, right: 90, bottom: 30, left: 90}, width = 960 - margin.left - margin.right, height = height - margin.top - margin.bottom;
    var svg = d3.select(parent).append("svg").attr("width", width + margin.right + margin.left)
            .attr("height", height + margin.top + margin.bottom).append("g")
            .attr("transform", "translate(" + margin.left + "," + margin.top + ")");
    var zoomer = d3.zoom().scaleExtent([.5, 10]).on("zoom", zoomed);
    var zoomBase = d3.select(parent + " svg").append("rect").style("opacity", "0").attr("width", width + margin.right + margin.left)
            .attr("height", height + margin.top + margin.bottom);
    zoomBase.call(zoomer).on("dblclick.zoom", null);
    function zoomed() {
        svg.attr('transform', d3.event.transform);
    }

    var nodeColor = d3.scaleOrdinal().range(d3.schemePaired);
    var modes = {};
    if (convert) {
        var data = {};
        basicData.map(function (elem) {
            elem.name = ((elem.firstName || "") + "  " + (elem.lastName || "")).trim() || "empty";
            if (elem.roleSelected == "") {
                elem.roleSelected = "blank";
            }

            if (elem.roleSelected == null) {
                elem.roleSelected = "empty";
            }

            data[elem.id] = elem;
            if (elem.roleSelected) {
                if (!names[elem.roleSelected]) {
                    names[elem.roleSelected] = nodeColor(elem.roleSelected);
                }
            }

            if (elem.nominatorId == null) {
                elem.nominatorId = "admin"
                elem.nominetorName = "admin"
            } else {
                if (elem.nominetorRole) {
                    if (!names[elem.nominetorRole]) {
                        names[elem.nominetorRole] = nodeColor(elem.nominetorRole);
                    }
                }
            }

            if (!data[elem.nominatorId]) {
                data[elem.nominatorId] = {
                    name: elem.nominetorName,
                    id: elem.nominatorId,
                    nominatorId: 'admin',
                    roleSelected: elem.nominetorRole
                }
            }
        });
        data['admin'] = {
            name: 'admin',
            id: "admin"
        }

        unflatten = function (array, parent, tree) {
            tree = typeof tree !== 'undefined' ? tree : [];
            parent = typeof parent !== 'undefined' ? parent : {id: 'admin'};
            var children = _.filter(array, function (child) {
                return child.nominatorId == parent.id;
            });
            if (!_.isEmpty(children)) {
                if (parent.id == 'admin') {
                    tree = children;
                } else {
                    parent['children'] = children
                    packageCount++;
                }
                _.each(children, function (child) {
                    unflatten(array, child)
                });
            }
            return tree;
        }


        var array = $.map(data, function (value, index) {
            return [value];
        });
        var tree = unflatten(array);
        opacityScale = d3.scaleLinear().domain([0.0, packageCount]).range([0, 1]);
        if (names[""]) {
            names["blank"] = names[""];
            delete names[""];
        }
        if (names[null]) {
            names["empty"] = names[null];
            delete names[null];
        }
        var scaleDistance = d3.scaleLinear().domain([1, 20]).range([80, 580]);
        for (var key in names) {
            $("<li data-value='" + key + "'>" +
                    '<span class="role-text" data-value="' + key + '">' + key + '</span>' +
                    '<span data-value="' + key + '"  class="iis-colorpicker" >' +
                    '<span class="color-holder" style="background:' + names[key] + '"></span></span></li>'
                    ).appendTo(parent + " .graph-role-container");
        }
        filterData = {
            "name": "admin",
            "id": "admin",
            "children": tree
        }
        currentDataSet = filterData;
        baseData = filterData;
    } else {
        currentDataSet = basicData;
        filterData = basicData;
    }


    modes.tree = function (initialData) {
        currentDataSet = initialData;
        var ctrlKey = false, hirarchiLevel = 5, root, nodeUpdate, linkUpdate, currentNode, linkDistance = 5;
        var treemap = d3.tree().size([height, width - 160]), cluster = d3.cluster().size([height, width - 160]), behavior = {};
        behavior.collapse = collapse;
        behavior.showDetails = showDetails;
        behavior.diagonal = diagonal;
        behavior.nodeClicked = nodeClicked;
        behavior.changeGraphMode = changeGraphMode;
        behavior.searchNode = searchNode;
        behavior.buildGraph = buildGraph;
        behavior.filterByCategory = filterByCategory;
        behavior.init = init;
        function buildGraph(data, source) {
            svg.selectAll('.node text').style("fill", "#444");
            svg.selectAll('circle.node').style("stroke", "steelblue");
            svg.attr("transform", "translate(" + margin.left + "," + margin.top + ")");
            if (!source) {
                root = d3.hierarchy(data, function (d) {
                    return d.children;
                });
                root.x0 = height / 2;
                root.y0 = 0;
                source = root;
            }
            var treeData = treemap(root);
            var nodes = treeData.descendants(), links = treeData.descendants().slice(1);
            nodes.forEach(function (d) {
                d.y = d.depth * (scaleDistance(linkDistance));
            });

            nodes = nodes.filter(function (d) {
                if (d.depth >= hirarchiLevel) {
                    return false;
                } else {
                    return true;
                }
            });

            links = links.filter(function (d) {
                if (d.depth >= hirarchiLevel) {
                    return false;
                } else {
                    return true;
                }
            });
            var node = svg.selectAll('g.node').data(nodes, function (d) {
                return d.id || (d.id = ++i);
            });

            var nodeEnter = node.enter().append('g').attr('class', 'node').on('click', behavior.nodeClicked)
                    .attr("transform", function (d) {
                        return "translate(" + source.y0 + "," + source.x0 + ")";
                    });

            nodeEnter.append('circle').attr('class', 'node').attr('r', 1e-6).style("fill", function (d) {
                return d._children ? "lightsteelblue" : names[d.data.roleSelected];
            }).style("stroke", "steelblue");

            nodeEnter.append('text').attr("dy", ".35em").attr("x", function (d) {
                return d.children || d._children ? -13 : 13;
            }).attr("text-anchor", function (d) {
                return d.children || d._children ? "end" : "start";
            }).text(function (d) {
                return d.data.name;
            }).on("mouseout", function () {
                $(parent + " .toolTip").hide();
            }).on("mouseover", behavior.showDetails);

            nodeUpdate = nodeEnter.merge(node);

            nodeUpdate.transition().duration(duration).attr("transform", function (d) {
                return "translate(" + d.y + "," + d.x + ")";
            });

            nodeUpdate.select('circle.node').attr('r', 4.5).style("fill", function (d) {
                return d._children ? "lightsteelblue" : names[d.data.roleSelected];
            }).attr('cursor', 'pointer');

            var nodeExit = node.exit().transition().duration(duration).attr("transform", function (d) {
                return "translate(" + source.y + "," + source.x + ")";
            }).remove();

            nodeExit.select('circle').attr('r', 1e-6);

            nodeExit.select('text').style('fill-opacity', 1e-6);

            var link = svg.selectAll('path.link').data(links, function (d) {
                return d.id;
            });

            var linkEnter = link.enter().insert('path', "g").attr("class", "link").attr('d', function (d) {
                var o = {x: source.x0, y: source.y0}
                return diagonal(o, o)
            });

            linkUpdate = linkEnter.merge(link);

            linkUpdate.transition().duration(duration).attr('d', function (d) {
                return diagonal(d, d.parent)
            });

            var linkExit = link.exit().transition().duration(duration).attr('d', function (d) {
                var o = {x: source.x, y: source.y}
                return diagonal(o, o)
            }).remove();

            nodes.forEach(function (d) {
                d.x0 = d.x;
                d.y0 = d.y;
            });
        }


        function init() {
            registerListener();
            root = d3.hierarchy(currentDataSet, function (d) {
                return d.children;
            });
            root.x0 = height / 2;
            root.y0 = 0;
            currentNode = root;
            behavior.buildGraph(null, root);
        }

        function registerListener() {
            $(parent + " .graph-reset").on('click', function () {
                root = d3.hierarchy(filterData, function (d) {
                    return d.children;
                });
                root.x0 = height / 2;
                root.y0 = 0;
                behavior.buildGraph(null, root);
            });

            $(parent + " .graph-role-container .role-text").on('click', function () {
                var value = $(this).attr("data-value") != "null" ? $(this).attr("data-value").trim() : null;
                behavior.filterByCategory("roleSelected", value);
            });

            d3.select(parent).on('keydown', function () {
                ctrlKey = d3.event.ctrlKey;
            });
            d3.select(parent).on('keyup', function () {
                ctrlKey = false;
            });
            d3.select(parent).select(".graph-mode").on("change", behavior.changeGraphMode);
            d3.select(parent).selectAll(".graph-search").on("keyup", behavior.searchNode);
            $(parent + " .iis-slider").each(function () {
                var min = parseInt($(this).attr("data-min") | 0);
                var max = parseInt($(this).attr("data-max") | 0);
                var value = parseInt($(this).attr("data-value") | 0);
                var handler = $(this).find(".ui-slider-handle");
                $(this).slider({
                    min: min,
                    max: max,
                    value: value,
                    create: function () {
                        handler.text($(this).slider("value"));
                    },
                    slide: function (event, ui) {
                        handler.text(ui.value);
                    }
                });
            });
            $(parent + " .hierarchy-level").on("slidestop", function (event, ui) {
                hirarchiLevel = parseInt(ui.value) + 1;
                behavior.buildGraph(null, root);
            });

            $(parent + " .graph-font-size").on("slide", function (event, ui) {
                var fontSize = parseInt(ui.value);
                svg.selectAll('.node text').style("font-size", fontSize + "px");
            });

            $(parent + " .graph-link-distance").on("slidestop", function (event, ui) {
                linkDistance = parseInt(ui.value);
                behavior.buildGraph(null, root);
            });
            console.log(names);
            $(".iis-dragable").draggable({containment: "parent"});
            $(parent + ' .graph-role-container .iis-colorpicker').on("click", function (e) {
                var container = $(this).find(".iris-picker");
                if (!container.is(e.target) && container.has(e.target).length === 0) {
                    $(this).iris('toggle');
                }
            }).iris({
                hide: true,
                palettes: true,
                change: function (event, ui) {
                    $(this).find(".color-holder").css({"background": ui.color.toString()});
                    var roleName = $(this).attr("data-value").toLowerCase();
                    nodeUpdate.filter(function (d) {
                        if (d.data['roleSelected'] && d.data['roleSelected'].toLowerCase().lastIndexOf(roleName) >= 0) {
                            return true;
                        } else {
                            return false;
                        }
                    }).select("circle.node").style("fill", ui.color.toString());
                    names[roleName] = ui.color.toString();
                }
            });
        }


        function showDetails(d) {
            let htm = "<ul>";
            var parentOffset = $(parent).offset()
            var left = parentOffset.left + d.y, top = d.x;
            if (d.data.children) {
                left += $(this).width() - 100;
            }
            if (d.data.nomineeVoterList) {
                d.data.nomineeVoterList.filter(function (elem) {
                    htm += "<li>" + elem.voter_name + "</li>";
                });
            } else {
                if (d.data.nominetorName) {
                    htm += "<li>" + d.data.nominetorName + "</li>";
                } else {
                    htm += "<li>" + d.data.name + "</li>";
                }
                left += $(this).width();
            }

            htm += "<ul>";
            $(parent + " .toolTip").html(htm).css({display: "block", top: top, left: left});
        }

        function nodeClicked(d) {
            if (ctrlKey) {
                currentDataSet = d.data;
                currentNode = d;
                behavior.buildGraph(currentDataSet, false);
            } else {
                if (d.children) {
                    d._children = d.children;
                    d.children = null;
                } else {
                    d.children = d._children;
                    d._children = null;
                }
                behavior.buildGraph(null, d);
            }
        }

        function filterByCategory(keyName, KeyValue) {
            nodeUpdate.filter(function (d) {
                if (d.data[keyName] && d.data[keyName].toLowerCase().lastIndexOf(KeyValue) >= 0) {
                    d3.select(this).select("circle").style("stroke", searchColor).style("fill", searchColor);
                    d3.select(this).select("text").style("fill", searchColor);
                } else {
                    d3.select(this).select("circle").style("stroke", "steelblue").style("fill", names[d.data.roleSelected]);
                    d3.select(this).select("text").style("fill", "#444");
                }
            });
        }

        function diagonal(s, d) {
            var path = `M ${s.y} ${s.x}
                    C ${(s.y + d.y) / 2} ${s.x},
                      ${(s.y + d.y) / 2} ${d.x},
                      ${d.y} ${d.x}`
            return path
        }

        function project(x, y) {
            var angle = (x - 90) / 180 * Math.PI, radius = y;
            return [radius * Math.cos(angle), radius * Math.sin(angle)];
        }

        function collapse(d) {
            if (d.children) {
                d._children = d.children
                d._children.forEach(collapse)
                d.children = null
            }
        }

        function changeGraphMode() {
            var t = d3.transition().duration(750);
            switch (this.value) {
                case "tree":
                {
                    svg.attr("transform", "translate(" + margin.left + "," + margin.top + ")");
                    treemap(root);
                    nodeUpdate.transition(t).attr("transform", function (d) {
                        return "translate(" + d.y + "," + d.x + ")";
                    });

                    linkUpdate.transition(t).attr("d", function (d) {
                        var o = {x: currentNode.x, y: currentNode.y}
                        return diagonal(d, d.parent);
                    });
                    break;
                }

                case "cluster":
                {
                    svg.attr("transform", "translate(" + margin.left + "," + margin.top + ")");
                    cluster(root);
                    nodeUpdate.transition(t).attr("transform", function (d) {
                        return "translate(" + d.y + "," + d.x + ")";
                    });

                    linkUpdate.transition(t).attr("d", function (d) {
                        var o = {x: currentNode.x, y: currentNode.y}
                        return diagonal(d, d.parent);
                    });
                    break;
                }
                case "circularTree":
                {
                    var theight = height > 1400 ? 800 : height;
                    svg.attr("transform", "translate(" + width / 2 + "," + (theight / 2) + ")");
                    var tempMode = d3.tree().size([theight, (width / 2) - 160]);
                    tempMode(root);
                    nodeUpdate.transition(t).attr("transform", function (d) {
                        return "translate(" + project(d.x, d.y) + ")";
                    });

                    linkUpdate.transition(t).attr("d", function (d) {
                        return "M" + project(d.x, d.y)
                                + "C" + project(d.x, (d.y + d.parent.y) / 2)
                                + " " + project(d.parent.x, (d.y + d.parent.y) / 2)
                                + " " + project(d.parent.x, d.parent.y);
                    });
                    break;
                }
            }


        }

        function searchNode() {
            var value = this.value.toLowerCase();
            if (value.trim() == "") {
                nodeUpdate.select("circle").style("stroke", "steelblue").style("fill", function (d) {
                    return names[d.data.roleSelected];
                });
                nodeUpdate.select("text").style("fill", "#444");
                return;
            }
            nodeUpdate.filter(function (d) {
                if (d.data.name.toLowerCase().lastIndexOf(value) >= 0) {
                    d3.select(this).select("circle").style("stroke", searchColor).style("fill", searchColor);
                    d3.select(this).select("text").style("fill", searchColor);
                } else {
                    d3.select(this).select("circle").style("stroke", "steelblue").style("fill", names[d.data.roleSelected]);
                    d3.select(this).select("text").style("fill", "#444");
                }
            });
        }
        behavior.init();
    }

    modes.newPacked = function (initialData) {
        currentDataSet = initialData;
        var ctrlKey = false, hirarchiLevel = 5, root, nodeUpdate, currentNode, i;
        height = width / 1.1;
        var packLayout = d3.pack().size([height, width - 160]), cluster = d3.cluster().size([height, width - 160]), behavior = {};
        behavior.showDetails = showDetails;
        //behavior.nodeClicked = nodeClicked;
        //behavior.searchNode = searchNode;
        behavior.buildGraph = buildGraph;
        behavior.init = init;
        svg.append('g').attr('class', 'packed');

        function buildGraph(data, source) {
            if (!source) {
                root = d3.hierarchy(data, function (d) {
                    return d.children;
                });
                root.sum(function (d) {
                    return d.size || 1;
                });
                root.x0 = height / 2;
                root.y0 = 0;
                source = root;
            }
            packLayout(root);
            var nodes = root.descendants();
            nodes = nodes.filter(function (d) {
                if (d.depth >= hirarchiLevel) {
                    return false;
                } else {
                    return true;
                }
            });

            var node = svg.select(".packed").selectAll('g.node').data(nodes, function (d) {
                return d.data.id || (d.id = ++i);
            });

            var nodeEnter = node.enter().append('g').attr('class', 'node').on('click', behavior.nodeClicked)
                    .attr("transform", function (d) {
                        return 'translate(' + [d.x, d.y] + ')';
                    });

            nodeEnter.append('circle').attr('r', function (d) {
                return d.r;
            }).attr("fill", function (d) {
                return (nodeColor(d.data.roleSelected));
            }).on("mousemove", behavior.showDetails).style("opacity", function (d) {
                if (d.depth == 0) {
                    return 0.1;
                } else {
                    return opacityScale(d.depth);
                }
                ;
            });


//            nodeEnter.append('text').attr('dy', 4).text(function (d) {
//                return d.children === undefined ? d.data.name : '';
//            });

            nodeUpdate = nodeEnter.merge(node);

            nodeUpdate.transition().duration(duration).attr("transform", function (d) {
                return 'translate(' + [d.x, d.y] + ')';
            });

            nodeUpdate.select('circle.node').attr('r', function (d) {
                return d.r;
            }).attr('cursor', 'pointer');

            var nodeExit = node.exit().transition().duration(duration).remove();

            nodeExit.select('circle').attr('r', function (d) {
                return d.r;
            });

        }


        function init() {
            //registerListener();
            root = d3.hierarchy(currentDataSet, function (d) {
                return d.children;
            });
            root.sum(function (d) {
                return d.size || 1;
            });
            currentNode = root;
            behavior.buildGraph(null, root);
        }

        function registerListener() {
            $(parent + " .graph-reset").on('click', function () {
                root = d3.hierarchy(filterData, function (d) {
                    return d.children;
                });
                root.x0 = height / 2;
                root.y0 = 0;
                behavior.buildGraph(null, root);
            });

            $(parent + " .graph-role-container .role-text").on('click', function () {
                var value = $(this).attr("data-value") != "null" ? $(this).attr("data-value").trim() : null;
                behavior.filterByCategory("roleSelected", value);
            });

            d3.select(parent).on('keydown', function () {
                ctrlKey = d3.event.ctrlKey;
            });
            d3.select(parent).on('keyup', function () {
                ctrlKey = false;
            });
            d3.select(parent).select(".graph-mode").on("change", behavior.changeGraphMode);
            d3.select(parent).selectAll(".graph-search").on("keyup", behavior.searchNode);
            $(parent + " .iis-slider").each(function () {
                var min = parseInt($(this).attr("data-min") | 0);
                var max = parseInt($(this).attr("data-max") | 0);
                var value = parseInt($(this).attr("data-value") | 0);
                var handler = $(this).find(".ui-slider-handle");
                $(this).slider({
                    min: min,
                    max: max,
                    value: value,
                    create: function () {
                        handler.text($(this).slider("value"));
                    },
                    slide: function (event, ui) {
                        handler.text(ui.value);
                    }
                });
            });
            $(parent + " .hierarchy-level").on("slidestop", function (event, ui) {
                hirarchiLevel = parseInt(ui.value) + 1;
                behavior.buildGraph(null, root);
            });

            $(parent + " .graph-font-size").on("slide", function (event, ui) {
                var fontSize = parseInt(ui.value);
                svg.selectAll('.node text').style("font-size", fontSize + "px");
            });

            $(parent + " .graph-link-distance").on("slidestop", function (event, ui) {
                linkDistance = parseInt(ui.value);
                behavior.buildGraph(null, root);
            });

            $(".iis-dragable").draggable({containment: "parent"});
            $(parent + ' .graph-role-container .iis-colorpicker').on("click", function (e) {
                var container = $(this).find(".iris-picker");
                if (!container.is(e.target) && container.has(e.target).length === 0) {
                    $(this).iris('toggle');
                }
            }).iris({
                hide: true,
                palettes: true,
                change: function (event, ui) {
                    $(this).find(".color-holder").css({"background": ui.color.toString()});
                    var roleName = $(this).attr("data-value").toLowerCase();
                    nodeUpdate.filter(function (d) {
                        if (d.data['roleSelected'] && d.data['roleSelected'].toLowerCase().lastIndexOf(roleName) >= 0) {
                            return true;
                        } else {
                            return false;
                        }
                    }).select("circle.node").style("fill", ui.color.toString());
                    names[roleName] = ui.color.toString();
                }
            });
        }

        function showDetails(d) {
            let htm = "<ul>";
            var parentOffset = $(parent).offset()
            var left = parentOffset.left + d.y, top = d.x;
            if (d.data.children) {
                left += $(this).width() - 100;
            }
            if (d.data.nomineeVoterList) {
                d.data.nomineeVoterList.filter(function (elem) {
                    htm += "<li>" + elem.voter_name + "</li>";
                });
            } else {
                if (d.data.nominetorName) {
                    htm += "<li>" + d.data.nominetorName + "</li>";
                } else {
                    htm += "<li>" + d.data.name + "</li>";
                }
                left += $(this).width();
            }

            htm += "<ul>";
            $(parent + " .toolTip").html(htm).css({display: "block", top: top, left: left});
        }

        function nodeClicked(d) {
            if (ctrlKey) {
                currentDataSet = d.data;
                currentNode = d;
                behavior.buildGraph(currentDataSet, false);
            } else {
                if (d.children) {
                    d._children = d.children;
                    d.children = null;
                } else {
                    d.children = d._children;
                    d._children = null;
                }
                behavior.buildGraph(null, d);
            }
        }

        function searchNode() {
            var value = this.value.toLowerCase();
            if (value.trim() == "") {
                nodeUpdate.select("circle").style("stroke", "steelblue").style("fill", function (d) {
                    return names[d.data.roleSelected];
                });
                nodeUpdate.select("text").style("fill", "#444");
                return;
            }
            nodeUpdate.filter(function (d) {
                if (d.data.name.toLowerCase().lastIndexOf(value) >= 0) {
                    d3.select(this).select("circle").style("stroke", searchColor).style("fill", searchColor);
                    d3.select(this).select("text").style("fill", searchColor);
                } else {
                    d3.select(this).select("circle").style("stroke", "steelblue").style("fill", names[d.data.roleSelected]);
                    d3.select(this).select("text").style("fill", "#444");
                }
            });
        }

        behavior.init();
    }


    //*/
    //modes.newPacked(currentDataSet);
    modes.tree(currentDataSet);
}
