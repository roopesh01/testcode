<?php
/*
 * Template Name: Membership Levels For Pam
 *
 */
get_header(); ?>
<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"/>
<div class="page-full-width">
	<div id="primary" class="site-content">
		<div id="content" role="main">
			<?php
			while ( have_posts() ) :
				the_post();
?>
				<?php
				get_template_part( 'content', 'page' );
				global $current_user, $wpdb;
				get_currentuserinfo();
				$role           = $current_user->roles;
				$userid         = get_current_user_id();
				$pmprousertable = $wpdb->prefix . 'pmpro_memberships_users';
				//echo $role[0];
				if ( is_user_logged_in() ) {
					if ( $role[0] == 'buyer' ) {
						?>
						<div class="row membershiplevels">
						<div class="col-sm-4">
			<?php
			echo do_shortcode( '[pmpro_advanced_levels levels="1" template="genesis" layout="3col" checkout_button="Buy Membership" description="false"]' );
			?>
		</div>
	   
		<div class="col-sm-4">
		<?php
			 echo do_shortcode( '[pmpro_advanced_levels levels="6" template="genesis" layout="3col" checkout_button="Buy Membership" description="false"]' );
				?>
				
		</div>
		 <div class="col-sm-4">
			<?php
			echo do_shortcode( '[pmpro_advanced_levels levels="12" template="genesis" layout="3col" checkout_button="Buy Membership" description="false"]' );
			?>
		</div>
		
	</div>
	<?php
					} elseif ( $role[0] == 'seller' ) {
						?>
						
					   <div class="row membershiplevels">
	   
		 <div class="col-sm-4">
			<?php
			echo do_shortcode( '[pmpro_advanced_levels levels="2" template="genesis" layout="3col" checkout_button="Buy Membership" description="false"]' );
			?>
		</div>
		<div class="col-sm-4">
		<?php
			 echo do_shortcode( '[pmpro_advanced_levels levels="5" template="genesis" layout="3col" checkout_button="Buy Membership" description="false"]' );
				?>
				
		</div>
		 <div class="col-sm-4">
			<?php
			echo do_shortcode( '[pmpro_advanced_levels levels="9" template="genesis" layout="3col" checkout_button="Buy Membership" description="false"]' );
			?>
		</div>
	   
	</div>
	<?php

					} elseif ( $role[0] == 'experts' ) {
						?>
						<div class="row membershiplevels">
							<div class="col-sm-4">
							<?php
							echo do_shortcode( '[pmpro_advanced_levels levels="3" template="genesis" layout="3col" checkout_button="Buy Membership" description="false"]' );
							?>
							</div>
							<div class="col-sm-4">
							<?php
							echo do_shortcode( '[pmpro_advanced_levels levels="7" template="genesis" layout="3col" checkout_button="Buy Membership" description="false"]' );
							?>
							   
							</div>
							<div class="col-sm-4">
							<?php
							echo do_shortcode( '[pmpro_advanced_levels levels="11" template="genesis" layout="3col" checkout_button="Buy Membership" description="false"]' );
							?>
							</div>
						</div>
						
							
					<?Php
					} elseif ( $role[0] == 'media' ) {
						?>
						<div class="row membershiplevels">
							<div class="col-sm-4">
							<?php
							echo do_shortcode( '[pmpro_advanced_levels levels="4" template="genesis" layout="3col" checkout_button="Buy Membership" description="false"]' );
							?>
							</div>       
							<div class="col-sm-4">
							<?php
							echo do_shortcode( '[pmpro_advanced_levels levels="8" template="genesis" layout="3col" checkout_button="Buy Membership" description="false"]' );
							?>
							   
							</div>
							<div class="col-sm-4">
							<?php
							echo do_shortcode( '[pmpro_advanced_levels levels="10" template="genesis" layout="3col" checkout_button="Buy Membership" description="false"]' );
							?>
							</div>
						</div>
						<?php
					} else {
						the_content();
					}
				}
				?>
				<?php comments_template( '', true ); ?>
			<?php endwhile; // end of the loop. ?>
		</div><!-- #content -->
	</div><!-- #primary -->
</div><!-- .page-full-width -->
<?php get_footer(); ?>
