<?php
include '../../../../wp-config.php';
global $wpdb;
$table = $wpdb->prefix . 'expert_team_detail';
$conference_table = $wpdb->prefix . 'setup_conference_call';
$response_table = $wpdb->prefix . 'conference_call_response';
$currentuserid = get_current_user_id();
$prefix = $wpdb->prefix;
$biling_table = $wpdb->prefix.'BillingInformation';
if (isset($_POST['deletevalue']) || isset($_POST['tableid'])) {
    $val = $_POST['deletevalue'];
    $dataid = $_POST['tableid'];
    $userdeletarray = explode(",", $val);
    $usersexist = $wpdb->get_var("SELECT `invited_experts` FROM $table WHERE `current_user_id`='$currentuserid' AND `id`='$dataid'");
    $userexistarray = explode(",", $usersexist);
    $removeselected = array_diff($userexistarray, $userdeletarray);
    $updateuser = implode(",", $removeselected);
    $update = $wpdb->query("UPDATE $table SET `invited_experts` ='$updateuser' WHERE `current_user_id`='$currentuserid' AND `id`=$dataid");
    if ($update) {
        echo "Selected Users Deleted Successfully";
    }
}
if (isset($_POST['new_team_name']) || isset($_POST['new_team_desc'])) {
    $new_team_name = $_POST['new_team_name'];
    $new_team_desc = $_POST['new_team_desc'];
    $userexist = $wpdb->get_results("SELECT * FROM $table WHERE `current_user_id`='$currentuserid' AND `meeeting_scheduled` IS NULL ORDER BY `id` DESC LIMIT 1");
    if ($userexist) {
        $update = $wpdb->query("UPDATE $table SET `team_name`='$new_team_name', `team_description`='$new_team_desc' WHERE `currentuserid`='$currentuserid' ORDER BY `id` DESC LIMIT 1");
        echo "successfully insert";
    } else {
        $wpdb->insert(
                $table, array
            (
            'current_user_id' => $currentuserid,
            'team_name' => $new_team_name,
            'team_description' => $new_team_desc
                ), array
            (
            '%d', '%s', '%s'
        ));
        echo "successfully insert";
    }
}
if (isset($_POST['tableids'])) {
    $tableids = $_POST['tableids'];
    $new_team_name = $_POST['new_team_name'];
    $new_team_desc = $_POST['new_team_desc'];
    $date = date("Y-m-d H:i:s");
    $get_data = $wpdb->get_results("SELECT * FROM $table WHERE `id` =$tableids AND  `current_user_id`=$currentuserid");
    //$update = $wpdb->query("UPDATE $table SET `meeeting_scheduled`='yes' WHERE `current_user_id`='$currentuserid' AND `meeeting_scheduled` IS NULL AND `id`= $tableids ORDER BY `id` DESC LIMIT 1");
    $update = $wpdb->query("UPDATE $table SET `meeeting_scheduled`='yes', `team_name`='$new_team_name', `team_description`='$new_team_desc', `created_date`='$date' WHERE `current_user_id`='$currentuserid' AND `id`= '$tableids'");
}
if (isset($_POST['meetingnotify'])) {
    include $_SERVER['DOCUMENT_ROOT'] . '/wp-content/themes/boss-child/email-template/schedule_meeting.php';
}
if (isset($_POST['timezone']) && isset($_POST['enter_reason']) && isset($_POST['conference_type']) && isset($_POST['formpost'])) {
    $user_id = get_current_user_id();
    $a_log_table = $wpdb->prefix . 'admin_transection_logs';
    $admin_user_id = 1;
    $timezone = $_POST['timezone'];
    $enter_reason = $_POST['enter_reason'];
    $conference_type = $_POST['conference_type'];
    switch ($conference_type) {
        case "Video":
            $price = "video_min_price";
            break;
        case "Chat":
            $price = "chat_price";
            break;
        case "SMS":
            $price = "sms_price";
            break;
        default:
            $price = "price";
    }
    $twilio_number = ($_POST['twilio_number'] != '') ? $_POST['twilio_number'] : '';
    $estimate_length = $_POST['estimate_length'];
    $amount = $_POST['amount'];
    $datepicker = $_POST['datepicker'];
    $timepicker = $_POST['timepicker'];
    $timepicker = str_replace(' ', '', $timepicker);
    $conf_date_time = $datepicker . ' ' . $timepicker;
    $couponecode = $_POST['couponecode'];
    $bookingid = $_POST['bookingid'];
    $conference_id = md5($bookingid);
    $team_id = $_POST['team_id'];
    $users_array = $_REQUEST['users'];
    $users_array = rtrim($users_array, ',');
    $payment_gateway = "Credits Point System";
    $credit_url = $_POST['points_page'];
    $blog_id = get_current_blog_id();
    $my_meta_key = "wp68_" . $blog_id . "_user_points";
    $teamtable = $wpdb->prefix . 'expert_team_detail';
    $current_user_credits = get_user_meta($user_id, $my_meta_key, true);
    $admin_credits = get_user_meta($admin_user_id, $my_meta_key, true);
    $conf_table = $wpdb->prefix . 'setup_conference_call';
    $credit_table = $wpdb->prefix . 'expert_price';
    $old_booking = $wpdb->get_results($wpdb->prepare("SELECT * FROM $conf_table WHERE current_user_id= %d", $user_id));
    $timezone_length = $_POST['timezone_length'];
    $con_confernce_time = new DateTime($conf_date_time, new DateTimeZone($timezone));
    $con_confernce_time->format('Y-m-d h:i A');
    $con_confernce_time->setTimezone(new DateTimeZone('UTC'));
    $booking_time_str = strtotime($con_confernce_time->format('Y-m-d h:i A'));
    $gmt_start_time = date('Y-m-d H:i:s', $booking_time_str);
    $time_length_second = $estimate_length * 60;
    $gmt_end_str = $booking_time_str + $time_length_second;
    $gmt_end_time = date('Y-m-d H:i:s', $gmt_end_str);
    $a_time = strtotime($conf_date_time);
    $end_booking_timestamp = $a_time + $time_length_second;
    $final_timezone = $timezone;
    $new_start_time = date('h:i A', $a_time);
    $new_estimate_seconds = $estimate_length * 60;
    $new_end_booking_str = $a_time + $new_estimate_seconds;
    foreach ($old_booking as $old_bookings) {
        $exist_timezone = $old_bookings->time_zone;
        $timezone_id_initial = explode(" ", $exist_timezone);
        $saved_timezone_id = $exist_timezone;
        $already_booked_time = $old_bookings->conference_datetime;
        $call_length = $old_bookings->estimated_length;
        $start_booking_str = strtotime($already_booked_time);
        $al_expload = explode(" ", $already_booked_time);
        $al_date = $al_expload[0];
        $start_time = date('h:i A', $start_booking_str);
        $estimate_seconds = $call_length * 60;
        $end_booking_str = $start_booking_str + $estimate_seconds;
        if ($exist_timezone == $final_timezone) {
            if ($a_time >= $start_booking_str && $a_time <= $end_booking_str) {
                echo "Your Start Time alreday lies in booked Range";
                exit;
            } else if ($new_end_booking_str >= $start_booking_str && $new_end_booking_str <= $end_booking_str) {
                echo "Your End Time alreday lies in booked range";
                exit;
            }
        } else {
            $confe_time = new DateTime($already_booked_time, new DateTimeZone($saved_timezone_id));
            $confe_time->format('Y-m-d h:i A');
            $confe_time->setTimezone(new DateTimeZone($timezone));
            $time_str = strtotime($confe_time->format('Y-m-d h:i A'));
            $update_end_str = $time_str + $new_estimate_seconds;

            if ($a_time >= $time_str && $a_time <= $update_end_str) {
                echo "Your Start Time alreday lies in booked range new ";
                exit;
            } else if ($new_end_booking_str >= $update_end_str && $new_end_booking_str <= $update_end_str) {
                echo "Your End Time alreday lies in booked range";
                exit;
            }
        }
    }
    $orginal = array();
    if ($current_user_credits <= $amount) {
        echo $message = "You Credits Balance is not enough to make this booking. please buy the credits from <a href='" . $credit_url . "' target='_blank'>Here</a> and try again.";
        exit;
    } else {
        if (empty($users_array)) {
            $teamdetail = $wpdb->get_results("SELECT * FROM $teamtable WHERE current_user_id='$user_id' AND `id`='$team_id'");
            $expert_ids = $teamdetail[0]->invited_experts;
            $expertarray = explode(",", $expert_ids);
            foreach ($expertarray as $expertid):
                $credit_price = $wpdb->get_var("SELECT $price FROM $credit_table WHERE `user_id`=$expertid");
                $orginal[$expertid] = $credit_price;
            endforeach;
            $serial_array = serialize($orginal);
        }
        else {

            $expert_ids = $users_array;
            $expertarray = explode(",", $users_array);
            foreach ($expertarray as $expertid):
                $credit_price = $wpdb->get_var("SELECT $price FROM $credit_table WHERE `user_id`=$expertid");
                $orginal[$expertid] = $credit_price;
            endforeach;
            $serial_array = serialize($orginal);
        }
        $updated_user_points = $current_user_credits - $amount;
        $update_admin_credit = $admin_credits + $amount;
        $update = update_user_meta($user_id, $my_meta_key, $updated_user_points);
        $update_admin = update_user_meta($admin_user_id, $my_meta_key, $update_admin_credit);
        $description = "Money in for conference call booking id" . $bookingid;
        $trans_type = "Incoming";
        $refund_status = "No Refund";
        $chargeId = "ch_" . uniqid();
        $admin_trans_id = "ch_ad_" . uniqid();
        $test_insert = $wpdb->insert($conference_table, array(
            'current_user_id' => $currentuserid,
            'conference_id' => $conference_id,
            'team_id' => $team_id,
            'call_topic' => $enter_reason,
            'conference_type' => $conference_type,
            'twilio_number' => $twilio_number,
            'estimated_length' => $estimate_length,
            'conference_datetime' => $conf_date_time,
            'gmt_starttime' => $gmt_start_time,
            'gmt_endtime' => $gmt_end_time,
            'book_timestamp' => $a_time,
            'amount' => $amount,
            'booking_id' => $bookingid,
            'transactionid' => $chargeId,
            'time_zone' => $final_timezone,
            'booking_status' => 'booked',
            'expert_ids' => $expert_ids,
            'expert_rate' => $serial_array,
            'payment_gateway' => $payment_gateway), array('%d', '%s', '%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%d', '%f', '%d', '%s', '%s', '%s', '%s', '%s', '%s'));

        if ($test_insert == 1) {
            $admin_entry = $wpdb->query($wpdb->prepare("INSERT INTO $a_log_table( orderid, user_id, amount, description, transaction_type, transaction_id, refund_status ) VALUES ( %d, %d, %f, %s, %s, %s, %s )", $bookingid, $user_id, $amount, $description, $trans_type, $admin_trans_id, $refund_status));

            $teamname = $wpdb->get_var("SELECT `team_name` FROM $table WHERE `current_user_id`='$currentuserid' AND `id`='$team_id'");
            $getexperts = $wpdb->get_var("SELECT `invited_experts` FROM $table WHERE `current_user_id`='$currentuserid' AND `id`='$team_id'");

            function booking_cancellation_notification() {
                return 'Conference Expert Invitation Mail';
            }

            add_filter('wp_mail_from_name', 'Conference Invitation Notification');
            require '../email-template/conference_expert_invitation_mail.php';
            echo "successfully insert";
        } else {
            echo "record failed  to update";
        }
    }
} else {
    //echo "Some Of the field value is empty";
}
if (isset($_POST['deleteteamid'])) {
    $deleteteamid = $_POST['deleteteamid'];
    $wpdb->query("DELETE FROM $table WHERE `id`=$deleteteamid AND `current_user_id`=$currentuserid");
}
if (isset($_POST['teamid'])) {
    $teamid = $_POST['teamid'];
    $userlogindata = get_userdata($currentuserid);
    $username = $userlogindata->user_login;
    //echo '<div class="callingParty">Calling Party: <strong>'.$username.'</strong></div>';
    $allmember = $wpdb->get_results("SELECT * FROM $table WHERE `current_user_id`='$currentuserid' AND `id`='$teamid'");
    $invited_experts = $allmember[0]->invited_experts;
    $teamname = $allmember[0]->team_name;
    $allexperts = explode(",", $invited_experts);
    ?>

    <div class="myExpertsTeam">
        <div class="headingPage">
            <h4>Team Name: <strong><?php echo $teamname; ?></strong></h4>
            <input type="hidden" class="team_iddd" value="<?php echo $teamid; ?>"/>
        </div>
        <table align="center" border="2"  class="invitedtablelist tableCommonStyle" id="team_member_call">
            <thead>
                <tr>
                    <th id="serialNumber">ID</th>
                    <th id="teamMember">User Name</th>
                    <th id="teamMember">First Name</th>
                    <th id="teamMember">Last Name</th>
                    <th id="organization">Organization</th>
                    <th id="city">City</th>
                    <th id="state">State</th>
                    <th id="country">Country</th>
                    <th id="primary_category">Category</th>
                    <th id="selectAll"><input type="checkbox" id="select_all_member" class="select_unselects" title="Select/Unselect All To Remove Users" /></th>
                </tr>
            </thead>
            <tbody class="experts_teams_body">
    <?php
    if ($allexperts):
        $i = 1;
        $single = true;
        foreach ($allexperts as $members):
        $userlogindata = get_userdata($members);
        $username = $userlogindata->user_login;
        $get_client = $wpdb->get_results("SELECT * FROM $biling_table WHERE `userid`=$currentuserid AND `expertid`=$members");
        if($get_client)
        {    
        $user_first =get_user_meta($members, 'first_name',$single);
        $user_last =get_user_meta($members, 'last_name',$single);        
        $city = bp_get_profile_field_data('field=City&user_id='.$members);
        $state = bp_get_profile_field_data('field=State&user_id='.$members);
        $country = bp_get_profile_field_data('field=Country&user_id='.$members);                                    
        $organization = bp_get_profile_field_data('field=Company&user_id='.$members);
        }
        elseif('is_friend' == BP_Friends_Friendship::check_is_friend( $currentuserid, $members ) )
        {
          $user_first =get_user_meta($members, $prefix.'friend_first_hidden_name',$single);
          $user_last =get_user_meta($members, $prefix.'friend_last_hidden_name',$single);                              
          $city =get_user_meta($members, $prefix.'friend_city_hidden_name',$single);
          $state =get_user_meta($members, $prefix.'friend_state_hidden_name',$single);
          $country =get_user_meta($members, $prefix.'friend_country_hidden_name',$single);
          $organization = get_user_meta($members, $prefix.'friend_company_hidden_name',$single);     
        }
        else
        {
          $user_first =get_user_meta($members, $prefix.'member_first_hidden_name',$single);
          $user_last =get_user_meta($members, $prefix.'member_last_hidden_name',$single);                                        
          $city =get_user_meta($members, $prefix.'member_city_hidden_name',$single);
          $state =get_user_meta($members, $prefix.'member_state_hidden_name',$single);
          $country =get_user_meta($members, $prefix.'member_country_hidden_name',$single);
          $organization = get_user_meta($members, $prefix.'member_company_hidden_name',$single); 
        }
            
            /* $option_name = 'show_username';
              $get_meta = get_user_option( $option_name, $members ); */

            $get_meta = bp_get_profile_field_data('field=username&user_id=' . $members);
            $primary_table = $wpdb->prefix . 'primary_category';
            $user_cat_table = $wpdb->prefix . 'user_category';
            $primary_cats = $wpdb->get_results("SELECT * FROM $primary_table WHERE `user_id`=$members AND `admin_approve`='yes'");
            if ($primary_cats):
                $primary_cat = $primary_cats[0]->primary_category;
                $get_category = $wpdb->get_var("SELECT `category_name` FROM $user_cat_table WHERE `category_key`='$primary_cat'");
            else:
                $get_category = '';
            endif;
            echo
            '<tr>
                            <td>' . $i . '</td>';
            ?>
                    <td><?php if ($get_meta == 'Yes') {
                echo $username;
            } else {
                ' ';
            } ?></td>
                        <?php
                        echo '<td>' . $user_first . '</td>
                            <td>' . $user_last . '</td>
                            <td>' . $organization . '</td>
                            <td>' . $city . '</td>
                            <td>' . $state . '</td>
                            <td>' . $country . '</td>
                            <td>' . $get_category . '</td>
                            <td><input type="checkbox" class="select_member" data-id="' . $members . '"/> </td>
                        </tr>';
                        $i++;
                    endforeach;
                endif;
                ?>
            </tbody>
                <?php
                ?>
        </table>
        <div class="addRemButtons">
            <div class="schedule_meeting"> <!-- Add Users -->
                <a href="javascript:void(0);" id="addteam" class="Addusertolist add_expert_team">Add Users</a>
            </div>
            <div class="schedule_meeting"> <!-- Add Users -->
                <a href="javascript:void(0);" id="removeexperts" class="remove_experts_team">Remove Users</a>
            </div>
        </div> <!--addRemButtons_END-->
    </div> <!--myExpertsTeam_END-->
                <?php
            }
            if (isset($_POST['removevalue']) && isset($_POST['team_idd'])) {
                $removevalue = $_POST['removevalue'];
                $team_idd = $_POST['team_idd'];
                $getexperts = $wpdb->get_var("SELECT `invited_experts` FROM $table WHERE `current_user_id`='$currentuserid' AND `id`='$team_idd'");
                $userdeletarray = explode(",", $removevalue);
                $userexistarray = explode(",", $getexperts);
                $removeselected = array_diff($userexistarray, $userdeletarray);
                $updateuser = implode(",", $removeselected);
                $update = $wpdb->query("UPDATE $table SET `invited_experts` ='$updateuser' WHERE `current_user_id`='$currentuserid' AND `id`=$team_idd");
                $allmember = $wpdb->get_results("SELECT * FROM $table WHERE `current_user_id`='$currentuserid' AND `id`='$team_idd'");
                $invited_experts = $allmember[0]->invited_experts;
                $allexperts = explode(",", $invited_experts);
                ?>

            <?php
            if ($allexperts):
                $i = 1;
                $single = true;
                foreach ($allexperts as $members):
                    $userlogindata = get_userdata($members);
                    $username = $userlogindata->user_login;
                    $user_first = get_user_meta($members, 'first_name', $single);
                    $user_last = get_user_meta($members, 'last_name', $single);
                    $city = bp_get_profile_field_data('field=City&user_id=' . $members);
                    $state = bp_get_profile_field_data('field=State&user_id=' . $members);
                    $country = bp_get_profile_field_data('field=Country&user_id=' . $members);
                    $organization = bp_get_profile_field_data('field=Company&user_id=' . $members);

                    /* $option_name = 'show_username';
                      $get_meta = get_user_option( $option_name, $members ); */
                    $get_meta = bp_get_profile_field_data('field=username&user_id=' . $members);

                    $primary_table = $wpdb->prefix . 'primary_category';
                    $user_cat_table = $wpdb->prefix . 'user_category';
                    $primary_cats = $wpdb->get_results("SELECT * FROM $primary_table WHERE `user_id`=$members AND `admin_approve`='yes'");
                    if ($primary_cats):
                        $primary_cat = $primary_cats[0]->primary_category;
                        $get_category = $wpdb->get_var("SELECT `category_name` FROM $user_cat_table WHERE `category_key`='$primary_cat'");
                    else:
                        $get_category = '';
                    endif;
                    /* $status = $wpdb->get_var("SELECT `user_response` FROM $response_table WHERE `current_user_id`=$currentuserid AND `team_id`=$teamid AND `expert_id`=$members");
                      $notscheduled = $wpdb->get_var("SELECT * FROM $response_table WHERE `team_id`=$teamid");
                      if($status=='yes')
                      $statuss = 'Accepted';
                      elseif($status=='no')
                      $statuss = 'Declined';
                      elseif(!$notscheduled)
                      $statuss = 'Not Scheduled';
                      else
                      $statuss = 'Pending'; */
                    echo
                    '<tr>
                            <td>' . $i . '</td>';
                    ?>
            <td><?php if ($get_meta == 'Yes') {
                echo $username;
            } else {
                ' ';
            } ?></td>
            <?php
            echo '<td>' . $user_first . '</td>
                            <td>' . $user_last . '</td>
                            <td>' . $organization . '</td>
                            <td>' . $city . '</td>
                            <td>' . $state . '</td>
                            <td>' . $country . '</td>
                            <td>' . $get_category . '</td>
                            <td><input type="checkbox" class="select_member" data-id="' . $members . '"/> </td>
                        </tr>';
            $i++;
        endforeach;
    endif;
}
if (isset($_POST['teamidd'])) {
    $teamidd = $_POST['teamidd'];
    $team_name = $_POST['team_name'];
    $team_desc = $_POST['team_desc'];
    $update = $wpdb->query("UPDATE $table SET `team_name`='$team_name', `team_description`='$team_desc' WHERE `current_user_id`='$currentuserid' AND `id`= $teamidd");
    if ($update):
        echo "success";
    else:
        echo "fail";
    endif;
}
if (isset($_POST['cloneteamid'])) {
    $cloneteamid = $_POST['cloneteamid'];
    $insert = $wpdb->query("insert into $table (current_user_id, team_name, team_description, invited_experts, meeeting_scheduled) select current_user_id, team_name, team_description, invited_experts, meeeting_scheduled from wp68_14_expert_team_detail where id = $cloneteamid");
    $lastInsertId = $wpdb->insert_id;
    $update = $wpdb->query("UPDATE $table SET `meeeting_scheduled`=NULL WHERE `id`= $lastInsertId");
}
?>
