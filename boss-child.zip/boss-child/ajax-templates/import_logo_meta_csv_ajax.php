<?php 
include '../../../../wp-config.php';
global $wpdb,$current_user;
$user_id = $current_user->ID;
$post_table = $wpdb->prefix.'postmeta';
$filename= $_FILES["logo_csv_meta"]["tmp_name"];			
		if($_FILES["logo_csv_meta"]["size"] > 0)
		{
			if (($handle = fopen($filename, "r")) !== FALSE) 
			{
				fgetcsv($handle); 
				$total_count = 0;				
				while (($getData = fgetcsv($handle, 10000, ",")) !== FALSE)
				{
                        $data = array( 
						'meta_id' => $getData[0], 
						'post_id' => $getData[1],
						'meta_key' => $getData[2],
						'meta_value' => $getData[3]						
						);

						$format = array( 
								'%d',
								'%d', 
								'%s',
								'%s'													
						);				
                        $insert_sql = $wpdb->insert($post_table, $data, $format);
                        if($insert_sql== 1)
                        {
                            
                        }
                        else
                        {
                            echo 'Error Occured In Inserting Post No'.$getData[0].'<br/>';
                        }                                             
                        $total_count++;
                }					
            }
			echo "Total Post Updated".$total_count;
	        fclose($file);	
    }
		