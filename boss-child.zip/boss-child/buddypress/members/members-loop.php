<?php
/**
 * BuddyPress - Members Loop
 *
 * Querystring is set via AJAX in _inc/ajax.php - bp_legacy_theme_object_filter()
 *
 * @package Boss
 * @subpackage bp-legacy
 */
?>
<?php do_action( 'bp_before_members_loop' ); ?>
<?php
global $wpdb;
$currentuserid = get_current_user_id();
$prefix        = $wpdb->prefix;
$biling_table  = $prefix . 'BillingInformation';

$allUsers = get_users( array( 'fields' => 'ID' ) );
$allUsers = implode( ',', $allUsers );
if ( bp_has_members( bp_ajax_querystring( 'members' ) . '&per_page=30&include=' . $allUsers ) ) :
	//if ( bp_has_members( bp_ajax_querystring( 'members' ) ) ) :
?>
	<div id="pag-top" class="pagination">
		<div class="pag-count" id="member-dir-count-top">
			<?php bp_members_pagination_count(); ?>
		</div>
		<div class="pagination-links" id="member-dir-pag-top">
			<?php bp_members_pagination_links(); ?>
		</div>
	</div>
	<?php do_action( 'bp_before_directory_members_list' ); ?>
	<ul id="members-list" class="item-list" role="main">
	<?php
	while ( bp_members() ) :
		bp_the_member();
			$ids        = bp_get_member_user_id();
			$key1       = 'first_name';
			$key2       = 'last_name';
			$single     = true;
			$get_client = $wpdb->get_results( "SELECT * FROM $biling_table WHERE `userid`=$currentuserid AND `expertid`=$ids" );
		if ( $get_client ) {
			$user_first   = get_user_meta( $ids, 'first_name', $single );
			$user_last    = get_user_meta( $ids, 'last_name', $single );
			$city         = bp_get_profile_field_data( 'field=City&user_id=' . $ids );
			$state        = bp_get_profile_field_data( 'field=State&user_id=' . $ids );
			$Country      = bp_get_profile_field_data( 'field=Country&user_id=' . $ids );
			$organization = bp_get_profile_field_data( 'field=Company&user_id=' . $ids );
			$avatar       = get_avatar( $ids, $size );
		} elseif ( 'is_friend' == BP_Friends_Friendship::check_is_friend( $currentuserid, $ids ) ) {
			$user_first     = get_user_meta( $ids, $prefix . 'friend_first_hidden_name', $single );
			$user_last      = get_user_meta( $ids, $prefix . 'friend_last_hidden_name', $single );
			$city           = get_user_meta( $ids, $prefix . 'friend_city_hidden_name', $single );
			$state          = get_user_meta( $ids, $prefix . 'friend_state_hidden_name', $single );
			$Country        = get_user_meta( $ids, $prefix . 'friend_country_hidden_name', $single );
			$organization   = get_user_meta( $ids, $prefix . 'friend_company_hidden_name', $single );
			$friend_profile = get_user_meta( $ids, $prefix . 'friend_profile_hidden', $single );
			if ( $friend_profile == 'yes' ) :
				$avatar = get_avatar( $ids, $size );
			else :
				$avatar = '<img src="/wp-content/themes/boss-child/images/avatar-member.jpg" class="avatar" />';
			endif;
		} else {
			$user_first     = get_user_meta( $ids, $prefix . 'member_first_hidden_name', $single );
			$user_last      = get_user_meta( $ids, $prefix . 'member_last_hidden_name', $single );
			$city           = get_user_meta( $ids, $prefix . 'member_city_hidden_name', $single );
			$state          = get_user_meta( $ids, $prefix . 'member_state_hidden_name', $single );
			$Country        = get_user_meta( $ids, $prefix . 'member_country_hidden_name', $single );
			$organization   = get_user_meta( $ids, $prefix . 'member_company_hidden_name', $single );
			$member_profile = get_user_meta( $ids, $prefix . 'member_profile_hidden', $single );
			if ( $member_profile == 'yes' ) :
				$avatar = get_avatar( $ids, $size );
		  else :
				$avatar = '<img src="/wp-content/themes/boss-child/images/avatar-member.jpg" class="avatar" />';
		  endif;
		}

			$loggedinuser     = get_userdata( get_current_user_id() );
			$role             = $loggedinuser->roles;
			$customProfileURL = site_url( 'user-basic-profile/?ExpertId=' . $ids );
			//if($role[0] !='administrator'):
		?>
		<li>
			<div class="item-avatar">
				<a href="<?php echo $customProfileURL; ?>"><?php bp_member_avatar( 'type=full&width=70&height=70' ); ?></a>

			</div>
			<div class="item">
				<div class="item-title">
					<!-- <a href="<?php bp_member_permalink(); ?>"><?php bp_member_name(); ?></a> -->
					<a href="<?php echo $customProfileURL; ?>"><?php echo $user_first . '&nbsp;' . $user_last; ?></a><br />
						<?php
						//echo '<span>'.$city.'</span>&nbsp;&nbsp;<span>'.$state.'&nbsp;&nbsp;'.$Country.'</span>';
						?>
					   <span>
						<?php
						if ( $city || $state || $Country ) {
							echo '<i class="fa fa-map-marker" aria-hidden="true"></i>';
						}if ( $city ) {
							echo $city;
						} if ( $city && $state ) {
							echo ',&nbsp';
						} if ( $state ) {
							echo $state;
						}if ( ( $state || $city ) && $Country ) {
							echo ',&nbsp';
						}if ( $Country ) {
							echo $Country;}
?>
</span>

				</div>
				<?php
				$showing = null;
				//if bp-followers activated then show it.
				if ( function_exists( 'bp_follow_add_follow_button' ) ) {
					$showing   = 'follows';
					$followers = bp_follow_total_follow_counts( array( 'user_id' => bp_displayed_user_id() ) );
				} elseif ( function_exists( 'bp_add_friend_button' ) ) {
					$showing = 'friends';
				}
				?>
				<div class="item-meta">
					<div class="activity">
						<?php bp_member_last_active(); ?>
					</div>
					<?php if ( $showing == 'friends' ) : ?>
					<span class="count"><?php echo friends_get_total_friend_count( bp_get_member_user_id() ); ?></span>
						<?php if ( friends_get_total_friend_count( bp_get_member_user_id() ) > 1 ) { ?>
							<span><?php _e( 'Friends', 'boss' ); ?></span>
						<?php } else { ?>
							<span><?php _e( 'Friend', 'boss' ); ?></span>
						<?php } ?>
					<?php endif; ?>
					<?php if ( $showing == 'follows' ) : ?>
					<span class="count">
					<?php
					$followers = bp_follow_total_follow_counts( array( 'user_id' => bp_get_member_user_id() ) );
					echo $followers['followers'];
?>
</span><span><?php _e( 'Followers', 'boss' ); ?></span>
					<?php endif; ?>
				</div>
				<div class="item-desc">
					<p>
						<?php if ( bp_get_member_latest_update() ) : ?>
							<?php bp_member_latest_update( array( 'view_link' => true ) ); ?>
						<?php endif; ?>
					</p>
				</div>
				<?php do_action( 'bp_directory_members_item' ); ?>
				<?php
				 /***
				  * If you want to show specific profile fields here you can,
				  * but it'll add an extra query for each member in the loop
				  * (only one regardless of the number of fields you show):
				  *
				  * bp_member_profile_data( 'field=the field name' );
				  */
				?>
			</div>
			<div class="action">
				<div class="action-wrap">
					<?php do_action( 'bp_directory_members_actions' ); ?>
				</div>
			</div>
			<div class="clear"></div>
		</li>
	<?php
	//endif;
	endwhile;
	?>
	</ul>
	<?php do_action( 'bp_after_directory_members_list' ); ?>
	<?php bp_member_hidden_fields(); ?>
	<div id="pag-bottom" class="pagination">
		<div class="pag-count" id="member-dir-count-bottom">
			<?php bp_members_pagination_count(); ?>
		</div>
		<div class="pagination-links" id="member-dir-pag-bottom">
			<?php bp_members_pagination_links(); ?>
		</div>
	</div>
<?php else : ?>
	<div id="message" class="info">
		<p><?php _e( 'Sorry, no members were found.', 'boss' ); ?></p>
	</div>
<?php endif; ?>
<?php do_action( 'bp_after_members_loop' ); ?>
