<?php
/*
 * Template Name: Custom Post
 *
*/
get_header(); ?>
<style>
	
.site-content.Allpostcontent 
{
	margin: 2% !important;
}
.posttitle a {
	margin-left: 27px;
	text-decoration: underline;
}
</style>
<div class="page-full-width">

	<div id="primary" class="site-content Allpostcontent">
		<div id="content" role="main">
				<?php
				$args =
				array(
					'post_type'      => 'post',
					'posts_per_page' => -1,
					'order'          => 'DESC',
					'cat'            => 'buyer',
				);

				$myposts = get_posts( $args );
			?>
		<div class="row">   
			<?php
			foreach ( $myposts as $post ) :
				setup_postdata( $post );
?>
			
			<div class="posttitle">
				<h3><a href="<?php the_permalink(); ?>"  rel="bookmark" title="Permanent Link to <?php the_title_attribute(); ?>"><?php the_title(); ?></a></h3>
				
			</div>
			<?php
			endforeach;
			?>
		</div>
		<?php

		wp_reset_postdata();
		?>
		</div><!-- #content -->
	</div><!-- #primary -->

</div><!-- .page-full-width -->
<?php get_footer(); ?>
