<?php
include '../../../../wp-config.php';
global $current_user, $wpdb,$post;
$user_id = $current_user->ID;
$currentdirectory = get_stylesheet_directory_uri();
$posttable = $wpdb->prefix.'posts';
$blockchain_setting =  get_option('update_user_profile_bc');
if(isset($_POST['deletpostid'])):
    $deletpostid = $_POST['deletpostid'];
    $directory = $_SERVER['DOCUMENT_ROOT'] . '/wp-content/themes/boss-child/';    
    $path = get_post_meta($deletpostid,'logo_path', $single=true);    
    $full_path = $directory.$path;
    //echo $full_path;
    $unlinkfile =  unlink($directory.$path);
    if($unlinkfile):
        wp_delete_post($deletpostid);  
        echo json_encode(array("status" => 1 , 'message' => "Successfully Deleted", 'response' => ''));
        if($blockchain_setting == "enable")
        {
            blockchain_updates();
        }
            exit();  
            else:
            echo json_encode(array("status" => 0 , 'message' => "Error In Delete post."));
            exit();  
    endif;
endif;

if(isset($_FILES["edit_logo"]["type"]) && isset( $_POST['cpt_nonce_field'] ) && wp_verify_nonce( $_POST['cpt_nonce_field'], 'cpt_nonce_action' ) )
{
    $validextensions = array("jpeg", "jpg", "png", "JPG","JPEG","PNG");
    $temp1 = $_FILES["edit_logo"]["name"];
    $temporary = explode(".", $_FILES["edit_logo"]["name"]);    
    $file_title = $temporary[0];
    $file_name = sanitize_title($file_title);
    $getext =  $temporary[1];
    if($getext=='jpg' OR $getext=='JPG' OR $getext=='JPEG'):
        $getext ='jpeg';
    endif; 
    $newfile = $temporary[0].'.'.$getext;     
    $file_type = $_FILES["edit_logo"]["type"];
    $file_extension = end($temporary);
    $edit_company_name = $_POST['edit_company_name'];
    
    if ((($_FILES["edit_logo"]["type"] == "image/png") || ($_FILES["edit_logo"]["type"] == "image/jpg") || ($_FILES["edit_logo"]["type"] == "image/jpeg") || ($_FILES["edit_logo"]["type"] == "image/JPG") || ($_FILES["edit_logo"]["type"] == "image/JPEG") || ($_FILES["edit_logo"]["type"] == "image/PNG") )&& ($_FILES["edit_logo"]["size"] < 1097152) //Approx. 1mb files can be uploaded.
    && in_array($file_extension, $validextensions)) 
    {
        if ($_FILES["edit_logo"]["error"] > 0)
        {
            $ErroString = $_FILES["edit_logo"]["error"];
           echo json_encode(array("status" => 0 , 'message' => $ErroString));
            exit();
            //echo "Return Code: " . $_FILES["edit_logo"]["error"] . "<br/><br/>";
        }
        else
        {
            /*chagne file name */                
            $fileData = pathinfo(basename($_FILES["edit_logo"]["name"]));
            $fileName =  $file_title. '.' . $fileData['extension'];
            /*chagne file name */
            $directory = $_SERVER['DOCUMENT_ROOT'] . '/wp-content/themes/boss-child/iis/company_logo/users/'.$user_id.'/current_company/';            
            if (wp_mkdir_p($directory)) 
            {
                //echo 'It worked <br/>';
            }
           /* if (file_exists($directory.$fileName))
            {*/
                    $logo_id = $_POST['logo_id'];
                    $logopath = get_post_meta($logo_id,'logo_path', $single=true);
                    $logo_directory = $_SERVER['DOCUMENT_ROOT'] . '/wp-content/themes/boss-child/'.$logopath; 
                    $unlinkfile =  unlink($logo_directory);
                    if($unlinkfile):                         
                        $sourcePath = $_FILES['edit_logo']['tmp_name']; // Storing source path of the file in a variable                             
                        $targetPath =  $directory.$fileName;// Target path where file is to be stored                
                        $uploadedfile =  move_uploaded_file($sourcePath,$targetPath); // Moving Uploaded file
                        $imgurl = $currentdirectory.'/iis/company_logo/users/'.$user_id.'/current_company/'.$fileName;                        
                        if($uploadedfile):
                            $post_mime_type = $_FILES["edit_logo"]["type"];
                            $today = date("Y-m-d H:i:s");                                                     
                            $update = $wpdb->query("UPDATE `$posttable` SET `post_title` ='$file_title', `post_name`='$file_name',`post_mime_type`='$post_mime_type', `guid`='$imgurl', `post_modified`='$today', `post_modified_gmt`='$today' WHERE `ID` = $logo_id AND `post_author` = $user_id AND `post_type`='company_logo'");                            
                             //$post_id = wp_update_post( $post_info, $wp_error );; 
                                    $path = 'iis/company_logo/users/'.$user_id.'/current_company/'.$fileName;
                                    update_post_meta($logo_id, 'logo_path', $path); 
                                    update_post_meta($logo_id, 'company_logo_name', $edit_company_name); 
                            
                         echo json_encode(array("status" => 1 , 'message' => "Image Edit Successfully...!!", 'imageURL' => $imgurl, 'logoTitle' => $edit_company_name));
                            if($blockchain_setting == "enable")
                            {
                                blockchain_updates();
                            }
                            exit();             
                              
                        endif;
                 endif;              
            //}     
        }
    }
    else
    {
        echo json_encode(array("status" => 0 , 'message' => "<span id='invalid'>***Invalid file Size or Type***<span>"));
                            exit();  
    }
}
?>