function toglecomment(formid) {
    var str1 = "Show Commentss";
    var str2 = "Hide Comments";
    $('.main_comment_body-' + formid).toggle('5000');
    $('.final_toggle-' + formid).toggleClass("change_image");
    if ($('.final_toggle-' + formid).hasClass("change_image")) {
        $('.final_toggle-' + formid).html(str2);
    } else {
        $('.final_toggle-' + formid).html(str1);
    }
}

function mydeletecomment(tableid, fieldno) {
    var actionperform = "deleteaction";
    $("html").addClass("overlay");
    $('#editcomment-' + tableid + ' .edit_comment_form').hide();
    var pollNonce = $('#editcomment-' + tableid + ' .poll_nonce').val();
    $.ajax({
        type: "POST",
        url: ajaxurl,
        data: {
            action: 'vl_poll_comment_edit_delete',
            commentaction: tableid,
            myfield: fieldno,
            performaction: actionperform,
            pollNonce: pollNonce
        },
        success: function(data) {
            if (data == 1) {
                $('#comment_action-' + tableid).html("Comment has been deleted successfully");
                setTimeout(function() { window.location.reload(); }, 1000);
            }
        },
        complete: function() {
            $("html").removeClass("overlay");
        },
        error: function(error) {
            $('#comment_action-' + tableid).html(error);
        }
    });
}

function comment_open(leadid) {
    $('#editcomment-' + leadid + ' .edit_comment_form').show();
}

function myeditcomment(tableid, fieldno) {
    var actionperform = "editaction";
    var textareavalue = $('#comment_edit_area-' + tableid).val();
    var pollNonce = $('#editcomment-' + tableid + ' .poll_nonce').val();
    $('#text_error-' + tableid).show();
    if (textareavalue === undefined || textareavalue === null || textareavalue === "") {
        $('#text_error-' + tableid).html("Comment Field can not be left blank");
        return false;
    }
    $('#text_error-' + tableid).hide();
    $("html").addClass("overlay");
    $.ajax({
        url: ajaxurl,
        type: "POST",
        data: {
            action: 'vl_poll_comment_edit_delete',
            commentaction: tableid,
            myfield: fieldno,
            performaction: actionperform,
            updatevalue: textareavalue,
            pollNonce: pollNonce
        },
        success: function(data) {
            if (data == 1) {
                $('#comment_action-' + tableid).html("Comment has been Edited successfully");
                setTimeout(function() { window.location.reload(); }, 1000);
            }
        },
        complete: function() {
            $("html").removeClass("overlay");
        },
        error: function(error) {
            $('#comment_action-' + tableid).html(error);
        }
    });
}
(function($) {
    $(document).ready(function() {
        var table = jQuery('#poll_comment_list').DataTable({
            dom: 'lrtip',
            "lengthChange": false,
            initComplete: function() {}
        });
        $('.edit_vote_btn').on('click', function() {
            $(".styled").removeAttr("disabled");
            $(".comment_class").removeAttr("disabled");
            $(".already_btn").hide();
            $(".save_form_btn").show();
        });

        $('.save_form_btn').on('click', function() {
            var arrNumber = new Array();
            $(".poll_get_f_id").each(function() {
                arrNumber.push($(this).val());
                var asset_type = arrNumber.join(',');
                $(".all_poll_id").val(asset_type);
            });
            var data = new FormData(document.getElementById("edit_response"));
            data.append('action', 'vl_poll_vote_edit');
            $("html").addClass("overlay");
            $.ajax({
                type: "POST",
                url: ajaxurl,
                data: data,
                contentType: false,
                cache: false,
                dataType: 'json',
                processData: false,
                success: function(data) {
                    if (data['login_error'] == 1) {
                        parent.location = data['redirect'];
                    }
                    if (data['success'] == 1) {
                        $("html").removeClass("overlay");
                        $('.action_status').html(data['insertmessage']);
                        //setTimeout(function() { parent.location = data['redirect']; }, 3000);
                    }
                    if (data['success'] == 0) {
                        $("html").removeClass("overlay");
                        $('.action_status').html(data['insertmessage']);
                    }
                },
                error: function(MLHttpRequest, textStatus, errorThrown) {
                    $('.action_status').html(data['insertmessage']);
                }
            });
        });

        jQuery('.filter_class').on('change', function() {
            var whatsSelected = [];
            search_in = 1;
            var str1 = jQuery.trim(jQuery(this).val());
            var txt = str1.replace(/\,/g, "");
            fitler_value = txt;
            if (fitler_value != '') {
                whatsSelected.push(fitler_value);
            }
            console.log(whatsSelected);
            table.columns(search_in).search(whatsSelected.join('|'), true).draw();
        });

        jQuery('.comment_search').focusout(function() {
            var whatsSelected = [];
            var str1 = jQuery.trim(jQuery(this).val());
            var txt = str1.replace(/\,/g, "");
            search_in = 0;
            jQuery(this).val("");
            fitler_value = txt;
            if (fitler_value != '') {
                whatsSelected.push(fitler_value);
            }
            console.log(whatsSelected);
            table.columns(search_in).search(whatsSelected.join('|'), true).draw();
        });

        $('.add_button_class').on('click', function() {
            var parentid = $(this).closest(".comments_filter").prop("id");
            $('#' + parentid + ' .main_form_open').show();

        });
    });
})(jQuery);